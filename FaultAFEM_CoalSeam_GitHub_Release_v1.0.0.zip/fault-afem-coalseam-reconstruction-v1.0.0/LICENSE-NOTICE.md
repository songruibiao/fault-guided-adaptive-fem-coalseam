# License notice

No open-source software license was specified in the materials supplied for this repository cleanup. This release therefore does **not** assign a license on the authors' behalf.

Before publishing on GitHub, the copyright holders should choose an explicit license (for example, MIT, BSD-3-Clause, GPL, or another license appropriate to the project and data-sharing obligations). Until an explicit license is added, reuse is governed by applicable copyright law.
