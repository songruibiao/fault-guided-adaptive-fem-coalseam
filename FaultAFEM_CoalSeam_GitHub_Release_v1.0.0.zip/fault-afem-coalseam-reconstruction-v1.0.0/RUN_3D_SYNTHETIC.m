function outDir = RUN_3D_SYNTHETIC()
% RUN_3D_SYNTHETIC  Run the self-contained 3-D fault-fitted graded-mesh benchmark.
root = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(root,'code')));
old = pwd;
cleanup = onCleanup(@() cd(old));
cd(root);
outDir = FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2;
end
