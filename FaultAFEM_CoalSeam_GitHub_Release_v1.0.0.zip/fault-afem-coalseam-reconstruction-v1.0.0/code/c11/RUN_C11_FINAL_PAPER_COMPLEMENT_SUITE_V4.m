function outDir = RUN_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4(coreRunDir,dataDir)
% RUN_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4
% =========================================================================
% Supplementary experiments for the manuscript
%   "Adaptive finite element reconstruction of coal-seam surfaces
%    constrained by fault geometry"
%
% This SINGLE MATLAB file runs the three most useful additional experiments:
%
%   E1. Strict equal-budget 2-D factorial ablation (N = 200 by default)
%       U-ISO : isotropic regularization + exact-budget quasi-uniform mesh
%       U-FLT : fault regularization     + exact-budget quasi-uniform mesh
%       A-ISO : isotropic regularization + exact-budget adaptive mesh
%       A-FLT : fault regularization     + exact-budget adaptive mesh
%
%       The same uniform mesh is shared by U-ISO/U-FLT, and the same
%       adaptive mesh is shared by A-ISO/A-FLT. Therefore the two factors
%       "fault-direction regularization" and "adaptive discretization" are
%       separated under an identical node budget.
%
%   E2. Fault-geometry perturbation robustness
%       Normal offset : 0, +/-10, +/-20, +/-40 m
%       Orientation   : 0, +/-5, +/-10, +/-15 deg
%       Sparse controls and c0 remain fixed.  The reconstruction uses the
%       perturbed interpreted fault, while retrospective evaluation uses the
%       original interpreted fault/reference.  This isolates sensitivity to
%       fault-interpretation error.
%
%   E3. One-at-a-time parameter sensitivity at N = 200
%       epsilon_min : [0.01 0.03 0.06 0.10]
%       sigma_Gamma : [0.70 1.00 1.30 1.60] x baseline effective sigma
%       omega_g     : [0.15 0.25 0.35 0.45 0.55]
%
% IMPORTANT
% ---------
% This supplement intentionally reuses the SAME sparse controls and the SAME
% c0 values selected by the main C11 run.  It does not retune c0 using dense
% C11 reference data.
%
% REQUIRED MAIN-RUN STATE
% -----------------------
% The code first looks for CORE_RESULT_STATE.mat from the main function
%   REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN.m
% If no state is found and that main function is on the MATLAB path, the main
% run is executed automatically once.
%
% REQUIRED C11 DATA
% -----------------
%   TVD_C11.dat
%   Dingji_t11_plg.dat
%
% EXAMPLES
% --------
%   % 1) Automatic discovery
%   outDir = RUN_C11_SUPPLEMENTARY_EXPERIMENTS_V1;
%
%   % 2) Explicit main-run folder and C11 data folder
%   outDir = RUN_C11_SUPPLEMENTARY_EXPERIMENTS_V1( ...
%       'G:\paper\out_REAL_C11_..._20260818_103000', ...
%       'G:\paper\data_C11');
%
% MAIN OUTPUTS
% ------------
%   E1_EQUAL_BUDGET_FACTORIAL.csv
%   E1_EQUAL_BUDGET_EFFECTS.csv
%   E2_FAULT_OFFSET_ROBUSTNESS_raw.csv
%   E2_FAULT_OFFSET_ROBUSTNESS_summary.csv
%   E2_FAULT_ANGLE_ROBUSTNESS_raw.csv
%   E2_FAULT_ANGLE_ROBUSTNESS_summary.csv
%   E3_PARAMETER_SENSITIVITY.csv
%   SUPPLEMENTARY_EXPERIMENT_STATE.mat
%   FIG_E1_equal_budget_metrics.png
%   FIG_E2_fault_geometry_robustness.png
%   FIG_E3_parameter_sensitivity_*.png
%
% Notes on "strict equal budget"
% ------------------------------
% The main paper's structured uniform mesh may contain fewer than exactly
% 200 vertices because a tensor-product grid cannot realize every integer
% node count.  E1 therefore uses an EXACT-N quasi-uniform Delaunay mesh for
% the uniform branch.  The adaptive branch uses the paper's compatible edge
% bisection; if conformity makes it stop below N, a final conforming
% triangle-centroid top-up is applied one node at a time.  The number of
% top-up nodes is reported in the CSV and should normally be zero or very
% small.  This experiment is therefore a strict NODE-BUDGET ablation, not a
% claim that both meshes have identical topology.
% =========================================================================

clc;
close all;

if nargin < 1, coreRunDir = ''; end
if nargin < 2, dataDir = ''; end

Sx = supplement_config();
scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir), scriptDir = pwd; end

% -------------------------------------------------------------------------
% Resolve or create the main-run state.
% -------------------------------------------------------------------------
[coreRunDir,stateFile] = resolve_core_state(coreRunDir,dataDir,scriptDir,Sx);
L = load(stateFile,'state');
state = L.state;

if ~isfield(state,'cfg') || ~isfield(state,'geometry') || ...
        ~isfield(state,'sparseControls')
    error('CORE_RESULT_STATE.mat does not contain the expected main-run fields.');
end

cfg = state.cfg;
G0  = state.geometry;
obs = obs_from_state_table(state.sparseControls);

if isfield(state,'cvIso') && isfield(state.cvIso,'value')
    c0Iso = state.cvIso.value;
else
    error('Main state does not contain state.cvIso.value.');
end
if isfield(state,'cvFault') && isfield(state.cvFault,'value')
    c0Fault = state.cvFault.value;
else
    error('Main state does not contain state.cvFault.value.');
end

dataDir = resolve_data_dir(dataDir,state,coreRunDir,scriptDir,cfg);
validate_required_data(dataDir,cfg);

% -------------------------------------------------------------------------
% Reconstruct the SAME retrospective reference window as the main paper.
% -------------------------------------------------------------------------
Hraw = read_c11_horizon_local(fullfile(dataDir,cfg.horizonFile));
UVall = global_to_local_local(Hraw.xy,G0);
phiAll = fault_phi_local(UVall,G0);

uLo = G0.uMin - cfg.mainMarginAlong;
uHi = G0.uMax + cfg.mainMarginAlong;
vLo = min(G0.vc) - cfg.mainMarginCross;
vHi = max(G0.vc) + cfg.mainMarginCross;

inside = UVall(:,1)>=uLo & UVall(:,1)<=uHi & ...
         UVall(:,2)>=vLo & UVall(:,2)<=vHi;

UVref = UVall(inside,:);
Zref  = Hraw.z(inside);
phiRef = phiAll(inside);
gateRef = fault_gate_local(UVref(:,1),G0,cfg);

faultMask = abs(phiRef)<=cfg.evalFaultBand & gateRef>=cfg.evalGateMin;
bgMask    = abs(phiRef)>=cfg.evalBackgroundDistance | gateRef<cfg.evalGateMin;
negMask   = phiRef<0;
posMask   = ~negMask;
Rref      = build_side_reference_interpolants_local(UVref,Zref,G0,cfg);

uRange = [uLo,uHi];
vRange = [vLo,vHi];

% Effective baseline fault-tensor bandwidth used by the main code.
sigma0 = max(cfg.faultSigmaMin,1.15*G0.halfWidth95);

if c0Fault<=1e-3 || sigma0<30
    error('FinalPaperSuite:NonPaperCoreState', ...
        ['The selected CORE_RESULT_STATE.mat is a parameter-reduced/non-paper state ' ...
         '(c0Fault=%.6g, sigma0=%.3f m).\nUse the CORE_RESULT_STATE.mat from ' ...
         'REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V3_FIX1, or a final ' ...
         'paper-equivalent run with c0Fault>1e-3 and sigma0 about 55 m.'], ...
         c0Fault,sigma0);
end

stamp = datestr(now,'yyyymmdd_HHMMSS');
outDir = fullfile(scriptDir,['out_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4_' stamp]);
if ~exist(outDir,'dir'), mkdir(outDir); end

diary(fullfile(outDir,'RUN_LOG.txt'));
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('\n============================================================\n');
fprintf('RUN_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4\n');
fprintf('Core state : %s\n',stateFile);
fprintf('C11 data   : %s\n',dataDir);
fprintf('Output     : %s\n',outDir);
fprintf('Controls   : %d\n',numel(obs.z));
fprintf('c0 ISO     : %.8g\n',c0Iso);
fprintf('c0 FAULT   : %.8g\n',c0Fault);
fprintf('sigma0     : %.3f m\n',sigma0);
fprintf('============================================================\n\n');

rng(Sx.seed,'twister');

% By default this file runs only the new, self-contained external-baseline
% experiment.  The supplied legacy E1--E3 code is retained for users who
% intentionally run it against the matching paper-state audit, but it is
% not safe to combine it with a parameter-reduced state.
cfgBase=cfg; cfgBase.expFaultSigmaOverride=sigma0;
TE1=table(); TE1eff=table(); TOffRaw=table(); TOff=table(); TAngRaw=table(); TAng=table(); TSens=table();
histA=[]; meshU=[]; meshA=[];
if Sx.runLegacyMeshExperiments

% =========================================================================
% E1. STRICT EQUAL-BUDGET 2-D FACTORIAL ABLATION
% =========================================================================
fprintf('[E1] Strict equal-budget 2-D factorial ablation ...\n');
Nbudget = Sx.equalBudgetNodes;

% Build the adaptive initial mesh first.  The paper's structured mesh
% expands the requested rectangle to floor/ceil grid lines; use the SAME
% actual rectangular domain for the exact-N quasi-uniform baseline.
cfgBase = cfg;
cfgBase.expFaultSigmaOverride = sigma0;
mesh0 = uniform_mesh_under_budget_local(uRange,vRange,cfg.afemInitialNodeBudget);
meshDomainU = [min(mesh0.P(:,1)),max(mesh0.P(:,1))];
meshDomainV = [min(mesh0.P(:,2)),max(mesh0.P(:,2))];

% Exact-N quasi-uniform mesh on exactly the same rectangular domain.
meshU = exact_quasiuniform_rect_mesh(meshDomainU,meshDomainV,Nbudget,Sx);
if size(meshU.P,1) ~= Nbudget
    error('Exact quasi-uniform mesh failed to realize N=%d.',Nbudget);
end

% Exact-N adaptive mesh using the paper algorithm plus rare centroid top-up.
[~,meshA,histA] = adapt_fault_mesh_to_budget_local( ...
    mesh0,Nbudget,obs,G0,c0Fault,cfgBase);
nBeforeTopup = size(meshA.P,1);
[meshA,nTopUp] = topup_adaptive_mesh_to_exact_budget( ...
    meshA,Nbudget,obs,G0,c0Fault,cfgBase);
if size(meshA.P,1) ~= Nbudget
    error('Adaptive exact-budget mesh failed: requested=%d actual=%d.', ...
        Nbudget,size(meshA.P,1));
end

fprintf('  uniform nodes          : %d\n',size(meshU.P,1));
fprintf('  adaptive edge-bisect   : %d\n',nBeforeTopup);
fprintf('  adaptive centroid topup: %d\n',nTopUp);
fprintf('  adaptive final nodes   : %d\n',size(meshA.P,1));

HU = build_interp_matrix_local(meshU,obs.uv);
HA = build_interp_matrix_local(meshA,obs.uv);

KUiso = assemble_iso_stiffness_local(meshU);
KUflt = assemble_fault_stiffness_local(meshU,G0,cfgBase);
KAiso = assemble_iso_stiffness_local(meshA);
KAflt = assemble_fault_stiffness_local(meshA,G0,cfgBase);

solUiso = fit_fem_solution_local(meshU,KUiso,HU,obs,c0Iso,'U-ISO');
solUflt = fit_fem_solution_local(meshU,KUflt,HU,obs,c0Fault,'U-FLT');
solAiso = fit_fem_solution_local(meshA,KAiso,HA,obs,c0Iso,'A-ISO');
solAflt = fit_fem_solution_local(meshA,KAflt,HA,obs,c0Fault,'A-FLT');

solsE1 = {solUiso,solUflt,solAiso,solAflt};
labelsE1 = {'U-ISO';'U-FLT';'A-ISO';'A-FLT'};
ME1 = cell(4,1);
for i=1:4
    pred = predict_solution_local(solsE1{i},UVref);
    [ME1{i},~] = evaluate_dense_v2_local( ...
        pred,Zref,faultMask,bgMask,negMask,posMask, ...
        obs,solsE1{i},Rref,G0,cfgBase);
end

TE1 = metrics_table_from_cells(labelsE1,ME1,repmat(Nbudget,4,1));
TE1.MeshClass = {'Exact quasi-uniform';'Exact quasi-uniform'; ...
                  'Adaptive';'Adaptive'};
TE1.C0 = [c0Iso;c0Fault;c0Iso;c0Fault];
TE1.AdaptiveTopUpNodes = [0;0;nTopUp;nTopUp];
writetable(TE1,fullfile(outDir,'E1_EQUAL_BUDGET_FACTORIAL.csv'));

TE1eff = equal_budget_effect_table(TE1);
writetable(TE1eff,fullfile(outDir,'E1_EQUAL_BUDGET_EFFECTS.csv'));

plot_equal_budget_metrics(outDir,TE1,Sx);
plot_equal_budget_meshes(outDir,meshU,meshA,G0,obs,Sx);

disp(' ');
disp('E1_EQUAL_BUDGET_FACTORIAL');
disp(TE1);
disp('E1_EQUAL_BUDGET_EFFECTS');
disp(TE1eff);

% =========================================================================
% E2. FAULT-GEOMETRY PERTURBATION ROBUSTNESS
% =========================================================================
fprintf('\n[E2] Fault-geometry perturbation robustness ...\n');

% --- E2A: normal offsets --------------------------------------------------
rows = {};
r = 0;
for im=1:numel(Sx.offsetMagnitudesM)
    mag = Sx.offsetMagnitudesM(im);
    signs = perturb_signs(mag);
    for is=1:numel(signs)
        sgn = signs(is);
        off = sgn*mag;
        Gp = perturb_fault_geometry_local(G0,off,0,cfgBase);

        [solP,meshP,topupP] = run_fault_adaptive_exact_budget( ...
            Nbudget,uRange,vRange,obs,Gp,c0Fault,cfgBase);

        pred = predict_solution_local(solP,UVref);
        [MP,~] = evaluate_dense_v2_local( ...
            pred,Zref,faultMask,bgMask,negMask,posMask, ...
            obs,solP,Rref,G0,cfgBase);  % evaluate against ORIGINAL geometry

        r=r+1;
        rows(r,:) = {mag,sgn,off,size(meshP.P,1),topupP, ...
            MP.RMSE_all,MP.RMSE_fault,MP.RMSE_bg,MP.Jump0MAE,MP.dataRMSE}; %#ok<AGROW>
        fprintf('  offset %+6.1f m | fault RMSE %.4f | jump MAE %.4f\n', ...
            off,MP.RMSE_fault,MP.Jump0MAE);
    end
end

TOffRaw = cell2table(rows,'VariableNames', ...
    {'Magnitude_m','Sign','SignedOffset_m','Nodes','TopUpNodes', ...
     'RMSE_Global_m','RMSE_Fault_m','RMSE_Background_m','JumpMAE_m','ControlRMSE_m'});
writetable(TOffRaw,fullfile(outDir,'E2_FAULT_OFFSET_ROBUSTNESS_raw.csv'));
TOff = aggregate_perturbation_table(TOffRaw,'Magnitude_m');
writetable(TOff,fullfile(outDir,'E2_FAULT_OFFSET_ROBUSTNESS_summary.csv'));

% --- E2B: orientation perturbations --------------------------------------
rows = {};
r = 0;
for im=1:numel(Sx.angleMagnitudesDeg)
    mag = Sx.angleMagnitudesDeg(im);
    signs = perturb_signs(mag);
    for is=1:numel(signs)
        sgn = signs(is);
        ang = sgn*mag;
        Gp = perturb_fault_geometry_local(G0,0,ang,cfgBase);

        [solP,meshP,topupP] = run_fault_adaptive_exact_budget( ...
            Nbudget,uRange,vRange,obs,Gp,c0Fault,cfgBase);

        pred = predict_solution_local(solP,UVref);
        [MP,~] = evaluate_dense_v2_local( ...
            pred,Zref,faultMask,bgMask,negMask,posMask, ...
            obs,solP,Rref,G0,cfgBase);

        r=r+1;
        rows(r,:) = {mag,sgn,ang,size(meshP.P,1),topupP, ...
            MP.RMSE_all,MP.RMSE_fault,MP.RMSE_bg,MP.Jump0MAE,MP.dataRMSE}; %#ok<AGROW>
        fprintf('  angle  %+6.1f deg | fault RMSE %.4f | jump MAE %.4f\n', ...
            ang,MP.RMSE_fault,MP.Jump0MAE);
    end
end

TAngRaw = cell2table(rows,'VariableNames', ...
    {'Magnitude_deg','Sign','SignedAngle_deg','Nodes','TopUpNodes', ...
     'RMSE_Global_m','RMSE_Fault_m','RMSE_Background_m','JumpMAE_m','ControlRMSE_m'});
writetable(TAngRaw,fullfile(outDir,'E2_FAULT_ANGLE_ROBUSTNESS_raw.csv'));
TAng = aggregate_perturbation_table(TAngRaw,'Magnitude_deg');
writetable(TAng,fullfile(outDir,'E2_FAULT_ANGLE_ROBUSTNESS_summary.csv'));

plot_fault_geometry_robustness(outDir,TOff,TAng,Sx);

% =========================================================================
% E3. PARAMETER SENSITIVITY
% =========================================================================
fprintf('\n[E3] One-at-a-time parameter sensitivity ...\n');

rows = {};
r = 0;

% epsilon_min -------------------------------------------------------------
for val = Sx.epsMinValues
    cfgP = cfgBase;
    cfgP.faultEpsMin = val;
    cfgP.expFaultSigmaOverride = sigma0;
    [solP,meshP,topupP] = run_fault_adaptive_exact_budget( ...
        Nbudget,uRange,vRange,obs,G0,c0Fault,cfgP);
    pred = predict_solution_local(solP,UVref);
    [MP,~] = evaluate_dense_v2_local(pred,Zref,faultMask,bgMask,negMask,posMask, ...
        obs,solP,Rref,G0,cfgP);
    r=r+1;
    rows(r,:) = {'epsilon_min',val,val,size(meshP.P,1),topupP, ...
        MP.RMSE_all,MP.RMSE_fault,MP.RMSE_bg,MP.Jump0MAE,MP.dataRMSE}; %#ok<AGROW>
    fprintf('  epsilon_min=%g | fault RMSE %.4f | jump MAE %.4f\n', ...
        val,MP.RMSE_fault,MP.Jump0MAE);
end

% sigma_Gamma -------------------------------------------------------------
for fac = Sx.sigmaFactors
    cfgP = cfgBase;
    cfgP.expFaultSigmaOverride = sigma0*fac;
    [solP,meshP,topupP] = run_fault_adaptive_exact_budget( ...
        Nbudget,uRange,vRange,obs,G0,c0Fault,cfgP);
    pred = predict_solution_local(solP,UVref);
    [MP,~] = evaluate_dense_v2_local(pred,Zref,faultMask,bgMask,negMask,posMask, ...
        obs,solP,Rref,G0,cfgP);
    r=r+1;
    rows(r,:) = {'sigma_Gamma_factor',fac,sigma0*fac,size(meshP.P,1),topupP, ...
        MP.RMSE_all,MP.RMSE_fault,MP.RMSE_bg,MP.Jump0MAE,MP.dataRMSE}; %#ok<AGROW>
    fprintf('  sigma factor=%.2f (%.2f m) | fault RMSE %.4f | jump MAE %.4f\n', ...
        fac,sigma0*fac,MP.RMSE_fault,MP.Jump0MAE);
end

% omega_g -----------------------------------------------------------------
for val = Sx.omegaGValues
    cfgP = cfgBase;
    cfgP.afemGeoWeight = val;
    cfgP.afemResidualWeight = 1-val;
    cfgP.expFaultSigmaOverride = sigma0;
    [solP,meshP,topupP] = run_fault_adaptive_exact_budget( ...
        Nbudget,uRange,vRange,obs,G0,c0Fault,cfgP);
    pred = predict_solution_local(solP,UVref);
    [MP,~] = evaluate_dense_v2_local(pred,Zref,faultMask,bgMask,negMask,posMask, ...
        obs,solP,Rref,G0,cfgP);
    r=r+1;
    rows(r,:) = {'omega_g',val,val,size(meshP.P,1),topupP, ...
        MP.RMSE_all,MP.RMSE_fault,MP.RMSE_bg,MP.Jump0MAE,MP.dataRMSE}; %#ok<AGROW>
    fprintf('  omega_g=%.2f | fault RMSE %.4f | jump MAE %.4f\n', ...
        val,MP.RMSE_fault,MP.Jump0MAE);
end

TSens = cell2table(rows,'VariableNames', ...
    {'Parameter','DisplayValue','PhysicalValue','Nodes','TopUpNodes', ...
     'RMSE_Global_m','RMSE_Fault_m','RMSE_Background_m','JumpMAE_m','ControlRMSE_m'});
writetable(TSens,fullfile(outDir,'E3_PARAMETER_SENSITIVITY.csv'));
plot_parameter_sensitivity(outDir,TSens,Sx);

end % Sx.runLegacyMeshExperiments

% =========================================================================
% E4. EXTERNAL INTERPOLATION AND GEOSTATISTICAL BASELINES
% =========================================================================
% All models use exactly the same 80 sparse controls.  Their scale/nugget
% parameters are selected from buffered spatial CV using controls only.
% Zref is never passed to a fitting or tuning routine.
fprintf('\n[E4] TPS / RBF / kriging / Bayesian geostatistical baselines ...\n');
B4 = run_external_baselines_local(obs,UVref,Zref,faultMask,bgMask, ...
    negMask,posMask,Rref,G0,cfgBase,Sx,outDir);
TE4 = B4.metrics;
writetable(TE4,fullfile(outDir,'E4_EXTERNAL_BASELINES.csv'));
writetable(B4.cvAudit,fullfile(outDir,'E4_EXTERNAL_BASELINES_SPATIAL_CV.csv'));
writetable(B4.uncertaintySummary,fullfile(outDir,'E4_BAYESIAN_GP_UNCERTAINTY.csv'));
plot_external_baseline_comparison_local(outDir,B4,UVref,Zref,faultMask,G0,Sx);
plot_bayesian_uncertainty_local(outDir,B4,UVref,G0,Sx);

% =========================================================================
% E5. REPEATED SPATIALLY BALANCED SPARSE-CONTROL SAMPLING
% =========================================================================
fprintf('\n[E5] Repeated spatially balanced sparse-control sampling ...\n');
TE5 = run_repeated_control_sampling_local(UVref,Zref,phiRef,faultMask,bgMask, ...
    negMask,posMask,Rref,G0,c0Fault,cfgBase,uRange,vRange,Sx,outDir);
writetable(TE5,fullfile(outDir,'E5_REPEATED_SPARSE_CONTROL_SAMPLING.csv'));
TE5summary = summarize_repeated_control_sampling_local(TE5);
writetable(TE5summary,fullfile(outDir,'E5_REPEATED_SPARSE_CONTROL_SAMPLING_SUMMARY.csv'));
plot_repeated_control_sampling_local(outDir,TE5,Sx);

% =========================================================================
% SAVE STATE + PAPER-FACING SUMMARY
% =========================================================================
Sup = struct();
Sup.config = Sx;
Sup.coreRunDir = coreRunDir;
Sup.dataDir = dataDir;
Sup.coreStateFile = stateFile;
Sup.c0Iso = c0Iso;
Sup.c0Fault = c0Fault;
Sup.sigma0 = sigma0;
Sup.equalBudget = TE1;
Sup.equalBudgetEffects = TE1eff;
Sup.offsetRaw = TOffRaw;
Sup.offsetSummary = TOff;
Sup.angleRaw = TAngRaw;
Sup.angleSummary = TAng;
Sup.parameterSensitivity = TSens;
Sup.externalBaselines = B4;
Sup.repeatedControlSampling = TE5;
Sup.repeatedControlSamplingSummary = TE5summary;
Sup.adaptiveHistoryE1 = histA;
Sup.uniformMeshE1 = meshU;
Sup.adaptiveMeshE1 = meshA;
save(fullfile(outDir,'SUPPLEMENTARY_EXPERIMENT_STATE.mat'),'Sup','-v7.3');

if Sx.runLegacyMeshExperiments
    write_paper_ready_summary(outDir,TE1,TE1eff,TOff,TAng,TSens,Sx,sigma0);
end

fprintf('\n============================================================\n');
fprintf('SUPPLEMENTARY EXPERIMENTS FINISHED\n');
fprintf('Output: %s\n',outDir);
fprintf('============================================================\n');

end

% =========================================================================
% CONFIGURATION
% =========================================================================
function S = supplement_config()
S = struct();
S.seed = 20260818;
S.equalBudgetNodes = 200;
% The final-paper suite runs E1--E4 by default.  These results are valid
% only after the hard paper-state guard above has passed.
S.runLegacyMeshExperiments = true;

% E2 perturbations; positive and negative signs are both run for nonzero mag.
S.offsetMagnitudesM = [0 10 20 40];
S.angleMagnitudesDeg = [0 5 10 15];

% E3 one-at-a-time sensitivity.
S.epsMinValues = [0.01 0.03 0.06 0.10];
S.sigmaFactors = [0.70 1.00 1.30 1.60];
S.omegaGValues = [0.15 0.25 0.35 0.45 0.55];

% E5 repeated sparse-control sampling.  It audits whether the fault-aware
% adaptive gain persists when the 80 controls are redrawn from the same
% high-density interpreted reference surface.  c0 is intentionally fixed
% at the paper-state CV value: this is a stability audit, not a second
% hyperparameter-optimisation study.
S.nReplicates = 10;
S.replicateControls = 80;
S.replicateNegativeSideControls = 39;
S.replicatePositiveSideControls = 41;
S.replicateBudgetNodes = 200;

% Exact quasi-uniform mesh candidate density.
S.uniformCandidateNu = 50;
S.uniformCandidateNv = 45;
S.uniformBoundaryFraction = 0.18;

% Figures.
S.figureDPI = 180;
end

% =========================================================================
% STATE / DATA RESOLUTION
% =========================================================================
function [coreRunDir,stateFile] = resolve_core_state(coreRunDir,dataDir,scriptDir,Sx) %#ok<INUSD>
if ~isempty(coreRunDir)
    stateFile = fullfile(coreRunDir,'CORE_RESULT_STATE.mat');
    if exist(stateFile,'file')
        return;
    end
    if exist(coreRunDir,'file') && endsWith(lower(coreRunDir),'.mat')
        stateFile = coreRunDir;
        coreRunDir = fileparts(coreRunDir);
        return;
    end

    % A manuscript folder is often supplied rather than its timestamped
    % output subfolder.  Also tolerate the illustrative ``_时间戳`` suffix
    % used in run instructions: climb to the nearest existing parent, then
    % select the newest paper-equivalent state beneath it.
    root = coreRunDir;
    while ~isempty(root) && ~exist(root,'dir')
        parent = fileparts(root);
        if strcmp(parent,root), break; end
        root = parent;
    end
    if ~isempty(root) && exist(root,'dir')
        [stateFile,ok] = find_paper_equivalent_state_local(root);
        if ok
            coreRunDir=fileparts(stateFile);
            fprintf('Resolved final paper-state automatically: %s\n',stateFile);
            return;
        end
    end
    error(['Could not find a paper-equivalent CORE_RESULT_STATE.mat below:\n%s\n' ...
           'Pass either the exact output folder containing CORE_RESULT_STATE.mat, ' ...
           'or the parent folder FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN.'],coreRunDir);
end

% Search near this file first, then current directory.
roots = unique({scriptDir,pwd});
for ir=1:numel(roots)
    [stateFile,ok] = find_paper_equivalent_state_local(roots{ir});
    if ok
        coreRunDir = fileparts(stateFile);
        fprintf('Resolved final paper-state automatically: %s\n',stateFile);
        return;
    end
end

% If the main function is available, run it once.
coreFn = 'REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN';
if exist(coreFn,'file')==2
    fprintf('No CORE_RESULT_STATE.mat was found. Running the main C11 core once...\n');
    if isempty(dataDir)
        coreRunDir = feval(coreFn);
    else
        coreRunDir = feval(coreFn,dataDir);
    end
    stateFile = fullfile(coreRunDir,'CORE_RESULT_STATE.mat');
    if ~exist(stateFile,'file')
        error('The main C11 run finished without CORE_RESULT_STATE.mat.');
    end
    return;
end

function [stateFile,ok] = find_paper_equivalent_state_local(root)
stateFile=''; ok=false;
if ~exist(root,'dir'), return; end
C=[dir(fullfile(root,'CORE_RESULT_STATE.mat')); dir(fullfile(root,'**','CORE_RESULT_STATE.mat'))];
if isempty(C), return; end
keep=false(numel(C),1);
for k=1:numel(C)
    f=fullfile(C(k).folder,C(k).name);
    try
        A=load(f,'state'); s=A.state;
        c0=s.cvFault.value;
        sig=max(s.cfg.faultSigmaMin,1.15*s.geometry.halfWidth95);
        keep(k)=isfinite(c0) && isfinite(sig) && c0>1e-3 && sig>=30;
    catch
        keep(k)=false;
    end
end
C=C(keep);
if isempty(C), return; end
[~,k]=max([C.datenum]);
stateFile=fullfile(C(k).folder,C(k).name); ok=true;
end

error(['No CORE_RESULT_STATE.mat was found and the main C11 core function is not on the MATLAB path.\n', ...
       'Run REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN first,\n', ...
       'or pass its output directory as the first input.']);
end

function dataDir = resolve_data_dir(dataDir,state,coreRunDir,scriptDir,cfg)
if ~isempty(dataDir) && has_required_data(dataDir,cfg)
    return;
end

cand = {};
if isfield(state.cfg,'dataDir') && ischar(state.cfg.dataDir)
    cand{end+1} = state.cfg.dataDir; %#ok<AGROW>
end
cand{end+1} = fullfile(coreRunDir,'data_C11');
cand{end+1} = fullfile(fileparts(coreRunDir),'data_C11');
cand{end+1} = fullfile(scriptDir,'data_C11');
cand{end+1} = fullfile(fileparts(scriptDir),'data_C11');
cand{end+1} = fullfile(pwd,'data_C11');

for i=1:numel(cand)
    if has_required_data(cand{i},cfg)
        dataDir = cand{i};
        return;
    end
end

% Last-resort recursive search from scriptDir and pwd.
roots = unique({scriptDir,pwd});
for ir=1:numel(roots)
    D = dir(fullfile(roots{ir},'**',cfg.horizonFile));
    for k=1:numel(D)
        d = D(k).folder;
        if has_required_data(d,cfg)
            dataDir = d;
            return;
        end
    end
end

error('Could not locate C11 data files %s and %s.',cfg.horizonFile,cfg.polygonFile);
end

function tf = has_required_data(d,cfg)
tf = ~isempty(d) && exist(fullfile(d,cfg.horizonFile),'file') && ...
                  exist(fullfile(d,cfg.polygonFile),'file');
end

function validate_required_data(d,cfg)
if ~has_required_data(d,cfg)
    error('Required C11 files are missing in: %s',d);
end
end

function obs = obs_from_state_table(T)
vars = T.Properties.VariableNames;
need = {'u','v','Elevation'};
for i=1:numel(need)
    if ~ismember(need{i},vars)
        error('state.sparseControls is missing column "%s".',need{i});
    end
end
obs = struct();
obs.uv = [T.u,T.v];
obs.z = T.Elevation;
obs.w = ones(height(T),1);
obs.idx = (1:height(T)).';
end

% =========================================================================
% C11 DATA / GEOMETRY
% =========================================================================
function D = read_c11_horizon_local(fileName)
fid=fopen(fileName,'r');
if fid<0, error('Cannot open horizon file: %s',fileName); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fgetl(fid);
C=textscan(fid,'%f%f%f%f%f','MultipleDelimsAsOne',true, ...
    'Delimiter',' \t','CollectOutput',true);
A=C{1};
if size(A,2)~=5
    error('Unexpected TVD_C11 format. Expected five numeric columns.');
end
A=A(all(isfinite(A),2),:);
D=struct('inline',A(:,1),'cdp',A(:,2),'xy',A(:,3:4),'z',A(:,5));
end

function uv = global_to_local_local(xy,G)
X=xy-G.c;
uv=[X*G.t.', X*G.n.'];
end

function [phi,dist,tt,nn,proj,segIdx] = fault_project_exact_local(uv,G)
uv=double(uv);
nq=size(uv,1);
ns=size(G.segA,1);
bestD2=inf(nq,1);
phi=zeros(nq,1);
proj=zeros(nq,2);
segIdx=ones(nq,1);
tt=zeros(nq,2);
nn=zeros(nq,2);
for j=1:ns
    a=G.segA(j,:);
    v=G.segV(j,:);
    L2=max(sum(v.^2),eps);
    w=uv-a;
    tau=(w*v.')/L2;
    tau=max(0,min(1,tau));
    pj=a+tau.*v;
    d=uv-pj;
    d2=sum(d.^2,2);
    upd=d2<bestD2;
    if any(upd)
        bestD2(upd)=d2(upd);
        proj(upd,:)=pj(upd,:);
        segIdx(upd)=j;
        tt(upd,:)=repmat(G.segT(j,:),nnz(upd),1);
        nn(upd,:)=repmat(G.segN(j,:),nnz(upd),1);
        phi(upd)=d(upd,:)*G.segN(j,:).';
    end
end
dist=sqrt(max(bestD2,0));
end

function phi = fault_phi_local(uv,G)
[phi,~,~,~,~,~]=fault_project_exact_local(uv,G);
end

function g = fault_gate_local(u,G,cfg)
tau=max(cfg.faultTipTaper,eps);
g=0.5*(tanh((u-G.uMin)/tau)-tanh((u-G.uMax)/tau));
g=max(min(g,1),0);
end

function [vc,slope] = fault_center_and_slope_local(u,G)
vc=interp1(G.uc,G.vc,u,'linear','extrap');
slope=interp1(G.uc,G.dvdu,u,'linear','extrap');
end

function Gp = perturb_fault_geometry_local(G0,offsetM,angleDeg,cfg)
% Perturb the interpreted polygon in the ORIGINAL local coordinate system.
P=G0.polyUV;
c=[0.5*(min(P(:,1))+max(P(:,1))), median(P(:,2))];
Q=P-c;
a=angleDeg*pi/180;
R=[cos(a),-sin(a);sin(a),cos(a)];
Q=(R*Q.').';
Pp=Q+c;
Pp(:,2)=Pp(:,2)+offsetM;
Gp=build_fault_geometry_from_local_poly(Pp,G0,cfg);
end

function G = build_fault_geometry_from_local_poly(P,G0,cfg)
u=P(:,1); v=P(:,2);
uMin=min(u); uMax=max(u);
edges=linspace(uMin,uMax,cfg.centerlineBins+1);
uc=[];vc=[];hw=[];
for b=1:cfg.centerlineBins
    if b<cfg.centerlineBins
        m=u>=edges(b)&u<edges(b+1);
    else
        m=u>=edges(b)&u<=edges(b+1);
    end
    if nnz(m)>=2
        ub=median(u(m));
        vb=v(m);
        vlo=percentile_local(vb,10);
        vhi=percentile_local(vb,90);
        uc(end+1,1)=ub; %#ok<AGROW>
        vc(end+1,1)=0.5*(vlo+vhi); %#ok<AGROW>
        hw(end+1,1)=0.5*(vhi-vlo); %#ok<AGROW>
    end
end
if numel(uc)<6
    error('Perturbed fault produced too few centerline bins.');
end
[uc,ord]=sort(uc);vc=vc(ord);hw=hw(ord);
if cfg.centerlineSmooth>1
    vc=movmean(vc,cfg.centerlineSmooth,'Endpoints','shrink');
    hw=movmean(hw,cfg.centerlineSmooth,'Endpoints','shrink');
end
if uc(1)>uMin
    uc=[uMin;uc];
    vc=[interp1(uc(2:end),vc,uMin,'linear','extrap');vc];
    hw=[interp1(uc(2:end),hw,uMin,'linear','extrap');hw];
end
if uc(end)<uMax
    vc1=interp1(uc,vc,uMax,'linear','extrap');
    hw1=interp1(uc,hw,uMax,'linear','extrap');
    uc=[uc;uMax];vc=[vc;vc1];hw=[hw;hw1];
end
dvdu=gradient(vc,uc);
segA=[uc(1:end-1),vc(1:end-1)];
segB=[uc(2:end),vc(2:end)];
segV=segB-segA;
segL=sqrt(sum(segV.^2,2));
segL=max(segL,eps);
segT=segV./segL;
segN=[-segT(:,2),segT(:,1)];
G=G0;
G.uMin=uMin;G.uMax=uMax;G.uc=uc;G.vc=vc;G.dvdu=dvdu;
G.halfWidth=max(median(hw(isfinite(hw))),1);
G.halfWidth95=percentile_local(abs(v-interp1(uc,vc,u,'linear','extrap')),95);
G.polyUV=P;
G.segA=segA;G.segB=segB;G.segV=segV;G.segL=segL;G.segT=segT;G.segN=segN;
end

% =========================================================================
% REFERENCE INTERPOLATION / METRICS
% =========================================================================
function R = build_side_reference_interpolants_local(uv,z,G,cfg)
phi=fault_phi_local(uv,G);
guard=max(10,0.15*G.halfWidth);
neg=phi<=-guard;
pos=phi>= guard;
if nnz(neg)<100 || nnz(pos)<100
    error('Insufficient reference points on one side of fault.');
end
R.neg=scatteredInterpolant(uv(neg,1),uv(neg,2),z(neg),'natural','nearest');
R.pos=scatteredInterpolant(uv(pos,1),uv(pos,2),z(pos),'natural','nearest');
R.allNearest=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
R.guard=guard;R.cfg=cfg;
end

function z = reference_predict_local(R,uv,G)
phi=fault_phi_local(uv,G);
z=zeros(size(phi));
neg=phi<0;
z(neg)=R.neg(uv(neg,1),uv(neg,2));
z(~neg)=R.pos(uv(~neg,1),uv(~neg,2));
end

function [M,J] = evaluate_dense_v2_local(pred,zref,faultMask,bgMask,negMask,posMask,obs,S,R,G,cfg)
e=pred-zref;
M=struct();
M.RMSE_all=sqrt(mean(e.^2));
M.MAE_all=mean(abs(e));
M.RMSE_fault=sqrt(mean(e(faultMask).^2));
M.MAE_fault=mean(abs(e(faultMask)));
M.RMSE_bg=sqrt(mean(e(bgMask).^2));
M.RMSE_neg=sqrt(mean(e(negMask).^2));
M.RMSE_pos=sqrt(mean(e(posMask).^2));
M.dataRMSE=S.dataRMSE;
M.nUnknowns=S.nUnknowns;
J=interface_jump_extrapolation_local(S,R,G,cfg);
good=isfinite(J.ref)&isfinite(J.pred);
if any(good)
    de=J.pred(good)-J.ref(good);
    M.Jump0MAE=mean(abs(de));
    M.Jump0RMSE=sqrt(mean(de.^2));
    M.RefJumpMedianAbs=median(abs(J.ref(good)));
    M.PredJumpMedianAbs=median(abs(J.pred(good)));
    M.Jump0Correlation=corr_local(J.ref(good),J.pred(good));
else
    M.Jump0MAE=nan;M.Jump0RMSE=nan;M.RefJumpMedianAbs=nan;
    M.PredJumpMedianAbs=nan;M.Jump0Correlation=nan;
end
pobs=predict_solution_local(S,obs.uv);
M.trainRMSE=sqrt(mean((pobs-obs.z).^2));
end

function J = interface_jump_extrapolation_local(S,R,G,cfg)
span=G.uMax-G.uMin;
u1=G.uMin+cfg.jumpTipFraction*span;
u2=G.uMax-cfg.jumpTipFraction*span;
uList=linspace(u1,u2,cfg.jumpNSamples).';
d0=max(cfg.jumpFitMinOffset,G.halfWidth95+cfg.jumpFitPolygonClearance);
d=d0+cfg.jumpFitDistanceAdd(:).';
Jref=nan(numel(uList),1);Jpred=Jref;
for i=1:numel(uList)
    [vc,slope]=fault_center_and_slope_local(uList(i),G);
    c=[uList(i),vc];
    nn=[-slope,1];nn=nn/max(norm(nn),eps);
    qPlus=c+d(:)*nn;qMinus=c-d(:)*nn;
    zrP=reference_predict_local(R,qPlus,G);
    zrM=reference_predict_local(R,qMinus,G);
    zpP=predict_solution_local(S,qPlus);
    zpM=predict_solution_local(S,qMinus);
    Jref(i)=two_side_intercept_jump_local(d,zrP,zrM,cfg.jumpLocalDegree);
    Jpred(i)=two_side_intercept_jump_local(d,zpP,zpM,cfg.jumpLocalDegree);
end
J=struct('u',uList,'ref',Jref,'pred',Jpred,'distances',d);
end

function J = two_side_intercept_jump_local(d,zPlus,zMinus,degree)
d=d(:);zPlus=zPlus(:);zMinus=zMinus(:);
goodP=isfinite(d)&isfinite(zPlus);goodM=isfinite(d)&isfinite(zMinus);
if nnz(goodP)<degree+1 || nnz(goodM)<degree+1
    J=nan;return;
end
pP=polyfit(d(goodP),zPlus(goodP),degree);
pM=polyfit(d(goodM),zMinus(goodM),degree);
J=polyval(pP,0)-polyval(pM,0);
end

% =========================================================================
% EXACT-N QUASI-UNIFORM RECTANGULAR MESH
% =========================================================================
function M = exact_quasiuniform_rect_mesh(uRange,vRange,N,Sx)
if N<20, error('N must be at least 20.'); end
nu=Sx.uniformCandidateNu;nv=Sx.uniformCandidateNv;
u=linspace(uRange(1),uRange(2),nu);
v=linspace(vRange(1),vRange(2),nv);
[U,V]=meshgrid(u,v);
Cand=[U(:),V(:)];

% Force corners and a modest number of nearly uniform boundary points.
nB=max(8,min(N-4,round(Sx.uniformBoundaryFraction*N)));
per=max(2,round(nB/4));
bottom=[linspace(uRange(1),uRange(2),per).',repmat(vRange(1),per,1)];
top=[linspace(uRange(1),uRange(2),per).',repmat(vRange(2),per,1)];
left=[repmat(uRange(1),per,1),linspace(vRange(1),vRange(2),per).'];
right=[repmat(uRange(2),per,1),linspace(vRange(1),vRange(2),per).'];
P0=unique([bottom;top;left;right],'rows','stable');

% Snap forced points to the candidate set then farthest-sample the rest.
sel=false(size(Cand,1),1);
for i=1:size(P0,1)
    d2=sum((Cand-P0(i,:)).^2,2);
    [~,k]=min(d2);sel(k)=true;
end
idx=find(sel);
if numel(idx)>N
    idx=idx(1:N);
end

dmin=inf(size(Cand,1),1);
for k=idx(:).'
    dmin=min(dmin,sum((Cand-Cand(k,:)).^2,2));
end
while numel(idx)<N
    dmin(idx)=-inf;
    [~,k]=max(dmin);
    idx(end+1,1)=k; %#ok<AGROW>
    dmin=min(dmin,sum((Cand-Cand(k,:)).^2,2));
end
P=Cand(idx,:);
DT=delaunayTriangulation(P);
T=DT.ConnectivityList;
M=finalize_unstructured_mesh_local(P,T);
end

% =========================================================================
% PAPER-LIKE UNIFORM / ADAPTIVE MESH AND FEM
% =========================================================================
function M = make_rect_mesh_local(uRange,vRange,h)
uAxis=(floor(uRange(1)/h)*h):h:(ceil(uRange(2)/h)*h);
vAxis=(floor(vRange(1)/h)*h):h:(ceil(vRange(2)/h)*h);
[U,V]=meshgrid(uAxis,vAxis);P=[U(:),V(:)];
nU=numel(uAxis);nV=numel(vAxis);
T=zeros(2*(nU-1)*(nV-1),3);r=0;
for iu=1:nU-1
    for iv=1:nV-1
        n00=iv+(iu-1)*nV;n01=n00+1;n10=iv+iu*nV;n11=n10+1;
        r=r+1;T(r,:)=[n00,n10,n11];
        r=r+1;T(r,:)=[n00,n11,n01];
    end
end
M=struct('P',P,'T',T,'uAxis',uAxis,'vAxis',vAxis,'nU',nU,'nV',nV, ...
    'TR',triangulation(T,P));
end

function M = uniform_mesh_under_budget_local(uRange,vRange,nodeBudget)
Lu=diff(uRange);Lv=diff(vRange);A=max(Lu*Lv,1);h0=sqrt(A/max(nodeBudget,1));
factors=linspace(0.55,2.8,180);best=[];bestN=-inf;
for k=1:numel(factors)
    Mt=make_rect_mesh_local(uRange,vRange,h0*factors(k));
    n=size(Mt.P,1);
    if n<=nodeBudget && n>bestN,best=Mt;bestN=n;end
end
if isempty(best)
    h=h0*3.5;best=make_rect_mesh_local(uRange,vRange,h);
    while size(best.P,1)>nodeBudget
        h=1.12*h;best=make_rect_mesh_local(uRange,vRange,h);
    end
end
M=best;
end

function H = build_interp_matrix_local(M,q)
tri=pointLocation(M.TR,q);nq=size(q,1);
rows=[];cols=[];vals=[];good=isfinite(tri);
if any(good)
    bc=cartesianToBarycentric(M.TR,tri(good),q(good,:));
    Tg=M.T(tri(good),:);rg=find(good);
    rows=[rows;repelem(rg,3,1)];
    cols=[cols;reshape(Tg.',[],1)];
    vals=[vals;reshape(bc.',[],1)];
end
bad=find(~good);
for kk=1:numel(bad)
    i=bad(kk);d2=sum((M.P-q(i,:)).^2,2);[~,node]=min(d2);
    rows(end+1,1)=i;cols(end+1,1)=node;vals(end+1,1)=1; %#ok<AGROW>
end
H=sparse(rows,cols,vals,nq,size(M.P,1));
end

function K = assemble_iso_stiffness_local(M)
n=size(M.P,1);nt=size(M.T,1);
I=zeros(9*nt,1);J=I;V=I;q=0;
for e=1:nt
    nodes=M.T(e,:);xy=M.P(nodes,:);[B,A]=tri_gradients_local(xy);
    Ke=A*(B.'*B);
    for a=1:3
        for b=1:3
            q=q+1;I(q)=nodes(a);J(q)=nodes(b);V(q)=Ke(a,b);
        end
    end
end
K=sparse(I,J,V,n,n);K=0.5*(K+K.');
end

function sigma = effective_fault_sigma_local(G,cfg)
if isfield(cfg,'expFaultSigmaOverride') && isfinite(cfg.expFaultSigmaOverride) ...
        && cfg.expFaultSigmaOverride>0
    sigma=cfg.expFaultSigmaOverride;
else
    sigma=max(cfg.faultSigmaMin,1.15*G.halfWidth95);
end
end

function K = assemble_fault_stiffness_local(M,G,cfg)
n=size(M.P,1);nt=size(M.T,1);
I=zeros(9*nt,1);J=I;V=I;q=0;
sigma=effective_fault_sigma_local(G,cfg);
for e=1:nt
    nodes=M.T(e,:);xy=M.P(nodes,:);cen=mean(xy,1);[B,A]=tri_gradients_local(xy);
    [phi,~,tt,nn]=fault_project_exact_local(cen,G);
    gate=fault_gate_local(cen(1),G,cfg);
    strength=gate*exp(-0.5*(phi/sigma)^2);
    epsn=1-(1-cfg.faultEpsMin)*strength;
    D=tt.'*tt+epsn*(nn.'*nn);
    Ke=A*(B.'*D*B);
    for a=1:3
        for b=1:3
            q=q+1;I(q)=nodes(a);J(q)=nodes(b);V(q)=Ke(a,b);
        end
    end
end
K=sparse(I,J,V,n,n);K=0.5*(K+K.');
end

function [B,A] = tri_gradients_local(xy)
x1=xy(1,1);y1=xy(1,2);x2=xy(2,1);y2=xy(2,2);x3=xy(3,1);y3=xy(3,2);
detJ=(x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);
A=abs(detJ)/2;
if A<=eps,error('Degenerate triangle encountered.');end
B=[y2-y3,y3-y1,y1-y2; x3-x2,x1-x3,x2-x1]/detJ;
end

function S = fit_fem_solution_local(mesh,Ks,H,obs,c0,name)
A=c0*Ks+H.'*H;b=H.'*obs.z;A=0.5*(A+A.');
ridge=1e-12*max(mean(abs(diag(A))),1);A=A+ridge*speye(size(A,1));
U=A\b;
S=struct('type','fem','name',name,'mesh',mesh,'U',U,'c0',c0, ...
    'nUnknowns',numel(U),'dataRMSE',sqrt(mean((H*U-obs.z).^2)));
end

function z = predict_solution_local(S,uv)
if isfield(S,'predictFcn')
    z=S.predictFcn(uv);
else
    H=build_interp_matrix_local(S.mesh,uv);z=H*S.U;
end
end

function [S,mesh,history] = adapt_fault_mesh_to_budget_local(mesh,nodeBudget,obs,G,c0,cfg)
history=struct('iter',{},'nodes',{},'triangles',{},'etaResidual',{}, ...
    'etaGeoMean',{},'marked',{},'acceptedMarks',{},'splitEdges',{}, ...
    'budgetLimited',{},'areaRelError',{});
for it=1:cfg.afemMaxAdaptPerBudget
    H=build_interp_matrix_local(mesh,obs.uv);
    K=assemble_fault_stiffness_local(mesh,G,cfg);
    S=fit_fem_solution_local(mesh,K,H,obs,c0,'FAULT-AFEM');
    [eta2,parts]=afem_hybrid_indicator_local(mesh,S.U,obs,H,G,c0,cfg);
    mark=doerfler_mark_local_local(eta2,cfg.afemDoerflerTheta);
    geom=mesh_triangle_geometry_local(mesh);
    phi=fault_phi_local(geom.centroid,G);
    gate=fault_gate_local(geom.centroid(:,1),G,cfg);
    sigma=max(cfg.afemGeoSigmaMin,cfg.afemGeoSigmaFactor*G.halfWidth95);
    geo=gate.*exp(-0.5*(phi/sigma).^2);
    markGeo=geo>=cfg.afemGeoForceThreshold & geom.hT>cfg.afemGeoTargetH;
    mark=mark|markGeo;
    if cfg.afemBackgroundSafeEnable
        markBg=geo<=cfg.afemBackgroundGeoMax & geom.hT>cfg.afemBackgroundMaxH;
        mark=mark|markBg;
    end
    rec=struct('iter',it,'nodes',size(mesh.P,1),'triangles',size(mesh.T,1), ...
        'etaResidual',sqrt(sum(parts.residual2)),'etaGeoMean',mean(parts.geo), ...
        'marked',nnz(mark),'acceptedMarks',0,'splitEdges',0, ...
        'budgetLimited',false,'areaRelError',0);
    if size(mesh.P,1)>=nodeBudget || ~any(mark)
        history(end+1)=rec; %#ok<AGROW>
        break;
    end
    [meshNew,stat,budgetLimited,nAccepted]=refine_with_node_budget_local_local( ...
        mesh,mark,parts.priority,nodeBudget,cfg);
    rec.acceptedMarks=nAccepted;rec.splitEdges=stat.nSplitEdges;
    rec.budgetLimited=budgetLimited;rec.areaRelError=stat.areaRelError;
    history(end+1)=rec; %#ok<AGROW>
    if size(meshNew.P,1)==size(mesh.P,1),break;end
    mesh=meshNew;
end
H=build_interp_matrix_local(mesh,obs.uv);K=assemble_fault_stiffness_local(mesh,G,cfg);
S=fit_fem_solution_local(mesh,K,H,obs,c0,'FAULT-AFEM');
S.adaptHistory=history;
end

function [eta2,parts] = afem_hybrid_indicator_local(mesh,U,obs,H,G,c0,cfg)
geom=mesh_triangle_geometry_local(mesh);T=mesh.T;nt=size(T,1);Ue=U(T);gradU=zeros(nt,2);
for e=1:nt
    [B,~]=tri_gradients_local(mesh.P(T(e,:),:));
    gradU(e,:)=(B*Ue(e,:).').';
end
[k11,k12,k22]=fault_tensor_at_points_local(geom.centroid,G,cfg);
qx=c0*(k11.*gradU(:,1)+k12.*gradU(:,2));
qy=c0*(k12.*gradU(:,1)+k22.*gradU(:,2));
edge2=zeros(nt,1);
E=[T(:,[1 2]);T(:,[2 3]);T(:,[3 1])];triId=[(1:nt)';(1:nt)';(1:nt)'];
Es=sort(E,2);[Eu,~,ic]=unique(Es,'rows');[ics,ord]=sort(ic);s0=1;
while s0<=numel(ics)
    t0=s0;while t0<numel(ics)&&ics(t0+1)==ics(s0),t0=t0+1;end
    if t0-s0+1==2
        a=ord(s0);b=ord(t0);t1=triId(a);t2=triId(b);eid=ics(s0);
        v1=Eu(eid,1);v2=Eu(eid,2);ev=mesh.P(v2,:)-mesh.P(v1,:);he=norm(ev);
        if he>0
            nface=[-ev(2),ev(1)]/he;
            jump=(qx(t1)-qx(t2))*nface(1)+(qy(t1)-qy(t2))*nface(2);
            val=0.5*he^2*jump^2;edge2(t1)=edge2(t1)+val;edge2(t2)=edge2(t2)+val;
        end
    end
    s0=t0+1;
end
cell2=zeros(nt,1);
for e=1:nt
    nodes=T(e,:);xy=mesh.P(nodes,:);cen=geom.centroid(e,:);fluxInt=0;
    locEdges=[1 2;2 3;3 1];
    for je=1:3
        p1=xy(locEdges(je,1),:);p2=xy(locEdges(je,2),:);mid=0.5*(p1+p2);
        ev=p2-p1;he=norm(ev);if he<=eps,continue;end
        nout=[ev(2),-ev(1)]/he;if dot(nout,cen-mid)>0,nout=-nout;end
        [a11,a12,a22]=fault_tensor_at_points_local(mid,G,cfg);
        qmid=c0*[a11*gradU(e,1)+a12*gradU(e,2), ...
                 a12*gradU(e,1)+a22*gradU(e,2)];
        fluxInt=fluxInt+he*dot(qmid,nout);
    end
    rcell=-fluxInt/max(geom.area(e),eps);
    cell2(e)=geom.hT(e)^2*geom.area(e)*rcell^2;
end
r=H*U-obs.z;triObs=pointLocation(mesh.TR,obs.uv);bad=~isfinite(triObs);
if any(bad)
    C=geom.centroid;ib=find(bad);
    for k=1:numel(ib)
        d2=sum((C-obs.uv(ib(k),:)).^2,2);[~,triObs(ib(k))]=min(d2);
    end
end
dataByTri=accumarray(triObs,r.^2,[nt,1],@sum,0);data2=(geom.hT.^2).*dataByTri;
cellW=1;if isfield(cfg,'afemCellResidualWeight'),cellW=cfg.afemCellResidualWeight;end
residual2=edge2+cellW*cell2+data2;res=sqrt(max(residual2,0));
if max(res)>0,resNorm=res/max(res);else,resNorm=zeros(size(res));end
phi=fault_phi_local(geom.centroid,G);gate=fault_gate_local(geom.centroid(:,1),G,cfg);
sigma=max(cfg.afemGeoSigmaMin,cfg.afemGeoSigmaFactor*G.halfWidth95);
geo=gate.*exp(-0.5*(phi/sigma).^2);geo=max(min(geo,1),0);
hybrid=cfg.afemResidualWeight*resNorm+cfg.afemGeoWeight*geo;
eta2=geom.area.*hybrid.^2;
bgPressure=zeros(nt,1);
if cfg.afemBackgroundSafeEnable
    bgPressure=(geo<=cfg.afemBackgroundGeoMax).* ...
        max(geom.hT/max(cfg.afemBackgroundMaxH,eps)-1,0).*(1-geo);
end
priority=hybrid+0.15*geo.*min(geom.hT/max(cfg.afemGeoTargetH,eps),2)+ ...
    cfg.afemBackgroundPriority*min(bgPressure,2);
parts=struct('residual2',residual2,'edge2',edge2,'cell2',cell2,'data2',data2, ...
    'resNorm',resNorm,'geo',geo,'hybrid',hybrid,'bgPressure',bgPressure,'priority',priority);
end

function [k11,k12,k22] = fault_tensor_at_points_local(q,G,cfg)
[phi,~,tt,nn]=fault_project_exact_local(q,G);gate=fault_gate_local(q(:,1),G,cfg);
sigma=effective_fault_sigma_local(G,cfg);
strength=gate.*exp(-0.5*(phi/sigma).^2);
epsn=1-(1-cfg.faultEpsMin).*strength;
k11=tt(:,1).^2+epsn.*nn(:,1).^2;
k12=tt(:,1).*tt(:,2)+epsn.*nn(:,1).*nn(:,2);
k22=tt(:,2).^2+epsn.*nn(:,2).^2;
end

function Gm = mesh_triangle_geometry_local(mesh)
T=mesh.T;P=mesh.P;nt=size(T,1);centroid=(P(T(:,1),:)+P(T(:,2),:)+P(T(:,3),:))/3;
area=zeros(nt,1);hT=zeros(nt,1);
for e=1:nt
    xy=P(T(e,:),:);[~,A]=tri_gradients_local(xy);area(e)=A;
    hT(e)=max([norm(xy(1,:)-xy(2,:)),norm(xy(2,:)-xy(3,:)),norm(xy(3,:)-xy(1,:))]);
end
Gm=struct('centroid',centroid,'area',area,'hT',hT);
end

function mark = doerfler_mark_local_local(eta2,theta)
mark=false(size(eta2));tot=sum(eta2);if ~(tot>0),return;end
[es,idx]=sort(eta2,'descend');cs=cumsum(es);k=find(cs>=theta*tot,1,'first');
if isempty(k),k=numel(idx);end;mark(idx(1:k))=true;
end

function [meshNew,stat,budgetLimited,nAccepted] = refine_with_node_budget_local_local(mesh,mark,priority,nodeBudget,cfg)
[full,statFull]=refine_mesh_conforming_edge_bisection_local_local(mesh,mark,cfg);
if size(full.P,1)<=nodeBudget
    meshNew=full;stat=statFull;budgetLimited=false;nAccepted=nnz(mark);return;
end
budgetLimited=true;idx=find(mark);
if isempty(idx)
    meshNew=mesh;stat=zero_refine_stats_local_local();nAccepted=0;return;
end
[~,ord]=sort(priority(idx),'descend');idx=idx(ord);lo=1;hi=numel(idx);
bestK=0;bestMesh=mesh;bestStat=zero_refine_stats_local_local();
while lo<=hi
    mid=floor((lo+hi)/2);m=false(size(mark));m(idx(1:mid))=true;
    [trial,st]=refine_mesh_conforming_edge_bisection_local_local(mesh,m,cfg);
    if size(trial.P,1)<=nodeBudget
        bestK=mid;bestMesh=trial;bestStat=st;lo=mid+1;
    else
        hi=mid-1;
    end
end
meshNew=bestMesh;stat=bestStat;nAccepted=bestK;
end

function s = zero_refine_stats_local_local()
s=struct('nSplitEdges',0,'nAffectedTriangles',0,'areaRelError',0);
end

function [meshNew,stat] = refine_mesh_conforming_edge_bisection_local_local(mesh,mark,cfg)
P=mesh.P;T=mesh.T;nt=size(T,1);
Eall=[T(:,[1 2]);T(:,[2 3]);T(:,[3 1])];Es=sort(Eall,2);[Eu,~,ic]=unique(Es,'rows');
edgeId=[ic(1:nt),ic(nt+1:2*nt),ic(2*nt+1:3*nt)];splitEdge=false(size(Eu,1),1);
ids=find(mark);
for ii=1:numel(ids)
    t=ids(ii);v=T(t,:);pp=P(v,:);
    len=[norm(pp(1,:)-pp(2,:)),norm(pp(2,:)-pp(3,:)),norm(pp(3,:)-pp(1,:))];
    [L,j]=max(len);if L>2.01*cfg.afemHMin,splitEdge(edgeId(t,j))=true;end
end
splitIds=find(splitEdge);stat=struct('nSplitEdges',numel(splitIds),'nAffectedTriangles',0,'areaRelError',0);
if isempty(splitIds),meshNew=mesh;return;end
midIndex=zeros(size(Eu,1),1);midPts=0.5*(P(Eu(splitIds,1),:)+P(Eu(splitIds,2),:));
midIndex(splitIds)=size(P,1)+(1:numel(splitIds));Pnew=[P;midPts];
Tnew=zeros(4*nt,3);nnew=0;affected=0;
for t=1:nt
    v1=T(t,1);v2=T(t,2);v3=T(t,3);f=splitEdge(edgeId(t,:));
    m12=midIndex(edgeId(t,1));m23=midIndex(edgeId(t,2));m31=midIndex(edgeId(t,3));nf=nnz(f);
    if nf==0
        nnew=nnew+1;Tnew(nnew,:)=[v1 v2 v3];
    elseif nf==1
        affected=affected+1;
        if f(1),ch=[v1 m12 v3;m12 v2 v3];
        elseif f(2),ch=[v2 m23 v1;m23 v3 v1];
        else,ch=[v3 m31 v2;m31 v1 v2];end
        Tnew(nnew+(1:2),:)=ch;nnew=nnew+2;
    elseif nf==2
        affected=affected+1;
        if f(1)&&f(2),ch=[m12 v2 m23;v1 m12 v3;m12 m23 v3];
        elseif f(2)&&f(3),ch=[m23 v3 m31;v2 m23 v1;m23 m31 v1];
        else,ch=[v1 m12 m31;v2 v3 m12;v3 m31 m12];end
        Tnew(nnew+(1:3),:)=ch;nnew=nnew+3;
    else
        affected=affected+1;ch=[v1 m12 m31;m12 v2 m23;m31 m23 v3;m12 m23 m31];
        Tnew(nnew+(1:4),:)=ch;nnew=nnew+4;
    end
end
Tnew=Tnew(1:nnew,:);meshNew=finalize_unstructured_mesh_local(Pnew,Tnew);
oldGeom=mesh_triangle_geometry_local(mesh);newGeom=mesh_triangle_geometry_local(meshNew);
stat.nAffectedTriangles=affected;
stat.areaRelError=abs(sum(newGeom.area)-sum(oldGeom.area))/max(sum(oldGeom.area),eps);
end

function M = finalize_unstructured_mesh_local(P,T)
% First remove zero-area cells WITHOUT calling tri_gradients_local: that
% helper intentionally throws on degeneracy, whereas this constructor must
% safely filter a transient bad cell created by a budget top-up attempt.
scale=max([max(P(:,1))-min(P(:,1)),max(P(:,2))-min(P(:,2)),1]);
areaTol=1e-12*scale^2;
good=true(size(T,1),1); signed2A=zeros(size(T,1),1);
for e=1:size(T,1)
    if numel(unique(T(e,:)))<3, good(e)=false; continue; end
    a=P(T(e,1),:); b=P(T(e,2),:); c=P(T(e,3),:);
    signed2A(e)=(b(1)-a(1))*(c(2)-a(2))-(b(2)-a(2))*(c(1)-a(1));
    if ~isfinite(signed2A(e)) || abs(signed2A(e))<=areaTol, good(e)=false; end
end
if any(~good)
    warning('AFEM:DegenerateTrianglesRemoved', ...
        'Removed %d transient degenerate triangles while finalizing the mesh.',nnz(~good));
end
T=T(good,:); signed2A=signed2A(good);
% Orient retained triangles counter-clockwise.
flip=signed2A<0; T(flip,[2 3])=T(flip,[3 2]);
% Remove duplicate triangles after orientation.
Ts=sort(T,2);[~,ia]=unique(Ts,'rows','stable');T=T(sort(ia),:);
if isempty(T), error('AFEM:EmptyMesh','No valid triangles remain after mesh finalization.'); end
% Do not count vertices that are no longer referenced after filtering; this
% prevents a false exact-node-budget certificate and suppresses MATLAB's
% ``input points not referenced'' triangulation warning.
used=unique(T(:)); map=zeros(size(P,1),1); map(used)=1:numel(used);
P=P(used,:); T=reshape(map(T),size(T));
M=struct();M.P=P;M.T=T;M.TR=triangulation(T,P);
end

function [mesh,nAdded] = topup_adaptive_mesh_to_exact_budget(mesh,N,obs,G,c0,cfg)
nAdded=0;
while size(mesh.P,1)<N
    H=build_interp_matrix_local(mesh,obs.uv);K=assemble_fault_stiffness_local(mesh,G,cfg);
    S=fit_fem_solution_local(mesh,K,H,obs,c0,'TOPUP');
    [~,parts]=afem_hybrid_indicator_local(mesh,S.U,obs,H,G,c0,cfg);
    geom=mesh_triangle_geometry_local(mesh);
    score=parts.priority.*geom.area;
    [~,ord]=sort(score,'descend');
    inserted=false;
    for kk=1:numel(ord)
        t=ord(kk);
        if geom.hT(t)<=1.5*cfg.afemHMin,continue;end
        mesh=split_triangle_at_centroid_local(mesh,t);
        nAdded=nAdded+1;inserted=true;break;
    end
    if ~inserted
        error('Could not top-up adaptive mesh to N=%d because all cells reached h_min.',N);
    end
end
end

function M2 = split_triangle_at_centroid_local(M,t)
% A local three-way split can inherit a hanging/duplicate edge from a
% preceding budget-limited bisection.  Re-triangulate the full point set
% instead: it is still a one-node top-up, but every counted point belongs
% to a valid conforming Delaunay mesh and no pseudo-node is retained.
P=M.P; v=M.T(t,:); c=mean(P(v,:),1);
tol=1e-10*max([range(P(:,1)),range(P(:,2)),1]);
if any(sqrt(sum((P-c).^2,2))<=tol)
    error('AFEM:TopUpDuplicatePoint', ...
        'Selected top-up triangle has a centroid coincident with an existing node.');
end
P=[P;c];
DT=delaunayTriangulation(P);
T=DT.ConnectivityList;
M2=finalize_unstructured_mesh_local(P,T);
if size(M2.P,1)~=size(P,1)
    error('AFEM:TopUpNodeLoss','Delaunay top-up did not retain the inserted node.');
end
end

function [sol,mesh,topup] = run_fault_adaptive_exact_budget(N,uRange,vRange,obs,G,c0,cfg)
mesh0=uniform_mesh_under_budget_local(uRange,vRange,cfg.afemInitialNodeBudget);
[~,mesh]=adapt_fault_mesh_to_budget_local(mesh0,N,obs,G,c0,cfg);
[mesh,topup]=topup_adaptive_mesh_to_exact_budget(mesh,N,obs,G,c0,cfg);
H=build_interp_matrix_local(mesh,obs.uv);K=assemble_fault_stiffness_local(mesh,G,cfg);
sol=fit_fem_solution_local(mesh,K,H,obs,c0,'FAULT-AFEM');
end

% =========================================================================
% TABLES / EFFECTS
% =========================================================================
function T = metrics_table_from_cells(labels,M,nodes)
n=numel(M);A=zeros(n,6);
for i=1:n
    A(i,:)=[M{i}.RMSE_all,M{i}.RMSE_fault,M{i}.RMSE_bg,M{i}.Jump0MAE, ...
            M{i}.dataRMSE,M{i}.Jump0Correlation];
end
T=table(labels,nodes,A(:,1),A(:,2),A(:,3),A(:,4),A(:,5),A(:,6), ...
    'VariableNames',{'Method','Nodes','RMSE_Global_m','RMSE_Fault_m', ...
    'RMSE_Background_m','JumpMAE_m','ControlRMSE_m','JumpCorrelation'});
end

function T = equal_budget_effect_table(E)
% Effects are reported as relative error reductions (%); positive = better.
get=@(name,var) E{strcmp(E.Method,name),var};
metrics={'RMSE_Fault_m','JumpMAE_m','RMSE_Global_m','RMSE_Background_m'};
rows={};r=0;
for i=1:numel(metrics)
    m=metrics{i};
    Uiso=get('U-ISO',m);Uflt=get('U-FLT',m);Aiso=get('A-ISO',m);Aflt=get('A-FLT',m);
    r=r+1;rows(r,:)={m,'Fault constraint on uniform mesh','U-FLT vs U-ISO',100*(Uiso-Uflt)/Uiso}; %#ok<AGROW>
    r=r+1;rows(r,:)={m,'Adaptive mesh under isotropic regularization','A-ISO vs U-ISO',100*(Uiso-Aiso)/Uiso}; %#ok<AGROW>
    r=r+1;rows(r,:)={m,'Adaptive mesh under fault regularization','A-FLT vs U-FLT',100*(Uflt-Aflt)/Uflt}; %#ok<AGROW>
    r=r+1;rows(r,:)={m,'Full method vs isotropic-uniform baseline','A-FLT vs U-ISO',100*(Uiso-Aflt)/Uiso}; %#ok<AGROW>
end
T=cell2table(rows,'VariableNames',{'Metric','Effect','Contrast','Reduction_percent'});
end

function s = perturb_signs(mag)
if mag==0,s=1;else,s=[-1 1];end
end

function T = aggregate_perturbation_table(R,magName)
mag=R.(magName);u=unique(mag);n=numel(u);
A=zeros(n,9);
for i=1:n
    m=mag==u(i);
    A(i,1)=mean(R.RMSE_Global_m(m));A(i,2)=std(R.RMSE_Global_m(m),0);
    A(i,3)=mean(R.RMSE_Fault_m(m));A(i,4)=std(R.RMSE_Fault_m(m),0);
    A(i,5)=mean(R.RMSE_Background_m(m));A(i,6)=std(R.RMSE_Background_m(m),0);
    A(i,7)=mean(R.JumpMAE_m(m));A(i,8)=std(R.JumpMAE_m(m),0);
    A(i,9)=mean(R.ControlRMSE_m(m));
end
T=table(u,A(:,1),A(:,2),A(:,3),A(:,4),A(:,5),A(:,6),A(:,7),A(:,8),A(:,9), ...
    'VariableNames',{magName,'RMSE_Global_mean','RMSE_Global_std','RMSE_Fault_mean', ...
    'RMSE_Fault_std','RMSE_Background_mean','RMSE_Background_std', ...
    'JumpMAE_mean','JumpMAE_std','ControlRMSE_mean'});
end

% =========================================================================
% FIGURES
% =========================================================================
function plot_equal_budget_metrics(outDir,T,Sx)
f=figure('Color','w','Position',[100 100 1180 430]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
nexttile;bar(categorical(T.Method),T.RMSE_Fault_m);ylabel('Fault-neighborhood RMSE (m)');grid on;
title('Strict equal-budget ablation: local RMSE');
nexttile;bar(categorical(T.Method),T.JumpMAE_m);ylabel('Cross-fault depth-difference MAE (m)');grid on;
title('Strict equal-budget ablation: cross-fault structure');
exportgraphics(f,fullfile(outDir,'FIG_E1_equal_budget_metrics.png'),'Resolution',Sx.figureDPI);close(f);
end

function plot_equal_budget_meshes(outDir,U,A,G,obs,Sx)
f=figure('Color','w','Position',[100 100 1150 460]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
nexttile;triplot(U.T,U.P(:,1),U.P(:,2));hold on;plot(G.uc,G.vc,'k-','LineWidth',1.5);scatter(obs.uv(:,1),obs.uv(:,2),14,'filled');axis equal tight;title(sprintf('Exact quasi-uniform, N=%d',size(U.P,1)));xlabel('u (m)');ylabel('v (m)');
nexttile;triplot(A.T,A.P(:,1),A.P(:,2));hold on;plot(G.uc,G.vc,'k-','LineWidth',1.5);scatter(obs.uv(:,1),obs.uv(:,2),14,'filled');axis equal tight;title(sprintf('Adaptive, N=%d',size(A.P,1)));xlabel('u (m)');ylabel('v (m)');
exportgraphics(f,fullfile(outDir,'FIG_E1_equal_budget_meshes.png'),'Resolution',Sx.figureDPI);close(f);
end

function plot_fault_geometry_robustness(outDir,To,Ta,Sx)
f=figure('Color','w','Position',[100 100 1150 450]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
nexttile;yyaxis left;errorbar(To.Magnitude_m,To.RMSE_Fault_mean,To.RMSE_Fault_std,'-o','LineWidth',1.2);ylabel('Fault RMSE (m)');yyaxis right;errorbar(To.Magnitude_m,To.JumpMAE_mean,To.JumpMAE_std,'-s','LineWidth',1.2);ylabel('Jump MAE (m)');xlabel('|fault offset| (m)');grid on;title('Fault-location perturbation');
nexttile;yyaxis left;errorbar(Ta.Magnitude_deg,Ta.RMSE_Fault_mean,Ta.RMSE_Fault_std,'-o','LineWidth',1.2);ylabel('Fault RMSE (m)');yyaxis right;errorbar(Ta.Magnitude_deg,Ta.JumpMAE_mean,Ta.JumpMAE_std,'-s','LineWidth',1.2);ylabel('Jump MAE (m)');xlabel('|orientation perturbation| (deg)');grid on;title('Fault-orientation perturbation');
exportgraphics(f,fullfile(outDir,'FIG_E2_fault_geometry_robustness.png'),'Resolution',Sx.figureDPI);close(f);
end

function plot_parameter_sensitivity(outDir,T,Sx)
params=unique(T.Parameter,'stable');
for ip=1:numel(params)
    p=params{ip};m=strcmp(T.Parameter,p);x=T.DisplayValue(m);
    [x,ord]=sort(x);tf=T.RMSE_Fault_m(m);tj=T.JumpMAE_m(m);tg=T.RMSE_Global_m(m);tf=tf(ord);tj=tj(ord);tg=tg(ord);
    f=figure('Color','w','Position',[100 100 920 430]);
    yyaxis left;plot(x,tf,'-o','LineWidth',1.3);hold on;plot(x,tg,'--s','LineWidth',1.1);ylabel('RMSE (m)');
    yyaxis right;plot(x,tj,'-d','LineWidth',1.3);ylabel('Jump MAE (m)');
    xlabel(strrep(p,'_','\_'));grid on;title(['Parameter sensitivity: ',strrep(p,'_','\_')]);
    legend({'Fault RMSE','Global RMSE','Jump MAE'},'Location','best');
    exportgraphics(f,fullfile(outDir,['FIG_E3_parameter_sensitivity_',p,'.png']),'Resolution',Sx.figureDPI);close(f);
end
end

% =========================================================================
% PAPER-READY TEXT SUMMARY
% =========================================================================
function write_paper_ready_summary(outDir,E,Eff,To,Ta,Ts,Sx,sigma0)
fid=fopen(fullfile(outDir,'PAPER_READY_SUMMARY.txt'),'w');
if fid<0,return;end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'Supplementary experiments summary\n');
fprintf(fid,'=================================\n\n');
fprintf(fid,'E1 strict equal-budget factorial ablation, N=%d\n',Sx.equalBudgetNodes);
for i=1:height(E)
    fprintf(fid,'%-6s | fault RMSE %.6f | jump MAE %.6f | global RMSE %.6f\n', ...
        E.Method{i},E.RMSE_Fault_m(i),E.JumpMAE_m(i),E.RMSE_Global_m(i));
end
fprintf(fid,'\nMain factorial contrasts (positive reduction = improvement):\n');
for i=1:height(Eff)
    fprintf(fid,'%s | %s | %.3f %%\n',Eff.Metric{i},Eff.Contrast{i},Eff.Reduction_percent(i));
end
fprintf(fid,'\nE2 geometry robustness: absolute perturbations are averaged over +/- signs.\n');
fprintf(fid,'Offset magnitudes: %s m\n',mat2str(To.Magnitude_m.'));
fprintf(fid,'Angle magnitudes : %s deg\n',mat2str(Ta.Magnitude_deg.'));
fprintf(fid,'\nE3 one-at-a-time sensitivity. Baseline effective sigma_Gamma = %.6f m.\n',sigma0);
fprintf(fid,'Rows written to E3_PARAMETER_SENSITIVITY.csv: %d\n',height(Ts));
fprintf(fid,'\nInterpretation rule:\n');
fprintf(fid,'1) E1 is the primary causal ablation.\n');
fprintf(fid,'2) E2 is the primary engineering robustness test.\n');
fprintf(fid,'3) E3 is a secondary tuning-sensitivity audit, not a parameter-selection procedure.\n');
end

% =========================================================================
% SMALL UTILITIES
% =========================================================================
% =========================================================================
% E4: EXTERNAL BASELINES (all fit/tune using sparse controls only)
% =========================================================================
function B = run_external_baselines_local(obs,UVref,Zref,faultMask,bgMask,negMask,posMask,Rref,G,cfg,Sx,outDir) %#ok<INUSD>
methods = {'TPS','Gaussian-RBF','Ordinary-Kriging','Anisotropic-Kriging','Bayesian-GP'};
DD = sqrt((obs.uv(:,1)-obs.uv(:,1).').^2 + (obs.uv(:,2)-obs.uv(:,2).').^2);
medD = median(DD(triu(true(size(DD)),1)));
scales = medD*[0.40 0.70 1.20 2.00 3.50];
nuggets = [1e-6 1e-4 1e-3 1e-2 5e-2];
% r = ell_tangent / ell_normal.  Search both directions around unity:
% r>1 favours longer correlation along the fault; r<1 favours the reverse.
ratios = [0.25 0.40 0.67 1.00 1.50 2.50 4.00];
fold = buffered_spatial_folds_local(obs.uv,4);
rows = cell(numel(methods),10); cvRows = cell(0,6);
predictions = cell(numel(methods),1); models = cell(numel(methods),1);
for im = 1:numel(methods)
    method = methods{im};
    [best, audit] = select_baseline_spatial_cv_local(method,obs,scales,nuggets,ratios,fold);
    cvRows = [cvRows; audit]; %#ok<AGROW>
    S = fit_external_model_local(method,obs.uv,obs.z,best,scales,nuggets,ratios);
    pred = predict_solution_local(S,UVref);
    [M,~] = evaluate_dense_v2_local(pred,Zref,faultMask,bgMask,negMask,posMask,obs,S,Rref,G,cfg);
    rows(im,:) = {method,best.scale,best.nugget,best.ratio,M.RMSE_all,M.RMSE_fault, ...
        M.RMSE_bg,M.Jump0MAE,M.trainRMSE,M.nUnknowns};
    predictions{im}=pred; models{im}=S;
    fprintf('  %-22s | CV scale %.3f | nugget %.4g | fault RMSE %.4f | bilateral-extrapolation MAE %.4f\n', ...
        method,best.scale,best.nugget,M.RMSE_fault,M.Jump0MAE);
end
B=struct();
B.metrics=cell2table(rows,'VariableNames',{'Method','Scale_m','NuggetRatio','AnisotropyRatio', ...
    'RMSE_Global_m','RMSE_Fault_m','RMSE_Background_m','BilateralExtrapolationMAE_m','ControlRMSE_m','NUnknowns'});
B.cvAudit=cell2table(cvRows,'VariableNames',{'Method','Scale_m','NuggetRatio','AnisotropyRatio','MeanSpatialCV_MSE','SE_SpatialCV_MSE'});
B.predictions=predictions; B.models=models; B.methods=methods;
ib=find(strcmp(methods,'Bayesian-GP'),1);
V=models{ib}.predictVarFcn(UVref);
B.bayesVariance=V;
B.uncertaintySummary=table(mean(sqrt(max(V,0))),median(sqrt(max(V,0))), ...
    mean(sqrt(max(V(faultMask),0))), 'VariableNames',{'MeanPosteriorSD_m','MedianPosteriorSD_m','FaultBandMeanPosteriorSD_m'});
end

function fold = buffered_spatial_folds_local(xy,K)
% Deterministic chessboard partitions avoid random point-wise CV leakage.
x=xy(:,1); y=xy(:,2); ex=linspace(min(x),max(x),K+1); ey=linspace(min(y),max(y),K+1);
ix=min(K,max(1,discretize(x,[-inf,ex(2:end-1),inf])));
iy=min(K,max(1,discretize(y,[-inf,ey(2:end-1),inf])));
fold=mod(ix+iy, K)+1;
end

function [best,audit] = select_baseline_spatial_cv_local(method,obs,scales,nuggets,ratios,fold)
if strcmp(method,'TPS') || strcmp(method,'Gaussian-RBF') || strcmp(method,'Ordinary-Kriging')
    R=1;
else
    R=numel(ratios);
end
audit=cell(0,6); q=0; best=struct('scale',nan,'nugget',nan,'ratio',1); best.score=inf;
for a=1:numel(scales)
 for b=1:numel(nuggets)
  for r=1:R
   ratio=ratios(r); e=[];
   for f=1:max(fold)
    tr=fold~=f; te=fold==f;
    if nnz(tr)<8 || nnz(te)<1, continue; end
    prm=struct('scale',scales(a),'nugget',nuggets(b),'ratio',ratio);
    S=fit_external_model_local(method,obs.uv(tr,:),obs.z(tr),prm,scales,nuggets,ratios);
    ep=predict_solution_local(S,obs.uv(te,:))-obs.z(te); e=[e;ep.^2]; %#ok<AGROW>
   end
   mu=mean(e); se=std(e)/sqrt(max(numel(e),1)); q=q+1;
   audit(q,:)={method,scales(a),nuggets(b),ratio,mu,se};
   if mu<best.score, best=struct('scale',scales(a),'nugget',nuggets(b),'ratio',ratio,'score',mu); end
  end
 end
end
end

function S = fit_external_model_local(method,X,z,prm,scales,nuggets,ratios)
z=z(:); n=numel(z); nug=max(prm.nugget,1e-10); ell=max(prm.scale,eps);
switch method
 case 'TPS'
  % Normalize coordinates before forming r^2 log(r); otherwise kilometre
  % coordinates make the TPS saddle system nearly singular.
  xMean=mean(X,1); xScale=max(std(X,0,1),1); Xn=(X-xMean)./xScale;
  R=pair_distance_local(Xn,Xn); K=tps_kernel_local(R); P=[ones(n,1),Xn]; A=[K+max(nug,1e-8)*eye(n),P;P.',zeros(3)];
  c=A\[z;zeros(3,1)];
  S=external_solution_local(method,X,z,@(Q) tps_kernel_local(pair_distance_local((Q-xMean)./xScale,Xn))*c(1:n)+[ones(size(Q,1),1),(Q-xMean)./xScale]*c(n+1:end),n+3);
 case 'Gaussian-RBF'
  K=exp(-(pair_distance_local(X,X)/ell).^2)+nug*eye(n); alpha=K\z;
  S=external_solution_local(method,X,z,@(Q) exp(-(pair_distance_local(Q,X)/ell).^2)*alpha,n);
 case {'Ordinary-Kriging','Anisotropic-Kriging'}
  aniso=strcmp(method,'Anisotropic-Kriging');
  D=geo_distance_local(X,X,ell,prm.ratio,aniso); K=exp(-D)+nug*eye(n); A=[K,ones(n,1);ones(1,n),0]; w=A\[z;0];
  S=external_solution_local(method,X,z,@(Q) [exp(-geo_distance_local(Q,X,ell,prm.ratio,aniso)),ones(size(Q,1),1)]*w,n+1);
 case 'Bayesian-GP'
  S=fit_bayesian_gp_local(X,z,scales,nuggets,ratios);
 otherwise
  error('Unsupported baseline method: %s',method);
end
end

function S = fit_bayesian_gp_local(X,z,scales,nuggets,ratios)
% Discrete Bayesian model averaging over covariance range, nugget and anisotropy.
n=numel(z); zbar=mean(z); y=z-zbar; cand=struct('ell',{},'nug',{},'ratio',{},'alpha',{},'L',{},'logw',{}); k=0;
for a=1:numel(scales), for b=1:numel(nuggets), for r=1:numel(ratios)
 D=geo_distance_local(X,X,scales(a),ratios(r),true); K=exp(-D)+max(nuggets(b),1e-8)*eye(n);
 [L,p]=chol(K,'lower'); if p~=0, continue; end
 alpha=L'\(L\y); logdet=2*sum(log(diag(L))); logml=-0.5*(y'*alpha+logdet+n*log(2*pi));
 k=k+1; cand(k)=struct('ell',scales(a),'nug',nuggets(b),'ratio',ratios(r),'alpha',alpha,'L',L,'logw',logml); %#ok<AGROW>
end,end,end
lw=[cand.logw]; wt=exp(lw-max(lw)); wt=wt/sum(wt);
pred=@(Q) bayes_gp_predict_local(Q,X,zbar,cand,wt,false);
varf=@(Q) bayes_gp_predict_local(Q,X,zbar,cand,wt,true);
S=external_solution_local('Bayesian-GP',X,z,pred,n); S.predictVarFcn=varf; S.posteriorWeights=wt;
end

function out = bayes_gp_predict_local(Q,X,zbar,cand,wt,wantVar)
m=size(Q,1); mu=zeros(m,1); sec=zeros(m,1);
for k=1:numel(cand)
 c=cand(k); Ks=exp(-geo_distance_local(Q,X,c.ell,c.ratio,true)); mk=zbar+Ks*c.alpha;
 if wantVar
  v=max(0,1-sum((Ks/c.L').^2,2)); sec=sec+wt(k)*(v+mk.^2);
 else
  mu=mu+wt(k)*mk;
 end
end
if wantVar
 for k=1:numel(cand)
  c=cand(k); Ks=exp(-geo_distance_local(Q,X,c.ell,c.ratio,true)); mu=mu+wt(k)*(zbar+Ks*c.alpha);
 end
 out=max(0,sec-mu.^2);
else, out=mu; end
end

function S = external_solution_local(name,X,z,predictFcn,nUnknowns)
S=struct('type','external','name',name,'predictFcn',predictFcn,'nUnknowns',nUnknowns);
S.dataRMSE=sqrt(mean((predictFcn(X)-z(:)).^2));
end

function D = geo_distance_local(A,B,ell,ratio,anisotropic)
du=A(:,1)-B(:,1).'; dv=A(:,2)-B(:,2).';
if anisotropic
 % Local coordinates are u=tangent and v=normal.  Keeping ell_u*ell_v
 % fixed avoids giving large-ratio models an artificial scale advantage.
 ratio=max(ratio,1e-8);
 ellU=ell*sqrt(ratio);
 ellV=ell/sqrt(ratio);
 D=sqrt((du/ellU).^2+(dv/ellV).^2);
else
 D=sqrt(du.^2+dv.^2)/ell;
end
end

function K = tps_kernel_local(R)
K=R.^2.*log(max(R,1e-12)); K(R==0)=0;
end

function D = pair_distance_local(A,B)
du=A(:,1)-B(:,1).'; dv=A(:,2)-B(:,2).'; D=sqrt(du.^2+dv.^2);
end

function plot_external_baseline_comparison_local(outDir,B,UVref,Zref,faultMask,G,Sx)
f=figure('Color','w','Position',[80 80 1500 760]); tl=tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
uLine=linspace(G.uMin,G.uMax,300).'; [vLine,~]=fault_center_and_slope_local(uLine,G);
for i=1:numel(B.methods)
 nexttile; scatter(UVref(:,1),UVref(:,2),10,B.predictions{i}-Zref,'filled'); hold on; plot(uLine,vLine,'r-','LineWidth',1.3); axis equal tight; colorbar; title(B.methods{i},'Interpreter','none'); xlabel('u / m'); ylabel('v / m');
end
title(tl,'External interpolation and geostatistical baselines: signed error on the high-density interpreted reference');
exportgraphics(f,fullfile(outDir,'FIG_E4_external_baseline_errors.png'),'Resolution',Sx.figureDPI); close(f);
end

function plot_bayesian_uncertainty_local(outDir,B,UVref,G,Sx)
f=figure('Color','w','Position',[100 100 1100 440]);
uLine=linspace(G.uMin,G.uMax,300).'; [vLine,~]=fault_center_and_slope_local(uLine,G);
subplot(1,2,1); scatter(UVref(:,1),UVref(:,2),10,sqrt(max(B.bayesVariance,0)),'filled'); hold on; plot(uLine,vLine,'r-','LineWidth',1.4); axis equal tight; colorbar; title('Bayesian GP posterior standard deviation'); xlabel('u / m'); ylabel('v / m');
subplot(1,2,2); bar(categorical(B.methods),B.metrics.RMSE_Fault_m); ylabel('Fault-neighborhood RMSE / m'); title('Fault-neighborhood comparison'); grid on;
exportgraphics(f,fullfile(outDir,'FIG_E4_bayesian_uncertainty_and_baselines.png'),'Resolution',Sx.figureDPI); close(f);
end

function r = corr_local(a,b)
a=a(:);b=b(:);m=isfinite(a)&isfinite(b);a=a(m);b=b(m);
if numel(a)<3 || std(a)<=eps || std(b)<=eps,r=nan;else,C=corrcoef(a,b);r=C(1,2);end
end

function q = percentile_local(x,p)
x=x(isfinite(x));
if isempty(x),q=nan;return;end
x=sort(x(:));
if numel(x)==1,q=x;return;end
r=1+(numel(x)-1)*p/100;i=floor(r);j=ceil(r);
if i==j,q=x(i);else,q=x(i)+(r-i)*(x(j)-x(i));end
end

% =========================================================================
% E5: repeated spatially balanced control redraws
% =========================================================================
function T = run_repeated_control_sampling_local(UVref,Zref,phiRef,faultMask,bgMask,negMask,posMask,Rref,G,c0,cfg,uRange,vRange,S,outDir) %#ok<INUSD>
rows=cell(2*S.nReplicates,9); r=0;
for ir=1:S.nReplicates
    idx=balanced_farthest_controls_local(UVref,phiRef, ...
        S.replicateNegativeSideControls,S.replicatePositiveSideControls,S.seed+1000*ir);
    obs=struct('uv',UVref(idx,:),'z',Zref(idx),'w',ones(numel(idx),1),'idx',(1:numel(idx)).');

    % Same paper-state c0 and the same node budget: only sparse-control
    % sampling changes between repetitions.
    meshU=uniform_mesh_under_budget_local(uRange,vRange,S.replicateBudgetNodes);
    HU=build_interp_matrix_local(meshU,obs.uv);
    KU=assemble_fault_stiffness_local(meshU,G,cfg);
    solU=fit_fem_solution_local(meshU,KU,HU,obs,c0,'R-U-FLT');

    [solA,meshA,topup]=run_fault_adaptive_exact_budget( ...
        S.replicateBudgetNodes,uRange,vRange,obs,G,c0,cfg);
    predU=predict_solution_local(solU,UVref);
    predA=predict_solution_local(solA,UVref);
    [MU,~]=evaluate_dense_v2_local(predU,Zref,faultMask,bgMask,negMask,posMask,obs,solU,Rref,G,cfg);
    [MA,~]=evaluate_dense_v2_local(predA,Zref,faultMask,bgMask,negMask,posMask,obs,solA,Rref,G,cfg);

    r=r+1; rows(r,:)={ir,'U-FLT',size(meshU.P,1),0,MU.RMSE_all,MU.RMSE_fault,MU.RMSE_bg,MU.Jump0MAE,MU.dataRMSE};
    r=r+1; rows(r,:)={ir,'A-FLT',size(meshA.P,1),topup,MA.RMSE_all,MA.RMSE_fault,MA.RMSE_bg,MA.Jump0MAE,MA.dataRMSE};
    fprintf('  replicate %d/%d | U-FLT fault %.4f, A-FLT fault %.4f, jump %.4f -> %.4f\n', ...
        ir,S.nReplicates,MU.RMSE_fault,MA.RMSE_fault,MU.Jump0MAE,MA.Jump0MAE);
end
T=cell2table(rows,'VariableNames',{'Replicate','Method','Nodes','TopUpNodes', ...
    'RMSE_Global_m','RMSE_Fault_m','RMSE_Background_m','JumpMAE_m','ControlRMSE_m'});
end

function T = summarize_repeated_control_sampling_local(R)
metrics={'RMSE_Global_m','RMSE_Fault_m','RMSE_Background_m','JumpMAE_m'};
rows=cell(numel(metrics),7);
for k=1:numel(metrics)
    a=R.(metrics{k})(strcmp(R.Method,'A-FLT'));
    u=R.(metrics{k})(strcmp(R.Method,'U-FLT'));
    d=u-a;
    rows(k,:)={metrics{k},mean(u),std(u),mean(a),std(a), ...
        100*mean(d)/mean(u),nnz(d>0)};
end
T=cell2table(rows,'VariableNames',{'Metric','UFLT_Mean_m','UFLT_Std_m', ...
    'AFLT_Mean_m','AFLT_Std_m','MeanReduction_percent','AFLT_Wins_of_10'});
end

function idx=balanced_farthest_controls_local(UV,phi,nNegative,nPositive,seed)
% Strictly preserve the C11 paper design: 39 / 41 controls on the two
% sides of the interpreted fault.  Farthest-point sampling prevents a
% redraw from being dominated by a local cluster of dense interpreted nodes.
rng(seed,'twister');
left=find(phi<0); right=find(phi>=0);
if nNegative>numel(left) || nPositive>numel(right)
    error('E5:InsufficientSideControls', ...
        'Cannot draw %d/%d controls: available negative/positive counts are %d/%d.', ...
        nNegative,nPositive,numel(left),numel(right));
end
idx=[left(farthest_point_indices_local(UV(left,:),nNegative)); ...
     right(farthest_point_indices_local(UV(right,:),nPositive))];
idx=idx(randperm(numel(idx)));
end

function pick=farthest_point_indices_local(X,n)
m=size(X,1); n=min(n,m); pick=zeros(n,1);
pick(1)=randi(m); d2=sum((X-X(pick(1),:)).^2,2);
for k=2:n
    [~,pick(k)]=max(d2);
    d2=min(d2,sum((X-X(pick(k),:)).^2,2));
end
end

function plot_repeated_control_sampling_local(outDir,T,S)
f=figure('Color','w','Position',[80 80 1200 430]);
tl=tiledlayout(1,2,'TileSpacing','compact','Padding','compact');
metrics={'RMSE_Fault_m','JumpMAE_m'}; titles={'Fault-neighborhood RMSE','Cross-fault depth-difference MAE'};
for k=1:2
    nexttile; hold on; grid on; box on;
    yU=T.(metrics{k})(strcmp(T.Method,'U-FLT'));
    yA=T.(metrics{k})(strcmp(T.Method,'A-FLT'));
    xU=1+0.08*randn(numel(yU),1); xA=2+0.08*randn(numel(yA),1);
    scatter(xU,yU,48,[0.35 0.35 0.35],'filled'); scatter(xA,yA,48,[0.00 0.42 0.70],'filled');
    plot([1 2],[mean(yU) mean(yA)],'-','Color',[0.25 0.25 0.25],'LineWidth',1.1);
    xlim([0.55 2.45]); set(gca,'XTick',[1 2],'XTickLabel',{'U-FLT','A-FLT'}); ylabel([titles{k},' / m']);
    title(titles{k});
end
title(tl,sprintf('Repeated spatially balanced control redraws (n = %d)',S.nReplicates));
exportgraphics(f,fullfile(outDir,'FIG_E5_repeated_control_sampling.png'),'Resolution',S.figureDPI); close(f);
end
