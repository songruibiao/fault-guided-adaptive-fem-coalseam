function outDir=RUN_CGE_ALL_FIGURES_VISUAL_V4
% RUN_CGE_ALL_FIGURES_VISUAL_V4
% =========================================================================
% 《煤田地质与勘探》论文图件视觉重构一键生成程序
%
% 唯一运行入口：
%
%     RUN_CGE_ALL_FIGURES_VISUAL_V4
%
% 本版针对上一版实际输出的两个问题作最终修正：
%
%   1. 中文显示：
%      不再优先使用 SimSun/SimHei；
%      MATLAB 图件统一优先使用 Microsoft YaHei；
%      若系统无可用中文字体，程序直接报错，不再静默输出方框。
%
%   2. 图中文字：
%      正文图全部采用中文表达；
%      不再出现 C11、TVD、RMSE、S-TPS、Uniform、Adaptive、
%      Fault、Fitted 等中英文混排。
%      数学变量/法定计量单位不属于英文表述，可正常保留。
%
%   3. 数值格式：
%      节点数、四面体数、非零元数：整数；
%      百分比：1 位小数；
%      网格尺度：1 位小数；
%      尺度比：2 位小数；
%      误差：图中尽量不堆数字，由坐标轴和图题解释。
%
%   4. 防遮挡：
%      柱图数值固定放在柱顶；
%      三维标注固定在数据较稀疏的左上角；
%      网格质量图主动预留右侧空白区放曲线说明；
%      不在主要曲线/断层交会位置叠放图例或长文字。
%
%   5. 自动审计：
%      每张图导出前扫描可见文字；
%      一旦发现禁用英文术语，立即报错并指出术语；
%      输出最终数值审计和图件生成审计。
%
% 默认逻辑：
%   - C11：首次运行本中文终稿版时自动重新运行一次正式 C11 引擎，
%          以保证图5/图6不是旧版英文标签；
%          后续若找到 FINALCN 结果则直接复用。
%   - 三维：优先复用已完成的 V2_FIX2 数值结果。
%   - 二维尺度：优先复用已有正式汇总结果。
% =========================================================================

clc;
close all;

cfg=final_config_cn_v4();

scriptDir=fileparts(mfilename('fullpath'));
if isempty(scriptDir), scriptDir=pwd; end
addpath(scriptDir);

% Apply reliable Chinese font globally before ANY figure is created.
apply_chinese_graphics_defaults_cn_v4(cfg);

stamp=datestr(now,'yyyymmdd_HHMMSS');
outDir=fullfile(scriptDir,['out_CGE_ALL_FIGURES_VISUAL_V4_' stamp]);
if ~exist(outDir,'dir'), mkdir(outDir); end

fprintf('\n============================================================\n');
fprintf('《煤田地质与勘探》论文图件视觉重构一键生成\n');
fprintf('输出目录：%s\n',outDir);
fprintf('============================================================\n');

audit={};
manifest={};

% =========================================================================
% 1. C11 FORMAL RESULT
% =========================================================================
fprintf('\n[1/6] 准备煤层实例正式结果 ...\n');

c11Run='';
if ~cfg.forceRecomputeC11
    c11Run=find_latest_run_cn_v4(scriptDir, ...
        'out_REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN_*', ...
        'CORE_RESULT_STATE.mat');
end

if isempty(c11Run)
    fprintf('  未找到中文终稿版实例结果，自动运行正式实例程序 ...\n');

    require_function_cn_v4( ...
        'REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN');

    dataDir=find_c11_data_cn_v4(scriptDir,cfg.manualC11DataDir);

    if isempty(dataDir)
        error(['未找到实例原始数据。需要 TVD_C11.dat 与 Dingji_t11_plg.dat。' ...
               '可在 final_config_cn_v4 中设置 manualC11DataDir。']);
    end

    c11Run=REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN(dataDir);
else
    fprintf('  复用已有中文终稿版实例结果：\n  %s\n',c11Run);
end

audit{end+1}=audit_item_cn_v4('实例数值结果',true,c11Run);

% =========================================================================
% 2. TRUE 3-D FORMAL RESULT
% =========================================================================
fprintf('\n[2/6] 准备三维断层拟合正式结果 ...\n');

ff3dRun='';
if ~cfg.forceRecompute3D
    ff3dRun=find_latest_run_cn_v4(scriptDir, ...
        'out_FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2_*', ...
        'FAULTFITTED3D_NUMERICAL_CHECKPOINT.mat');
end

if isempty(ff3dRun)
    fprintf('  未找到可复用三维结果，自动运行正式三维程序 ...\n');

    require_function_cn_v4( ...
        'FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2');

    ff3dRun=FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2;
else
    fprintf('  复用已有三维正式结果：\n  %s\n',ff3dRun);
end

audit{end+1}=audit_item_cn_v4('三维数值结果',true,ff3dRun);

% =========================================================================
% 3. SCALE-EXPANSION RESULT
% =========================================================================
fprintf('\n[3/6] 准备二维尺度扩展结果 ...\n');

scaleRun=find_latest_scaling_cn_v4(scriptDir);

if isempty(scaleRun) || cfg.forceRecomputeScaling
    require_function_cn_v4('PAPER_SCALING_AND_SUMMARY_FIGURES_V1');
    scaleRun=PAPER_SCALING_AND_SUMMARY_FIGURES_V1;
else
    fprintf('  复用已有二维尺度扩展结果：\n  %s\n',scaleRun);
end

scaleCSV=fullfile(scaleRun,'PAPER_SCALING_VALUES.csv');
if ~isfile(scaleCSV)
    error('缺少二维尺度扩展汇总文件：%s',scaleCSV);
end

audit{end+1}=audit_item_cn_v4('二维尺度扩展结果',true,scaleRun);

% =========================================================================
% 4. LOAD FROZEN RESULTS
% =========================================================================
fprintf('\n[4/6] 读取冻结数值结果并执行一致性检查 ...\n');

% ---- C11 instance ----
S=load(fullfile(c11Run,'CORE_RESULT_STATE.mat'),'state');
state=S.state;

N=readtable(fullfile(c11Run,'V4_C11_3D_SURFACE_NODES.csv'));
Obs=readtable(fullfile(c11Run,'SPARSE_CONTROLS.csv'));

Muni=state.uniformMesh;
Madp=state.adaptiveMesh;
G=state.geometry;

audit_c11_schema_cn_v4(N,Obs,Muni,Madp,G);

% ---- true 3-D ----
Q=load(fullfile(ff3dRun,'FAULTFITTED3D_NUMERICAL_CHECKPOINT.mat'),'checkpoint');
C=Q.checkpoint;

required3d={'cfg','UniformMatchedMesh','FittedMatchedMesh','Match', ...
    'Ablation','UniformCurve','FittedCurve'};
for k=1:numel(required3d)
    if ~isfield(C,required3d{k})
        error('三维检查点缺少字段：checkpoint.%s',required3d{k});
    end
end

audit_ff3d_cn_v4(C);

% ---- scaling ----
ScaleT=readtable(scaleCSV);
audit_scaling_cn_v4(ScaleT);

% =========================================================================
% 5. FINAL FIGURES
% =========================================================================
fprintf('\n[5/6] 统一生成中文终稿图件 ...\n');

[audit,manifest]=safe_plot_cn_v4('图1', ...
    @() fig01_reference_cn_v4(outDir,scriptDir,cfg),audit,manifest,cfg);

[audit,manifest]=safe_plot_cn_v4('图2', ...
    @() fig02_mesh_compare_cn_v4(outDir,N,Muni,Madp,G,Obs,cfg), ...
    audit,manifest,cfg);

[audit,manifest]=safe_plot_cn_v4('图3', ...
    @() fig03_tensor_cn_v4(outDir,cfg),audit,manifest,cfg);

[audit,manifest]=safe_plot_cn_v4('图4', ...
    @() fig04_geological_cn_v4(outDir,N,Obs,Madp,G,cfg), ...
    audit,manifest,cfg);

% Fig.05 / Fig.06 are regenerated by the patched formal C11 engine.
c11Paper=fullfile(c11Run,'PAPER_FIGURES_REBUILT');

[audit,manifest]=safe_plot_cn_v4('图5', ...
    @() copy_engine_figure_cn_v4( ...
        fullfile(c11Paper,'PAPER_FIG_C11_05_FAULT_LOCAL_ZOOM.png'), ...
        fullfile(c11Paper,'PAPER_FIG_C11_05_FAULT_LOCAL_ZOOM.pdf'), ...
        fullfile(outDir,'FIG05_FAULT_LOCAL_ERROR_CN.png'), ...
        fullfile(outDir,'FIG05_FAULT_LOCAL_ERROR_CN.pdf')), ...
    audit,manifest,cfg);

[audit,manifest]=safe_plot_cn_v4('图6', ...
    @() copy_engine_figure_cn_v4( ...
        fullfile(c11Paper,'PAPER_FIG_C11_01_METHOD_COMPARE.png'), ...
        fullfile(c11Paper,'PAPER_FIG_C11_01_METHOD_COMPARE.pdf'), ...
        fullfile(outDir,'FIG06_METHOD_COMPARISON_CN.png'), ...
        fullfile(outDir,'FIG06_METHOD_COMPARISON_CN.pdf')), ...
    audit,manifest,cfg);

[audit,manifest]=safe_plot_cn_v4('图7', ...
    @() fig07_scaling_cn_v4(outDir,ScaleT,cfg),audit,manifest,cfg);

[audit,manifest]=safe_plot_cn_v4('图8', ...
    @() fig08_cutaway_cn_v4(outDir, ...
        C.UniformMatchedMesh,C.FittedMatchedMesh,C.Match,C.cfg,cfg), ...
    audit,manifest,cfg);

[audit,manifest]=safe_plot_cn_v4('图9', ...
    @() fig09_evidence_cn_v4(outDir, ...
        C.Match,C.Ablation,C.UniformCurve,C.FittedCurve,cfg), ...
    audit,manifest,cfg);

% =========================================================================
% 6. FINAL AUDIT
% =========================================================================
fprintf('\n[6/6] 写入图件与数值审计 ...\n');

write_final_audit_cn_v4(outDir,audit,manifest,C,ScaleT,N,Obs,cfg);

fprintf('\n============================================================\n');
fprintf('全部视觉重构图件生成完成\n');
fprintf('输出目录：%s\n',outDir);
fprintf('============================================================\n');

end


% =========================================================================
% CONFIG
% =========================================================================
function cfg=final_config_cn_v4()

cfg.forceRecomputeC11=false;
cfg.forceRecompute3D=false;
cfg.forceRecomputeScaling=false;
cfg.manualC11DataDir='';

% 期刊图件尺寸：按双栏宽度设计，避免留白过大。
cfg.doubleWidthCM=17.6;
cfg.singleWidthCM=8.5;
cfg.rasterDPI=600;

cfg.fontCN=require_chinese_font_cn_v4();

% 正文图字号整体收敛，不让标题抢画面。
cfg.fontAxis=7.0;
cfg.fontPanel=7.6;
cfg.fontLegend=6.1;
cfg.fontAnnotation=6.1;

cfg.axisLW=0.55;
cfg.lineLW=1.10;
cfg.faultLW=1.55;
cfg.meshLW=0.22;

% 全文统一颜色语义。
cfg.colBlue=[0.18 0.43 0.70];
cfg.colOrange=[0.91 0.43 0.12];
cfg.colFault=[0.83 0.08 0.06];
cfg.colGray=[0.57 0.60 0.63];
cfg.colMesh=[0.15 0.18 0.20];
cfg.colGreen=[0.08 0.48 0.18];

% 煤层实例
cfg.c11MeshBand=105;
cfg.c11LocalHalfU=180;
cfg.c11LocalHalfV=145;
cfg.c11DenseRadius=125;
cfg.c11FaultCurtainHalfDepth=60;
cfg.c11MarkerSize=4.5;
cfg.c11VerticalExaggeration=0.30;
cfg.c11ViewAz=-34;
cfg.c11ViewEl=25;

% 三维断层拟合
cfg.ff3dViewAz=-32;
cfg.ff3dViewEl=23;
cfg.ff3dFaultAlpha=0.20;
cfg.ff3dPlaneAlpha=0.23;

% 已批准的图1原图资产。
cfg.approvedFig1File='FIG01_APPROVED_REFERENCE.PNG';

% 图中禁止出现的英文方法缩写。
cfg.forbiddenTerms={ ...
    'C11','TVD','RMSE','S-TPS','FAULT-FEM','FAULT-AFEM', ...
    'Uniform','Adaptive','Fault','Fitted','Reference'};

end

function fontName=require_chinese_font_cn_v4()

cands={'Microsoft YaHei','Microsoft YaHei UI','SimHei','SimSun'};
avail=listfonts;

fontName='';

for k=1:numel(cands)
    if any(strcmpi(avail,cands{k}))
        fontName=cands{k};
        break;
    end
end

if isempty(fontName)
    error(['MATLAB 未检测到可可靠显示中文的字体。' ...
           '请安装或启用 Microsoft YaHei（微软雅黑）、' ...
           'Microsoft YaHei UI、SimHei 或 SimSun 后再运行。']);
end

fprintf('  中文绘图字体：%s\n',fontName);

end


function apply_chinese_graphics_defaults_cn_v4(cfg)

set(groot, ...
    'defaultAxesFontName',cfg.fontCN, ...
    'defaultTextFontName',cfg.fontCN, ...
    'defaultLegendFontName',cfg.fontCN, ...
    'defaultAxesFontSize',cfg.fontAxis, ...
    'defaultAxesTitleFontWeight','normal', ...
    'defaultTextInterpreter','none', ...
    'defaultLegendInterpreter','none', ...
    'defaultAxesTickLabelInterpreter','none');

end

function fig01_reference_cn_v4(outDir,scriptDir,cfg)
% 图1不再尝试用 MATLAB 重画。
% 直接复制用户已确认“无需修改任何部位”的批准版原图，保证视觉完全一致。

src=fullfile(scriptDir,cfg.approvedFig1File);

if ~isfile(src)
    error(['缺少已批准的图1资产：%s。请使用完整压缩包运行，' ...
           '不要单独复制主程序。'],src);
end

dst=fullfile(outDir,'FIG01_METHOD_CONCEPT_APPROVED.png');
copyfile(src,dst,'f');

end

function fig02_mesh_compare_cn_v4(outDir,N,MU,MA,G,Obs,cfg)

% 用煤层埋深作为统一底色，不再使用纯白背景网格。
% 这样既保持真实数值，又与已批准的概念图视觉语言一致。

depthA=N.TVD(:);
FA=scatteredInterpolant(MA.P(:,1),MA.P(:,2),depthA,'natural','nearest');

depthU=FA(MU.P(:,1),MU.P(:,2));
depthAplot=FA(MA.P(:,1),MA.P(:,2));

f=figure('Color','w','Units','centimeters', ...
    'Position',[1 1 cfg.doubleWidthCM 6.6],'Renderer','opengl');

ax1=axes(f,'Position',[0.055 0.20 0.405 0.69]);
ax2=axes(f,'Position',[0.500 0.20 0.405 0.69]);

cLim=[min(depthA),max(depthA)];
cmap=geology_cmap_cn_v4(256);

draw_mesh_panel_cn_v4(ax1,MU,depthU,G,Obs,cfg);
draw_mesh_panel_cn_v4(ax2,MA,depthAplot,G,Obs,cfg);

for ax=[ax1 ax2]
    colormap(ax,cmap);
    caxis(ax,cLim);
end

title(ax1,'(a) 均匀网格', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');
title(ax2,'(b) 自适应网格', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');

% 共用横向色标，避免两个色标挤压主图。
cb=colorbar(ax2,'southoutside');
cb.Position=[0.355 0.065 0.300 0.030];
cb.Label.String='煤层埋深 / m';
cb.Label.FontName=cfg.fontCN;
cb.Label.FontSize=cfg.fontAxis-0.2;
cb.FontName=cfg.fontCN;
cb.FontSize=cfg.fontAxis-0.4;

% 断层图例放在图外底部左侧，不覆盖网格。
annotation(f,'line',[0.085 0.125],[0.095 0.095], ...
    'Color',cfg.colFault,'LineWidth',1.6);
annotation(f,'textbox',[0.130 0.065 0.16 0.055], ...
    'String','断层迹线','EdgeColor','none', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontLegend, ...
    'VerticalAlignment','middle');

audit_figure_text_cn_v4(f,cfg);
export_png_pdf_cn_v4(f,outDir,'FIG02_MESH_COMPARE_CN',cfg,true);
close(f);

end

function draw_mesh_panel_cn_v4(ax,M,depth,G,Obs,cfg)

hold(ax,'on');

patch(ax,'Faces',M.T,'Vertices',M.P, ...
    'FaceVertexCData',depth, ...
    'FaceColor','interp', ...
    'EdgeColor',cfg.colMesh, ...
    'LineWidth',cfg.meshLW);

plot(ax,G.uc,G.vc,'-', ...
    'Color',cfg.colFault,'LineWidth',cfg.faultLW);

% 控制点仅作为辅助信息，尺寸统一减小。
scatter(ax,Obs.u,Obs.v,7,'k','filled', ...
    'MarkerEdgeColor',[0.90 0.90 0.90],'LineWidth',0.12);

uMin=min([M.P(:,1);G.uc(:)]);
uMax=max([M.P(:,1);G.uc(:)]);
vMin=min([M.P(:,2);G.vc(:)]);
vMax=max([M.P(:,2);G.vc(:)]);

% 重点显示断层所在的主要工作区域。
uPad=0.03*(uMax-uMin);
vPad=0.03*(vMax-vMin);
xlim(ax,[uMin-uPad,uMax+uPad]);
ylim(ax,[vMin-vPad,vMax+vPad]);

axis(ax,'equal');
style_axis_cn_v4(ax,cfg);

xlabel(ax,'横向坐标 / m');
ylabel(ax,'纵向坐标 / m');

set(ax,'Box','on','GridAlpha',0.06);
grid(ax,'off');

end

function fig03_tensor_cn_v4(outDir,cfg)

f=figure('Color','w','Units','centimeters', ...
    'Position',[1 1 cfg.singleWidthCM 9.4],'Renderer','opengl');

ax=axes(f,'Position',[0.07 0.30 0.86 0.64]);
hold(ax,'on');
axis(ax,'equal');
axis(ax,'off');
axis(ax,[-1.02 1.02 -1.05 1.05]);

% 断层曲线采用接近批准版的纵向弯曲形态。
s=linspace(-1.18,1.18,500);
xf=0.36*s+0.08*sin(2.6*s);
yf=s;
plot(ax,xf,yf,'-','Color',cfg.colFault,'LineWidth',1.9);

% 在曲线中部构造切向/法向。
s0=0.02;
x0=0.36*s0+0.08*sin(2.6*s0);
y0=s0;
dx=0.36+0.08*2.6*cos(2.6*s0);
tv=[dx 1]; tv=tv/norm(tv);
nv=[-tv(2) tv(1)];

th=linspace(0,2*pi,360);
E=[x0;y0]+tv(:)*(0.48*cos(th))+nv(:)*(0.16*sin(th));

patch(ax,E(1,:),E(2,:),[0.84 0.90 0.98], ...
    'FaceAlpha',0.65,'EdgeColor',cfg.colBlue,'LineWidth',0.95);

% 黑色虚线表示几何主方向。
plot(ax,[x0-0.66*tv(1),x0+0.66*tv(1)], ...
        [y0-0.66*tv(2),y0+0.66*tv(2)],'--', ...
        'Color',[0.15 0.15 0.15],'LineWidth',0.85);
plot(ax,[x0-0.48*nv(1),x0+0.48*nv(1)], ...
        [y0-0.48*nv(2),y0+0.48*nv(2)],'--', ...
        'Color',[0.15 0.15 0.15],'LineWidth',0.85);

% 蓝色：沿断层方向平滑增强。
quiver(ax,x0,y0, 0.40*tv(1), 0.40*tv(2),0, ...
    'Color',cfg.colBlue,'LineWidth',1.65,'MaxHeadSize',0.33);
quiver(ax,x0,y0,-0.40*tv(1),-0.40*tv(2),0, ...
    'Color',cfg.colBlue,'LineWidth',1.65,'MaxHeadSize',0.33);

% 绿色：跨断层方向平滑减弱。
quiver(ax,x0,y0, 0.27*nv(1), 0.27*nv(2),0, ...
    'Color',cfg.colGreen,'LineWidth',1.65,'MaxHeadSize',0.36);
quiver(ax,x0,y0,-0.27*nv(1),-0.27*nv(2),0, ...
    'Color',cfg.colGreen,'LineWidth',1.65,'MaxHeadSize',0.36);

plot(ax,x0,y0,'ko','MarkerFaceColor','k','MarkerSize',4.0);

% 文字全部放在数据之外的空白区域。
text(ax,-0.96,0.44,'断层法向', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',[0.12 0.12 0.12],'FontWeight','normal');

text(ax,0.45,0.78,'断层切向', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',[0.12 0.12 0.12],'FontWeight','normal');

text(ax,0.43,0.11,'沿断层方向', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',cfg.colBlue,'FontWeight','bold');
text(ax,0.43,0.00,'平滑增强', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',cfg.colBlue,'FontWeight','bold');

text(ax,0.32,-0.49,'跨断层方向', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',cfg.colGreen,'FontWeight','bold');
text(ax,0.32,-0.60,'平滑减弱', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',cfg.colGreen,'FontWeight','bold');

% 下部说明区：与主示意图分离，避免遮挡。
annotation(f,'line',[0.11 0.17],[0.205 0.205], ...
    'Color',cfg.colBlue,'LineWidth',1.5);
annotation(f,'textbox',[0.19 0.176 0.70 0.055], ...
    'String','沿断层方向平滑增强','EdgeColor','none', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontLegend);

annotation(f,'line',[0.11 0.17],[0.145 0.145], ...
    'Color',cfg.colGreen,'LineWidth',1.5);
annotation(f,'textbox',[0.19 0.116 0.70 0.055], ...
    'String','跨断层方向平滑减弱','EdgeColor','none', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontLegend);

annotation(f,'ellipse',[0.105 0.065 0.07 0.030], ...
    'FaceColor',[0.84 0.90 0.98],'EdgeColor',cfg.colBlue,'LineWidth',0.8);
annotation(f,'textbox',[0.19 0.045 0.70 0.055], ...
    'String','各向异性平滑等值线','EdgeColor','none', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontLegend);

audit_figure_text_cn_v4(f,cfg);
export_png_pdf_cn_v4(f,outDir,'FIG03_ANISOTROPIC_TENSOR_CN',cfg,true);
close(f);

end

function fig04_geological_cn_v4(outDir,N,Obs,M,G,cfg)

u=M.P(:,1);
v=M.P(:,2);
depth=N.TVD(:);

obsDepth=Obs.Elevation(:);
if median(obsDepth)<0 && median(depth)>0
    obsDepth=-obsDepth;
end

V=[u,v,depth];

fu=G.uc(:);
fv=G.vc(:);

FI=scatteredInterpolant(u,v,depth,'natural','nearest');
fd=FI(fu,fv);

tc=(M.P(M.T(:,1),:)+M.P(M.T(:,2),:)+M.P(M.T(:,3),:))/3;
dTri=distance_fault_cn_v4(tc,G);
nearFault=dTri<=cfg.c11MeshBand;

[uc0,vc0]=densest_fault_center_cn_v4(M.P,G,cfg.c11DenseRadius);

uL=clip_limits_cn_v4([uc0-cfg.c11LocalHalfU,uc0+cfg.c11LocalHalfU], ...
    [min(u),max(u)]);
vL=clip_limits_cn_v4([vc0-cfg.c11LocalHalfV,vc0+cfg.c11LocalHalfV], ...
    [min(v),max(v)]);

local=u>=uL(1)&u<=uL(2)&v>=vL(1)&v<=vL(2);
ld=depth(local);
zPad=max(8,0.10*(max(ld)-min(ld)+eps));
zL=[min(ld)-zPad,max(ld)+zPad];

f=figure('Color','w','Units','centimeters', ...
    'Position',[1 1 cfg.doubleWidthCM 7.25],'Renderer','opengl');

ax1=axes(f,'Position',[0.045 0.14 0.405 0.80]);
ax2=axes(f,'Position',[0.500 0.14 0.350 0.80]);

axesList=[ax1 ax2];

for ip=1:2

    ax=axesList(ip);
    hold(ax,'on');

    trisurf(M.T,u,v,depth,depth,'Parent',ax, ...
        'FaceColor','interp','EdgeColor','none','FaceAlpha',1.0);

    % 断层面只作为半透明解释面。
    surf(ax,[fu,fu],[fv,fv], ...
        [fd-cfg.c11FaultCurtainHalfDepth,fd+cfg.c11FaultCurtainHalfDepth], ...
        'FaceColor',[0.50 0.28 0.23], ...
        'FaceAlpha',0.17,'EdgeColor','none');

    plot3(ax,fu,fv,fd,'-', ...
        'Color',cfg.colFault,'LineWidth',cfg.faultLW);

    % 全区图弱化网格；局部图突出断层邻域网格。
    if ip==1
        eAlpha=0.18; lw=0.15;
    else
        eAlpha=0.58; lw=0.28;
    end

    patch(ax,'Faces',M.T(nearFault,:),'Vertices',V, ...
        'FaceColor','none','EdgeColor',cfg.colMesh, ...
        'EdgeAlpha',eAlpha,'LineWidth',lw);

    if ip==1
        in=true(height(Obs),1);
    else
        in=Obs.u>=uL(1)&Obs.u<=uL(2)&Obs.v>=vL(1)&Obs.v<=vL(2);
    end

    scatter3(ax,Obs.u(in),Obs.v(in),obsDepth(in), ...
        cfg.c11MarkerSize,'o', ...
        'MarkerFaceColor',[0.04 0.04 0.04], ...
        'MarkerEdgeColor','none');

    format_geology_axis_cn_v4(ax,cfg);

    if ip==1
        title(ax,'(a) 煤层面重建', ...
            'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');
    else
        xlim(ax,uL); ylim(ax,vL); zlim(ax,zL);
        title(ax,'(b) 断层邻域局部放大', ...
            'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');
    end

    colormap(ax,geology_cmap_cn_v4(256));
    caxis(ax,[min(depth),max(depth)]);

end

cb=colorbar(ax2);
cb.Position=[0.875 0.18 0.016 0.64];
cb.Label.String='煤层埋深 / m';
cb.Label.FontName=cfg.fontCN;
cb.Label.FontSize=cfg.fontAxis;
cb.FontName=cfg.fontCN;
cb.FontSize=cfg.fontAxis-0.3;

audit_figure_text_cn_v4(f,cfg);
exportgraphics(f,fullfile(outDir,'FIG04_GEOLOGICAL_SURFACE_CN.png'), ...
    'Resolution',cfg.rasterDPI);
close(f);

R=table(uc0,vc0,uL(1),uL(2),vL(1),vL(2), ...
    'VariableNames',{'CenterU','CenterV','Umin','Umax','Vmin','Vmax'});
writetable(R,fullfile(outDir,'FIG04_LOCAL_WINDOW.csv'));

end

function format_geology_axis_cn_v4(ax,cfg)

view(ax,[cfg.c11ViewAz cfg.c11ViewEl]);
camproj(ax,'perspective');

axis(ax,'tight');
axis(ax,'vis3d');
daspect(ax,[1 1 cfg.c11VerticalExaggeration]);

set(ax,'ZDir','reverse', ...
    'FontName',cfg.fontCN, ...
    'FontSize',cfg.fontAxis, ...
    'LineWidth',cfg.axisLW, ...
    'TickDir','out', ...
    'Box','off');

grid(ax,'off');

xlabel(ax,'横向坐标 / m','FontName',cfg.fontCN,'FontSize',cfg.fontAxis);
ylabel(ax,'纵向坐标 / m','FontName',cfg.fontCN,'FontSize',cfg.fontAxis);
zlabel(ax,'煤层埋深 / m','FontName',cfg.fontCN,'FontSize',cfg.fontAxis);

camlight(ax,'headlight');
lighting(ax,'gouraud');
material(ax,'dull');

end

function fig07_scaling_cn_v4(outDir,T,cfg)

req={'Scale','UniformNodes','AdaptiveNodes','NodeSavingPct', ...
     'NodeSavingStdPct','IdealSavingPct'};
assert_table_vars_cn_v4(T,req,'二维尺度扩展汇总表');

f=figure('Color','w','Units','centimeters', ...
    'Position',[1 1 cfg.doubleWidthCM 5.8],'Renderer','opengl');

ax1=axes(f,'Position',[0.075 0.19 0.390 0.72]);
ax2=axes(f,'Position',[0.565 0.19 0.390 0.72]);

loglog(ax1,T.Scale,T.UniformNodes,'-o', ...
    'Color',cfg.colBlue,'LineWidth',cfg.lineLW, ...
    'MarkerSize',3.8,'MarkerFaceColor',cfg.colBlue);
hold(ax1,'on');

loglog(ax1,T.Scale,T.AdaptiveNodes,'-s', ...
    'Color',cfg.colOrange,'LineWidth',cfg.lineLW, ...
    'MarkerSize',3.8,'MarkerFaceColor',cfg.colOrange);

style_axis_cn_v4(ax1,cfg);
set(ax1,'XTick',T.Scale,'XTickLabel',compose('%d倍',T.Scale), ...
    'XMinorGrid','off','YMinorGrid','off','Box','off');
grid(ax1,'on'); ax1.GridAlpha=0.09;

xlabel(ax1,'区域线性尺度');
ylabel(ax1,'达到目标精度的节点数');
title(ax1,'(a) 等精度节点规模', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');

legend(ax1,{'均匀网格','自适应网格'}, ...
    'Location','northwest','Box','off','FontSize',cfg.fontLegend);

errorbar(ax2,T.Scale,T.NodeSavingPct,T.NodeSavingStdPct, ...
    'o-','Color',cfg.colBlue,'LineWidth',cfg.lineLW, ...
    'MarkerSize',3.8,'MarkerFaceColor',cfg.colBlue);
hold(ax2,'on');

plot(ax2,T.Scale,T.IdealSavingPct,'--', ...
    'Color',[0.43 0.43 0.43],'LineWidth',0.95);

style_axis_cn_v4(ax2,cfg);
set(ax2,'XTick',T.Scale,'XTickLabel',compose('%d倍',T.Scale), ...
    'Box','off');
grid(ax2,'on'); ax2.GridAlpha=0.09;

xlabel(ax2,'区域线性尺度');
ylabel(ax2,'节点减少率 / %');
ylim(ax2,[70 98]);

title(ax2,'(b) 节点减少率', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');

legend(ax2,{'3组试验均值±标准差','两尺度估计'}, ...
    'Location','southeast','Box','off','FontSize',cfg.fontLegend);

audit_figure_text_cn_v4(f,cfg);
export_png_pdf_cn_v4(f,outDir,'FIG07_2D_SCALING_CN',cfg,true);
close(f);

end

function fig08_cutaway_cn_v4(outDir,MU,MF,Match,cfg3d,cfg)

assert_table_vars_cn_v4(Match,{ ...
    'UniformFaultNormalH','FittedFaultNormalH', ...
    'FittedBackgroundNormalH','FittedNormalSpacingRatio'},'三维匹配结果');

hU=Match.UniformFaultNormalH(1);
hF=Match.FittedFaultNormalH(1);
hB=Match.FittedBackgroundNormalH(1);
ratio=Match.FittedNormalSpacingRatio(1);

f=figure('Color','w','Units','centimeters', ...
    'Position',[1 1 cfg.doubleWidthCM 6.8],'Renderer','opengl');

ax1=axes(f,'Position',[0.040 0.12 0.435 0.82]);
ax2=axes(f,'Position',[0.525 0.12 0.435 0.82]);

draw_cutaway_cn_v4(ax1,MU,cfg3d,cfg);
draw_cutaway_cn_v4(ax2,MF,cfg3d,cfg);

title(ax1,sprintf('(a) 均匀网格（%d节点）',size(MU.P,1)), ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');
title(ax2,sprintf('(b) 断层拟合分级网格（%d节点）',size(MF.P,1)), ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');

% 尺度数字用极短说明，放在图外上沿，不盖住剖切面。
annotation(f,'textbox',[0.055 0.885 0.30 0.045], ...
    'String',sprintf('断层邻域尺度 %.1f m',hU), ...
    'EdgeColor','none','BackgroundColor','none', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontLegend);

annotation(f,'textbox',[0.555 0.855 0.36 0.075], ...
    'String',{sprintf('断层 %.1f m；背景 %.1f m',hF,hB), ...
              sprintf('背景/断层尺度比 %.2f',ratio)}, ...
    'EdgeColor','none','BackgroundColor','none', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontLegend);

audit_figure_text_cn_v4(f,cfg);
exportgraphics(f,fullfile(outDir,'FIG08_3D_CUTAWAY_CN.png'), ...
    'Resolution',cfg.rasterDPI);
close(f);

end

function draw_cutaway_cn_v4(ax,M,cfg3d,cfg)

dims=M.Dims;
nx=dims(1); ny=dims(2); nz=dims(3);

X=reshape(M.P(:,1),dims);
Y=reshape(M.P(:,2),dims);
Z=reshape(M.P(:,3),dims);

hold(ax,'on');

k0=round((nz+1)/2);
j0=round((ny+1)/2);

% 水平剖面
XH=squeeze(X(:,:,k0));
YH=squeeze(Y(:,:,k0));
ZH=squeeze(Z(:,:,k0));

surf(ax,XH,YH,ZH, ...
    'FaceColor',[0.72 0.84 0.90], ...
    'FaceAlpha',cfg.ff3dPlaneAlpha,'EdgeColor','none');

for j=1:ny
    plot3(ax,XH(:,j),YH(:,j),ZH(:,j),'-', ...
        'Color',[0.25 0.35 0.43],'LineWidth',0.34);
end
for i=1:nx
    plot3(ax,XH(i,:),YH(i,:),ZH(i,:),'-', ...
        'Color',[0.25 0.35 0.43],'LineWidth',0.34);
end

% 垂直剖面
XV=squeeze(X(:,j0,:));
YV=squeeze(Y(:,j0,:));
ZV=squeeze(Z(:,j0,:));

surf(ax,XV,YV,ZV, ...
    'FaceColor',[0.90 0.82 0.69], ...
    'FaceAlpha',cfg.ff3dPlaneAlpha,'EdgeColor','none');

for k=1:nz
    plot3(ax,XV(:,k),YV(:,k),ZV(:,k),'-', ...
        'Color',[0.40 0.31 0.25],'LineWidth',0.34);
end
for i=1:nx
    plot3(ax,XV(i,:),YV(i,:),ZV(i,:),'-', ...
        'Color',[0.40 0.31 0.25],'LineWidth',0.34);
end

% 半透明断层面
yy=linspace(0,cfg3d.L(2),110);
zz=linspace(0,cfg3d.L(3),82);
[YF,ZF]=meshgrid(yy,zz);
XF=fault_x_cn_v4(YF,ZF,cfg3d);

surf(ax,XF,YF,ZF, ...
    'FaceColor',[0.72 0.20 0.17], ...
    'FaceAlpha',cfg.ff3dFaultAlpha,'EdgeColor','none');

% 剖面与断层交线
zmid=median(ZH(:));
yv=linspace(0,cfg3d.L(2),500);
xh=fault_x_cn_v4(yv,zmid*ones(size(yv)),cfg3d);
plot3(ax,xh,yv,zmid*ones(size(yv)),'-', ...
    'Color',cfg.colFault,'LineWidth',1.30);

ymid=median(YV(:));
zv=linspace(0,cfg3d.L(3),500);
xv=fault_x_cn_v4(ymid*ones(size(zv)),zv,cfg3d);
plot3(ax,xv,ymid*ones(size(zv)),zv,'-', ...
    'Color',cfg.colFault,'LineWidth',1.30);

draw_box_cn_v4(ax,cfg3d.L);

view(ax,[cfg.ff3dViewAz cfg.ff3dViewEl]);
camproj(ax,'perspective');
axis(ax,'equal');
axis(ax,'vis3d');

xlim(ax,[0 cfg3d.L(1)]);
ylim(ax,[0 cfg3d.L(2)]);
zlim(ax,[0 cfg3d.L(3)]);

set(ax,'FontName',cfg.fontCN,'FontSize',cfg.fontAxis, ...
    'LineWidth',cfg.axisLW,'TickDir','out','Box','off');

xlabel(ax,'横向坐标 / m');
ylabel(ax,'纵向坐标 / m');
zlabel(ax,'垂向坐标 / m');

grid(ax,'off');
camlight(ax,'headlight');
lighting(ax,'gouraud');
material(ax,'dull');

end

function fig09_evidence_cn_v4(outDir,M,A,U,F,cfg)

assert_table_vars_cn_v4(M,{ ...
    'UniformNodes','FittedNodes', ...
    'UniformTetrahedra','FittedTetrahedra', ...
    'UniformNNZ','FittedNNZ'},'三维匹配结果');

assert_table_vars_cn_v4(A, ...
    {'Method','FaultRMSE','GlobalRMSE','BackgroundRMSE'},'分级消融结果');

assert_table_vars_cn_v4(U, ...
    {'Nodes','MinTetQuality','P01TetQuality'},'均匀网格曲线');

assert_table_vars_cn_v4(F, ...
    {'Nodes','MinTetQuality','P01TetQuality'},'分级网格曲线');

names=string(A.Method);
iUG=find(contains(lower(names),'ungraded'),1);
iGR=find(contains(lower(names),'graded') & ~contains(lower(names),'ungraded'),1);

if isempty(iUG)||isempty(iGR)
    if height(A)>=3
        iUG=2; iGR=3;
    else
        error('无法识别未分级/分级消融行。');
    end
end

ab=[ ...
    A.FaultRMSE([iUG iGR]), ...
    A.GlobalRMSE([iUG iGR]), ...
    A.BackgroundRMSE([iUG iGR])];

f=figure('Color','w','Units','centimeters', ...
    'Position',[1 1 cfg.doubleWidthCM 8.8],'Renderer','opengl');

% 手工布局，避免 tiledlayout 对下方曲线图产生过度压缩。
ax1=axes(f,'Position',[0.075 0.59 0.38 0.33]);
ax2=axes(f,'Position',[0.555 0.59 0.38 0.33]);
ax3=axes(f,'Position',[0.075 0.12 0.86 0.34]);

% (a) 等精度资源占比
ratios=100*[ ...
    M.FittedNodes(1)/M.UniformNodes(1), ...
    M.FittedTetrahedra(1)/M.UniformTetrahedra(1), ...
    M.FittedNNZ(1)/M.UniformNNZ(1)];
saving=100-ratios;

b=bar(ax1,1:3,ratios,0.48);
b.FaceColor=cfg.colOrange;
b.EdgeColor='none';

style_axis_cn_v4(ax1,cfg);
set(ax1,'XTick',1:3,'XTickLabel',{'节点','四面体','非零元'}, ...
    'Box','off');
ylabel(ax1,'占均匀网格规模 / %');
ylim(ax1,[0 31]);
grid(ax1,'on'); ax1.YGrid='on'; ax1.XGrid='off'; ax1.GridAlpha=0.08;

for j=1:3
    text(ax1,j,ratios(j)+0.75, ...
        sprintf('%.1f%%',ratios(j)), ...
        'HorizontalAlignment','center','VerticalAlignment','bottom', ...
        'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation);
    text(ax1,j,ratios(j)-1.6, ...
        sprintf('减少%.1f%%',saving(j)), ...
        'HorizontalAlignment','center','VerticalAlignment','top', ...
        'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation-0.5, ...
        'Color',[0.30 0.30 0.30]);
end

title(ax1,'(a) 等精度资源占比', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');

% (b) 断层法向分级作用
bb=bar(ax2,ab.','grouped');
bb(1).FaceColor=cfg.colGray;
bb(2).FaceColor=cfg.colOrange;
bb(1).EdgeColor='none';
bb(2).EdgeColor='none';

style_axis_cn_v4(ax2,cfg);
set(ax2,'XTickLabel',{'断层邻域','全区','背景'},'Box','off');
ylabel(ax2,'均方根误差 / m');
grid(ax2,'on'); ax2.YGrid='on'; ax2.XGrid='off'; ax2.GridAlpha=0.08;

gain=100*(ab(1,:)-ab(2,:))./ab(1,:);
yMax=max(ab(:))*1.18;
ylim(ax2,[0 yMax]);

for j=1:3
    text(ax2,j,max(ab(:,j))+0.022*yMax, ...
        sprintf('%.1f%%',gain(j)), ...
        'HorizontalAlignment','center','VerticalAlignment','bottom', ...
        'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation);
end

legend(ax2,{'未分级','分级'}, ...
    'Location','northeast','Box','off','FontSize',cfg.fontLegend);
title(ax2,'(b) 断层法向分级作用', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');

% (c) 三维网格质量
semilogx(ax3,U.Nodes,U.MinTetQuality,'-o', ...
    'Color',cfg.colBlue,'LineWidth',1.10, ...
    'MarkerSize',3.0,'MarkerFaceColor',cfg.colBlue);
hold(ax3,'on');

semilogx(ax3,F.Nodes,F.MinTetQuality,'-s', ...
    'Color',cfg.colOrange,'LineWidth',1.10, ...
    'MarkerSize',3.0,'MarkerFaceColor',cfg.colOrange);

semilogx(ax3,F.Nodes,F.P01TetQuality,'--s', ...
    'Color',cfg.colOrange,'LineWidth',0.85, ...
    'MarkerSize',2.6,'MarkerFaceColor','w');

style_axis_cn_v4(ax3,cfg);
set(ax3,'Box','off');
xlabel(ax3,'节点数');
ylabel(ax3,'平均比值质量');
grid(ax3,'on'); ax3.GridAlpha=0.06;
ax3.XMinorGrid='off'; ax3.YMinorGrid='off';

maxNode=max([U.Nodes;F.Nodes]);
minNode=min([U.Nodes;F.Nodes]);

xlim(ax3,[0.90*minNode,1.95*maxNode]);
labelX=1.12*maxNode;

text(ax3,labelX,U.MinTetQuality(end), ...
    '均匀网格最小质量', ...
    'HorizontalAlignment','left','VerticalAlignment','middle', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',cfg.colBlue);

text(ax3,labelX,F.P01TetQuality(end)+0.018, ...
    '分级网格1%分位质量', ...
    'HorizontalAlignment','left','VerticalAlignment','bottom', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',cfg.colOrange);

text(ax3,labelX,F.MinTetQuality(end)-0.014, ...
    '分级网格最小质量', ...
    'HorizontalAlignment','left','VerticalAlignment','top', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontAnnotation, ...
    'Color',cfg.colOrange);

title(ax3,'(c) 三维网格质量', ...
    'FontName',cfg.fontCN,'FontSize',cfg.fontPanel,'FontWeight','normal');

audit_figure_text_cn_v4(f,cfg);
export_png_pdf_cn_v4(f,outDir,'FIG09_3D_EVIDENCE_CN',cfg,true);
close(f);

end

function audit_figure_text_cn_v4(f,cfg)
% Detect the exact English/mixed labels that caused the previous version to
% look inconsistent. Mathematical unit symbols (m, %, x/y tick values) are
% intentionally not forbidden.

H=findall(f,'-property','String');

found={};

for k=1:numel(H)

    try
        s=H(k).String;
    catch
        continue;
    end

    ss=flatten_string_cn_v4(s);

    for j=1:numel(cfg.forbiddenTerms)
        term=cfg.forbiddenTerms{j};

        if contains(ss,term,'IgnoreCase',false)
            found{end+1}=sprintf('%s -> "%s"',term,ss); %#ok<AGROW>
        end
    end
end

if ~isempty(found)
    error('图件可见文字中仍存在禁用英文/缩写：%s',strjoin(unique(found),' | '));
end

end


function s=flatten_string_cn_v4(x)

if ischar(x)
    s=x;
elseif isstring(x)
    s=strjoin(cellstr(x(:).'),' ');
elseif iscell(x)
    c=cell(size(x));
    for k=1:numel(x)
        c{k}=flatten_string_cn_v4(x{k});
    end
    s=strjoin(c,' ');
else
    s='';
end

end


% =========================================================================
% COMMON STYLE
% =========================================================================
function style_axis_cn_v4(ax,cfg)

set(ax, ...
    'FontName',cfg.fontCN, ...
    'FontSize',cfg.fontAxis, ...
    'LineWidth',cfg.axisLW, ...
    'TickDir','out', ...
    'Box','off', ...
    'Layer','top');

end

function export_png_pdf_cn_v4(f,outDir,stem,cfg,makePDF)

audit_figure_text_cn_v4(f,cfg);

exportgraphics(f,fullfile(outDir,[stem '.png']), ...
    'Resolution',cfg.rasterDPI);

if makePDF
    try
        exportgraphics(f,fullfile(outDir,[stem '.pdf']), ...
            'ContentType','vector');
    catch ME
        warning('矢量 PDF 导出失败，仅保留 PNG：%s',ME.message);
    end
end

end


function C=geology_cmap_cn_v4(n)

if nargin<1, n=256; end

A=[ ...
    0.13 0.30 0.50;
    0.13 0.48 0.61;
    0.29 0.63 0.59;
    0.57 0.72 0.51;
    0.81 0.69 0.39;
    0.70 0.46 0.28];

x=linspace(0,1,size(A,1));
xi=linspace(0,1,n);

C=[ ...
    interp1(x,A(:,1),xi,'pchip').', ...
    interp1(x,A(:,2),xi,'pchip').', ...
    interp1(x,A(:,3),xi,'pchip').'];

C=max(0,min(1,C));

end


% =========================================================================
% SEARCH / DATA
% =========================================================================
function out=find_latest_run_cn_v4(rootDir,pattern,requiredFile)

out='';

D=dir(fullfile(rootDir,pattern));
D=D([D.isdir]);

try
    R=dir(fullfile(rootDir,'**',pattern));
    R=R([R.isdir]);
    D=[D(:);R(:)]; %#ok<AGROW>
catch
end

if isempty(D), return; end

keys=strcat({D.folder},filesep,{D.name});
[~,ia]=unique(keys,'stable');
D=D(ia);

[~,ord]=sort([D.datenum],'descend');

for ii=ord
    p=fullfile(D(ii).folder,D(ii).name);
    if isfile(fullfile(p,requiredFile))
        out=p;
        return;
    end
end

end


function out=find_latest_scaling_cn_v4(rootDir)

out='';

D=dir(fullfile(rootDir,'out_PAPER_SCALING_FIGURES_*'));
D=D([D.isdir]);

try
    R=dir(fullfile(rootDir,'**','out_PAPER_SCALING_FIGURES_*'));
    R=R([R.isdir]);
    D=[D(:);R(:)]; %#ok<AGROW>
catch
end

if isempty(D), return; end

keys=strcat({D.folder},filesep,{D.name});
[~,ia]=unique(keys,'stable');
D=D(ia);

[~,ord]=sort([D.datenum],'descend');

for ii=ord
    p=fullfile(D(ii).folder,D(ii).name);
    if isfile(fullfile(p,'PAPER_SCALING_VALUES.csv'))
        out=p; return;
    end
end

end


function dataDir=find_c11_data_cn_v4(scriptDir,manualDir)

req={'TVD_C11.dat','Dingji_t11_plg.dat'};

if ~isempty(manualDir) && c11_dir_ok_cn_v4(manualDir,req)
    dataDir=manualDir; return;
end

envDir=getenv('C11_DATA_DIR');
if ~isempty(envDir) && c11_dir_ok_cn_v4(envDir,req)
    dataDir=envDir; return;
end

p1=fileparts(scriptDir);
p2=fileparts(p1);
p3=fileparts(p2);
roots={scriptDir,pwd,p1,p2,p3};

for i=1:numel(roots)
    if isempty(roots{i}), continue; end

    cands={fullfile(roots{i},'data_C11'),roots{i}};

    for j=1:numel(cands)
        if c11_dir_ok_cn_v4(cands{j},req)
            dataDir=cands{j}; return;
        end
    end
end

try
    H=dir(fullfile(p2,'**','TVD_C11.dat'));
    for i=1:numel(H)
        if c11_dir_ok_cn_v4(H(i).folder,req)
            dataDir=H(i).folder; return;
        end
    end
catch
end

dataDir='';

end


function tf=c11_dir_ok_cn_v4(d,req)

tf=isfolder(d);

if ~tf, return; end

for k=1:numel(req)
    tf=tf && isfile(fullfile(d,req{k}));
end

end


function require_function_cn_v4(name)

if exist(name,'file')~=2
    error('完整代码包缺少程序：%s.m',name);
end

end


function copy_engine_figure_cn_v4(srcPNG,srcPDF,dstPNG,dstPDF)

if ~isfile(srcPNG)
    error('实例正式程序未生成所需图件：%s',srcPNG);
end

copyfile(srcPNG,dstPNG,'f');

if isfile(srcPDF)
    copyfile(srcPDF,dstPDF,'f');
end

end


% =========================================================================
% AUDIT
% =========================================================================
function audit_c11_schema_cn_v4(N,Obs,MU,MA,G)

assert_table_vars_cn_v4(N,{'NodeID','X','Y','TVD'},'实例节点表');
assert_table_vars_cn_v4(Obs,{'ID','X','Y','u','v','Elevation'},'实例控制点表');

if height(N)~=size(MA.P,1)
    error('实例节点表与自适应网格节点数不一致。');
end

if size(MU.P,2)~=2 || size(MA.P,2)~=2
    error('实例网格必须使用二维局部坐标。');
end

for nm={'uc','vc','segA','segV'}
    if ~isfield(G,nm{1})
        error('断层几何缺少字段：%s',nm{1});
    end
end

end


function audit_ff3d_cn_v4(C)

M=C.Match;

assert_table_vars_cn_v4(M,{ ...
    'Matched','UniformNodes','FittedNodes','NodeSavingPct', ...
    'UniformTetrahedra','FittedTetrahedra','TetSavingPct', ...
    'UniformNNZ','FittedNNZ','NNZSavingPct', ...
    'FittedMinTetQuality','FittedP01TetQuality', ...
    'UniformFaultNormalH','FittedFaultNormalH', ...
    'FittedBackgroundNormalH','FittedNormalSpacingRatio'}, ...
    '三维匹配结果');

if ~logical(M.Matched(1))
    error('三维结果未达到冻结的等精度目标，禁止生成资源节省图。');
end

if any([M.NodeSavingPct(1),M.TetSavingPct(1),M.NNZSavingPct(1)]<=0)
    error('三维资源节省率必须为正。');
end

if M.FittedMinTetQuality(1)<0.10
    warning('断层拟合网格最小质量低于 0.10，请在论文中谨慎解释。');
end

end


function audit_scaling_cn_v4(T)

assert_table_vars_cn_v4(T,{ ...
    'Scale','UniformNodes','AdaptiveNodes','NodeSavingPct', ...
    'NodeSavingStdPct','NNZSavingPct','GlobalRMSEChangePct','IdealSavingPct'}, ...
    '二维尺度扩展表');

end


function assert_table_vars_cn_v4(T,names,label)

miss=names(~ismember(names,T.Properties.VariableNames));

if ~isempty(miss)
    error('%s 缺少字段：%s',label,strjoin(miss,', '));
end

end


function [audit,manifest]=safe_plot_cn_v4(name,fn,audit,manifest,cfg)

try
    fn();
    fprintf('  [通过] %s\n',name);
    audit{end+1}=audit_item_cn_v4(name,true,'通过');
    manifest{end+1}=name;
catch ME
    fprintf(2,'  [失败] %s：%s\n',name,ME.message);
    audit{end+1}=audit_item_cn_v4(name,false,ME.message);
end

end


function R=audit_item_cn_v4(name,pass,msg)

R=struct('Name',name,'Passed',logical(pass),'Message',char(msg));

end


function write_final_audit_cn_v4(outDir,audit,manifest,C,ScaleT,N,Obs,cfg)

fid=fopen(fullfile(outDir,'FINAL_FIGURE_AUDIT.txt'),'w');

fprintf(fid,'《煤田地质与勘探》最终中文图件审计\n');
fprintf(fid,'===================================\n');
fprintf(fid,'中文字体：%s\n\n',cfg.fontCN);

for k=1:numel(audit)
    R=audit{k};
    fprintf(fid,'%-12s | 通过=%d | %s\n',R.Name,R.Passed,R.Message);
end

fprintf(fid,'\n实例数据\n');
fprintf(fid,'--------\n');
fprintf(fid,'煤层面节点数：%d\n',height(N));
fprintf(fid,'控制点数：%d\n',height(Obs));

M=C.Match;

fprintf(fid,'\n三维等精度结果\n');
fprintf(fid,'--------------\n');
fprintf(fid,'均匀网格节点数：%.0f\n',M.UniformNodes(1));
fprintf(fid,'分级网格节点数：%.0f\n',M.FittedNodes(1));
fprintf(fid,'节点减少率：%.1f %%\n',M.NodeSavingPct(1));
fprintf(fid,'四面体减少率：%.1f %%\n',M.TetSavingPct(1));
fprintf(fid,'非零元减少率：%.1f %%\n',M.NNZSavingPct(1));
fprintf(fid,'分级网格最小质量：%.3f\n',M.FittedMinTetQuality(1));
fprintf(fid,'断层邻域尺度：%.1f m\n',M.FittedFaultNormalH(1));
fprintf(fid,'背景区域尺度：%.1f m\n',M.FittedBackgroundNormalH(1));
fprintf(fid,'背景/断层尺度比：%.2f\n',M.FittedNormalSpacingRatio(1));

fprintf(fid,'\n二维尺度扩展\n');
fprintf(fid,'------------\n');

for k=1:height(ScaleT)
    fprintf(fid,'%g倍尺度：节点减少 %.1f %%；非零元减少 %.1f %%；全区误差变化 %.1f %%\n', ...
        ScaleT.Scale(k),ScaleT.NodeSavingPct(k), ...
        ScaleT.NNZSavingPct(k),ScaleT.GlobalRMSEChangePct(k));
end

fprintf(fid,'\n最终生成图号\n');
fprintf(fid,'------------\n');

for k=1:numel(manifest)
    fprintf(fid,'%s\n',manifest{k});
end

fclose(fid);

V=table( ...
    M.UniformNodes(1),M.FittedNodes(1),M.NodeSavingPct(1), ...
    M.UniformTetrahedra(1),M.FittedTetrahedra(1),M.TetSavingPct(1), ...
    M.UniformNNZ(1),M.FittedNNZ(1),M.NNZSavingPct(1), ...
    M.FittedMinTetQuality(1),M.FittedP01TetQuality(1), ...
    M.UniformFaultNormalH(1),M.FittedFaultNormalH(1), ...
    M.FittedBackgroundNormalH(1),M.FittedNormalSpacingRatio(1), ...
    'VariableNames',{ ...
    'UniformNodes','FittedNodes','NodeSavingPct', ...
    'UniformTetrahedra','FittedTetrahedra','TetSavingPct', ...
    'UniformNNZ','FittedNNZ','NNZSavingPct', ...
    'FittedMinTetQuality','FittedP01TetQuality', ...
    'UniformFaultNormalH','FittedFaultNormalH', ...
    'FittedBackgroundNormalH','FittedNormalSpacingRatio'});

writetable(V,fullfile(outDir,'FINAL_NUMERICAL_SUMMARY.csv'));

end


% =========================================================================
% GEOMETRY HELPERS
% =========================================================================
function d=distance_fault_cn_v4(q,G)

nq=size(q,1);
d2=inf(nq,1);

for j=1:size(G.segA,1)

    a=G.segA(j,:);
    w=G.segV(j,:);
    ww=sum(w.^2);

    if ww<=eps, continue; end

    qa=q-repmat(a,nq,1);
    tau=(qa*w.')/ww;
    tau=max(0,min(1,tau));

    proj=repmat(a,nq,1)+tau*w;
    rr=q-proj;

    d2=min(d2,sum(rr.^2,2));

end

d=sqrt(d2);

end


function [uc0,vc0]=densest_fault_center_cn_v4(P,G,R)

fu=G.uc(:);
fv=G.vc(:);

score=zeros(numel(fu),1);

for k=1:numel(fu)
    score(k)=sum((P(:,1)-fu(k)).^2+(P(:,2)-fv(k)).^2<=R^2);
end

iLo=max(1,round(0.08*numel(fu)));
iHi=min(numel(fu),round(0.92*numel(fu)));

[~,ii]=max(score(iLo:iHi));
idx=iLo+ii-1;

uc0=fu(idx);
vc0=fv(idx);

end


function lim=clip_limits_cn_v4(lim,domain)

w=diff(lim);

if lim(1)<domain(1)
    lim=lim+(domain(1)-lim(1));
end

if lim(2)>domain(2)
    lim=lim-(lim(2)-domain(2));
end

lim(1)=max(lim(1),domain(1));
lim(2)=min(lim(2),domain(2));

if diff(lim)<0.75*w
    lim=domain;
end

end


function x=fault_x_cn_v4(y,z,cfg3d)

x=cfg3d.faultX0 ...
    + cfg3d.faultAmpY*sin(2*pi*y/cfg3d.L(2)) ...
    + cfg3d.faultAmpZ*sin(2*pi*z/cfg3d.L(3)+cfg3d.faultPhaseZ);

end


function draw_box_cn_v4(ax,L)

V=[ ...
    0 0 0;
    L(1) 0 0;
    L(1) L(2) 0;
    0 L(2) 0;
    0 0 L(3);
    L(1) 0 L(3);
    L(1) L(2) L(3);
    0 L(2) L(3)];

E=[ ...
    1 2;2 3;3 4;4 1;
    5 6;6 7;7 8;8 5;
    1 5;2 6;3 7;4 8];

for k=1:size(E,1)
    plot3(ax,V(E(k,:),1),V(E(k,:),2),V(E(k,:),3), ...
        '-','Color',[0.66 0.66 0.66],'LineWidth',0.32);
end

end
