function outDir = FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2
% FAULT_AFEM_3D_FAULTFITTED_V1_FIX1
% =========================================================================
% TRUE 3-D FAULT-FITTED TETRAHEDRAL MATCHED-ACCURACY BENCHMARK
%
% Single-file MATLAB program. No external data or helper files are required.
%
% PURPOSE
% -------
% This benchmark is designed to answer one specific paper-facing question:
%
%   At the same prescribed fault-neighborhood reconstruction accuracy,
%   can a fault-fitted graded 3-D tetrahedral discretization use fewer
%   degrees of freedom / tetrahedra / sparse-matrix nonzeros than a
%   globally uniform 3-D tetrahedral discretization?
%
% IMPORTANT NUMERICAL DESIGN
% --------------------------
% 1) NO adaptive point insertion + global Delaunay retriangulation.
% 2) Uniform and fault-fitted meshes use the SAME deterministic 6-tetrahedron
%    subdivision of every structured hexahedral cell.
% 3) The fault-fitted mesh is generated in a computational coordinate
%       (r,y,z),  r in [-1,1],
%    with r=0 mapped exactly to the curved fault surface x=x_f(y,z).
% 4) A smooth sinh grading concentrates r-layers near r=0 while keeping
%    coarse layers away from the fault.
% 5) Every mesh is independently audited for tetrahedron volume and
%    mean-ratio quality; no tetrahedron is deleted after construction.
% 6) The same observations, same fault-aware regularization tensor and same
%    c0 selected from sparse-observation CV are used by BOTH mesh families.
% 7) The matched target is frozen from the uniform family:
%
%       E_tar = matchTolerance * min RMSE_fault(uniform).
%
%    We then find the MINIMUM-NODE passing mesh in each family.
%
% PHYSICAL MODEL
% --------------
% Unknown scalar field m(x,y,z) in a 3-D rectangular domain.  The model
% contains a smooth background and a narrow transition across a curved fault.
% The regularization tensor weakens smoothing in the local fault-normal
% direction while retaining tangential smoothing.
%
% OUTPUTS
% -------
%   FAULTFITTED3D_UNIFORM_CURVE.csv
%   FAULTFITTED3D_FITTED_CURVE.csv
%   FAULTFITTED3D_ALL_CURVES.csv
%   FAULTFITTED3D_MATCHED_ACCURACY.csv
%   FAULTFITTED3D_MESH_QUALITY.csv
%   FAULTFITTED3D_ABLATION.csv
%   FAULTFITTED3D_THEORY.csv
%   FAULTFITTED3D_CV.csv
%   FAULTFITTED3D_LATEX_MACROS.tex
%   FAULTFITTED3D_MATCHED_TABLE.tex
%   FAULTFITTED3D_PAPER_SNIPPET.tex
%   FAULTFITTED3D_SUMMARY.txt
%   FAULTFITTED3D_STATE.mat
%
%   FIG_FF3D_01_truth_fault_slices.png
%   FIG_FF3D_02_matched_meshes.png
%   FIG_FF3D_03_accuracy_nodes.png
%   FIG_FF3D_04_matched_resources.png
%   FIG_FF3D_05_mesh_quality.png
%   FIG_FF3D_06_crosssection_grading.png
%   FIG_FF3D_07_cv_c0.png
%
% RUN
% ---
%   >> FAULT_AFEM_3D_FAULTFITTED_V1_FIX1
%
% =========================================================================

clc;
close all;

cfg = default_cfg_ff3d();
rng(cfg.seed,'twister');

tag = datestr(now,'yyyymmdd_HHMMSS');
outDir = fullfile(pwd,['out_FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2_' tag]);
if ~exist(outDir,'dir')
    mkdir(outDir);
end

fprintf('\n============================================================\n');
fprintf('FAULT_AFEM_3D_FAULTFITTED_V1_FIX1\n');
fprintf('true 3-D fault-fitted tetrahedral matched-accuracy benchmark\n');
fprintf('Output: %s\n',outDir);
fprintf('============================================================\n');

% -------------------------------------------------------------------------
% 1. Synthetic observations and independent test points.
% -------------------------------------------------------------------------
fprintf('\n[1/7] Generating sparse 3-D observations and test points ...\n');
obs = make_observations_ff3d(cfg);
test = make_test_points_ff3d(cfg);

fprintf('  observations : %d\n',size(obs.xyz,1));
fprintf('  test points  : %d\n',size(test.xyz,1));
fprintf('  fault test   : %d\n',nnz(test.faultMask));
fprintf('  background   : %d\n',nnz(test.bgMask));

% -------------------------------------------------------------------------
% 2. Select c0 once from sparse-observation CV on a fixed common mesh.
% -------------------------------------------------------------------------
fprintf('\n[2/7] Selecting c0 from sparse-observation CV ...\n');
Mcv = make_uniform_mesh_ff3d(cfg,cfg.cvGrid);
Kcv = assemble_fault_stiffness_ff3d(Mcv,cfg);
Hcv = build_interp_matrix_ff3d(Mcv,obs.xyz,cfg);
CV = select_c0_cv_ff3d(Mcv,Kcv,Hcv,obs,cfg);
c0 = CV.value;

fprintf('  selected c0 = %.8g | raw = %.8g | CV MSE %.6f -> %.6f\n', ...
    c0,CV.rawValue,CV.rawMSE,CV.selectedMSE);

TCV = table(CV.grid,CV.meanMSE,CV.seMSE, ...
    'VariableNames',{'c0','MeanMSE','SEMSE'});
writetable(TCV,fullfile(outDir,'FAULTFITTED3D_CV.csv'));

% -------------------------------------------------------------------------
% 3. Uniform structured tetrahedral family.
% -------------------------------------------------------------------------
fprintf('\n[3/7] Uniform structured tetrahedral family ...\n');
nU = size(cfg.uniformGrids,1);
U = empty_curve_table_ff3d(nU);
USol = cell(nU,1);
UMesh = cell(nU,1);

for i=1:nU
    g = cfg.uniformGrids(i,:);
    fprintf('  uniform %d/%d grid=[%d %d %d] ...\n', ...
        i,nU,g(1),g(2),g(3));

    M = make_uniform_mesh_ff3d(cfg,g);
    [S,A] = fit_solution_ff3d(M,obs,c0,cfg);
    E = evaluate_solution_ff3d(S,test,cfg);

    U = fill_curve_row_ff3d(U,i,'UNIFORM',g(1),g(2),g(3),0,M,A,E,S);
    USol{i}=S;
    UMesh{i}=M;

    fprintf(['    nodes=%d tets=%d nnz=%d qMin=%.3f q01=%.3f | ', ...
        'hFault=%.2f | RMSE fault=%.5f all=%.5f\n'], ...
        U.Nodes(i),U.Tetrahedra(i),U.NNZ(i), ...
        U.MinTetQuality(i),U.P01TetQuality(i),U.FaultNormalHMedian(i), ...
        U.RMSE_fault(i),U.RMSE_all(i));
end

writetable(U,fullfile(outDir,'FAULTFITTED3D_UNIFORM_CURVE.csv'));

target = cfg.matchTolerance * min(U.RMSE_fault);
[iu,passU] = minimum_node_pass_ff3d(U,target);
if ~passU
    error('Uniform family failed to define a matched target.');
end

fprintf('  frozen matched target = %.6f\n',target);
fprintf('  minimum uniform pass  = %d nodes | fault RMSE %.6f\n', ...
    U.Nodes(iu),U.RMSE_fault(iu));

% -------------------------------------------------------------------------
% 4. Fault-fitted graded structured tetrahedral family.
% -------------------------------------------------------------------------
fprintf('\n[4/7] Fault-fitted graded tetrahedral family ...\n');
nF = size(cfg.fittedGrids,1);
F = empty_curve_table_ff3d(nF);
FSol = cell(nF,1);
FMesh = cell(nF,1);

for i=1:nF
    g = cfg.fittedGrids(i,:);
    beta = cfg.fittedBeta;
    fprintf('  fitted %d/%d grid=[%d %d %d] beta=%.2f ...\n', ...
        i,nF,g(1),g(2),g(3),beta);

    M = make_faultfitted_mesh_ff3d(cfg,g,beta);
    [S,A] = fit_solution_ff3d(M,obs,c0,cfg);
    E = evaluate_solution_ff3d(S,test,cfg);

    F = fill_curve_row_ff3d(F,i,'FAULT_FITTED',g(1),g(2),g(3),beta,M,A,E,S);
    FSol{i}=S;
    FMesh{i}=M;

    fprintf(['    nodes=%d tets=%d nnz=%d qMin=%.3f q01=%.3f | ', ...
        'hFault=%.2f hBg=%.2f r=%.2f | RMSE fault=%.5f all=%.5f | pass=%d\n'], ...
        F.Nodes(i),F.Tetrahedra(i),F.NNZ(i), ...
        F.MinTetQuality(i),F.P01TetQuality(i), ...
        F.FaultNormalHMedian(i),F.BackgroundNormalHMedian(i), ...
        F.NormalSpacingRatio(i),F.RMSE_fault(i),F.RMSE_all(i), ...
        F.RMSE_fault(i)<=target);
end

writetable(F,fullfile(outDir,'FAULTFITTED3D_FITTED_CURVE.csv'));

AllCurves=[U;F];
writetable(AllCurves,fullfile(outDir,'FAULTFITTED3D_ALL_CURVES.csv'));

% -------------------------------------------------------------------------
% 5. Matched-accuracy resource audit and a small geometry/grading ablation.
% -------------------------------------------------------------------------
fprintf('\n[5/7] Matched-fault-accuracy audit ...\n');
[ifit,passF] = minimum_node_pass_ff3d(F,target);

Match = build_match_table_ff3d(U,F,iu,ifit,passF,target,cfg);
disp(Match);
writetable(Match,fullfile(outDir,'FAULTFITTED3D_MATCHED_ACCURACY.csv'));

Quality = AllCurves(:,{ ...
    'Method','NX','NY','NZ','Beta','Nodes','Tetrahedra', ...
    'MinTetQuality','P01TetQuality','MedianTetQuality', ...
    'FaultNormalHMedian','BackgroundNormalHMedian','NormalSpacingRatio'});
writetable(Quality,fullfile(outDir,'FAULTFITTED3D_MESH_QUALITY.csv'));

% One paper-facing ablation at the matched fitted dimensions:
% same fault-fitted geometry but beta=0 (no near-fault grading).
Ablation = table();
UngradedSol = [];
UngradedMesh = [];

if passF
    gA = [F.NX(ifit),F.NY(ifit),F.NZ(ifit)];

    fprintf('  grading ablation at fitted matched dimensions [%d %d %d] ...\n', ...
        gA(1),gA(2),gA(3));

    MU = make_faultfitted_mesh_ff3d(cfg,gA,0);
    [SU,AA] = fit_solution_ff3d(MU,obs,c0,cfg);
    EU = evaluate_solution_ff3d(SU,test,cfg);

    UngradedSol=SU;
    UngradedMesh=MU;

    Method = {'UNIFORM_MATCHED';'FITTED_UNGRADED';'FITTED_GRADED'};
    Nodes = [U.Nodes(iu);size(MU.P,1);F.Nodes(ifit)];
    Tetrahedra = [U.Tetrahedra(iu);size(MU.T,1);F.Tetrahedra(ifit)];
    NNZ = [U.NNZ(iu);nnz(AA);F.NNZ(ifit)];
    FaultRMSE = [U.RMSE_fault(iu);EU.RMSE_fault;F.RMSE_fault(ifit)];
    GlobalRMSE = [U.RMSE_all(iu);EU.RMSE_all;F.RMSE_all(ifit)];
    BackgroundRMSE = [U.RMSE_bg(iu);EU.RMSE_bg;F.RMSE_bg(ifit)];
    MinTetQuality = [U.MinTetQuality(iu);MU.MinTetQuality;F.MinTetQuality(ifit)];
    FaultNormalH = [U.FaultNormalHMedian(iu);MU.FaultNormalHMedian; ...
        F.FaultNormalHMedian(ifit)];

    Ablation = table(Method,Nodes,Tetrahedra,NNZ,FaultRMSE,GlobalRMSE, ...
        BackgroundRMSE,MinTetQuality,FaultNormalH);

    writetable(Ablation,fullfile(outDir,'FAULTFITTED3D_ABLATION.csv'));
end

% Idealized 3-D two-scale interpretation.
rho = mean(abs(test.sdist)<=cfg.theoryFaultHalfWidth);
if passF
    rMeasured = F.NormalSpacingRatio(ifit);
else
    rMeasured = cfg.theoryBackgroundH/cfg.theoryFaultH;
end
idealRatioMeasured = rho + (1-rho)/max(rMeasured,1)^3;
idealSavingMeasured = 100*(1-idealRatioMeasured);

rNominal = cfg.theoryBackgroundH/cfg.theoryFaultH;
idealRatioNominal = rho + (1-rho)/rNominal^3;
idealSavingNominal = 100*(1-idealRatioNominal);

Theory = table(rho,rMeasured,rNominal,idealRatioMeasured, ...
    idealSavingMeasured,idealRatioNominal,idealSavingNominal, ...
    'VariableNames',{'FaultVolumeFraction','MeasuredSpacingRatio', ...
    'NominalSpacingRatio','IdealDOFRatioMeasured', ...
    'IdealSavingPctMeasured','IdealDOFRatioNominal', ...
    'IdealSavingPctNominal'});
writetable(Theory,fullfile(outDir,'FAULTFITTED3D_THEORY.csv'));

% -------------------------------------------------------------------------
% Numerical checkpoint BEFORE plotting.
% A figure/export bug must never destroy a successfully completed matched
% FEM experiment.  This checkpoint contains the complete paper-facing
% numerical result and the matched meshes/solutions.
% -------------------------------------------------------------------------
checkpoint=struct();
checkpoint.cfg=cfg;
checkpoint.c0=c0;
checkpoint.CV=CV;
checkpoint.UniformCurve=U;
checkpoint.FittedCurve=F;
checkpoint.Match=Match;
checkpoint.Theory=Theory;
checkpoint.Ablation=Ablation;
checkpoint.UniformMatchedIndex=iu;
checkpoint.FittedMatchedIndex=ifit;
if passF
    checkpoint.UniformMatchedMesh=strip_mesh_ff3d(UMesh{iu});
    checkpoint.FittedMatchedMesh=strip_mesh_ff3d(FMesh{ifit});
    checkpoint.UniformMatchedSolution=USol{iu}.U;
    checkpoint.FittedMatchedSolution=FSol{ifit}.U;
end
try
    save(fullfile(outDir,'FAULTFITTED3D_NUMERICAL_CHECKPOINT.mat'), ...
        'checkpoint','-v7.3');
catch
    save(fullfile(outDir,'FAULTFITTED3D_NUMERICAL_CHECKPOINT.mat'), ...
        'checkpoint','-v7');
end

% -------------------------------------------------------------------------
% 6. Publication figures and LaTeX exports.
% -------------------------------------------------------------------------
fprintf('\n[6/7] Writing publication figures and LaTeX exports ...\n');

plotAudit={};
plotAudit{end+1}=safe_plot_ff3d('truth_fault_slices', ...
    @() plot_truth_slices_ff3d(outDir,cfg));
plotAudit{end+1}=safe_plot_ff3d('accuracy_nodes', ...
    @() plot_accuracy_nodes_ff3d(outDir,U,F,target,iu,ifit,passF,cfg));
plotAudit{end+1}=safe_plot_ff3d('mesh_quality', ...
    @() plot_mesh_quality_ff3d(outDir,U,F,iu,ifit,passF,cfg));
plotAudit{end+1}=safe_plot_ff3d('cv_c0', ...
    @() plot_cv_ff3d(outDir,CV,cfg));

if passF
    plotAudit{end+1}=safe_plot_ff3d('matched_meshes', ...
        @() plot_matched_meshes_ff3d(outDir,UMesh{iu},FMesh{ifit},cfg));
    plotAudit{end+1}=safe_plot_ff3d('matched_resources', ...
        @() plot_matched_resources_ff3d(outDir,Match,cfg));
    plotAudit{end+1}=safe_plot_ff3d('crosssection_grading', ...
        @() plot_crosssection_grading_ff3d(outDir,UMesh{iu},FMesh{ifit},cfg));
else
    plotAudit{end+1}=safe_plot_ff3d('unmatched_notice', ...
        @() plot_unmatched_notice_ff3d(outDir,cfg));
end

write_plot_audit_ff3d(outDir,plotAudit);

% Text/LaTeX exports are independent of plotting and must still run even if
% a figure backend is unavailable.
write_latex_exports_ff3d(outDir,Match,Theory,c0,cfg);
write_summary_ff3d(outDir,U,F,Match,Theory,c0,cfg);

fprintf('\n[6B/7] Rebuilding journal-style 3-D paper figures ...\n');
paperfigs_ff3d_v1(outDir,U,F,UMesh,FMesh,iu,ifit,passF,Match,Ablation,cfg);

% -------------------------------------------------------------------------
% 7. Save full reproducibility state.
% -------------------------------------------------------------------------
fprintf('\n[7/7] Saving state ...\n');

state = struct();
state.cfg=cfg;
state.obs=obs;
state.test=test;
state.CV=CV;
state.c0=c0;
state.UniformCurve=U;
state.FittedCurve=F;
state.Match=Match;
state.Theory=Theory;
state.Ablation=Ablation;
state.UniformMatchedIndex=iu;
state.FittedMatchedIndex=ifit;

if passF
    state.UniformMatchedMesh=strip_mesh_ff3d(UMesh{iu});
    state.FittedMatchedMesh=strip_mesh_ff3d(FMesh{ifit});
    state.UniformMatchedSolution=USol{iu}.U;
    state.FittedMatchedSolution=FSol{ifit}.U;
end
if ~isempty(UngradedMesh)
    state.UngradedMatchedDimsMesh=strip_mesh_ff3d(UngradedMesh);
    state.UngradedMatchedDimsSolution=UngradedSol.U;
end

try
    save(fullfile(outDir,'FAULTFITTED3D_STATE.mat'),'state','-v7.3');
catch
    save(fullfile(outDir,'FAULTFITTED3D_STATE.mat'),'state','-v7');
end

fprintf('\n============================================================\n');
if passF
    fprintf('MATCHED 3-D RESULT\n');
    fprintf('  target fault RMSE : %.6f\n',target);
    fprintf('  uniform nodes     : %d\n',Match.UniformNodes(1));
    fprintf('  fitted nodes      : %d\n',Match.FittedNodes(1));
    fprintf('  node saving       : %.2f %%\n',Match.NodeSavingPct(1));
    fprintf('  tetra saving      : %.2f %%\n',Match.TetSavingPct(1));
    fprintf('  nnz saving        : %.2f %%\n',Match.NNZSavingPct(1));
    fprintf('  fitted q_min      : %.4f\n',Match.FittedMinTetQuality(1));
    fprintf('  spacing ratio     : %.2f\n',Match.FittedNormalSpacingRatio(1));
else
    fprintf('NO FITTED MESH IN THE CURRENT CANDIDATE FAMILY MET TARGET.\n');
    fprintf('Savings are intentionally reported as NaN / undefined.\n');
end
fprintf('Output: %s\n',outDir);
fprintf('============================================================\n');

end


% =========================================================================
% CONFIGURATION
% =========================================================================
function cfg=default_cfg_ff3d()

cfg.seed=20260816;

% Physical domain [m].
cfg.L=[1000 1000 500];

% Curved fault x=x_f(y,z).
cfg.faultX0=500;
cfg.faultAmpY=90;
cfg.faultAmpZ=45;
cfg.faultPhaseZ=0.45;

% Synthetic truth.
cfg.jumpAmp=5.5;
cfg.jumpWidth=14;
cfg.obsNoiseStd=0.05;
cfg.nObs=480;
cfg.nTest=12000;
cfg.faultEvalBand=55;
cfg.bgEvalDistance=180;

% Fault-aware tensor.
cfg.faultEpsMin=0.035;
cfg.faultSigma=72;

% c0 calibration on a common uniform mesh.
cfg.cvGrid=[9 9 7];
cfg.cvFolds=4;
cfg.cvPlateau=0.02;
cfg.c0Grid=logspace(-4,1.5,8);

% Uniform family [nx ny nz].
cfg.uniformGrids=[ ...
     5  5  4; ...
     7  7  5; ...
     9  9  6; ...
    11 11  7; ...
    13 13  8; ...
    15 15  9];

% Fault-fitted family [n_r ny nz].
% n_r MUST be odd so r=0 is an exact mesh layer coincident with the fault.
cfg.fittedGrids=[ ...
     7  7  5; ...
     9  7  5; ...
     9  9  5; ...
    11  9  5; ...
    11  9  7; ...
    13  9  7; ...
    13 11  7; ...
    15 11  7; ...
    17 11  7; ...
    17 11  9; ...
    19 13  9];

% Smooth grading strength:
% r(t)=sinh(beta*t)/sinh(beta), t in [-1,1].
% beta=0 gives ungraded fault-fitted layers.
cfg.fittedBeta=2.20;

% Matched-accuracy rule.
cfg.matchTolerance=1.05;

% Mesh safety.
cfg.meshQualityHard=1e-8;
cfg.meshQualityWarn=0.15;
cfg.baryTol=1e-8;
cfg.baryHardTol=5e-7;

% Theory-only interpretation.
cfg.theoryFaultHalfWidth=70;
cfg.theoryFaultH=55;
cfg.theoryBackgroundH=220;

% Figure/output.
cfg.figureDPI=180;
cfg.plotMaxNodes=5000;

end


% =========================================================================
% FAULT GEOMETRY / TRUE MODEL
% =========================================================================
function xf=fault_x_ff3d(y,z,cfg)

xf = cfg.faultX0 + ...
    cfg.faultAmpY*sin(2*pi*y/cfg.L(2)) + ...
    cfg.faultAmpZ*sin(2*pi*z/cfg.L(3)+cfg.faultPhaseZ);

end


function [sdist,n,xf]=fault_signed_distance_normal_ff3d(xyz,cfg)
% First-order signed-distance representation of
% F(x,y,z)=x-x_f(y,z)=0.

x=xyz(:,1);
y=xyz(:,2);
z=xyz(:,3);

xf=fault_x_ff3d(y,z,cfg);

dfdy=cfg.faultAmpY*(2*pi/cfg.L(2)).*cos(2*pi*y/cfg.L(2));
dfdz=cfg.faultAmpZ*(2*pi/cfg.L(3)).*cos(2*pi*z/cfg.L(3)+cfg.faultPhaseZ);

gradF=[ones(size(x)),-dfdy,-dfdz];
gn=sqrt(sum(gradF.^2,2));
n=gradF./max(gn,eps);

sdist=(x-xf)./max(gn,eps);

end


function m=truth_field_ff3d(xyz,cfg)

x=xyz(:,1);
y=xyz(:,2);
z=xyz(:,3);

[sdist,~,~]=fault_signed_distance_normal_ff3d(xyz,cfg);

Lx=cfg.L(1);
Ly=cfg.L(2);
Lz=cfg.L(3);

background = ...
    0.004*(x-0.5*Lx) + ...
    1.60*sin(2*pi*y/Ly) + ...
    1.10*cos(2*pi*z/Lz) + ...
    0.75*sin(2*pi*(x/Lx+y/Ly)) + ...
    0.40*cos(2*pi*(y/Ly+z/Lz));

transition=cfg.jumpAmp*tanh(sdist/cfg.jumpWidth);

m=background+transition;

end


function O=make_observations_ff3d(cfg)
% 75% volume-wide + 25% near-fault controls.

n1=round(0.75*cfg.nObs);
n2=cfg.nObs-n1;

P1=rand(n1,3).*cfg.L;

y=rand(n2,1)*cfg.L(2);
z=rand(n2,1)*cfg.L(3);
xf=fault_x_ff3d(y,z,cfg);

P0=[xf,y,z];
[~,n,~]=fault_signed_distance_normal_ff3d(P0,cfg);

off=(2*rand(n2,1)-1)*1.30*cfg.faultEvalBand;
P2=P0+off.*n;

% Keep controls inside the rectangular domain.
P2=max(P2,0);
P2=min(P2,cfg.L);

P=[P1;P2];

truth=truth_field_ff3d(P,cfg);
zobs=truth+cfg.obsNoiseStd*randn(size(truth));

O=struct('xyz',P,'z',zobs,'truth',truth);

end


function T=make_test_points_ff3d(cfg)

P=rand(cfg.nTest,3).*cfg.L;
truth=truth_field_ff3d(P,cfg);
[sdist,~,~]=fault_signed_distance_normal_ff3d(P,cfg);

T=struct();
T.xyz=P;
T.truth=truth;
T.sdist=sdist;
T.faultMask=abs(sdist)<=cfg.faultEvalBand;
T.bgMask=abs(sdist)>=cfg.bgEvalDistance;

end


% =========================================================================
% STRUCTURED TETRAHEDRAL MESHES
% =========================================================================
function M=make_uniform_mesh_ff3d(cfg,g)

nx=g(1); ny=g(2); nz=g(3);

x=linspace(0,cfg.L(1),nx);
y=linspace(0,cfg.L(2),ny);
z=linspace(0,cfg.L(3),nz);

[X,Y,Z]=ndgrid(x,y,z);
P=[X(:),Y(:),Z(:)];

T=structured_hex6_connectivity_ff3d(nx,ny,nz);

M=finalize_mesh_ff3d(P,T,[nx ny nz],'UNIFORM',0,[],cfg);

% Spacing audit in physical fault-normal direction.
[~,nFault,~]=fault_signed_distance_normal_ff3d( ...
    [fault_x_ff3d(Y(:),Z(:),cfg),Y(:),Z(:)],cfg);
nxcomp=abs(nFault(:,1));

hx=cfg.L(1)/(nx-1);
M.FaultNormalHMedian=median(hx*nxcomp);
M.BackgroundNormalHMedian=M.FaultNormalHMedian;
M.NormalSpacingRatio=1;

end


function M=make_faultfitted_mesh_ff3d(cfg,g,beta)

nr=g(1); ny=g(2); nz=g(3);

if mod(nr,2)~=1
    error('Fault-fitted n_r must be odd so r=0 is an exact fault layer.');
end

t=linspace(-1,1,nr);
if abs(beta)<1e-14
    r=t;
else
    r=sinh(beta*t)/sinh(beta);
end
r((nr+1)/2)=0;

y=linspace(0,cfg.L(2),ny);
z=linspace(0,cfg.L(3),nz);

[R,Y,Z]=ndgrid(r,y,z);
XF=fault_x_ff3d(Y,Z,cfg);

X=zeros(size(R));
left=R<=0;
right=~left;

% Boundary-preserving fitted map:
% r=-1 -> x=0, r=0 -> x=x_f(y,z), r=+1 -> x=Lx.
X(left)=XF(left).*(1+R(left));
X(right)=XF(right)+R(right).*(cfg.L(1)-XF(right));

P=[X(:),Y(:),Z(:)];
T=structured_hex6_connectivity_ff3d(nr,ny,nz);

M=finalize_mesh_ff3d(P,T,[nr ny nz],'FAULT_FITTED',beta,r,cfg);

% Mesh-spacing audit using the two layers adjacent to r=0 and outer layers.
i0=(nr+1)/2;
Xg=reshape(M.P(:,1),[nr ny nz]);
Yg=reshape(M.P(:,2),[nr ny nz]);
Zg=reshape(M.P(:,3),[nr ny nz]);

Y0=squeeze(Yg(i0,:,:));
Z0=squeeze(Zg(i0,:,:));
XF0=squeeze(Xg(i0,:,:));

[~,n0,~]=fault_signed_distance_normal_ff3d( ...
    [XF0(:),Y0(:),Z0(:)],cfg);
nxcomp=abs(n0(:,1));

dLeft=squeeze(Xg(i0,:,:)-Xg(i0-1,:,:));
dRight=squeeze(Xg(i0+1,:,:)-Xg(i0,:,:));
dFault=0.5*(dLeft(:)+dRight(:)).*nxcomp;

dBgLeft=squeeze(Xg(2,:,:)-Xg(1,:,:));
dBgRight=squeeze(Xg(end,:,:)-Xg(end-1,:,:));
dBg=0.5*(dBgLeft(:)+dBgRight(:)).*nxcomp;

M.FaultNormalHMedian=median(dFault);
M.BackgroundNormalHMedian=median(dBg);
M.NormalSpacingRatio=M.BackgroundNormalHMedian/max(M.FaultNormalHMedian,eps);

end


function T=structured_hex6_connectivity_ff3d(nx,ny,nz)
% Globally conforming Freudenthal-like 6-tetra decomposition.
% All hexahedra use the same body diagonal v000 -> v111.

nHex=(nx-1)*(ny-1)*(nz-1);
T=zeros(6*nHex,4);
q=0;

for k=1:nz-1
    for j=1:ny-1
        for i=1:nx-1

            v000=sub2ind([nx ny nz],i,  j,  k);
            v100=sub2ind([nx ny nz],i+1,j,  k);
            v010=sub2ind([nx ny nz],i,  j+1,k);
            v110=sub2ind([nx ny nz],i+1,j+1,k);

            v001=sub2ind([nx ny nz],i,  j,  k+1);
            v101=sub2ind([nx ny nz],i+1,j,  k+1);
            v011=sub2ind([nx ny nz],i,  j+1,k+1);
            v111=sub2ind([nx ny nz],i+1,j+1,k+1);

            local=[ ...
                v000 v100 v110 v111; ...
                v000 v110 v010 v111; ...
                v000 v010 v011 v111; ...
                v000 v011 v001 v111; ...
                v000 v001 v101 v111; ...
                v000 v101 v100 v111];

            T(q+(1:6),:)=local;
            q=q+6;
        end
    end
end

end


function M=finalize_mesh_ff3d(P,T,dims,kind,beta,r,cfg)

nt=size(T,1);
vol=zeros(nt,1);
qual=zeros(nt,1);

% Enforce positive orientation deterministically.
for e=1:nt
    nodes=T(e,:);
    xyz=P(nodes,:);
    ds=det([xyz(2,:)-xyz(1,:); ...
            xyz(3,:)-xyz(1,:); ...
            xyz(4,:)-xyz(1,:)])/6;

    if abs(ds)<=eps(max(abs(xyz(:)))+1)
        error('Degenerate tetrahedron detected before orientation correction.');
    end

    if ds<0
        T(e,[2 3])=T(e,[3 2]);
        xyz=P(T(e,:),:);
    end

    [~,vol(e)]=tet_gradients_ff3d(xyz);
    qual(e)=tet_quality_mean_ratio_ff3d(xyz);
end

if any(~isfinite(vol)) || any(vol<=0)
    error('Mesh has invalid/non-positive tetrahedron volume.');
end

if any(~isfinite(qual)) || any(qual<=cfg.meshQualityHard)
    [qmin,iq]=min(qual);
    error('Mesh contains a degenerate/near-degenerate tetrahedron: qMin=%.3e at tet %d.', ...
        qmin,iq);
end

qs=sort(qual);
i01=max(1,ceil(0.01*numel(qs)));

DT=triangulation(T,P);

M=struct();
M.P=P;
M.T=T;
M.DT=DT;
M.Dims=dims;
M.Kind=kind;
M.Beta=beta;
M.RCoord=r;
M.MinTetVolume=min(vol);
M.MinTetQuality=min(qual);
M.P01TetQuality=qs(i01);
M.MedianTetQuality=median(qual);
M.TinyTetCount=nnz(vol<1e-13*max(prod(cfg.L),1));
M.FaultNormalHMedian=nan;
M.BackgroundNormalHMedian=nan;
M.NormalSpacingRatio=nan;

if M.MinTetQuality<cfg.meshQualityWarn
    warning('%s mesh has qMin=%.3f below warning threshold %.3f.', ...
        kind,M.MinTetQuality,cfg.meshQualityWarn);
end

end


function q=tet_quality_mean_ratio_ff3d(xyz)

edges=[1 2;1 3;1 4;2 3;2 4;3 4];

s2=0;
for k=1:6
    d=xyz(edges(k,1),:)-xyz(edges(k,2),:);
    s2=s2+dot(d,d);
end

V=abs(det([xyz(2,:)-xyz(1,:); ...
           xyz(3,:)-xyz(1,:); ...
           xyz(4,:)-xyz(1,:)]))/6;

if ~(V>0) || ~(s2>0)
    q=0;
else
    q=12*(3*V)^(2/3)/s2;
end

q=max(0,min(1,q));

end


function [B,V]=tet_gradients_ff3d(xyz)

A=[ones(4,1),xyz];
C=A\eye(4);
B=C(2:4,:);

V=abs(det([xyz(2,:)-xyz(1,:); ...
           xyz(3,:)-xyz(1,:); ...
           xyz(4,:)-xyz(1,:)]))/6;

if ~(V>0)
    error('Degenerate tetrahedron.');
end

end


% =========================================================================
% FAULT-AWARE FEM
% =========================================================================
function D=fault_tensor_one_ff3d(xyz,cfg)

[sdist,n,~]=fault_signed_distance_normal_ff3d(xyz,cfg);

strength=exp(-0.5*(sdist/cfg.faultSigma).^2);
epsn=1-(1-cfg.faultEpsMin)*strength;

n=n(1,:);
D=eye(3)-(1-epsn)*(n.'*n);

end


function K=assemble_fault_stiffness_ff3d(M,cfg)

nt=size(M.T,1);
n=size(M.P,1);

I=zeros(16*nt,1);
J=zeros(16*nt,1);
Vv=zeros(16*nt,1);
q=0;

for e=1:nt
    nodes=M.T(e,:);
    xyz=M.P(nodes,:);

    [B,vol]=tet_gradients_ff3d(xyz);
    cen=mean(xyz,1);
    D=fault_tensor_one_ff3d(cen,cfg);

    Ke=vol*(B.'*D*B);

    for a=1:4
        for b=1:4
            q=q+1;
            I(q)=nodes(a);
            J(q)=nodes(b);
            Vv(q)=Ke(a,b);
        end
    end
end

K=sparse(I,J,Vv,n,n);
K=0.5*(K+K.');

end


function H=build_interp_matrix_ff3d(M,Q,cfg)

Qeval=Q;

% First direct point-location attempt.
ti=pointLocation(M.DT,Qeval);
bad=~isfinite(ti);

% Boundary-only inward nudge.  No interior projection is permitted.
if any(bad)

    lo=[0 0 0];
    hi=cfg.L;

    span=max(cfg.L);
    locTol=max(1e-10*span,1e-9);

    qb=Qeval(bad,:);

    trulyOutside=any(qb<(lo-locTol) | qb>(hi+locTol),2);
    if any(trulyOutside)
        error('Interpolation has %d truly outside-domain points.',nnz(trulyOutside));
    end

    for d=1:3
        onLo=abs(qb(:,d)-lo(d))<=locTol;
        onHi=abs(qb(:,d)-hi(d))<=locTol;
        qb(onLo,d)=lo(d)+locTol;
        qb(onHi,d)=hi(d)-locTol;
    end

    Qeval(bad,:)=qb;
    ti(bad)=pointLocation(M.DT,Qeval(bad,:));
end

if any(~isfinite(ti))
    ib=find(~isfinite(ti));
    qbad=Q(ib(1),:);
    error(['Point location failed for %d points. First unresolved point = ', ...
        '[%.15g %.15g %.15g].'],numel(ib),qbad(1),qbad(2),qbad(3));
end

bc=cartesianToBarycentric(M.DT,ti,Qeval);
tol=cfg.baryTol;

sus=any(~isfinite(bc),2) | any(bc<-tol,2) | any(bc>1+tol,2) | ...
    abs(sum(bc,2)-1)>10*tol;

% Independent local barycentric re-solve for suspicious rows.
ii=find(sus);
for kk=1:numel(ii)
    i=ii(kk);

    tet=M.T(ti(i),:);
    X=M.P(tet,:);
    qpt=Qeval(i,:);

    x4=X(4,:);
    scale=max(local_edge_lengths_ff3d(X));
    if ~(scale>0)
        scale=1;
    end

    A=[(X(1,:)-x4).'/scale, ...
       (X(2,:)-x4).'/scale, ...
       (X(3,:)-x4).'/scale];

    rhs=(qpt-x4).'/scale;

    if rcond(A)>1e-13
        l123=A\rhs;
    else
        l123=pinv(A,1e-12)*rhs;
    end

    bc(i,:)=[l123(:).',1-sum(l123)];
end

hardTol=cfg.baryHardTol;
badbc=any(~isfinite(bc),2) | any(bc<-hardTol,2) | ...
    any(bc>1+hardTol,2) | abs(sum(bc,2)-1)>10*hardTol;

if any(badbc)
    i=find(badbc,1,'first');
    tet=M.T(ti(i),:);
    qTet=tet_quality_mean_ratio_ff3d(M.P(tet,:));

    error(['Barycentric inconsistency after local re-solve: row=%d tet=%d ', ...
        'qTet=%.3e bc=[%.3e %.3e %.3e %.3e].'], ...
        i,ti(i),qTet,bc(i,1),bc(i,2),bc(i,3),bc(i,4));
end

% Roundoff-scale simplex projection only.
bc(abs(bc)<tol)=0;
bc(abs(bc-1)<tol)=1;
bc=max(bc,0);
bc=min(bc,1);
bc=bc./sum(bc,2);

rows=repelem((1:size(Q,1)).',4,1);
cols=reshape(M.T(ti,:).',[],1);
vals=reshape(bc.',[],1);

H=sparse(rows,cols,vals,size(Q,1),size(M.P,1));

end


function d=local_edge_lengths_ff3d(X)

pairs=[1 2;1 3;1 4;2 3;2 4;3 4];
d=zeros(6,1);

for k=1:6
    d(k)=norm(X(pairs(k,1),:)-X(pairs(k,2),:));
end

end


function [S,A]=fit_solution_ff3d(M,obs,c0,cfg)

K=assemble_fault_stiffness_ff3d(M,cfg);
H=build_interp_matrix_ff3d(M,obs.xyz,cfg);

A=c0*K+H.'*H;
b=H.'*obs.z;

A=0.5*(A+A.');

ridge=1e-11*max(mean(abs(diag(A))),1);
A=A+ridge*speye(size(A,1));

U=A\b;

res=H*U-obs.z;

S=struct();
S.mesh=M;
S.U=U;
S.c0=c0;
S.dataRMSE=sqrt(mean(res.^2));

end


function pred=predict_solution_ff3d(S,Q,cfg)

H=build_interp_matrix_ff3d(S.mesh,Q,cfg);
pred=H*S.U;

end


% =========================================================================
% CV
% =========================================================================
function CV=select_c0_cv_ff3d(M,K,H,obs,cfg) %#ok<INUSD>

grid=cfg.c0Grid(:);
n=numel(obs.z);

ord=randperm(n);
fold=zeros(n,1);

for i=1:n
    fold(ord(i))=1+mod(i-1,cfg.cvFolds);
end

mse=nan(numel(grid),cfg.cvFolds);

for ig=1:numel(grid)
    for k=1:cfg.cvFolds

        tr=fold~=k;
        te=fold==k;

        Htr=H(tr,:);
        Hte=H(te,:);

        A=grid(ig)*K+Htr.'*Htr;
        b=Htr.'*obs.z(tr);

        A=0.5*(A+A.');
        ridge=1e-11*max(mean(abs(diag(A))),1);

        U=(A+ridge*speye(size(A,1)))\b;

        e=Hte*U-obs.z(te);
        mse(ig,k)=mean(e.^2);
    end
end

meanMSE=mean(mse,2,'omitnan');
seMSE=std(mse,0,2,'omitnan')/sqrt(cfg.cvFolds);

[raw,ir]=min(meanMSE);

% Strongest regularization inside a fixed near-minimum plateau.
elig=meanMSE<=(1+cfg.cvPlateau)*raw;
idx=find(elig);
is=idx(end);

CV=struct();
CV.grid=grid;
CV.meanMSE=meanMSE;
CV.seMSE=seMSE;
CV.rawValue=grid(ir);
CV.rawMSE=raw;
CV.value=grid(is);
CV.selectedMSE=meanMSE(is);

end


% =========================================================================
% EVALUATION / TABLES
% =========================================================================
function E=evaluate_solution_ff3d(S,test,cfg)

pred=predict_solution_ff3d(S,test.xyz,cfg);
err=pred-test.truth;

E=struct();
E.RMSE_all=sqrt(mean(err.^2));

if any(test.faultMask)
    E.RMSE_fault=sqrt(mean(err(test.faultMask).^2));
else
    E.RMSE_fault=nan;
end

if any(test.bgMask)
    E.RMSE_bg=sqrt(mean(err(test.bgMask).^2));
else
    E.RMSE_bg=nan;
end

end


function T=empty_curve_table_ff3d(n)

Method=repmat({''},n,1);

NX=nan(n,1);
NY=nan(n,1);
NZ=nan(n,1);
Beta=nan(n,1);

Nodes=nan(n,1);
Tetrahedra=nan(n,1);
NNZ=nan(n,1);
SparseBytes=nan(n,1);

RMSE_all=nan(n,1);
RMSE_fault=nan(n,1);
RMSE_bg=nan(n,1);
DataRMSE=nan(n,1);

MinTetQuality=nan(n,1);
P01TetQuality=nan(n,1);
MedianTetQuality=nan(n,1);

FaultNormalHMedian=nan(n,1);
BackgroundNormalHMedian=nan(n,1);
NormalSpacingRatio=nan(n,1);

T=table(Method,NX,NY,NZ,Beta,Nodes,Tetrahedra,NNZ,SparseBytes, ...
    RMSE_all,RMSE_fault,RMSE_bg,DataRMSE, ...
    MinTetQuality,P01TetQuality,MedianTetQuality, ...
    FaultNormalHMedian,BackgroundNormalHMedian,NormalSpacingRatio);

end


function T=fill_curve_row_ff3d(T,i,name,nx,ny,nz,beta,M,A,E,S)

T.Method{i}=name;
T.NX(i)=nx;
T.NY(i)=ny;
T.NZ(i)=nz;
T.Beta(i)=beta;

T.Nodes(i)=size(M.P,1);
T.Tetrahedra(i)=size(M.T,1);
T.NNZ(i)=nnz(A);

w=whos('A');
T.SparseBytes(i)=w.bytes;

T.RMSE_all(i)=E.RMSE_all;
T.RMSE_fault(i)=E.RMSE_fault;
T.RMSE_bg(i)=E.RMSE_bg;
T.DataRMSE(i)=S.dataRMSE;

T.MinTetQuality(i)=M.MinTetQuality;
T.P01TetQuality(i)=M.P01TetQuality;
T.MedianTetQuality(i)=M.MedianTetQuality;

T.FaultNormalHMedian(i)=M.FaultNormalHMedian;
T.BackgroundNormalHMedian(i)=M.BackgroundNormalHMedian;
T.NormalSpacingRatio(i)=M.NormalSpacingRatio;

end


function [idx,pass]=minimum_node_pass_ff3d(T,target)

q=find(T.RMSE_fault<=target & isfinite(T.RMSE_fault));

if isempty(q)
    idx=[];
    pass=false;
    return;
end

nodes=T.Nodes(q);
nmin=min(nodes);
qcand=q(nodes==nmin);

if numel(qcand)==1
    idx=qcand;
else
    [~,j]=min(T.RMSE_fault(qcand));
    idx=qcand(j);
end

pass=true;

end


function Match=build_match_table_ff3d(U,F,iu,ifit,passF,target,cfg)

Matched=passF;
FaultTarget=target;

UniformNodes=U.Nodes(iu);
UniformTetrahedra=U.Tetrahedra(iu);
UniformNNZ=U.NNZ(iu);
UniformSparseBytes=U.SparseBytes(iu);

UniformFaultRMSE=U.RMSE_fault(iu);
UniformGlobalRMSE=U.RMSE_all(iu);
UniformBackgroundRMSE=U.RMSE_bg(iu);
UniformMinTetQuality=U.MinTetQuality(iu);
UniformP01TetQuality=U.P01TetQuality(iu);
UniformFaultNormalH=U.FaultNormalHMedian(iu);

if passF

    FittedNodes=F.Nodes(ifit);
    FittedTetrahedra=F.Tetrahedra(ifit);
    FittedNNZ=F.NNZ(ifit);
    FittedSparseBytes=F.SparseBytes(ifit);

    FittedFaultRMSE=F.RMSE_fault(ifit);
    FittedGlobalRMSE=F.RMSE_all(ifit);
    FittedBackgroundRMSE=F.RMSE_bg(ifit);
    FittedMinTetQuality=F.MinTetQuality(ifit);
    FittedP01TetQuality=F.P01TetQuality(ifit);
    FittedFaultNormalH=F.FaultNormalHMedian(ifit);
    FittedBackgroundNormalH=F.BackgroundNormalHMedian(ifit);
    FittedNormalSpacingRatio=F.NormalSpacingRatio(ifit);

    NodeSavingPct=100*(1-FittedNodes/UniformNodes);
    TetSavingPct=100*(1-FittedTetrahedra/UniformTetrahedra);
    NNZSavingPct=100*(1-FittedNNZ/UniformNNZ);
    MemorySavingPct=100*(1-FittedSparseBytes/UniformSparseBytes);

    FaultRMSEratio=FittedFaultRMSE/UniformFaultRMSE;
    GlobalPenaltyPct=100*(FittedGlobalRMSE/UniformGlobalRMSE-1);
    BackgroundPenaltyPct=100*(FittedBackgroundRMSE/UniformBackgroundRMSE-1);

else

    FittedNodes=nan;
    FittedTetrahedra=nan;
    FittedNNZ=nan;
    FittedSparseBytes=nan;

    FittedFaultRMSE=nan;
    FittedGlobalRMSE=nan;
    FittedBackgroundRMSE=nan;
    FittedMinTetQuality=nan;
    FittedP01TetQuality=nan;
    FittedFaultNormalH=nan;
    FittedBackgroundNormalH=nan;
    FittedNormalSpacingRatio=nan;

    NodeSavingPct=nan;
    TetSavingPct=nan;
    NNZSavingPct=nan;
    MemorySavingPct=nan;

    FaultRMSEratio=nan;
    GlobalPenaltyPct=nan;
    BackgroundPenaltyPct=nan;

end

Match=table(FaultTarget,Matched, ...
    UniformNodes,FittedNodes,NodeSavingPct, ...
    UniformTetrahedra,FittedTetrahedra,TetSavingPct, ...
    UniformNNZ,FittedNNZ,NNZSavingPct, ...
    UniformSparseBytes,FittedSparseBytes,MemorySavingPct, ...
    UniformFaultRMSE,FittedFaultRMSE,FaultRMSEratio, ...
    UniformGlobalRMSE,FittedGlobalRMSE,GlobalPenaltyPct, ...
    UniformBackgroundRMSE,FittedBackgroundRMSE,BackgroundPenaltyPct, ...
    UniformMinTetQuality,FittedMinTetQuality, ...
    UniformP01TetQuality,FittedP01TetQuality, ...
    UniformFaultNormalH,FittedFaultNormalH,FittedBackgroundNormalH, ...
    FittedNormalSpacingRatio);

if ~Matched
    warning(['Fault-fitted candidate family did not reach matched target %.6f. ', ...
        'Resource savings are intentionally undefined.'],target);
end

end


function S=strip_mesh_ff3d(M)

S=rmfield(M,'DT');

end


% =========================================================================
% FIGURES
% =========================================================================
function plot_truth_slices_ff3d(outDir,cfg)

nx=55; ny=55; nz=31;

x=linspace(0,cfg.L(1),nx);
y=linspace(0,cfg.L(2),ny);
z=linspace(0,cfg.L(3),nz);

[X,Y,Z]=meshgrid(x,y,z);
V=reshape(truth_field_ff3d([X(:),Y(:),Z(:)],cfg),size(X));

f=figure('Color','w','Units','pixels','Position',[80 80 1200 760]);

slice(X,Y,Z,V,cfg.L(1)*[0.35 0.65], ...
    cfg.L(2)*[0.25 0.50 0.75],cfg.L(3)*0.5);

shading interp;
hold on;
plot_fault_surface_ff3d(gca,cfg,0.20);

xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');
title('Synthetic true 3-D field and curved fault');
grid on;
axis tight;
view(3);
colorbar;

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_01_truth_fault_slices.png'),cfg);

end


function plot_fault_surface_ff3d(ax,cfg,faceAlpha)

y=linspace(0,cfg.L(2),40);
z=linspace(0,cfg.L(3),25);
[Y,Z]=meshgrid(y,z);
X=fault_x_ff3d(Y,Z,cfg);

surf(ax,X,Y,Z,zeros(size(X)), ...
    'FaceAlpha',faceAlpha,'EdgeAlpha',0.20);

end


function plot_matched_meshes_ff3d(outDir,MU,MF,cfg)

f=figure('Color','w','Units','pixels','Position',[80 80 1350 650]);

subplot(1,2,1);
scatter_mesh_nodes_ff3d(MU,cfg);
title(sprintf('Uniform matched mesh: %d nodes',size(MU.P,1)));

subplot(1,2,2);
scatter_mesh_nodes_ff3d(MF,cfg);
title(sprintf('Fault-fitted matched mesh: %d nodes',size(MF.P,1)));

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_02_matched_meshes.png'),cfg);

end


function scatter_mesh_nodes_ff3d(M,cfg)

P=M.P;

if size(P,1)>cfg.plotMaxNodes
    idx=round(linspace(1,size(P,1),cfg.plotMaxNodes));
    P=P(idx,:);
end

scatter3(P(:,1),P(:,2),P(:,3),8,'.');
hold on;
plot_fault_surface_ff3d(gca,cfg,0.12);

xlabel('x [m]');
ylabel('y [m]');
zlabel('z [m]');
grid on;
axis tight;
view(3);

end


function plot_accuracy_nodes_ff3d(outDir,U,F,target,iu,ifit,passF,cfg)

f=figure('Color','w','Units','pixels','Position',[100 100 1080 700]);

semilogx(U.Nodes,U.RMSE_fault,'-o','LineWidth',1.5,'MarkerSize',7);
hold on;
semilogx(F.Nodes,F.RMSE_fault,'-s','LineWidth',1.5,'MarkerSize',7);

yline(target,'k--','LineWidth',1.2);

plot(U.Nodes(iu),U.RMSE_fault(iu),'o','MarkerSize',13,'LineWidth',2.2);

if passF
    plot(F.Nodes(ifit),F.RMSE_fault(ifit),'s','MarkerSize',13,'LineWidth',2.2);
    lg={'Uniform','Fault-fitted graded','Matched target', ...
        'Uniform minimum pass','Fault-fitted minimum pass'};
else
    lg={'Uniform','Fault-fitted graded','Matched target', ...
        'Uniform minimum pass'};
end

grid on;
xlabel('nodes');
ylabel('fault-neighborhood RMSE');
title('True 3-D matched-accuracy comparison');
legend(lg,'Location','best');

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_03_accuracy_nodes.png'),cfg);

end


function plot_matched_resources_ff3d(outDir,M,cfg)

vals=[ ...
    100,100-M.NodeSavingPct(1); ...
    100,100-M.TetSavingPct(1); ...
    100,100-M.NNZSavingPct(1); ...
    100,100-M.MemorySavingPct(1)];

f=figure('Color','w','Units','pixels','Position',[110 110 1080 680]);

bar(vals);
grid on;

set(gca,'XTickLabel',{'Nodes','Tetrahedra','NNZ','Sparse memory'});
ylabel('resource relative to uniform matched [%]');
legend({'Uniform matched','Fault-fitted matched'},'Location','best');
title(sprintf('Matched fault accuracy: target %.4f',M.FaultTarget(1)));

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_04_matched_resources.png'),cfg);

end


function plot_mesh_quality_ff3d(outDir,U,F,iu,ifit,passF,cfg)

f=figure('Color','w','Units','pixels','Position',[110 110 1080 680]);

semilogx(U.Nodes,U.MinTetQuality,'-o','LineWidth',1.5);
hold on;
semilogx(F.Nodes,F.MinTetQuality,'-s','LineWidth',1.5);

plot(U.Nodes(iu),U.MinTetQuality(iu),'o','MarkerSize',12,'LineWidth',2);

if passF
    plot(F.Nodes(ifit),F.MinTetQuality(ifit),'s','MarkerSize',12,'LineWidth',2);
end

yline(cfg.meshQualityWarn,'k--','LineWidth',1.0);

grid on;
xlabel('nodes');
ylabel('minimum tetrahedral mean-ratio quality');
title('Mesh-quality audit');

if passF
    legend({'Uniform','Fault-fitted graded','Uniform matched', ...
        'Fault-fitted matched','warning threshold'},'Location','best');
else
    legend({'Uniform','Fault-fitted graded','Uniform matched', ...
        'warning threshold'},'Location','best');
end

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_05_mesh_quality.png'),cfg);

end


function plot_crosssection_grading_ff3d(outDir,MU,MF,cfg)

f=figure('Color','w','Units','pixels','Position',[80 80 1350 650]);

subplot(1,2,1);
plot_mesh_xy_section_ff3d(MU,cfg);
title('Uniform matched: z-mid cross-section');

subplot(1,2,2);
plot_mesh_xy_section_ff3d(MF,cfg);
title('Fault-fitted matched: z-mid cross-section');

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_06_crosssection_grading.png'),cfg);

end


function plot_mesh_xy_section_ff3d(M,cfg)

dims=M.Dims;
nx=dims(1);
ny=dims(2);
nz=dims(3);

X=reshape(M.P(:,1),dims);
Y=reshape(M.P(:,2),dims);

k=round((nz+1)/2);

hold on;

for i=1:nx
    plot(squeeze(X(i,:,k)),squeeze(Y(i,:,k)),'-','LineWidth',0.8);
end

for j=1:ny
    plot(squeeze(X(:,j,k)),squeeze(Y(:,j,k)),'-','LineWidth',0.8);
end

ylineVals=linspace(0,cfg.L(2),300);
z0=cfg.L(3)*(k-1)/(nz-1);
xf=fault_x_ff3d(ylineVals,z0*ones(size(ylineVals)),cfg);

plot(xf,ylineVals,'k-','LineWidth',2.0);

xlabel('x [m]');
ylabel('y [m]');
axis equal tight;
grid on;

end


function plot_cv_ff3d(outDir,CV,cfg)

f=figure('Color','w','Units','pixels','Position',[120 120 900 620]);

errorbar(CV.grid,CV.meanMSE,CV.seMSE,'-o','LineWidth',1.4);
set(gca,'XScale','log');
grid on;
hold on;

xline(CV.value,'k--','LineWidth',1.2);

xlabel('c_0');
ylabel('CV MSE');
title('Sparse-observation calibration of c_0');
legend({'CV mean \pm SE','selected c_0'},'Location','best');

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_07_cv_c0.png'),cfg);

end


function plot_unmatched_notice_ff3d(outDir,cfg)

f=figure('Color','w','Units','pixels','Position',[200 200 900 450]);
axis off;

text(0.5,0.6,'Fault-fitted family did not reach the matched target.', ...
    'HorizontalAlignment','center','FontSize',16);
text(0.5,0.42,'Resource savings are undefined; extend fittedGrids before paper use.', ...
    'HorizontalAlignment','center','FontSize',13);

save_fig_ff3d(f,fullfile(outDir,'FIG_FF3D_04_matched_resources.png'),cfg);

end


% =========================================================================
% LATEX / TEXT EXPORTS
% =========================================================================
function write_latex_exports_ff3d(outDir,M,Theory,c0,cfg)

fid=fopen(fullfile(outDir,'FAULTFITTED3D_LATEX_MACROS.tex'),'w');

fprintf(fid,'%% Auto-generated by FAULT_AFEM_3D_FAULTFITTED_V1_FIX1\n');
fprintf(fid,'\\newcommand{\\FFThreeDCZero}{%.6g}\n',c0);
fprintf(fid,'\\newcommand{\\FFThreeDFaultTarget}{%.4f}\n',M.FaultTarget(1));
fprintf(fid,'\\newcommand{\\FFThreeDMatched}{%d}\n',M.Matched(1));
fprintf(fid,'\\newcommand{\\FFThreeDUniformNodes}{%.0f}\n',M.UniformNodes(1));
fprintf(fid,'\\newcommand{\\FFThreeDUniformFaultRMSE}{%.4f}\n',M.UniformFaultRMSE(1));
fprintf(fid,'\\newcommand{\\FFThreeDUniformQMin}{%.3f}\n',M.UniformMinTetQuality(1));

if M.Matched(1)
    fprintf(fid,'\\newcommand{\\FFThreeDFittedNodes}{%.0f}\n',M.FittedNodes(1));
    fprintf(fid,'\\newcommand{\\FFThreeDNodeSaving}{%.2f}\n',M.NodeSavingPct(1));
    fprintf(fid,'\\newcommand{\\FFThreeDTetSaving}{%.2f}\n',M.TetSavingPct(1));
    fprintf(fid,'\\newcommand{\\FFThreeDNNZSaving}{%.2f}\n',M.NNZSavingPct(1));
    fprintf(fid,'\\newcommand{\\FFThreeDMemorySaving}{%.2f}\n',M.MemorySavingPct(1));
    fprintf(fid,'\\newcommand{\\FFThreeDFittedFaultRMSE}{%.4f}\n',M.FittedFaultRMSE(1));
    fprintf(fid,'\\newcommand{\\FFThreeDGlobalPenalty}{%.2f}\n',M.GlobalPenaltyPct(1));
    fprintf(fid,'\\newcommand{\\FFThreeDBackgroundPenalty}{%.2f}\n',M.BackgroundPenaltyPct(1));
    fprintf(fid,'\\newcommand{\\FFThreeDFittedQMin}{%.3f}\n',M.FittedMinTetQuality(1));
    fprintf(fid,'\\newcommand{\\FFThreeDFittedQOne}{%.3f}\n',M.FittedP01TetQuality(1));
    fprintf(fid,'\\newcommand{\\FFThreeDFaultSpacing}{%.2f}\n',M.FittedFaultNormalH(1));
    fprintf(fid,'\\newcommand{\\FFThreeDBackgroundSpacing}{%.2f}\n',M.FittedBackgroundNormalH(1));
    fprintf(fid,'\\newcommand{\\FFThreeDSpacingRatio}{%.2f}\n',M.FittedNormalSpacingRatio(1));
end

fprintf(fid,'\\newcommand{\\FFThreeDFaultVolumeFraction}{%.3f}\n',Theory.FaultVolumeFraction(1));
fprintf(fid,'\\newcommand{\\FFThreeDIdealSaving}{%.2f}\n',Theory.IdealSavingPctMeasured(1));

fclose(fid);

% Matched table.
fid=fopen(fullfile(outDir,'FAULTFITTED3D_MATCHED_TABLE.tex'),'w');

fprintf(fid,'%% Auto-generated matched-accuracy table\n');
fprintf(fid,'\\begin{table}[htbp]\n');
fprintf(fid,'\\centering\n');
fprintf(fid,'\\caption{True 3-D matched-fault-accuracy resource comparison.}\n');
fprintf(fid,'\\label{tab:ff3d_matched}\n');
fprintf(fid,'\\begin{tabular}{lrrrrr}\n');
fprintf(fid,'\\toprule\n');
fprintf(fid,'Method & Nodes & Tets & NNZ & Fault RMSE & $q_{\\min}$ \\\\\n');
fprintf(fid,'\\midrule\n');

fprintf(fid,'Uniform & %.0f & %.0f & %.0f & %.4f & %.3f \\\\\n', ...
    M.UniformNodes(1),M.UniformTetrahedra(1),M.UniformNNZ(1), ...
    M.UniformFaultRMSE(1),M.UniformMinTetQuality(1));

if M.Matched(1)
    fprintf(fid,'Fault-fitted & %.0f & %.0f & %.0f & %.4f & %.3f \\\\\n', ...
        M.FittedNodes(1),M.FittedTetrahedra(1),M.FittedNNZ(1), ...
        M.FittedFaultRMSE(1),M.FittedMinTetQuality(1));
end

fprintf(fid,'\\bottomrule\n');
fprintf(fid,'\\end{tabular}\n');
fprintf(fid,'\\end{table}\n');

fclose(fid);

% Short paper snippet, intentionally conservative.
fid=fopen(fullfile(outDir,'FAULTFITTED3D_PAPER_SNIPPET.tex'),'w');

fprintf(fid,'%% Auto-generated draft result paragraph; verify wording before submission.\n');

if M.Matched(1)
    fprintf(fid,['在独立的真正三维四面体算例中，以全域统一网格序列的最佳断层邻域误差为基准，', ...
        '将匹配阈值固定为其 %.0f\\%%。在该统一标准下，全域统一离散首次达到目标需要 ', ...
        '%d 个节点，而断层拟合分级网格仅需 %d 个节点，对应节点、四面体和稀疏系统非零元分别减少 ', ...
        '%.2f\\%%、%.2f\\%% 和 %.2f\\%%。匹配网格的最小四面体 mean-ratio 质量为 %.3f，', ...
        '说明计算节省并非通过近退化单元获得。该实验用于验证结构导向离散在真正三维体问题中的资源配置潜力，', ...
        '而不将其解释为所有全局误差指标均无代价改善。\n'], ...
        100*cfg.matchTolerance,M.UniformNodes(1),M.FittedNodes(1), ...
        M.NodeSavingPct(1),M.TetSavingPct(1),M.NNZSavingPct(1), ...
        M.FittedMinTetQuality(1));
else
    fprintf(fid,['当前 fault-fitted 候选网格族尚未达到统一 matched-accuracy 阈值，', ...
        '因此不报告资源节省结论，应扩展网格候选集合后重新审计。\n']);
end

fclose(fid);

end


function write_summary_ff3d(outDir,U,F,M,Theory,c0,cfg)

fid=fopen(fullfile(outDir,'FAULTFITTED3D_SUMMARY.txt'),'w');

fprintf(fid,'FAULT_AFEM_3D_FAULTFITTED_V1 SUMMARY\n');
fprintf(fid,'====================================\n\n');

fprintf(fid,'c0 selected by common sparse-observation CV : %.8g\n',c0);
fprintf(fid,'uniform best fault RMSE                    : %.6f\n',min(U.RMSE_fault));
fprintf(fid,'matched target                              : %.6f\n',M.FaultTarget(1));
fprintf(fid,'matched                                     : %d\n\n',M.Matched(1));

fprintf(fid,'Uniform minimum matched:\n');
fprintf(fid,'  nodes     : %.0f\n',M.UniformNodes(1));
fprintf(fid,'  tets      : %.0f\n',M.UniformTetrahedra(1));
fprintf(fid,'  nnz       : %.0f\n',M.UniformNNZ(1));
fprintf(fid,'  sparse B  : %.0f\n',M.UniformSparseBytes(1));
fprintf(fid,'  fault RMSE: %.6f\n',M.UniformFaultRMSE(1));
fprintf(fid,'  global    : %.6f\n',M.UniformGlobalRMSE(1));
fprintf(fid,'  q_min     : %.6f\n\n',M.UniformMinTetQuality(1));

if M.Matched(1)

    fprintf(fid,'Fault-fitted minimum matched:\n');
    fprintf(fid,'  nodes     : %.0f\n',M.FittedNodes(1));
    fprintf(fid,'  tets      : %.0f\n',M.FittedTetrahedra(1));
    fprintf(fid,'  nnz       : %.0f\n',M.FittedNNZ(1));
    fprintf(fid,'  sparse B  : %.0f\n',M.FittedSparseBytes(1));
    fprintf(fid,'  fault RMSE: %.6f\n',M.FittedFaultRMSE(1));
    fprintf(fid,'  global    : %.6f\n',M.FittedGlobalRMSE(1));
    fprintf(fid,'  q_min     : %.6f\n',M.FittedMinTetQuality(1));
    fprintf(fid,'  q_1%%      : %.6f\n',M.FittedP01TetQuality(1));
    fprintf(fid,'  h_fault   : %.3f m\n',M.FittedFaultNormalH(1));
    fprintf(fid,'  h_bg      : %.3f m\n',M.FittedBackgroundNormalH(1));
    fprintf(fid,'  h_bg/h_f  : %.3f\n\n',M.FittedNormalSpacingRatio(1));

    fprintf(fid,'Matched resource changes:\n');
    fprintf(fid,'  node saving       : %.3f %%\n',M.NodeSavingPct(1));
    fprintf(fid,'  tetra saving      : %.3f %%\n',M.TetSavingPct(1));
    fprintf(fid,'  nnz saving        : %.3f %%\n',M.NNZSavingPct(1));
    fprintf(fid,'  sparse memory save: %.3f %%\n',M.MemorySavingPct(1));
    fprintf(fid,'  global penalty    : %.3f %%\n',M.GlobalPenaltyPct(1));
    fprintf(fid,'  background penalty: %.3f %%\n\n',M.BackgroundPenaltyPct(1));

else
    fprintf(fid,'Fault-fitted family did NOT reach target.\n');
    fprintf(fid,'Resource savings are undefined and must not be reported.\n\n');
end

fprintf(fid,'Idealized 3-D two-scale interpretation:\n');
fprintf(fid,'  fault volume fraction rho  : %.4f\n',Theory.FaultVolumeFraction(1));
fprintf(fid,'  measured spacing ratio r   : %.4f\n',Theory.MeasuredSpacingRatio(1));
fprintf(fid,'  ideal measured DOF saving  : %.3f %%\n',Theory.IdealSavingPctMeasured(1));
fprintf(fid,'  model: N_A/N_U ~= rho + (1-rho)/r^3\n\n');

fprintf(fid,'Paper interpretation:\n');
fprintf(fid,'  This is an independent true 3-D m(x,y,z) proof-of-principle.\n');
fprintf(fid,'  It must be presented separately from the real C11 Z(x,y) surface case.\n');
fprintf(fid,'  The main claim is matched-accuracy resource allocation, not universal\n');
fprintf(fid,'  pointwise superiority of the fault-fitted mesh.\n');

fclose(fid);

end


function R=safe_plot_ff3d(name,fn)

R=struct('Name',name,'Passed',false,'Message','');

try
    fn();
    R.Passed=true;
    R.Message='OK';
    fprintf('  [figure pass] %s\n',name);
catch ME
    R.Passed=false;
    R.Message=ME.message;
    warning('Figure "%s" failed: %s',name,ME.message);
end

end


function write_plot_audit_ff3d(outDir,A)

fid=fopen(fullfile(outDir,'FAULTFITTED3D_PLOT_AUDIT.txt'),'w');
fprintf(fid,'FAULTFITTED3D plot/export audit\n');
fprintf(fid,'================================\n');

for i=1:numel(A)
    R=A{i};
    fprintf(fid,'%s | pass=%d | %s\n',R.Name,R.Passed,R.Message);
end

fclose(fid);

end


function save_fig_ff3d(f,fileName,cfg)

try
    exportgraphics(f,fileName,'Resolution',cfg.figureDPI);
catch
    print(f,fileName,'-dpng',sprintf('-r%d',cfg.figureDPI));
end

close(f);

end


% =========================================================================
% JOURNAL-STYLE 3-D PAPER FIGURES V1
% =========================================================================
function paperfigs_ff3d_v1(outDir,U,F,UMesh,FMesh,iu,ifit,passF,Match,Ablation,cfg)

if ~passF, return; end

pdir=fullfile(outDir,'PAPER_FIGURES_REBUILT');
if ~exist(pdir,'dir'), mkdir(pdir); end

fontName=paper_font_ff3d_v1();

paperAudit={};
paperAudit{end+1}=safe_paper_plot_ff3d_v2('3D_cutaway_mesh', ...
    @() paper_ff3d_cutaway_v1(pdir,UMesh{iu},FMesh{ifit},cfg,fontName));
paperAudit{end+1}=safe_paper_plot_ff3d_v2('3D_accuracy_nodes', ...
    @() paper_ff3d_accuracy_v1(pdir,U,F,Match.FaultTarget(1),iu,ifit,fontName));
paperAudit{end+1}=safe_paper_plot_ff3d_v2('3D_resources', ...
    @() paper_ff3d_resources_v1(pdir,Match,fontName));
paperAudit{end+1}=safe_paper_plot_ff3d_v2('3D_grading_crosssection', ...
    @() paper_ff3d_crosssection_v1(pdir,UMesh{iu},FMesh{ifit},cfg,fontName));
paperAudit{end+1}=safe_paper_plot_ff3d_v2('3D_mesh_quality', ...
    @() paper_ff3d_quality_v1(pdir,U,F,fontName));
paperAudit{end+1}=safe_paper_plot_ff3d_v2('3D_grading_ablation', ...
    @() paper_ff3d_ablation_v1(pdir,Ablation,fontName));

write_paper_plot_audit_ff3d_v2(pdir,paperAudit);
fprintf('  paper figures -> %s\n',pdir);

end


function paper_ff3d_cutaway_v1(pdir,MU,MF,cfg,fontName)

f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 8.6], ...
    'Renderer','opengl');
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

ax=nexttile(tl,1);
paper_structured_cutaway_ff3d_v1(ax,MU,cfg,fontName);
title(ax,sprintf('(a) 均匀网格（%d节点）',size(MU.P,1)), ...
    'FontName',fontName,'FontSize',9,'FontWeight','bold');

ax=nexttile(tl,2);
paper_structured_cutaway_ff3d_v1(ax,MF,cfg,fontName);
title(ax,sprintf('(b) 断层拟合分级网格（%d节点）',size(MF.P,1)), ...
    'FontName',fontName,'FontSize',9,'FontWeight','bold');

exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_01_CUTAWAY_MESH.png'),'Resolution',600);
close(f);

end


function paper_structured_cutaway_ff3d_v1(ax,M,cfg,fontName)

dims=M.Dims;
nx=dims(1); ny=dims(2); nz=dims(3);
X=reshape(M.P(:,1),dims);
Y=reshape(M.P(:,2),dims);
Z=reshape(M.P(:,3),dims);

hold(ax,'on');

% Horizontal mid-depth section.
k0=round((nz+1)/2);
for j=1:ny
    plot3(ax,squeeze(X(:,j,k0)),squeeze(Y(:,j,k0)),squeeze(Z(:,j,k0)), ...
        '-','Color',[0.37 0.42 0.46],'LineWidth',0.45);
end
for i=1:nx
    plot3(ax,squeeze(X(i,:,k0)),squeeze(Y(i,:,k0)),squeeze(Z(i,:,k0)), ...
        '-','Color',[0.37 0.42 0.46],'LineWidth',0.45);
end

% Vertical mid-y section.
j0=round((ny+1)/2);
for k=1:nz
    plot3(ax,squeeze(X(:,j0,k)),squeeze(Y(:,j0,k)),squeeze(Z(:,j0,k)), ...
        '-','Color',[0.20 0.33 0.46],'LineWidth',0.55);
end
for i=1:nx
    plot3(ax,squeeze(X(i,j0,:)),squeeze(Y(i,j0,:)),squeeze(Z(i,j0,:)), ...
        '-','Color',[0.20 0.33 0.46],'LineWidth',0.55);
end

plot_fault_surface_ff3d(ax,cfg,0.28);

paper_box_edges_ff3d_v1(ax,cfg.L);

view(ax,[-37 24]);
axis(ax,'equal');
xlim(ax,[0 cfg.L(1)]); ylim(ax,[0 cfg.L(2)]); zlim(ax,[0 cfg.L(3)]);
set(ax,'FontName',fontName,'FontSize',8.2,'LineWidth',0.65,'TickDir','out', ...
    'GridAlpha',0.12);
grid(ax,'on');
xlabel(ax,'x / m'); ylabel(ax,'y / m'); zlabel(ax,'z / m');

end


function paper_box_edges_ff3d_v1(ax,L)
x=[0 L(1)]; y=[0 L(2)]; z=[0 L(3)];
V=[x(1) y(1) z(1); x(2) y(1) z(1); x(2) y(2) z(1); x(1) y(2) z(1); ...
   x(1) y(1) z(2); x(2) y(1) z(2); x(2) y(2) z(2); x(1) y(2) z(2)];
E=[1 2;2 3;3 4;4 1;5 6;6 7;7 8;8 5;1 5;2 6;3 7;4 8];
for e=1:size(E,1)
    plot3(ax,V(E(e,:),1),V(E(e,:),2),V(E(e,:),3),'-', ...
        'Color',[0.55 0.55 0.55],'LineWidth',0.55);
end
end


function paper_ff3d_accuracy_v1(pdir,U,F,target,iu,ifit,fontName)

f=figure('Color','w','Units','centimeters','Position',[2 2 12.5 7.8], ...
    'Renderer','painters');
ax=axes(f);

semilogx(ax,U.Nodes,U.RMSE_fault,'-o','LineWidth',1.45,'MarkerSize',4.5, ...
    'Color',[0.15 0.37 0.66],'MarkerFaceColor',[0.15 0.37 0.66]);
hold(ax,'on');
semilogx(ax,F.Nodes,F.RMSE_fault,'-s','LineWidth',1.45,'MarkerSize',4.5, ...
    'Color',[0.86 0.39 0.12],'MarkerFaceColor',[0.86 0.39 0.12]);
yline(ax,target,'--','目标误差','LineWidth',1.15,'Color',[0.25 0.25 0.25]);

scatter(ax,U.Nodes(iu),U.RMSE_fault(iu),48,[0.15 0.37 0.66],'filled','MarkerEdgeColor','k');
scatter(ax,F.Nodes(ifit),F.RMSE_fault(ifit),48,[0.86 0.39 0.12],'filled','MarkerEdgeColor','k');

set(ax,'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
grid(ax,'on');
xlabel(ax,'节点数','FontName',fontName);
ylabel(ax,'断层邻域RMSE / m','FontName',fontName);
legend(ax,{'均匀网格','断层拟合分级网格'},'Location','northeast','Box','off');

exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_02_ACCURACY_NODES.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_02_ACCURACY_NODES.pdf'),'ContentType','vector');
close(f);

end


function paper_ff3d_resources_v1(pdir,M,fontName)

vals=[ ...
    M.FittedNodes(1)/M.UniformNodes(1); ...
    M.FittedTetrahedra(1)/M.UniformTetrahedra(1); ...
    M.FittedNNZ(1)/M.UniformNNZ(1); ...
    M.FittedSparseBytes(1)/M.UniformSparseBytes(1)]*100;

saving=100-vals;
labels={'节点','四面体','非零元','稀疏存储'};

f=figure('Color','w','Units','centimeters','Position',[2 2 12.0 7.6], ...
    'Renderer','painters');
b=bar(1:4,[100*ones(4,1),vals],0.72,'grouped');
b(1).FaceColor=[0.25 0.42 0.62];
b(2).FaceColor=[0.89 0.47 0.18];
b(1).EdgeColor='none'; b(2).EdgeColor='none';

ax=gca;
set(ax,'XTick',1:4,'XTickLabel',labels,'FontName',fontName,'FontSize',8.5, ...
    'LineWidth',0.7,'TickDir','out');
ylabel(ax,'相对规模 / %','FontName',fontName);
ylim(ax,[0 112]); grid(ax,'on'); ax.YGrid='on'; ax.XGrid='off';
legend(ax,{'均匀网格','断层拟合分级网格'},'Location','northoutside', ...
    'Orientation','horizontal','Box','off');

for i=1:4
    text(i+0.15,vals(i)+4,sprintf('减少%.1f%%',saving(i)), ...
        'HorizontalAlignment','center','FontName',fontName,'FontSize',8.2);
end

exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_03_RESOURCES.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_03_RESOURCES.pdf'),'ContentType','vector');
close(f);

end


function paper_ff3d_crosssection_v1(pdir,MU,MF,cfg,fontName)

f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 7.8], ...
    'Renderer','painters');
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

Ms={MU,MF};
titles={'(a) 均匀网格中截面','(b) 断层拟合分级网格中截面'};

for m=1:2
    M=Ms{m};
    dims=M.Dims;
    nx=dims(1); ny=dims(2); nz=dims(3);
    X=reshape(M.P(:,1),dims);
    Y=reshape(M.P(:,2),dims);
    Z=reshape(M.P(:,3),dims);
    k0=round((nz+1)/2);

    ax=nexttile(tl,m); hold(ax,'on');
    for j=1:ny
        plot(ax,squeeze(X(:,j,k0)),squeeze(Y(:,j,k0)),'-', ...
            'Color',[0.36 0.39 0.43],'LineWidth',0.42);
    end
    for i=1:nx
        plot(ax,squeeze(X(i,:,k0)),squeeze(Y(i,:,k0)),'-', ...
            'Color',[0.36 0.39 0.43],'LineWidth',0.42);
    end

    yy=linspace(0,cfg.L(2),500);
    zz=cfg.L(3)*(k0-1)/(nz-1);
    xf=fault_x_ff3d(yy,zz*ones(size(yy)),cfg);
    plot(ax,xf,yy,'-','LineWidth',2.1,'Color',[0.82 0.13 0.10]);

    axis(ax,'equal'); xlim(ax,[0 cfg.L(1)]); ylim(ax,[0 cfg.L(2)]);
    set(ax,'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
    xlabel(ax,'x / m'); ylabel(ax,'y / m');
    title(ax,titles{m},'FontName',fontName,'FontSize',9,'FontWeight','bold');
end

exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_04_GRADING_CROSSSECTION.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_04_GRADING_CROSSSECTION.pdf'),'ContentType','vector');
close(f);

end


function paper_ff3d_quality_v1(pdir,U,F,fontName)

f=figure('Color','w','Units','centimeters','Position',[2 2 12.4 7.7], ...
    'Renderer','painters');
ax=axes(f);

semilogx(ax,U.Nodes,U.MinTetQuality,'-o','LineWidth',1.35,'MarkerSize',4.2, ...
    'Color',[0.15 0.37 0.66]); hold(ax,'on');
semilogx(ax,F.Nodes,F.MinTetQuality,'-s','LineWidth',1.35,'MarkerSize',4.2, ...
    'Color',[0.86 0.39 0.12]);
semilogx(ax,U.Nodes,U.P01TetQuality,'--o','LineWidth',1.05,'MarkerSize',3.6, ...
    'Color',[0.15 0.37 0.66]);
semilogx(ax,F.Nodes,F.P01TetQuality,'--s','LineWidth',1.05,'MarkerSize',3.6, ...
    'Color',[0.86 0.39 0.12]);

set(ax,'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
grid(ax,'on');
xlabel(ax,'节点数'); ylabel(ax,'四面体平均比值质量');
legend(ax,{'均匀网格 q_{min}','断层拟合 q_{min}', ...
    '均匀网格 q_{1%}','断层拟合 q_{1%}'}, ...
    'Location','southwest','Box','off');

exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_05_MESH_QUALITY.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_05_MESH_QUALITY.pdf'),'ContentType','vector');
close(f);

end


function paper_ff3d_ablation_v1(pdir,A,fontName)
if isempty(A) || height(A)<2, return; end

% Use rows if method names are present; otherwise take the final two rows.
vars=A.Properties.VariableNames;
metricNames={'FaultRMSE','GlobalRMSE','BackgroundRMSE'};
if ~all(ismember(metricNames,vars)), return; end

if ismember('Method',vars)
    names=string(A.Method);
    iU=find(contains(lower(names),'ungraded'),1);
    iG=find(contains(lower(names),'graded') & ~contains(lower(names),'ungraded'),1);
else
    iU=max(1,height(A)-1); iG=height(A);
end
if isempty(iU) || isempty(iG), return; end

V=[A.FaultRMSE([iU iG]),A.GlobalRMSE([iU iG]),A.BackgroundRMSE([iU iG])];

f=figure('Color','w','Units','centimeters','Position',[2 2 12.2 7.8], ...
    'Renderer','painters');
b=bar(V.','grouped');
b(1).FaceColor=[0.52 0.58 0.64];
b(2).FaceColor=[0.86 0.39 0.12];
b(1).EdgeColor='none'; b(2).EdgeColor='none';
ax=gca;
set(ax,'XTickLabel',{'断层邻域RMSE','全区RMSE','背景RMSE'}, ...
    'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
ylabel(ax,'RMSE / m');
grid(ax,'on'); ax.YGrid='on'; ax.XGrid='off';
legend(ax,{'断层拟合未分级','断层拟合分级'},'Location','northoutside', ...
    'Orientation','horizontal','Box','off');

exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_06_GRADING_ABLATION.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_3D_06_GRADING_ABLATION.pdf'),'ContentType','vector');
close(f);
end


function R=safe_paper_plot_ff3d_v2(name,fn)
R=struct('Name',name,'Passed',false,'Message','');
try
    fn();
    R.Passed=true;
    R.Message='OK';
    fprintf('  [paper figure pass] %s\n',name);
catch ME
    R.Passed=false;
    R.Message=ME.message;
    warning('Paper figure "%s" failed: %s',name,ME.message);
end
end

function write_paper_plot_audit_ff3d_v2(pdir,A)
fid=fopen(fullfile(pdir,'PAPER_FIGURE_AUDIT.txt'),'w');
fprintf(fid,'3-D journal-style paper figure audit\n');
fprintf(fid,'====================================\n');
for i=1:numel(A)
    R=A{i};
    fprintf(fid,'%s | pass=%d | %s\n',R.Name,R.Passed,R.Message);
end
fclose(fid);
end

function name=paper_font_ff3d_v1()
cands={'Microsoft YaHei','SimHei','SimSun','Arial Unicode MS','Arial'};
avail=listfonts;
name='Arial';
for i=1:numel(cands)
    if any(strcmpi(avail,cands{i}))
        name=cands{i}; return;
    end
end
end
