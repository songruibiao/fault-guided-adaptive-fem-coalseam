function outDir=PAPER_SCALING_AND_SUMMARY_FIGURES_V1
% PAPER_SCALING_AND_SUMMARY_FIGURES_V1
% Journal-style plots from the FINALIZED 2-D scaling summary reported in
% the manuscript.  No truth/model re-tuning occurs here; this file only
% redraws the frozen numerical summary in publication style.
%
% Direct run:
%   PAPER_SCALING_AND_SUMMARY_FIGURES_V1

outDir=fullfile(pwd,['out_PAPER_SCALING_FIGURES_' datestr(now,'yyyymmdd_HHMMSS')]);
if ~exist(outDir,'dir'), mkdir(outDir); end

fontName=paper_font_scaling_v1();

scale=[1 2 4 8];
uniformNodes=[784 2401 8281 26896];
adaptiveNodes=[99 280 1001 3438];
nodeSaving=[80.99 87.98 87.76 87.84];
nodeSavingStd=[6.53 0.85 0.95 3.26];
nnzSaving=[81.58 87.44 85.91 85.56];
globalPenalty=[10.59 9.58 9.77 13.74];
idealSaving=[75.01 85.02 90.13 92.67];

% ---------------------------------------------------------------------
% Fig S1: absolute node counts + savings.
% ---------------------------------------------------------------------
f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 7.8], ...
    'Renderer','painters');
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

ax=nexttile(tl,1);
loglog(ax,scale,uniformNodes,'-o','LineWidth',1.5,'MarkerSize',5, ...
    'Color',[0.15 0.37 0.66],'MarkerFaceColor',[0.15 0.37 0.66]);
hold(ax,'on');
loglog(ax,scale,adaptiveNodes,'-s','LineWidth',1.5,'MarkerSize',5, ...
    'Color',[0.86 0.39 0.12],'MarkerFaceColor',[0.86 0.39 0.12]);
set(ax,'XTick',scale,'XTickLabel',{'1×','2×','4×','8×'}, ...
    'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
grid(ax,'on');
xlabel(ax,'区域线性尺度');
ylabel(ax,'达到目标精度所需节点数');
title(ax,'(a) 等精度条件下节点规模','FontName',fontName,'FontSize',9,'FontWeight','bold');
legend(ax,{'均匀网格','自适应网格'},'Location','northwest','Box','off');

ax=nexttile(tl,2);
errorbar(ax,scale,nodeSaving,nodeSavingStd,'o-','LineWidth',1.45,'MarkerSize',5, ...
    'Color',[0.15 0.37 0.66],'MarkerFaceColor',[0.15 0.37 0.66]);
hold(ax,'on');
plot(ax,scale,idealSaving,'--','LineWidth',1.25,'Color',[0.45 0.45 0.45]);
set(ax,'XTick',scale,'XTickLabel',{'1×','2×','4×','8×'}, ...
    'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
ylim(ax,[70 98]); grid(ax,'on');
xlabel(ax,'区域线性尺度');
ylabel(ax,'节点减少率 / %');
title(ax,'(b) 节点减少率','FontName',fontName,'FontSize',9,'FontWeight','bold');
legend(ax,{'3组试验均值±标准差','两尺度理想估计'},'Location','southeast','Box','off');

exportgraphics(f,fullfile(outDir,'PAPER_FIG_SCALING_01_NODE_EFFICIENCY.png'),'Resolution',600);
exportgraphics(f,fullfile(outDir,'PAPER_FIG_SCALING_01_NODE_EFFICIENCY.pdf'),'ContentType','vector');
close(f);

% ---------------------------------------------------------------------
% Fig S2: resource saving vs global-error change.
% ---------------------------------------------------------------------
f=figure('Color','w','Units','centimeters','Position',[2 2 12.5 7.6], ...
    'Renderer','painters');
yyaxis left
plot(scale,nnzSaving,'-o','LineWidth',1.45,'MarkerSize',5, ...
    'Color',[0.15 0.37 0.66],'MarkerFaceColor',[0.15 0.37 0.66]);
ylabel('非零元减少率 / %');
ylim([75 95]);

yyaxis right
plot(scale,globalPenalty,'-s','LineWidth',1.45,'MarkerSize',5, ...
    'Color',[0.86 0.39 0.12],'MarkerFaceColor',[0.86 0.39 0.12]);
ylabel('全区RMSE变化 / %');
ylim([0 18]);

ax=gca;
set(ax,'XTick',scale,'XTickLabel',{'1×','2×','4×','8×'}, ...
    'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
grid(ax,'on');
xlabel('区域线性尺度');
legend({'非零元减少率','全区RMSE增加率'},'Location','northwest','Box','off');

exportgraphics(f,fullfile(outDir,'PAPER_FIG_SCALING_02_RESOURCE_ERROR_TRADEOFF.png'),'Resolution',600);
exportgraphics(f,fullfile(outDir,'PAPER_FIG_SCALING_02_RESOURCE_ERROR_TRADEOFF.pdf'),'ContentType','vector');
close(f);

T=table(scale.',uniformNodes.',adaptiveNodes.',nodeSaving.',nodeSavingStd.', ...
    nnzSaving.',globalPenalty.',idealSaving.', ...
    'VariableNames',{'Scale','UniformNodes','AdaptiveNodes','NodeSavingPct', ...
    'NodeSavingStdPct','NNZSavingPct','GlobalRMSEChangePct','IdealSavingPct'});
writetable(T,fullfile(outDir,'PAPER_SCALING_VALUES.csv'));

fprintf('Finished: %s\n',outDir);
end

function name=paper_font_scaling_v1()
cands={'Microsoft YaHei','SimHei','SimSun','Arial Unicode MS','Arial'};
avail=listfonts;
name='Arial';
for i=1:numel(cands)
    if any(strcmpi(avail,cands{i}))
        name=cands{i}; return;
    end
end
end
