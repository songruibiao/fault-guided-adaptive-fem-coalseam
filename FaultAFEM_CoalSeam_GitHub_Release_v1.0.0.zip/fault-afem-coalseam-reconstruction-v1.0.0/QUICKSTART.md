# Quick start

1. Open MATLAB in the repository root.
2. Run `RUN_CHECK`.
3. For the self-contained benchmark, run `RUN_3D_SYNTHETIC`.
4. For C11, place `TVD_C11.dat` and `Dingji_t11_plg.dat` in `data/C11/`, then run `RUN_C11_REALDATA`.
5. To audit frozen paper numbers without MATLAB, run `python scripts/verify_reported_values.py`.

Do **not** use `archive/experimental_parameter_reduced_v2/` to reproduce the current manuscript tables: it is a later experimental branch with a different parameterization.
