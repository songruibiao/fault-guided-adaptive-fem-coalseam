# Changelog

## v1.0.0 - GitHub cleanup release

- Selected the current-manuscript V4/V5 paper-equivalent code path as canonical.
- Separated the later parameter-reduced V2 branch into `archive/experimental_parameter_reduced_v2/`.
- Removed timestamped historical output duplication, nested ZIPs, PPT material and exact duplicate MATLAB copies from the public-facing tree.
- Curated frozen outputs that match the current manuscript tables/figures.
- Added MATLAB entry-point wrappers, data requirements, paper-to-code map, reproducibility notes, integrity manifest and a standard-library Python result checker.
- Applied two non-numerical hygiene edits to the complement-suite copy (core function name and output-folder label); see `REPRODUCIBILITY.md`.
