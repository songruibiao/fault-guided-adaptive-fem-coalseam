#!/usr/bin/env python3
from pathlib import Path
import csv, math, sys
ROOT=Path(__file__).resolve().parents[1]

def rows(rel):
    with (ROOT/rel).open(newline='',encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def near(x,y,tol=0.02): return abs(float(x)-float(y)) <= tol

def pct_drop(a,b): return 100.0*(float(a)-float(b))/float(a)

ok=True
print('Fault-AFEM frozen-result audit')

E=rows('results/c11/supplement/E1_EQUAL_BUDGET_FACTORIAL.csv')
D={r['Method']:r for r in E}
r_fault=pct_drop(D['U-ISO']['RMSE_Fault_m'],D['A-FLT']['RMSE_Fault_m'])
r_jump=pct_drop(D['U-ISO']['JumpMAE_m'],D['A-FLT']['JumpMAE_m'])
checks=[('200-node fault RMSE reduction (%)',r_fault,8.93,0.02),
        ('200-node MAE_int reduction (%)',r_jump,37.57,0.02)]

S=rows('results/scaling2d/PAPER_SCALING_VALUES.csv')
svals=[float(r['NodeSavingPct']) for r in S if float(r['Scale']) in (2,4,8)]
checks.append(('2D scale 2x-8x mean node saving (%)',sum(svals)/len(svals),87.86,0.02))

M=rows('results/benchmark3d/FAULTFITTED3D_MATCHED_ACCURACY.csv')[0]
checks.append(('3D matched-accuracy node saving (%)',float(M['NodeSavingPct']),84.44,0.02))

A=rows('results/benchmark3d/FAULTFITTED3D_ABLATION.csv')
AD={r['Method']:r for r in A}
r3=pct_drop(AD['FITTED_UNGRADED']['FaultRMSE'],AD['FITTED_GRADED']['FaultRMSE'])
checks.append(('3D same-topology grading fault-RMSE reduction (%)',r3,32.41,0.02))

for name,val,target,tol in checks:
    passed=abs(val-target)<=tol
    ok = ok and passed
    print(f"{'PASS' if passed else 'FAIL':4s}  {name}: {val:.4f} (paper {target:.2f})")

print('\nAll headline checks passed.' if ok else '\nOne or more checks failed.')
sys.exit(0 if ok else 1)
