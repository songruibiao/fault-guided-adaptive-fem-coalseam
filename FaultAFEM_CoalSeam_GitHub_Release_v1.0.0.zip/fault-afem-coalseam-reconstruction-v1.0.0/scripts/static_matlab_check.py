#!/usr/bin/env python3
from pathlib import Path
import re, sys
ROOT=Path(__file__).resolve().parents[1]
files=list((ROOT/'code').rglob('*.m')) + [ROOT/x for x in ['RUN_CHECK.m','RUN_C11_REALDATA.m','RUN_3D_SYNTHETIC.m','RUN_REPORTED_SCALING_FIGURE.m','RUN_ALL_AVAILABLE.m']]
ok=True
for p in files:
    text=p.read_text(encoding='utf-8',errors='replace')
    m=re.search(r'^\s*function(?:\s+[^=\n]+\s*=\s*|\s+)([A-Za-z]\w*)',text,re.M)
    if not m:
        print('WARN no function declaration:',p.relative_to(ROOT)); continue
    fn=m.group(1); good=(fn==p.stem)
    ok=ok and good
    print(('PASS' if good else 'FAIL'), p.relative_to(ROOT), '->', fn)
sys.exit(0 if ok else 1)
