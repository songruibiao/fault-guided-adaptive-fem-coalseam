# C11 real-data inputs

The uploaded source archive did **not** contain the raw C11 `.dat` files required by the current paper-equivalent MATLAB code. To reproduce the real-data experiments, copy the original author data here.

Required files:

## `TVD_C11.dat`

The current MATLAB reader uses `textscan(...,'%f%f%f%f%f',...)` and therefore expects **five numeric columns**. In the original code these represent the C11 interpreted horizon records (including planar coordinates and elevation/depth information used by the preprocessing routine).

## `Dingji_t11_plg.dat`

The current MATLAB reader also expects **five numeric columns** for the study-area polygon records; comment/header lines beginning with `#` are tolerated by the reader used in the project.

## Optional fault-stick file

The core code can inspect an optional fault-stick file when available, but the two files above are the required inputs detected by the release wrapper.

### Data-sharing note

If these mine data cannot be redistributed publicly, keep them out of Git and provide an access statement (for example, "available from the corresponding author subject to data-use restrictions"). Do not commit confidential mine coordinates unless redistribution is authorized.
