# Reproducibility statement

## Scope

This repository distinguishes three levels of reproducibility:

- **Executable from this release alone:** the 3-D synthetic static graded-mesh experiment.
- **Executable when the original C11 mine data are supplied:** C11 core reconstruction, equal-budget ablation, perturbation robustness, parameter sensitivity, external baselines, Bayesian-GP diagnostics, and repeated sparse-control sampling.
- **Numerically auditable but not exactly regenerable from the supplied archive:** the manuscript's original 2-D scale-expansion simulation. The frozen summary CSV and its plotting code are included, but the exact generator that produced those frozen values was not present in the uploaded archive.

## Missing C11 raw data

The canonical real-data code requires:

- `TVD_C11.dat`: five numeric columns read by the code as the horizon point file.
- `Dingji_t11_plg.dat`: five numeric columns read by the code as the study-area polygon file.

Neither `.dat` file was present in the uploaded archive. We therefore do not create synthetic substitutes under the same filenames. This matters because the high-density interpreted C11 reference and the study boundary cannot be reconstructed exactly from the included reduced result state.

## 2-D scaling limitation

The manuscript reports node savings of 87.86% on average for the 2x-8x scale-expansion cases at a common fault-neighborhood error threshold. `results/scaling2d/PAPER_SCALING_VALUES.csv` stores the frozen values used for the paper figure. `code/scaling2d/PAPER_SCALING_AND_SUMMARY_FIGURES_V1.m` only redraws this frozen summary.

A later script named `FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2.m` was present in the source archive, but it implements a different parameter-reduced method and does not reproduce the current manuscript's frozen scaling values. It is retained only under `archive/experimental_parameter_reduced_v2/`.

## Release-only code hygiene changes

`code/c11/RUN_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4.m` was copied from the supplied V4 file with **non-numerical cleanup only**:

1. its automatic core-function reference was updated from the historical `...PAPERFIGS_V3_FIX1` name to the included current `...PAPERFIGS_V5_FINALCN` name;
2. its generated output-directory prefix was updated from the historical `...SUITE_V2_` label to `...SUITE_V4_`.

No numerical formulas, constants, algorithms, experiment settings, or result values were changed.

## Numerical execution in this packaging environment

MATLAB/Octave is not installed in the packaging environment, so the MATLAB programs were not numerically rerun here. The release was checked structurally, selected results were cross-checked against the manuscript, and `scripts/verify_reported_values.py` validates headline frozen values from the CSV files.
