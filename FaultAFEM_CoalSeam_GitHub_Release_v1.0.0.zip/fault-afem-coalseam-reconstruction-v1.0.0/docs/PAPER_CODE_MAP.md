# Paper-to-code map

| Paper component | Canonical code | Frozen result(s) |
|---|---|---|
| Fault-aware P1 FEM and budget-constrained AFEM | `code/c11/REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN.m` | `results/c11/core/MAIN_metrics.csv`, stopping/tuning CSVs |
| Strict 200-node U-ISO/U-FLT/A-ISO/A-FLT ablation | `code/c11/RUN_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4.m` | `results/c11/supplement/E1_EQUAL_BUDGET_FACTORIAL.csv` |
| Fault geometry perturbation | same complement suite | `E2_FAULT_*` CSVs |
| epsilon_min / sigma_Gamma / omega_g sensitivity | same complement suite | `E3_PARAMETER_SENSITIVITY.csv` |
| TPS, Gaussian RBF, ordinary/anisotropic kriging, Bayesian GP | same complement suite | `E4_EXTERNAL_BASELINES.csv` |
| Repeated sparse-control sampling | same complement suite | `E5_REPEATED_SPARSE_CONTROL_SAMPLING*.csv` |
| Common-c0 submission-stage audit | `code/c11/RUN_C11_COMMON_C0_EQUAL_BUDGET_AUDIT_V2_FIX1.m` | run on demand when C11 data are available |
| 2-D scale-expansion paper figure | `code/scaling2d/PAPER_SCALING_AND_SUMMARY_FIGURES_V1.m` | `results/scaling2d/PAPER_SCALING_VALUES.csv` (frozen values) |
| 3-D static fault-fitted graded mesh | `code/benchmark3d/FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2.m` | `results/benchmark3d/FAULTFITTED3D_MATCHED_ACCURACY.csv`, `...ABLATION.csv` |
| Current manuscript source | `paper/manuscript.tex` | `paper/manuscript.pdf` |

## Manuscript figure mapping

The TeX source expects the following paths, all included here:

- `paper/figures/fig01_method_concept.png`
- `paper/figures/fig02_c11_uniform_vs_adaptive.png`
- `paper/figures/fig03_c11_method_comparison.png`
- `paper/figures/fig04_c11_local_error.png`
- `paper/figures/fig05_scaling.png`
- `paper/figures/fig06_3d_cutaway.png`
