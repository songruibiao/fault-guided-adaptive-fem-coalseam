# Cleanup report

## Original supplied ZIP

- Files: **447**
- Uncompressed size: **117.88 MiB**
- MATLAB files found: **34**
- Unique MATLAB contents by SHA-256: **23**
- Exact duplicate MATLAB copies beyond the first: **11**

## Canonical version choice

The current manuscript appendix describes the hybrid refinement formulation (numerical/geometric weights 0.65/0.35, Dörfler theta 0.45, engineering-CV alpha 0.50). The canonical C11 code was therefore selected from the `...CORE_V4...PAPERFIGS_V5_FINALCN` line, together with the V4 final complement suite.

The `FAULT_AFEM_PARAMETER_REDUCED_V2` folder changes those design choices and yields different scale-expansion behavior; it was moved to `archive/experimental_parameter_reduced_v2/` instead of being mixed into the main code path.

## Excluded from the clean GitHub tree

- timestamped duplicate `out_*` directories except for curated frozen CSV/MAT results copied to `results/`;
- duplicate MATLAB copies from `新建文件夹/`;
- nested ZIP archives;
- PowerPoint working material;
- old/intermediate code versions that are superseded by the canonical files;
- redundant PNG/PDF plots not referenced by the current manuscript.

## Known reproducibility gaps

1. `TVD_C11.dat` and `Dingji_t11_plg.dat` are absent from the supplied archive, so the real C11 experiment cannot be regenerated from this release alone.
2. The exact original 2-D scaling simulation generator that produced the manuscript's frozen 87.86% average node saving is absent. The frozen CSV and plotting code are preserved. The later parameter-reduced scaling code is not treated as a substitute.
3. MATLAB/Octave was unavailable in the packaging environment, so no numerical rerun is claimed.
