# GitHub release checklist

Before making the repository public:

- [ ] Decide whether the C11 raw mine data can legally and contractually be redistributed.
- [ ] If redistribution is allowed, add `TVD_C11.dat` and `Dingji_t11_plg.dat` under `data/C11/` and remove/adjust the corresponding `.gitignore` rule.
- [ ] If redistribution is not allowed, add the final data-availability statement and contact/access procedure to the paper and README.
- [ ] Choose an explicit software license and replace `LICENSE-NOTICE.md` with the selected license text.
- [ ] Run `python scripts/verify_reported_values.py` and `python scripts/static_matlab_check.py`.
- [ ] Run `RUN_CHECK` in the MATLAB version used for the paper.
- [ ] Run the self-contained `RUN_3D_SYNTHETIC` once on a clean clone and compare its CSV outputs with `results/benchmark3d/`.
- [ ] If C11 data can be supplied, run `RUN_C11_REALDATA` from a clean clone and compare Table 3/Table 4 values with the frozen CSVs.
- [ ] Confirm author names/order in `CITATION.cff` and add DOI/journal metadata after acceptance/publication.
- [ ] Create a tagged GitHub release (for example `v1.0.0`) and optionally archive it with Zenodo to obtain a software DOI.
