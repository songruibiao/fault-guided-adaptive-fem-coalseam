# Fault-guided budget-constrained adaptive FEM for coal-seam surface reconstruction

GitHub-ready research code accompanying the manuscript **“Budget-constrained adaptive finite element reconstruction of coal-seam surfaces guided by fault geometry”** (Chinese: **“断层几何引导的煤层面预算约束自适应有限元重建”**).

[中文说明 / Chinese README](README_CN.md)

This release was reorganized from the authors' supplied MATLAB code/results archive. The goal is to make the **paper-equivalent implementation** easy to find and to separate it from historical outputs and a later experimental parameter-reduced branch.

## What is the paper method?

The manuscript uses continuous P1 finite elements, a fault-direction anisotropic regularization tensor, a hybrid numerical/geometric refinement indicator under a hard node budget, and a predictive + local-morphology stability rule for selecting mesh size. The strict 200-node ablation separates the effects of fault-aware regularization and adaptive degree-of-freedom placement.

## Repository layout

```text
.
├── RUN_CHECK.m                         # first command to run
├── RUN_C11_REALDATA.m                  # C11 core + supplementary experiments
├── RUN_3D_SYNTHETIC.m                  # self-contained 3-D benchmark
├── RUN_REPORTED_SCALING_FIGURE.m       # redraws frozen 2-D scaling summary
├── RUN_ALL_AVAILABLE.m
├── code/
│   ├── c11/                            # canonical current-manuscript C11 code
│   ├── benchmark3d/                    # canonical current-manuscript 3-D code
│   ├── scaling2d/                      # figure script for reported frozen summary
│   └── figures/                        # figure helper
├── data/C11/README.md                  # required real-data file formats
├── results/                            # frozen outputs used to audit paper numbers
├── paper/                              # manuscript PDF, TeX, and referenced figures
├── scripts/verify_reported_values.py   # no third-party Python packages required
├── docs/
└── archive/experimental_parameter_reduced_v2/
```

## Quick start

### 1. Check the release

From MATLAB, with the repository root as the current directory:

```matlab
report = RUN_CHECK;
```

The code uses functionality available in modern MATLAB releases; **R2020a or newer is recommended** because the plotting code uses `tiledlayout` / `exportgraphics`.

### 2. Run the self-contained 3-D synthetic benchmark

```matlab
out3d = RUN_3D_SYNTHETIC;
```

No mine data are required for this experiment.

### 3. Reproduce the C11 real-data experiment

Place the two required files in `data/C11/`:

```text
TVD_C11.dat
Dingji_t11_plg.dat
```

Then run:

```matlab
outC11 = RUN_C11_REALDATA;
```

**Important:** these raw C11 files were not contained in the archive supplied for this cleanup, so they are intentionally **not fabricated or silently reconstructed**. Frozen numerical outputs are included under `results/c11/` so the reported tables can still be audited.

### 4. Check the headline manuscript values without MATLAB

```bash
python scripts/verify_reported_values.py
```

This verifies the strict 200-node ablation, the reported 2-D scaling average, and the 3-D node-saving result directly from the included frozen CSV files.

## Reproducibility status

| Manuscript component | Status in this release |
|---|---|
| C11 core FEM / AFEM implementation | Code included; rerun requires author-supplied raw C11 `.dat` files |
| Strict 200-node equal-budget ablation | Code + frozen outputs included; rerun requires C11 data |
| Fault-position/orientation perturbation | Code + frozen outputs included; rerun requires C11 data |
| Parameter sensitivity | Code + frozen outputs included; rerun requires C11 data |
| External baselines / Bayesian GP | Code + frozen outputs included; rerun requires C11 data |
| Repeated sparse-control sampling | Code + frozen outputs included; rerun requires C11 data |
| 2-D scale-expansion values reported in the manuscript | Frozen CSV + plotting code included; the exact original simulation generator was not present in the supplied archive |
| 3-D static fault-fitted graded mesh | Fully self-contained code + frozen outputs included |

See [`REPRODUCIBILITY.md`](REPRODUCIBILITY.md) and [`docs/PAPER_CODE_MAP.md`](docs/PAPER_CODE_MAP.md) for details.

## Current paper-equivalent parameterization

The canonical code in `code/c11/` corresponds to the manuscript appendix: hybrid indicator weights 0.65/0.35, Dörfler marking 0.45, candidate node budgets `[120,135,150,175,200,225,250,300,400,550]`, engineering-risk weight `alpha=0.50`, and the common strict-ablation value `c0=5.6234e-3`.

The folder `archive/experimental_parameter_reduced_v2/` contains a later alternative parameterization (set-union marking, joint parameter selection, etc.). **It is not the implementation used for the current manuscript results.**

## Integrity and provenance

`MANIFEST.sha256` contains checksums for all release files. `docs/ORIGINAL_ARCHIVE_MANIFEST.txt` records every path in the original supplied ZIP, including excluded duplicate/historical output folders.

## License

No software license was specified in the supplied materials. Before making the repository public, the authors should choose an explicit license. Until then, normal copyright restrictions apply. See `LICENSE-NOTICE.md`.
