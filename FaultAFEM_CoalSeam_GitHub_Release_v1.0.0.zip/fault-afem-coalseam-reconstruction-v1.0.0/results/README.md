# Frozen numerical results

These are curated outputs copied from the supplied archive because they match the numerical values used in the current manuscript. Timestamped historical output directories, duplicate plots, nested ZIPs, and obsolete runs were intentionally excluded.

- `c11/core/`: main real-data reconstruction, stopping and tuning diagnostics.
- `c11/supplement/`: strict equal-budget ablation, robustness, sensitivity, external baselines and repeated sparse controls.
- `c11/TABLE3_MANUSCRIPT_METHODS.csv`: convenience table assembled from the two canonical C11 result files in manuscript order.
- `scaling2d/`: frozen scale-expansion values used by the paper figure.
- `benchmark3d/`: static graded-mesh benchmark outputs.
