function outDir = RUN_REPORTED_SCALING_FIGURE()
% RUN_REPORTED_SCALING_FIGURE  Redraw the frozen 2-D scaling summary.
% IMPORTANT: this does NOT rerun the original scale-expansion simulations.
% The original generator matching the manuscript's frozen 87.86% result was
% not present in the supplied archive. See REPRODUCIBILITY.md.
root = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(root,'code')));
old = pwd;
cleanup = onCleanup(@() cd(old));
cd(root);
outDir = PAPER_SCALING_AND_SUMMARY_FIGURES_V1;
end
