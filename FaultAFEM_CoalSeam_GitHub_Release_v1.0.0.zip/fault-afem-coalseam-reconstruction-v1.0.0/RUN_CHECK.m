function report = RUN_CHECK(dataDir)
% RUN_CHECK  Static environment/data check for the GitHub release.
root = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(root,'code')));
if nargin < 1 || isempty(dataDir)
    dataDir = fullfile(root,'data','C11');
end
fprintf('\nFault-AFEM GitHub release check\n');
fprintf('MATLAB: %s\n', version);
try
    v = ver('MATLAB');
    fprintf('Release metadata: %s\n', v.Version);
catch
end
requiredCode = { ...
    'REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN', ...
    'RUN_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4', ...
    'FAULT_AFEM_3D_FAULTFITTED_V1_FIX1_PAPERFIGS_V2_FIX2', ...
    'PAPER_SCALING_AND_SUMMARY_FIGURES_V1'};
codeOK = true;
for k=1:numel(requiredCode)
    tf = exist(requiredCode{k},'file')==2;
    fprintf('  code %-68s : %s\n', requiredCode{k}, passfail(tf));
    codeOK = codeOK && tf;
end
reqData = {'TVD_C11.dat','Dingji_t11_plg.dat'};
dataOK = true;
for k=1:numel(reqData)
    tf = exist(fullfile(dataDir,reqData{k}),'file')==2;
    fprintf('  data %-68s : %s\n', reqData{k}, passfail(tf));
    dataOK = dataOK && tf;
end
fprintf('\n3-D synthetic benchmark can run without C11 data.\n');
if ~dataOK
    fprintf('C11 real-data runs are disabled until the two required .dat files are supplied.\n');
end
report = struct('root',root,'codeOK',codeOK,'dataOK',dataOK,'dataDir',dataDir);
end
function s=passfail(tf)
if tf, s='OK'; else, s='MISSING'; end
end
