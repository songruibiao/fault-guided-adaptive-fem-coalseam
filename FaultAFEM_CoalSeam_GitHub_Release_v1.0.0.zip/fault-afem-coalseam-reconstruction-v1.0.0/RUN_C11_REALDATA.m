function out = RUN_C11_REALDATA(dataDir)
% RUN_C11_REALDATA  Reproduce the C11 core + manuscript complement suite.
root = fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(root,'code')));
if nargin < 1 || isempty(dataDir)
    dataDir = fullfile(root,'data','C11');
end
required = {fullfile(dataDir,'TVD_C11.dat'), fullfile(dataDir,'Dingji_t11_plg.dat')};
for k=1:numel(required)
    if exist(required{k},'file')~=2
        error(['Missing C11 input: ' required{k} newline ...
               'See data/C11/README.md. The raw mine data were not present in the supplied archive.']);
    end
end
coreDir = REAL_C11_FAULT_AFEM_CORE_V4_GEOMRES_BGSAFE_PAPERFIGS_V5_FINALCN(dataDir);
suppDir = RUN_C11_FINAL_PAPER_COMPLEMENT_SUITE_V4(coreDir,dataDir);
out = struct('coreDir',coreDir,'supplementDir',suppDir);
end
