FAULT-AFEM PARAMETER-REDUCED V2
=================================

Purpose
-------
This package re-runs the three paper experiments with a reduced-parameter
methodology:

A. Real C11 main reconstruction and stopping-scale selection.
B. Strict N=200 equal-budget factorial ablation.
C. 2-D scale-expansion matched-accuracy validation.

Main MATLAB entry
-----------------
    OUT = RUN_FAULT_AFEM_PARAMETER_REDUCED_V2('', 'quick');

After the quick run passes:
    OUT = RUN_FAULT_AFEM_PARAMETER_REDUCED_V2('', 'paper');

If automatic C11 data discovery fails:
    OUT = RUN_FAULT_AFEM_PARAMETER_REDUCED_V2( ...
        'G:\...\data_C11','paper');

The C11 data folder must contain:
    TVD_C11.dat
    Dingji_t11_plg.dat

Files
-----
1. RUN_FAULT_AFEM_PARAMETER_REDUCED_V2.m
   One-command driver.

2. REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2.m
   Real C11 parameter-reduced main engine.

3. RUN_C11_EQUAL_BUDGET_PARAMETER_REDUCED_V2.m
   Strict N=200 equal-budget 2x2 factorial ablation.

4. FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2.m
   Formal 2-D scale-expansion validation.

What changed relative to the previous paper engine
--------------------------------------------------
1. Fault influence scale:
       sigma_Gamma = interpreted fault robust half-width95
   It is no longer prescribed as 55 m.

2. Core fault regularization:
       (c0, epsilon_min)
   is selected jointly by buffered spatial CV using sparse controls only.

3. Scalar TPS / isotropic-FEM regularization:
   standard one-standard-error selection replaces the fixed 1% plateau rule.

4. Spatial-CV buffer:
       min(sigma_Gamma, median sparse-control nearest-neighbour spacing)
   rather than a prescribed physical distance.

5. Adaptive marking:
       M = M_residual(Dorfler) UNION M_fault(one-sigma geometry band)
   There is no 0.65/0.35 residual--geology weighted sum.

6. Removed from the active refinement algorithm:
       sigma_geo
       omega_r, omega_g
       g_force, g_bg
       omega_bg
       the 0.15 geometry-priority coefficient
       prescribed h_geo / h_bg refinement priorities

7. Predictive stopping:
   global and fault-weighted CV risks are treated as separate one-SE
   constraints:
       A_pred = A_global INTERSECT A_fault
   There is no alpha=0.5 weighted engineering-risk objective.

8. Structural stopping:
   field/gradient thresholds are estimated from the variation caused by
   spatial-CV withholding on the finest internal mesh.  There is no q_SE
   multiplier and no c_tail multiplier.

9. Strict N=200 ablation:
   both branches contain exactly 200 nodes.  The exact quasi-uniform mesh
   construction derives its candidate density from N and aspect ratio.

10. Scale expansion:
    sigma_Gamma is derived from base-scale sparse-control spacing;
    (lambda_dimless, epsilon_min) are jointly calibrated on base-scale
    sparse controls and then frozen for all larger scales and seeds.
    Adaptive marking uses the same residual-set UNION geometry-set rule.

Parameter status
----------------
Method-defining free coefficients have been reduced substantially, but this
does NOT mean that every numerical setting disappears.  The main remaining
fixed AFEM marking parameter is the standard Dorfler theta=0.5.  Fold counts,
candidate grids, solver tolerances, plotting resolution, evaluation sampling,
and the tested node-budget ladder are numerical/experimental settings rather
than fitted geological-model coefficients.

Key C11 outputs
---------------
    PARAMETER_PROVENANCE_V2.csv
    PARAMETER_PROVENANCE_V2.txt
    TUNING_FAULT_FEM_C0_EPS.csv
    TUNING_TPS.csv
    TUNING_ISO_FEM.csv
    AFEM_STOP_PREDICTIVE_CV.csv
    STRUCT_STOP_data_variability.csv
    STRUCT_STOP_self_convergence.csv
    AFEM_STOP_FINAL.csv
    MAIN_metrics.csv
    CORE_RESULT_STATE.mat

Key equal-budget outputs
------------------------
    E1_EQUAL_BUDGET_FACTORIAL.csv
    E1_EQUAL_BUDGET_EFFECTS.csv
    EQUAL_BUDGET_PARAMETER_REDUCED_V2_STATE.mat

Key scaling outputs
-------------------
    SCALING_PARAMETER_CALIBRATION.csv
    SCALING_ALL_CURVES.csv
    SCALING_PAPER_MATCHED_ACCURACY.csv
    SCALING_AGGREGATE.csv
    SCALING_THEORY.csv
    SCALING_STATE.mat

Recommended execution order
---------------------------
1. Run QUICK.
2. Inspect:
       PARAMETER_PROVENANCE_V2.csv
       TUNING_FAULT_FEM_C0_EPS.csv
       AFEM_STOP_FINAL.csv
       E1_EQUAL_BUDGET_FACTORIAL.csv
       SCALING_PAPER_MATCHED_ACCURACY.csv
3. If QUICK completes without an uncertified C11 stop, run PAPER.
4. Replace manuscript numbers only after PAPER outputs have been checked.

Scientific caution
------------------
Dense C11 interpreted reference values and dense synthetic scaling truth are
used only for retrospective evaluation.  They are not used to choose C11
regularization parameters, adaptive marks, or the stopping scale.

The residual indicator remains a refinement-ranking device.  This code does
not claim a theorem-level AFEM reliability/efficiency bound.
