function outDir = RUN_C11_EQUAL_BUDGET_PARAMETER_REDUCED_V2(coreRunDir,dataDir)
% RUN_C11_EQUAL_BUDGET_PARAMETER_REDUCED_V2
% =========================================================================
% Strict N=200 factorial ablation using the parameter-reduced V2 state.
%
%   U-ISO : isotropic regularization + exact-N quasi-uniform mesh
%   U-FLT : CV-selected fault regularization + same quasi-uniform mesh
%   A-ISO : isotropic regularization + same structure-guided adaptive mesh
%   A-FLT : CV-selected fault regularization + same adaptive mesh
%
% The two meshes both contain exactly 200 nodes.  c0 and epsilon_min are
% inherited from the main sparse-data calibration; dense C11 reference data
% enter only the retrospective evaluation.
% =========================================================================
clc;
close all;

if nargin < 1, coreRunDir = ''; end
if nargin < 2, dataDir = ''; end

Sx = supplement_config();
scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir), scriptDir = pwd; end

% -------------------------------------------------------------------------
% Resolve or create the main-run state.
% -------------------------------------------------------------------------
[coreRunDir,stateFile] = resolve_core_state(coreRunDir,dataDir,scriptDir,Sx);
L = load(stateFile,'state');
state = L.state;

if ~isfield(state,'cfg') || ~isfield(state,'geometry') || ...
        ~isfield(state,'sparseControls')
    error('CORE_RESULT_STATE.mat does not contain the expected main-run fields.');
end

cfg = state.cfg;
G0  = state.geometry;
obs = obs_from_state_table(state.sparseControls);

if isfield(state,'cvIso') && isfield(state.cvIso,'value')
    c0Iso = state.cvIso.value;
else
    error('Main state does not contain state.cvIso.value.');
end
if isfield(state,'cvFault') && isfield(state.cvFault,'value')
    c0Fault = state.cvFault.value;
else
    error('Main state does not contain state.cvFault.value.');
end

dataDir = resolve_data_dir(dataDir,state,coreRunDir,scriptDir,cfg);
validate_required_data(dataDir,cfg);

% -------------------------------------------------------------------------
% Reconstruct the SAME retrospective reference window as the main paper.
% -------------------------------------------------------------------------
Hraw = read_c11_horizon_local(fullfile(dataDir,cfg.horizonFile));
UVall = global_to_local_local(Hraw.xy,G0);
phiAll = fault_phi_local(UVall,G0);

uLo = G0.uMin - cfg.mainMarginAlong;
uHi = G0.uMax + cfg.mainMarginAlong;
vLo = min(G0.vc) - cfg.mainMarginCross;
vHi = max(G0.vc) + cfg.mainMarginCross;

inside = UVall(:,1)>=uLo & UVall(:,1)<=uHi & ...
         UVall(:,2)>=vLo & UVall(:,2)<=vHi;

UVref = UVall(inside,:);
Zref  = Hraw.z(inside);
phiRef = phiAll(inside);
gateRef = fault_gate_local(UVref(:,1),G0,cfg);

faultMask = abs(phiRef)<=cfg.evalFaultBand & gateRef>=cfg.evalGateMin;
bgMask    = abs(phiRef)>=cfg.evalBackgroundDistance | gateRef<cfg.evalGateMin;
negMask   = phiRef<0;
posMask   = ~negMask;
Rref      = build_side_reference_interpolants_local(UVref,Zref,G0,cfg);

uRange = [uLo,uHi];
vRange = [vLo,vHi];

% Effective baseline fault-tensor bandwidth used by the main code.
sigma0 = cfg.faultSigmaMin;

stamp = datestr(now,'yyyymmdd_HHMMSS');
outDir = fullfile(scriptDir,['out_C11_EQUAL_BUDGET_PARAMETER_REDUCED_V2_' stamp]);
if ~exist(outDir,'dir'), mkdir(outDir); end

diary(fullfile(outDir,'RUN_LOG.txt'));
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('\n============================================================\n');
fprintf('RUN_C11_EQUAL_BUDGET_PARAMETER_REDUCED_V2\n');
fprintf('Core state : %s\n',stateFile);
fprintf('C11 data   : %s\n',dataDir);
fprintf('Output     : %s\n',outDir);
fprintf('Controls   : %d\n',numel(obs.z));
fprintf('c0 ISO     : %.8g\n',c0Iso);
fprintf('c0 FAULT   : %.8g\n',c0Fault);
fprintf('sigma0     : %.3f m\n',sigma0);
fprintf('============================================================\n\n');

rng(Sx.seed,'twister');

% =========================================================================
% E1. STRICT EQUAL-BUDGET 2-D FACTORIAL ABLATION
% =========================================================================
fprintf('[E1] Strict equal-budget 2-D factorial ablation ...\n');
Nbudget = Sx.equalBudgetNodes;

% Build the adaptive initial mesh first.  The paper's structured mesh
% expands the requested rectangle to floor/ceil grid lines; use the SAME
% actual rectangular domain for the exact-N quasi-uniform baseline.
cfgBase = cfg;
mesh0 = uniform_mesh_under_budget_local(uRange,vRange,cfg.afemInitialNodeBudget);
meshDomainU = [min(mesh0.P(:,1)),max(mesh0.P(:,1))];
meshDomainV = [min(mesh0.P(:,2)),max(mesh0.P(:,2))];

% Exact-N quasi-uniform mesh on exactly the same rectangular domain.
meshU = exact_quasiuniform_rect_mesh(meshDomainU,meshDomainV,Nbudget,Sx);
if size(meshU.P,1) ~= Nbudget
    error('Exact quasi-uniform mesh failed to realize N=%d.',Nbudget);
end

% Exact-N adaptive mesh using the paper algorithm plus rare centroid top-up.
[~,meshA,histA] = adapt_fault_mesh_to_budget_local( ...
    mesh0,Nbudget,obs,G0,c0Fault,cfgBase);
nBeforeTopup = size(meshA.P,1);
[meshA,nTopUp] = topup_adaptive_mesh_to_exact_budget( ...
    meshA,Nbudget,obs,G0,c0Fault,cfgBase);
if size(meshA.P,1) ~= Nbudget
    error('Adaptive exact-budget mesh failed: requested=%d actual=%d.', ...
        Nbudget,size(meshA.P,1));
end

fprintf('  uniform nodes          : %d\n',size(meshU.P,1));
fprintf('  adaptive edge-bisect   : %d\n',nBeforeTopup);
fprintf('  adaptive centroid topup: %d\n',nTopUp);
fprintf('  adaptive final nodes   : %d\n',size(meshA.P,1));

HU = build_interp_matrix_local(meshU,obs.uv);
HA = build_interp_matrix_local(meshA,obs.uv);

KUiso = assemble_iso_stiffness_local(meshU);
KUflt = assemble_fault_stiffness_local(meshU,G0,cfgBase);
KAiso = assemble_iso_stiffness_local(meshA);
KAflt = assemble_fault_stiffness_local(meshA,G0,cfgBase);

solUiso = fit_fem_solution_local(meshU,KUiso,HU,obs,c0Iso,'U-ISO');
solUflt = fit_fem_solution_local(meshU,KUflt,HU,obs,c0Fault,'U-FLT');
solAiso = fit_fem_solution_local(meshA,KAiso,HA,obs,c0Iso,'A-ISO');
solAflt = fit_fem_solution_local(meshA,KAflt,HA,obs,c0Fault,'A-FLT');

solsE1 = {solUiso,solUflt,solAiso,solAflt};
labelsE1 = {'U-ISO';'U-FLT';'A-ISO';'A-FLT'};
ME1 = cell(4,1);
for i=1:4
    pred = predict_solution_local(solsE1{i},UVref);
    [ME1{i},~] = evaluate_dense_v2_local( ...
        pred,Zref,faultMask,bgMask,negMask,posMask, ...
        obs,solsE1{i},Rref,G0,cfgBase);
end

TE1 = metrics_table_from_cells(labelsE1,ME1,repmat(Nbudget,4,1));
TE1.MeshClass = {'Exact quasi-uniform';'Exact quasi-uniform'; ...
                  'Adaptive';'Adaptive'};
TE1.C0 = [c0Iso;c0Fault;c0Iso;c0Fault];
TE1.EpsilonMin = [1;cfgBase.faultEpsMin;1;cfgBase.faultEpsMin];
TE1.AdaptiveTopUpNodes = [0;0;nTopUp;nTopUp];
writetable(TE1,fullfile(outDir,'E1_EQUAL_BUDGET_FACTORIAL.csv'));

TE1eff = equal_budget_effect_table(TE1);
writetable(TE1eff,fullfile(outDir,'E1_EQUAL_BUDGET_EFFECTS.csv'));

plot_equal_budget_metrics(outDir,TE1,Sx);
plot_equal_budget_meshes(outDir,meshU,meshA,G0,obs,Sx);

disp(' ');
disp('E1_EQUAL_BUDGET_FACTORIAL');
disp(TE1);
disp('E1_EQUAL_BUDGET_EFFECTS');
disp(TE1eff);

% =========================================================================
% SAVE E1 STATE
% =========================================================================
Sup = struct();
Sup.config = Sx;
Sup.coreRunDir = coreRunDir;
Sup.dataDir = dataDir;
Sup.coreStateFile = stateFile;
Sup.c0Iso = c0Iso;
Sup.c0Fault = c0Fault;
if isfield(state.cvFault,'epsValue')
    Sup.epsilonMin = state.cvFault.epsValue;
else
    Sup.epsilonMin = cfg.faultEpsMin;
end
Sup.sigmaGamma = cfg.faultSigmaMin;
Sup.equalBudget = TE1;
Sup.equalBudgetEffects = TE1eff;
Sup.adaptiveHistoryE1 = histA;
Sup.uniformMeshE1 = meshU;
Sup.adaptiveMeshE1 = meshA;
save(fullfile(outDir,'EQUAL_BUDGET_PARAMETER_REDUCED_V2_STATE.mat'),'Sup','-v7.3');

fprintf('\n============================================================\n');
fprintf('PARAMETER-REDUCED V2 EQUAL-BUDGET ABLATION FINISHED\n');
fprintf('Output: %s\n',outDir);
fprintf('============================================================\n');

end

% =========================================================================
% CONFIGURATION
% =========================================================================
function S = supplement_config()
S = struct();
S.seed = 20260818;
S.equalBudgetNodes = 200;
S.figureDPI = 180;
end


% =========================================================================
% STATE / DATA RESOLUTION
% =========================================================================
function [coreRunDir,stateFile] = resolve_core_state(coreRunDir,dataDir,scriptDir,Sx) %#ok<INUSD>
if ~isempty(coreRunDir)
    stateFile = fullfile(coreRunDir,'CORE_RESULT_STATE.mat');
    if exist(stateFile,'file')
        return;
    end
    if exist(coreRunDir,'file') && endsWith(lower(coreRunDir),'.mat')
        stateFile = coreRunDir;
        coreRunDir = fileparts(coreRunDir);
        return;
    end
    error('No CORE_RESULT_STATE.mat in the supplied coreRunDir: %s',coreRunDir);
end

% Search near this file first, then current directory.
C = [dir(fullfile(scriptDir,'**','out_REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2_*','CORE_RESULT_STATE.mat')); ...
     dir(fullfile(pwd,'**','out_REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2_*','CORE_RESULT_STATE.mat'))];
if ~isempty(C)
    dn = [C.datenum];
    [~,k] = max(dn);
    stateFile = fullfile(C(k).folder,C(k).name);
    coreRunDir = C(k).folder;
    return;
end

% If the main function is available, run it once.
coreFn = 'REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2';
if exist(coreFn,'file')==2
    fprintf('No CORE_RESULT_STATE.mat was found. Running the main C11 core once...\n');
    if isempty(dataDir)
        coreRunDir = feval(coreFn,'','paper');
    else
        coreRunDir = feval(coreFn,dataDir,'paper');
    end
    stateFile = fullfile(coreRunDir,'CORE_RESULT_STATE.mat');
    if ~exist(stateFile,'file')
        error('The main C11 run finished without CORE_RESULT_STATE.mat.');
    end
    return;
end

error(['No CORE_RESULT_STATE.mat was found and the main C11 core function is not on the MATLAB path.\n', ...
       'Run REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2 first,\n', ...
       'or pass its output directory as the first input.']);
end

function dataDir = resolve_data_dir(dataDir,state,coreRunDir,scriptDir,cfg)
if ~isempty(dataDir) && has_required_data(dataDir,cfg)
    return;
end

cand = {};
if isfield(state.cfg,'dataDir') && ischar(state.cfg.dataDir)
    cand{end+1} = state.cfg.dataDir; %#ok<AGROW>
end
cand{end+1} = fullfile(coreRunDir,'data_C11');
cand{end+1} = fullfile(fileparts(coreRunDir),'data_C11');
cand{end+1} = fullfile(scriptDir,'data_C11');
cand{end+1} = fullfile(fileparts(scriptDir),'data_C11');
cand{end+1} = fullfile(pwd,'data_C11');

for i=1:numel(cand)
    if has_required_data(cand{i},cfg)
        dataDir = cand{i};
        return;
    end
end

% Last-resort recursive search from scriptDir and pwd.
roots = unique({scriptDir,pwd});
for ir=1:numel(roots)
    D = dir(fullfile(roots{ir},'**',cfg.horizonFile));
    for k=1:numel(D)
        d = D(k).folder;
        if has_required_data(d,cfg)
            dataDir = d;
            return;
        end
    end
end

error('Could not locate C11 data files %s and %s.',cfg.horizonFile,cfg.polygonFile);
end

function tf = has_required_data(d,cfg)
tf = ~isempty(d) && exist(fullfile(d,cfg.horizonFile),'file') && ...
                  exist(fullfile(d,cfg.polygonFile),'file');
end

function validate_required_data(d,cfg)
if ~has_required_data(d,cfg)
    error('Required C11 files are missing in: %s',d);
end
end

function obs = obs_from_state_table(T)
vars = T.Properties.VariableNames;
need = {'u','v','Elevation'};
for i=1:numel(need)
    if ~ismember(need{i},vars)
        error('state.sparseControls is missing column "%s".',need{i});
    end
end
obs = struct();
obs.uv = [T.u,T.v];
obs.z = T.Elevation;
obs.w = ones(height(T),1);
obs.idx = (1:height(T)).';
end

% =========================================================================
% C11 DATA / GEOMETRY
% =========================================================================
function D = read_c11_horizon_local(fileName)
fid=fopen(fileName,'r');
if fid<0, error('Cannot open horizon file: %s',fileName); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fgetl(fid);
C=textscan(fid,'%f%f%f%f%f','MultipleDelimsAsOne',true, ...
    'Delimiter',' \t','CollectOutput',true);
A=C{1};
if size(A,2)~=5
    error('Unexpected TVD_C11 format. Expected five numeric columns.');
end
A=A(all(isfinite(A),2),:);
D=struct('inline',A(:,1),'cdp',A(:,2),'xy',A(:,3:4),'z',A(:,5));
end

function uv = global_to_local_local(xy,G)
X=xy-G.c;
uv=[X*G.t.', X*G.n.'];
end

function [phi,dist,tt,nn,proj,segIdx] = fault_project_exact_local(uv,G)
uv=double(uv);
nq=size(uv,1);
ns=size(G.segA,1);
bestD2=inf(nq,1);
phi=zeros(nq,1);
proj=zeros(nq,2);
segIdx=ones(nq,1);
tt=zeros(nq,2);
nn=zeros(nq,2);
for j=1:ns
    a=G.segA(j,:);
    v=G.segV(j,:);
    L2=max(sum(v.^2),eps);
    w=uv-a;
    tau=(w*v.')/L2;
    tau=max(0,min(1,tau));
    pj=a+tau.*v;
    d=uv-pj;
    d2=sum(d.^2,2);
    upd=d2<bestD2;
    if any(upd)
        bestD2(upd)=d2(upd);
        proj(upd,:)=pj(upd,:);
        segIdx(upd)=j;
        tt(upd,:)=repmat(G.segT(j,:),nnz(upd),1);
        nn(upd,:)=repmat(G.segN(j,:),nnz(upd),1);
        phi(upd)=d(upd,:)*G.segN(j,:).';
    end
end
dist=sqrt(max(bestD2,0));
end

function phi = fault_phi_local(uv,G)
[phi,~,~,~,~,~]=fault_project_exact_local(uv,G);
end

function g = fault_gate_local(u,G,cfg)
tau=max(cfg.faultTipTaper,eps);
g=0.5*(tanh((u-G.uMin)/tau)-tanh((u-G.uMax)/tau));
g=max(min(g,1),0);
end

function [vc,slope] = fault_center_and_slope_local(u,G)
vc=interp1(G.uc,G.vc,u,'linear','extrap');
slope=interp1(G.uc,G.dvdu,u,'linear','extrap');
end

function Gp = perturb_fault_geometry_local(G0,offsetM,angleDeg,cfg)
% Perturb the interpreted polygon in the ORIGINAL local coordinate system.
P=G0.polyUV;
c=[0.5*(min(P(:,1))+max(P(:,1))), median(P(:,2))];
Q=P-c;
a=angleDeg*pi/180;
R=[cos(a),-sin(a);sin(a),cos(a)];
Q=(R*Q.').';
Pp=Q+c;
Pp(:,2)=Pp(:,2)+offsetM;
Gp=build_fault_geometry_from_local_poly(Pp,G0,cfg);
end

function G = build_fault_geometry_from_local_poly(P,G0,cfg)
u=P(:,1); v=P(:,2);
uMin=min(u); uMax=max(u);
edges=linspace(uMin,uMax,cfg.centerlineBins+1);
uc=[];vc=[];hw=[];
for b=1:cfg.centerlineBins
    if b<cfg.centerlineBins
        m=u>=edges(b)&u<edges(b+1);
    else
        m=u>=edges(b)&u<=edges(b+1);
    end
    if nnz(m)>=2
        ub=median(u(m));
        vb=v(m);
        vlo=percentile_local(vb,10);
        vhi=percentile_local(vb,90);
        uc(end+1,1)=ub; %#ok<AGROW>
        vc(end+1,1)=0.5*(vlo+vhi); %#ok<AGROW>
        hw(end+1,1)=0.5*(vhi-vlo); %#ok<AGROW>
    end
end
if numel(uc)<6
    error('Perturbed fault produced too few centerline bins.');
end
[uc,ord]=sort(uc);vc=vc(ord);hw=hw(ord);
if cfg.centerlineSmooth>1
    vc=movmean(vc,cfg.centerlineSmooth,'Endpoints','shrink');
    hw=movmean(hw,cfg.centerlineSmooth,'Endpoints','shrink');
end
if uc(1)>uMin
    uc=[uMin;uc];
    vc=[interp1(uc(2:end),vc,uMin,'linear','extrap');vc];
    hw=[interp1(uc(2:end),hw,uMin,'linear','extrap');hw];
end
if uc(end)<uMax
    vc1=interp1(uc,vc,uMax,'linear','extrap');
    hw1=interp1(uc,hw,uMax,'linear','extrap');
    uc=[uc;uMax];vc=[vc;vc1];hw=[hw;hw1];
end
dvdu=gradient(vc,uc);
segA=[uc(1:end-1),vc(1:end-1)];
segB=[uc(2:end),vc(2:end)];
segV=segB-segA;
segL=sqrt(sum(segV.^2,2));
segL=max(segL,eps);
segT=segV./segL;
segN=[-segT(:,2),segT(:,1)];
G=G0;
G.uMin=uMin;G.uMax=uMax;G.uc=uc;G.vc=vc;G.dvdu=dvdu;
G.halfWidth=max(median(hw(isfinite(hw))),1);
G.halfWidth95=percentile_local(abs(v-interp1(uc,vc,u,'linear','extrap')),95);
G.polyUV=P;
G.segA=segA;G.segB=segB;G.segV=segV;G.segL=segL;G.segT=segT;G.segN=segN;
end

% =========================================================================
% REFERENCE INTERPOLATION / METRICS
% =========================================================================
function R = build_side_reference_interpolants_local(uv,z,G,cfg)
phi=fault_phi_local(uv,G);
guard=max(10,0.15*G.halfWidth);
neg=phi<=-guard;
pos=phi>= guard;
if nnz(neg)<100 || nnz(pos)<100
    error('Insufficient reference points on one side of fault.');
end
R.neg=scatteredInterpolant(uv(neg,1),uv(neg,2),z(neg),'natural','nearest');
R.pos=scatteredInterpolant(uv(pos,1),uv(pos,2),z(pos),'natural','nearest');
R.allNearest=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
R.guard=guard;R.cfg=cfg;
end

function z = reference_predict_local(R,uv,G)
phi=fault_phi_local(uv,G);
z=zeros(size(phi));
neg=phi<0;
z(neg)=R.neg(uv(neg,1),uv(neg,2));
z(~neg)=R.pos(uv(~neg,1),uv(~neg,2));
end

function [M,J] = evaluate_dense_v2_local(pred,zref,faultMask,bgMask,negMask,posMask,obs,S,R,G,cfg)
e=pred-zref;
M=struct();
M.RMSE_all=sqrt(mean(e.^2));
M.MAE_all=mean(abs(e));
M.RMSE_fault=sqrt(mean(e(faultMask).^2));
M.MAE_fault=mean(abs(e(faultMask)));
M.RMSE_bg=sqrt(mean(e(bgMask).^2));
M.RMSE_neg=sqrt(mean(e(negMask).^2));
M.RMSE_pos=sqrt(mean(e(posMask).^2));
M.dataRMSE=S.dataRMSE;
M.nUnknowns=S.nUnknowns;
J=interface_jump_extrapolation_local(S,R,G,cfg);
good=isfinite(J.ref)&isfinite(J.pred);
if any(good)
    de=J.pred(good)-J.ref(good);
    M.Jump0MAE=mean(abs(de));
    M.Jump0RMSE=sqrt(mean(de.^2));
    M.RefJumpMedianAbs=median(abs(J.ref(good)));
    M.PredJumpMedianAbs=median(abs(J.pred(good)));
    M.Jump0Correlation=corr_local(J.ref(good),J.pred(good));
else
    M.Jump0MAE=nan;M.Jump0RMSE=nan;M.RefJumpMedianAbs=nan;
    M.PredJumpMedianAbs=nan;M.Jump0Correlation=nan;
end
pobs=predict_solution_local(S,obs.uv);
M.trainRMSE=sqrt(mean((pobs-obs.z).^2));
end

function J = interface_jump_extrapolation_local(S,R,G,cfg)
span=G.uMax-G.uMin;
u1=G.uMin+cfg.jumpTipFraction*span;
u2=G.uMax-cfg.jumpTipFraction*span;
uList=linspace(u1,u2,cfg.jumpNSamples).';
d0=max(cfg.jumpFitMinOffset,G.halfWidth95+cfg.jumpFitPolygonClearance);
d=d0+cfg.jumpFitDistanceAdd(:).';
Jref=nan(numel(uList),1);Jpred=Jref;
for i=1:numel(uList)
    [vc,slope]=fault_center_and_slope_local(uList(i),G);
    c=[uList(i),vc];
    nn=[-slope,1];nn=nn/max(norm(nn),eps);
    qPlus=c+d(:)*nn;qMinus=c-d(:)*nn;
    zrP=reference_predict_local(R,qPlus,G);
    zrM=reference_predict_local(R,qMinus,G);
    zpP=predict_solution_local(S,qPlus);
    zpM=predict_solution_local(S,qMinus);
    Jref(i)=two_side_intercept_jump_local(d,zrP,zrM,cfg.jumpLocalDegree);
    Jpred(i)=two_side_intercept_jump_local(d,zpP,zpM,cfg.jumpLocalDegree);
end
J=struct('u',uList,'ref',Jref,'pred',Jpred,'distances',d);
end

function J = two_side_intercept_jump_local(d,zPlus,zMinus,degree)
d=d(:);zPlus=zPlus(:);zMinus=zMinus(:);
goodP=isfinite(d)&isfinite(zPlus);goodM=isfinite(d)&isfinite(zMinus);
if nnz(goodP)<degree+1 || nnz(goodM)<degree+1
    J=nan;return;
end
pP=polyfit(d(goodP),zPlus(goodP),degree);
pM=polyfit(d(goodM),zMinus(goodM),degree);
J=polyval(pP,0)-polyval(pM,0);
end

% =========================================================================
% EXACT-N QUASI-UNIFORM RECTANGULAR MESH
% =========================================================================
function M = exact_quasiuniform_rect_mesh(uRange,vRange,N,Sx) %#ok<INUSD>
% Deterministic exact-N quasi-uniform Delaunay mesh.
% Candidate-grid density and boundary sampling are derived from N and the
% rectangle aspect ratio; no user-tuned mesh-construction coefficient is used.
if N<20, error('N must be at least 20.'); end

Lu=uRange(2)-uRange(1);
Lv=vRange(2)-vRange(1);
aspect=max(Lu/max(Lv,eps),eps);

nu=max(12,ceil(4*sqrt(N*aspect)));
nv=max(12,ceil(4*sqrt(N/aspect)));

u=linspace(uRange(1),uRange(2),nu);
v=linspace(vRange(1),vRange(2),nv);
[U,V]=meshgrid(u,v);
Cand=[U(:),V(:)];

% Boundary sample count scales with the square root of N, consistent with a
% two-dimensional quasi-uniform point set.
per=max(2,ceil(sqrt(N)/2));
bottom=[linspace(uRange(1),uRange(2),per).',repmat(vRange(1),per,1)];
top=[linspace(uRange(1),uRange(2),per).',repmat(vRange(2),per,1)];
left=[repmat(uRange(1),per,1),linspace(vRange(1),vRange(2),per).'];
right=[repmat(uRange(2),per,1),linspace(vRange(1),vRange(2),per).'];
P0=unique([bottom;top;left;right],'rows','stable');

sel=false(size(Cand,1),1);
for i=1:size(P0,1)
    d2=sum((Cand-P0(i,:)).^2,2);
    [~,k]=min(d2);
    sel(k)=true;
end
idx=find(sel);
if numel(idx)>N
    idx=idx(1:N);
end

dmin=inf(size(Cand,1),1);
for k=idx(:).'
    dmin=min(dmin,sum((Cand-Cand(k,:)).^2,2));
end
while numel(idx)<N
    dmin(idx)=-inf;
    [~,k]=max(dmin);
    idx(end+1,1)=k; %#ok<AGROW>
    dmin=min(dmin,sum((Cand-Cand(k,:)).^2,2));
end

P=Cand(idx,:);
DT=delaunayTriangulation(P);
T=DT.ConnectivityList;
M=finalize_unstructured_mesh_local(P,T);
end


function M = make_rect_mesh_local(uRange,vRange,h)
uAxis=(floor(uRange(1)/h)*h):h:(ceil(uRange(2)/h)*h);
vAxis=(floor(vRange(1)/h)*h):h:(ceil(vRange(2)/h)*h);
[U,V]=meshgrid(uAxis,vAxis);P=[U(:),V(:)];
nU=numel(uAxis);nV=numel(vAxis);
T=zeros(2*(nU-1)*(nV-1),3);r=0;
for iu=1:nU-1
    for iv=1:nV-1
        n00=iv+(iu-1)*nV;n01=n00+1;n10=iv+iu*nV;n11=n10+1;
        r=r+1;T(r,:)=[n00,n10,n11];
        r=r+1;T(r,:)=[n00,n11,n01];
    end
end
M=struct('P',P,'T',T,'uAxis',uAxis,'vAxis',vAxis,'nU',nU,'nV',nV, ...
    'TR',triangulation(T,P));
end

function M = uniform_mesh_under_budget_local(uRange,vRange,nodeBudget)
Lu=diff(uRange);Lv=diff(vRange);A=max(Lu*Lv,1);h0=sqrt(A/max(nodeBudget,1));
factors=linspace(0.55,2.8,180);best=[];bestN=-inf;
for k=1:numel(factors)
    Mt=make_rect_mesh_local(uRange,vRange,h0*factors(k));
    n=size(Mt.P,1);
    if n<=nodeBudget && n>bestN,best=Mt;bestN=n;end
end
if isempty(best)
    h=h0*3.5;best=make_rect_mesh_local(uRange,vRange,h);
    while size(best.P,1)>nodeBudget
        h=1.12*h;best=make_rect_mesh_local(uRange,vRange,h);
    end
end
M=best;
end

function H = build_interp_matrix_local(M,q)
tri=pointLocation(M.TR,q);nq=size(q,1);
rows=[];cols=[];vals=[];good=isfinite(tri);
if any(good)
    bc=cartesianToBarycentric(M.TR,tri(good),q(good,:));
    Tg=M.T(tri(good),:);rg=find(good);
    rows=[rows;repelem(rg,3,1)];
    cols=[cols;reshape(Tg.',[],1)];
    vals=[vals;reshape(bc.',[],1)];
end
bad=find(~good);
for kk=1:numel(bad)
    i=bad(kk);d2=sum((M.P-q(i,:)).^2,2);[~,node]=min(d2);
    rows(end+1,1)=i;cols(end+1,1)=node;vals(end+1,1)=1; %#ok<AGROW>
end
H=sparse(rows,cols,vals,nq,size(M.P,1));
end

function K = assemble_iso_stiffness_local(M)
n=size(M.P,1);nt=size(M.T,1);
I=zeros(9*nt,1);J=I;V=I;q=0;
for e=1:nt
    nodes=M.T(e,:);xy=M.P(nodes,:);[B,A]=tri_gradients_local(xy);
    Ke=A*(B.'*B);
    for a=1:3
        for b=1:3
            q=q+1;I(q)=nodes(a);J(q)=nodes(b);V(q)=Ke(a,b);
        end
    end
end
K=sparse(I,J,V,n,n);K=0.5*(K+K.');
end

function sigma = effective_fault_sigma_local(G,cfg) %#ok<INUSD>
sigma=cfg.faultSigmaMin;
end

function K = assemble_fault_stiffness_local(M,G,cfg)
n=size(M.P,1);nt=size(M.T,1);
I=zeros(9*nt,1);J=I;V=I;q=0;
sigma=effective_fault_sigma_local(G,cfg);
for e=1:nt
    nodes=M.T(e,:);xy=M.P(nodes,:);cen=mean(xy,1);[B,A]=tri_gradients_local(xy);
    [phi,~,tt,nn]=fault_project_exact_local(cen,G);
    gate=fault_gate_local(cen(1),G,cfg);
    strength=gate*exp(-0.5*(phi/sigma)^2);
    epsn=1-(1-cfg.faultEpsMin)*strength;
    D=tt.'*tt+epsn*(nn.'*nn);
    Ke=A*(B.'*D*B);
    for a=1:3
        for b=1:3
            q=q+1;I(q)=nodes(a);J(q)=nodes(b);V(q)=Ke(a,b);
        end
    end
end
K=sparse(I,J,V,n,n);K=0.5*(K+K.');
end

function [B,A] = tri_gradients_local(xy)
x1=xy(1,1);y1=xy(1,2);x2=xy(2,1);y2=xy(2,2);x3=xy(3,1);y3=xy(3,2);
detJ=(x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);
A=abs(detJ)/2;
if A<=eps,error('Degenerate triangle encountered.');end
B=[y2-y3,y3-y1,y1-y2; x3-x2,x1-x3,x2-x1]/detJ;
end

function S = fit_fem_solution_local(mesh,Ks,H,obs,c0,name)
A=c0*Ks+H.'*H;b=H.'*obs.z;A=0.5*(A+A.');
ridge=1e-12*max(mean(abs(diag(A))),1);A=A+ridge*speye(size(A,1));
U=A\b;
S=struct('type','fem','name',name,'mesh',mesh,'U',U,'c0',c0, ...
    'nUnknowns',numel(U),'dataRMSE',sqrt(mean((H*U-obs.z).^2)));
end

function z = predict_solution_local(S,uv)
H=build_interp_matrix_local(S.mesh,uv);z=H*S.U;
end

function [S,mesh,history] = adapt_fault_mesh_to_budget_local(mesh,nodeBudget,obs,G,c0,cfg)
history=struct('iter',{},'nodes',{},'triangles',{},'etaResidual',{}, ...
    'etaGeoMean',{},'marked',{},'acceptedMarks',{},'splitEdges',{}, ...
    'budgetLimited',{},'areaRelError',{});
for it=1:cfg.afemMaxAdaptPerBudget
    H=build_interp_matrix_local(mesh,obs.uv);
    K=assemble_fault_stiffness_local(mesh,G,cfg);
    S=fit_fem_solution_local(mesh,K,H,obs,c0,'FAULT-AFEM');
    [eta2,parts]=afem_hybrid_indicator_local(mesh,S.U,obs,H,G,c0,cfg);
    markRes=doerfler_mark_local_local(eta2,cfg.afemDoerflerTheta);
    geom=mesh_triangle_geometry_local(mesh);
    phi=fault_phi_local(geom.centroid,G);
    gate=fault_gate_local(geom.centroid(:,1),G,cfg);
    sigma=cfg.faultSigmaMin;
    markGeo=abs(phi)<=sigma & gate>=exp(-0.5);
    mark=markRes|markGeo;
    rec=struct('iter',it,'nodes',size(mesh.P,1),'triangles',size(mesh.T,1), ...
        'etaResidual',sqrt(sum(parts.residual2)),'etaGeoMean',mean(parts.geo), ...
        'marked',nnz(mark),'acceptedMarks',0,'splitEdges',0, ...
        'budgetLimited',false,'areaRelError',0);
    if size(mesh.P,1)>=nodeBudget || ~any(mark)
        history(end+1)=rec; %#ok<AGROW>
        break;
    end
    [meshNew,stat,budgetLimited,nAccepted]=refine_with_node_budget_local_local( ...
        mesh,mark,parts.priority,nodeBudget,cfg);
    rec.acceptedMarks=nAccepted;rec.splitEdges=stat.nSplitEdges;
    rec.budgetLimited=budgetLimited;rec.areaRelError=stat.areaRelError;
    history(end+1)=rec; %#ok<AGROW>
    if size(meshNew.P,1)==size(mesh.P,1),break;end
    mesh=meshNew;
end
H=build_interp_matrix_local(mesh,obs.uv);K=assemble_fault_stiffness_local(mesh,G,cfg);
S=fit_fem_solution_local(mesh,K,H,obs,c0,'FAULT-AFEM');
S.adaptHistory=history;
end

function [eta2,parts] = afem_hybrid_indicator_local(mesh,U,obs,H,G,c0,cfg)
geom=mesh_triangle_geometry_local(mesh);T=mesh.T;nt=size(T,1);Ue=U(T);gradU=zeros(nt,2);
for e=1:nt
    [B,~]=tri_gradients_local(mesh.P(T(e,:),:));
    gradU(e,:)=(B*Ue(e,:).').';
end
[k11,k12,k22]=fault_tensor_at_points_local(geom.centroid,G,cfg);
qx=c0*(k11.*gradU(:,1)+k12.*gradU(:,2));
qy=c0*(k12.*gradU(:,1)+k22.*gradU(:,2));
edge2=zeros(nt,1);
E=[T(:,[1 2]);T(:,[2 3]);T(:,[3 1])];triId=[(1:nt)';(1:nt)';(1:nt)'];
Es=sort(E,2);[Eu,~,ic]=unique(Es,'rows');[ics,ord]=sort(ic);s0=1;
while s0<=numel(ics)
    t0=s0;while t0<numel(ics)&&ics(t0+1)==ics(s0),t0=t0+1;end
    if t0-s0+1==2
        a=ord(s0);b=ord(t0);t1=triId(a);t2=triId(b);eid=ics(s0);
        v1=Eu(eid,1);v2=Eu(eid,2);ev=mesh.P(v2,:)-mesh.P(v1,:);he=norm(ev);
        if he>0
            nface=[-ev(2),ev(1)]/he;
            jump=(qx(t1)-qx(t2))*nface(1)+(qy(t1)-qy(t2))*nface(2);
            val=0.5*he^2*jump^2;edge2(t1)=edge2(t1)+val;edge2(t2)=edge2(t2)+val;
        end
    end
    s0=t0+1;
end
cell2=zeros(nt,1);
for e=1:nt
    nodes=T(e,:);xy=mesh.P(nodes,:);cen=geom.centroid(e,:);fluxInt=0;
    locEdges=[1 2;2 3;3 1];
    for je=1:3
        p1=xy(locEdges(je,1),:);p2=xy(locEdges(je,2),:);mid=0.5*(p1+p2);
        ev=p2-p1;he=norm(ev);if he<=eps,continue;end
        nout=[ev(2),-ev(1)]/he;if dot(nout,cen-mid)>0,nout=-nout;end
        [a11,a12,a22]=fault_tensor_at_points_local(mid,G,cfg);
        qmid=c0*[a11*gradU(e,1)+a12*gradU(e,2), ...
                 a12*gradU(e,1)+a22*gradU(e,2)];
        fluxInt=fluxInt+he*dot(qmid,nout);
    end
    rcell=-fluxInt/max(geom.area(e),eps);
    cell2(e)=geom.hT(e)^2*geom.area(e)*rcell^2;
end
r=H*U-obs.z;triObs=pointLocation(mesh.TR,obs.uv);bad=~isfinite(triObs);
if any(bad)
    C=geom.centroid;ib=find(bad);
    for k=1:numel(ib)
        d2=sum((C-obs.uv(ib(k),:)).^2,2);[~,triObs(ib(k))]=min(d2);
    end
end
dataByTri=accumarray(triObs,r.^2,[nt,1],@sum,0);data2=(geom.hT.^2).*dataByTri;
cellW=1;if isfield(cfg,'afemCellResidualWeight'),cellW=cfg.afemCellResidualWeight;end
residual2=edge2+cellW*cell2+data2;res=sqrt(max(residual2,0));
if max(res)>0,resNorm=res/max(res);else,resNorm=zeros(size(res));end
phi=fault_phi_local(geom.centroid,G);gate=fault_gate_local(geom.centroid(:,1),G,cfg);
sigma=cfg.faultSigmaMin;
geo=gate.*exp(-0.5*(phi/sigma).^2);geo=max(min(geo,1),0);
eta2=geom.area.*resNorm.^2;
priority=max(resNorm,geo);
parts=struct('residual2',residual2,'edge2',edge2,'cell2',cell2,'data2',data2, ...
    'resNorm',resNorm,'geo',geo,'hybrid',priority,'bgPressure',zeros(nt,1), ...
    'priority',priority);
end

function [k11,k12,k22] = fault_tensor_at_points_local(q,G,cfg)
[phi,~,tt,nn]=fault_project_exact_local(q,G);gate=fault_gate_local(q(:,1),G,cfg);
sigma=effective_fault_sigma_local(G,cfg);
strength=gate.*exp(-0.5*(phi/sigma).^2);
epsn=1-(1-cfg.faultEpsMin).*strength;
k11=tt(:,1).^2+epsn.*nn(:,1).^2;
k12=tt(:,1).*tt(:,2)+epsn.*nn(:,1).*nn(:,2);
k22=tt(:,2).^2+epsn.*nn(:,2).^2;
end

function Gm = mesh_triangle_geometry_local(mesh)
T=mesh.T;P=mesh.P;nt=size(T,1);centroid=(P(T(:,1),:)+P(T(:,2),:)+P(T(:,3),:))/3;
area=zeros(nt,1);hT=zeros(nt,1);
for e=1:nt
    xy=P(T(e,:),:);[~,A]=tri_gradients_local(xy);area(e)=A;
    hT(e)=max([norm(xy(1,:)-xy(2,:)),norm(xy(2,:)-xy(3,:)),norm(xy(3,:)-xy(1,:))]);
end
Gm=struct('centroid',centroid,'area',area,'hT',hT);
end

function mark = doerfler_mark_local_local(eta2,theta)
mark=false(size(eta2));tot=sum(eta2);if ~(tot>0),return;end
[es,idx]=sort(eta2,'descend');cs=cumsum(es);k=find(cs>=theta*tot,1,'first');
if isempty(k),k=numel(idx);end;mark(idx(1:k))=true;
end

function [meshNew,stat,budgetLimited,nAccepted] = refine_with_node_budget_local_local(mesh,mark,priority,nodeBudget,cfg)
[full,statFull]=refine_mesh_conforming_edge_bisection_local_local(mesh,mark,cfg);
if size(full.P,1)<=nodeBudget
    meshNew=full;stat=statFull;budgetLimited=false;nAccepted=nnz(mark);return;
end
budgetLimited=true;idx=find(mark);
if isempty(idx)
    meshNew=mesh;stat=zero_refine_stats_local_local();nAccepted=0;return;
end
[~,ord]=sort(priority(idx),'descend');idx=idx(ord);lo=1;hi=numel(idx);
bestK=0;bestMesh=mesh;bestStat=zero_refine_stats_local_local();
while lo<=hi
    mid=floor((lo+hi)/2);m=false(size(mark));m(idx(1:mid))=true;
    [trial,st]=refine_mesh_conforming_edge_bisection_local_local(mesh,m,cfg);
    if size(trial.P,1)<=nodeBudget
        bestK=mid;bestMesh=trial;bestStat=st;lo=mid+1;
    else
        hi=mid-1;
    end
end
meshNew=bestMesh;stat=bestStat;nAccepted=bestK;
end

function s = zero_refine_stats_local_local()
s=struct('nSplitEdges',0,'nAffectedTriangles',0,'areaRelError',0);
end

function [meshNew,stat] = refine_mesh_conforming_edge_bisection_local_local(mesh,mark,cfg)
P=mesh.P;T=mesh.T;nt=size(T,1);
Eall=[T(:,[1 2]);T(:,[2 3]);T(:,[3 1])];Es=sort(Eall,2);[Eu,~,ic]=unique(Es,'rows');
edgeId=[ic(1:nt),ic(nt+1:2*nt),ic(2*nt+1:3*nt)];splitEdge=false(size(Eu,1),1);
ids=find(mark);
for ii=1:numel(ids)
    t=ids(ii);v=T(t,:);pp=P(v,:);
    len=[norm(pp(1,:)-pp(2,:)),norm(pp(2,:)-pp(3,:)),norm(pp(3,:)-pp(1,:))];
    [L,j]=max(len);if L>2.01*cfg.afemHMin,splitEdge(edgeId(t,j))=true;end
end
splitIds=find(splitEdge);stat=struct('nSplitEdges',numel(splitIds),'nAffectedTriangles',0,'areaRelError',0);
if isempty(splitIds),meshNew=mesh;return;end
midIndex=zeros(size(Eu,1),1);midPts=0.5*(P(Eu(splitIds,1),:)+P(Eu(splitIds,2),:));
midIndex(splitIds)=size(P,1)+(1:numel(splitIds));Pnew=[P;midPts];
Tnew=zeros(4*nt,3);nnew=0;affected=0;
for t=1:nt
    v1=T(t,1);v2=T(t,2);v3=T(t,3);f=splitEdge(edgeId(t,:));
    m12=midIndex(edgeId(t,1));m23=midIndex(edgeId(t,2));m31=midIndex(edgeId(t,3));nf=nnz(f);
    if nf==0
        nnew=nnew+1;Tnew(nnew,:)=[v1 v2 v3];
    elseif nf==1
        affected=affected+1;
        if f(1),ch=[v1 m12 v3;m12 v2 v3];
        elseif f(2),ch=[v2 m23 v1;m23 v3 v1];
        else,ch=[v3 m31 v2;m31 v1 v2];end
        Tnew(nnew+(1:2),:)=ch;nnew=nnew+2;
    elseif nf==2
        affected=affected+1;
        if f(1)&&f(2),ch=[m12 v2 m23;v1 m12 v3;m12 m23 v3];
        elseif f(2)&&f(3),ch=[m23 v3 m31;v2 m23 v1;m23 m31 v1];
        else,ch=[v1 m12 m31;v2 v3 m12;v3 m31 m12];end
        Tnew(nnew+(1:3),:)=ch;nnew=nnew+3;
    else
        affected=affected+1;ch=[v1 m12 m31;m12 v2 m23;m31 m23 v3;m12 m23 m31];
        Tnew(nnew+(1:4),:)=ch;nnew=nnew+4;
    end
end
Tnew=Tnew(1:nnew,:);meshNew=finalize_unstructured_mesh_local(Pnew,Tnew);
oldGeom=mesh_triangle_geometry_local(mesh);newGeom=mesh_triangle_geometry_local(meshNew);
stat.nAffectedTriangles=affected;
stat.areaRelError=abs(sum(newGeom.area)-sum(oldGeom.area))/max(sum(oldGeom.area),eps);
end

function M = finalize_unstructured_mesh_local(P,T)
% Orient triangles counter-clockwise and build triangulation.
for e=1:size(T,1)
    a=P(T(e,1),:);b=P(T(e,2),:);c=P(T(e,3),:);
    s=(b(1)-a(1))*(c(2)-a(2))-(b(2)-a(2))*(c(1)-a(1));
    if s<0,T(e,[2 3])=T(e,[3 2]);end
end
% Remove degenerate/duplicate triangles.
good=true(size(T,1),1);
for e=1:size(T,1)
    if numel(unique(T(e,:)))<3,good(e)=false;continue;end
    [~,A]=tri_gradients_local(P(T(e,:),:));if ~(A>1e-12),good(e)=false;end
end
T=T(good,:);
Ts=sort(T,2);[~,ia]=unique(Ts,'rows','stable');T=T(sort(ia),:);
M=struct();M.P=P;M.T=T;M.TR=triangulation(T,P);
end

function [mesh,nAdded] = topup_adaptive_mesh_to_exact_budget(mesh,N,obs,G,c0,cfg)
nAdded=0;
while size(mesh.P,1)<N
    H=build_interp_matrix_local(mesh,obs.uv);K=assemble_fault_stiffness_local(mesh,G,cfg);
    S=fit_fem_solution_local(mesh,K,H,obs,c0,'TOPUP');
    [~,parts]=afem_hybrid_indicator_local(mesh,S.U,obs,H,G,c0,cfg);
    geom=mesh_triangle_geometry_local(mesh);
    score=parts.priority.*geom.area;
    [~,ord]=sort(score,'descend');
    inserted=false;
    for kk=1:numel(ord)
        t=ord(kk);
        if geom.hT(t)<=1.5*cfg.afemHMin,continue;end
        mesh=split_triangle_at_centroid_local(mesh,t);
        nAdded=nAdded+1;inserted=true;break;
    end
    if ~inserted
        error('Could not top-up adaptive mesh to N=%d because all cells reached h_min.',N);
    end
end
end

function M2 = split_triangle_at_centroid_local(M,t)
P=M.P;T=M.T;v=T(t,:);c=mean(P(v,:),1);ic=size(P,1)+1;P=[P;c];
newT=[v(1) v(2) ic;v(2) v(3) ic;v(3) v(1) ic];
T=[T(1:t-1,:);newT;T(t+1:end,:)];
M2=finalize_unstructured_mesh_local(P,T);
end

function [sol,mesh,topup] = run_fault_adaptive_exact_budget(N,uRange,vRange,obs,G,c0,cfg)
mesh0=uniform_mesh_under_budget_local(uRange,vRange,cfg.afemInitialNodeBudget);
[~,mesh]=adapt_fault_mesh_to_budget_local(mesh0,N,obs,G,c0,cfg);
[mesh,topup]=topup_adaptive_mesh_to_exact_budget(mesh,N,obs,G,c0,cfg);
H=build_interp_matrix_local(mesh,obs.uv);K=assemble_fault_stiffness_local(mesh,G,cfg);
sol=fit_fem_solution_local(mesh,K,H,obs,c0,'FAULT-AFEM');
end

% =========================================================================
% TABLES / EFFECTS
% =========================================================================
function T = metrics_table_from_cells(labels,M,nodes)
n=numel(M);A=zeros(n,6);
for i=1:n
    A(i,:)=[M{i}.RMSE_all,M{i}.RMSE_fault,M{i}.RMSE_bg,M{i}.Jump0MAE, ...
            M{i}.dataRMSE,M{i}.Jump0Correlation];
end
T=table(labels,nodes,A(:,1),A(:,2),A(:,3),A(:,4),A(:,5),A(:,6), ...
    'VariableNames',{'Method','Nodes','RMSE_Global_m','RMSE_Fault_m', ...
    'RMSE_Background_m','JumpMAE_m','ControlRMSE_m','JumpCorrelation'});
end

function T = equal_budget_effect_table(E)
% Effects are reported as relative error reductions (%); positive = better.
get=@(name,var) E{strcmp(E.Method,name),var};
metrics={'RMSE_Fault_m','JumpMAE_m','RMSE_Global_m','RMSE_Background_m'};
rows={};r=0;
for i=1:numel(metrics)
    m=metrics{i};
    Uiso=get('U-ISO',m);Uflt=get('U-FLT',m);Aiso=get('A-ISO',m);Aflt=get('A-FLT',m);
    r=r+1;rows(r,:)={m,'Fault constraint on uniform mesh','U-FLT vs U-ISO',100*(Uiso-Uflt)/Uiso}; %#ok<AGROW>
    r=r+1;rows(r,:)={m,'Adaptive mesh under isotropic regularization','A-ISO vs U-ISO',100*(Uiso-Aiso)/Uiso}; %#ok<AGROW>
    r=r+1;rows(r,:)={m,'Adaptive mesh under fault regularization','A-FLT vs U-FLT',100*(Uflt-Aflt)/Uflt}; %#ok<AGROW>
    r=r+1;rows(r,:)={m,'Full method vs isotropic-uniform baseline','A-FLT vs U-ISO',100*(Uiso-Aflt)/Uiso}; %#ok<AGROW>
end
T=cell2table(rows,'VariableNames',{'Metric','Effect','Contrast','Reduction_percent'});
end

function s = perturb_signs(mag)
if mag==0,s=1;else,s=[-1 1];end
end

function T = aggregate_perturbation_table(R,magName)
mag=R.(magName);u=unique(mag);n=numel(u);
A=zeros(n,9);
for i=1:n
    m=mag==u(i);
    A(i,1)=mean(R.RMSE_Global_m(m));A(i,2)=std(R.RMSE_Global_m(m),0);
    A(i,3)=mean(R.RMSE_Fault_m(m));A(i,4)=std(R.RMSE_Fault_m(m),0);
    A(i,5)=mean(R.RMSE_Background_m(m));A(i,6)=std(R.RMSE_Background_m(m),0);
    A(i,7)=mean(R.JumpMAE_m(m));A(i,8)=std(R.JumpMAE_m(m),0);
    A(i,9)=mean(R.ControlRMSE_m(m));
end
T=table(u,A(:,1),A(:,2),A(:,3),A(:,4),A(:,5),A(:,6),A(:,7),A(:,8),A(:,9), ...
    'VariableNames',{magName,'RMSE_Global_mean','RMSE_Global_std','RMSE_Fault_mean', ...
    'RMSE_Fault_std','RMSE_Background_mean','RMSE_Background_std', ...
    'JumpMAE_mean','JumpMAE_std','ControlRMSE_mean'});
end

% =========================================================================
% FIGURES
% =========================================================================
function plot_equal_budget_metrics(outDir,T,Sx)
f=figure('Color','w','Position',[100 100 1180 430]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
nexttile;bar(categorical(T.Method),T.RMSE_Fault_m);ylabel('Fault-neighborhood RMSE (m)');grid on;
title('Strict equal-budget ablation: local RMSE');
nexttile;bar(categorical(T.Method),T.JumpMAE_m);ylabel('Cross-fault depth-difference MAE (m)');grid on;
title('Strict equal-budget ablation: cross-fault structure');
exportgraphics(f,fullfile(outDir,'FIG_E1_equal_budget_metrics.png'),'Resolution',Sx.figureDPI);close(f);
end

function plot_equal_budget_meshes(outDir,U,A,G,obs,Sx)
f=figure('Color','w','Position',[100 100 1150 460]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
nexttile;triplot(U.T,U.P(:,1),U.P(:,2));hold on;plot(G.uc,G.vc,'k-','LineWidth',1.5);scatter(obs.uv(:,1),obs.uv(:,2),14,'filled');axis equal tight;title(sprintf('Exact quasi-uniform, N=%d',size(U.P,1)));xlabel('u (m)');ylabel('v (m)');
nexttile;triplot(A.T,A.P(:,1),A.P(:,2));hold on;plot(G.uc,G.vc,'k-','LineWidth',1.5);scatter(obs.uv(:,1),obs.uv(:,2),14,'filled');axis equal tight;title(sprintf('Adaptive, N=%d',size(A.P,1)));xlabel('u (m)');ylabel('v (m)');
exportgraphics(f,fullfile(outDir,'FIG_E1_equal_budget_meshes.png'),'Resolution',Sx.figureDPI);close(f);
end

function plot_fault_geometry_robustness(outDir,To,Ta,Sx)
f=figure('Color','w','Position',[100 100 1150 450]);
tiledlayout(1,2,'Padding','compact','TileSpacing','compact');
nexttile;yyaxis left;errorbar(To.Magnitude_m,To.RMSE_Fault_mean,To.RMSE_Fault_std,'-o','LineWidth',1.2);ylabel('Fault RMSE (m)');yyaxis right;errorbar(To.Magnitude_m,To.JumpMAE_mean,To.JumpMAE_std,'-s','LineWidth',1.2);ylabel('Jump MAE (m)');xlabel('|fault offset| (m)');grid on;title('Fault-location perturbation');
nexttile;yyaxis left;errorbar(Ta.Magnitude_deg,Ta.RMSE_Fault_mean,Ta.RMSE_Fault_std,'-o','LineWidth',1.2);ylabel('Fault RMSE (m)');yyaxis right;errorbar(Ta.Magnitude_deg,Ta.JumpMAE_mean,Ta.JumpMAE_std,'-s','LineWidth',1.2);ylabel('Jump MAE (m)');xlabel('|orientation perturbation| (deg)');grid on;title('Fault-orientation perturbation');
exportgraphics(f,fullfile(outDir,'FIG_E2_fault_geometry_robustness.png'),'Resolution',Sx.figureDPI);close(f);
end

function plot_parameter_sensitivity(outDir,T,Sx)
params=unique(T.Parameter,'stable');
for ip=1:numel(params)
    p=params{ip};m=strcmp(T.Parameter,p);x=T.DisplayValue(m);
    [x,ord]=sort(x);tf=T.RMSE_Fault_m(m);tj=T.JumpMAE_m(m);tg=T.RMSE_Global_m(m);tf=tf(ord);tj=tj(ord);tg=tg(ord);
    f=figure('Color','w','Position',[100 100 920 430]);
    yyaxis left;plot(x,tf,'-o','LineWidth',1.3);hold on;plot(x,tg,'--s','LineWidth',1.1);ylabel('RMSE (m)');
    yyaxis right;plot(x,tj,'-d','LineWidth',1.3);ylabel('Jump MAE (m)');
    xlabel(strrep(p,'_','\_'));grid on;title(['Parameter sensitivity: ',strrep(p,'_','\_')]);
    legend({'Fault RMSE','Global RMSE','Jump MAE'},'Location','best');
    exportgraphics(f,fullfile(outDir,['FIG_E3_parameter_sensitivity_',p,'.png']),'Resolution',Sx.figureDPI);close(f);
end
end

% =========================================================================
% PAPER-READY TEXT SUMMARY
% =========================================================================
function write_paper_ready_summary(outDir,E,Eff,To,Ta,Ts,Sx,sigma0)
fid=fopen(fullfile(outDir,'PAPER_READY_SUMMARY.txt'),'w');
if fid<0,return;end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>
fprintf(fid,'Supplementary experiments summary\n');
fprintf(fid,'=================================\n\n');
fprintf(fid,'E1 strict equal-budget factorial ablation, N=%d\n',Sx.equalBudgetNodes);
for i=1:height(E)
    fprintf(fid,'%-6s | fault RMSE %.6f | jump MAE %.6f | global RMSE %.6f\n', ...
        E.Method{i},E.RMSE_Fault_m(i),E.JumpMAE_m(i),E.RMSE_Global_m(i));
end
fprintf(fid,'\nMain factorial contrasts (positive reduction = improvement):\n');
for i=1:height(Eff)
    fprintf(fid,'%s | %s | %.3f %%\n',Eff.Metric{i},Eff.Contrast{i},Eff.Reduction_percent(i));
end
fprintf(fid,'\nE2 geometry robustness: absolute perturbations are averaged over +/- signs.\n');
fprintf(fid,'Offset magnitudes: %s m\n',mat2str(To.Magnitude_m.'));
fprintf(fid,'Angle magnitudes : %s deg\n',mat2str(Ta.Magnitude_deg.'));
fprintf(fid,'\nE3 one-at-a-time sensitivity. Baseline effective sigma_Gamma = %.6f m.\n',sigma0);
fprintf(fid,'Rows written to E3_PARAMETER_SENSITIVITY.csv: %d\n',height(Ts));
fprintf(fid,'\nInterpretation rule:\n');
fprintf(fid,'1) E1 is the primary causal ablation.\n');
fprintf(fid,'2) E2 is the primary engineering robustness test.\n');
fprintf(fid,'3) E3 is a secondary tuning-sensitivity audit, not a parameter-selection procedure.\n');
end

% =========================================================================
% SMALL UTILITIES
% =========================================================================
function r = corr_local(a,b)
a=a(:);b=b(:);m=isfinite(a)&isfinite(b);a=a(m);b=b(m);
if numel(a)<3 || std(a)<=eps || std(b)<=eps,r=nan;else,C=corrcoef(a,b);r=C(1,2);end
end

function q = percentile_local(x,p)
x=x(isfinite(x));
if isempty(x),q=nan;return;end
x=sort(x(:));
if numel(x)==1,q=x;return;end
r=1+(numel(x)-1)*p/100;i=floor(r);j=ceil(r);
if i==j,q=x(i);else,q=x(i)+(r-i)*(x(j)-x(i));end
end
