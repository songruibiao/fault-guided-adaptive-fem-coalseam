function OUT = RUN_FAULT_AFEM_PARAMETER_REDUCED_V2(dataDir,profile)
% RUN_FAULT_AFEM_PARAMETER_REDUCED_V2
% =========================================================================
% One-command driver for the parameter-reduced V2 paper experiments:
%
%   A. C11 main reconstruction + parameter provenance + predictive/structural stop
%   B. strict N=200 equal-budget factorial ablation
%   C. 2-D scale-expansion matched-accuracy validation
%
% Usage
% -----
%   % Fast validation first:
%   OUT = RUN_FAULT_AFEM_PARAMETER_REDUCED_V2('', 'quick');
%
%   % Formal paper run:
%   OUT = RUN_FAULT_AFEM_PARAMETER_REDUCED_V2('', 'paper');
%
%   % Explicit C11 data folder:
%   OUT = RUN_FAULT_AFEM_PARAMETER_REDUCED_V2( ...
%       'G:\paper\data_C11','paper');
%
% C11 data folder must contain
%   TVD_C11.dat
%   Dingji_t11_plg.dat
%
% The scale-expansion experiment is synthetic and does not require C11 data.
% =========================================================================
clc;
close all;

if nargin<1, dataDir=''; end
if nargin<2 || isempty(profile), profile='paper'; end
profile=lower(char(profile));

if ~ismember(profile,{'quick','paper'})
    error('profile must be ''quick'' or ''paper''.');
end

scriptDir=fileparts(mfilename('fullpath'));
if isempty(scriptDir), scriptDir=pwd; end
addpath(scriptDir);

fprintf('\n============================================================\n');
fprintf('RUN_FAULT_AFEM_PARAMETER_REDUCED_V2\n');
fprintf('Profile: %s\n',upper(profile));
fprintf('============================================================\n\n');

fprintf('[A/3] C11 parameter-reduced main experiment ...\n');
c11Out=REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2(dataDir,profile);

fprintf('\n[B/3] Strict N=200 equal-budget factorial ablation ...\n');
e1Out=RUN_C11_EQUAL_BUDGET_PARAMETER_REDUCED_V2(c11Out,dataDir);

fprintf('\n[C/3] 2-D scale-expansion matched-accuracy validation ...\n');
scaleOut=FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2(profile);

OUT=struct();
OUT.profile=profile;
OUT.c11=c11Out;
OUT.equalBudget=e1Out;
OUT.scaling=scaleOut;

fprintf('\n============================================================\n');
fprintf('PARAMETER-REDUCED V2 SUITE FINISHED\n');
fprintf('C11          : %s\n',c11Out);
fprintf('Equal budget : %s\n',e1Out);
fprintf('Scaling      : %s\n',scaleOut);
fprintf('\nKey paper-facing outputs:\n');
fprintf('  %s\n',fullfile(c11Out,'PARAMETER_PROVENANCE_V2.csv'));
fprintf('  %s\n',fullfile(c11Out,'TUNING_FAULT_FEM_C0_EPS.csv'));
fprintf('  %s\n',fullfile(c11Out,'AFEM_STOP_PREDICTIVE_CV.csv'));
fprintf('  %s\n',fullfile(c11Out,'STRUCT_STOP_data_variability.csv'));
fprintf('  %s\n',fullfile(c11Out,'MAIN_metrics.csv'));
fprintf('  %s\n',fullfile(e1Out,'E1_EQUAL_BUDGET_FACTORIAL.csv'));
fprintf('  %s\n',fullfile(e1Out,'E1_EQUAL_BUDGET_EFFECTS.csv'));
fprintf('  %s\n',fullfile(scaleOut,'SCALING_PARAMETER_CALIBRATION.csv'));
fprintf('  %s\n',fullfile(scaleOut,'SCALING_PAPER_MATCHED_ACCURACY.csv'));
fprintf('  %s\n',fullfile(scaleOut,'SCALING_AGGREGATE.csv'));
fprintf('============================================================\n\n');
end
