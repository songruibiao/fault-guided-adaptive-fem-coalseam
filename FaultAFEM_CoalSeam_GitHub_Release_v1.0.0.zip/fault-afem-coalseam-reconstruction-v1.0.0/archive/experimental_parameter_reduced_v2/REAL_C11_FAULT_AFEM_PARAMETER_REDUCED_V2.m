function outDir=REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2(dataDirOverride,profile)
% REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2
% =========================================================================
% Parameter-reduced paper engine for the C11 coal-seam reconstruction.
%
% Main changes relative to CORE V4:
%   1) sigma_Gamma is derived from interpreted fault geometry:
%          sigma_Gamma = G.halfWidth95.
%   2) (c0, epsilon_min) are selected jointly by buffered spatial CV.
%   3) adaptive marking uses a SET UNION:
%          residual Dörfler set UNION one-sigma fault-geometry set,
%      rather than 0.65/0.35 residual--geology mixing.
%   4) background-priority coefficients and g_force/g_bg heuristics are
%      removed from the refinement decision.
%   5) predictive stopping is the intersection of independent one-SE sets
%      for global and fault-weighted CV risks; no alpha mixing is used.
%   6) structural stopping thresholds are estimated from spatial-CV
%      withholding variability on the finest internal mesh; no q_SE or
%      c_tail multiplier is used.
%
% Dense interpreted C11 horizon values are used only for retrospective
% evaluation after the model and stopping scale have been selected.
%
% Usage:
%   outDir = REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2;
%   outDir = REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2('', 'quick');
%   outDir = REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2('G:\...\data_C11','paper');
%
% Required:
%   data_C11/TVD_C11.dat
%   data_C11/Dingji_t11_plg.dat
%
% Key outputs:
%   PARAMETER_PROVENANCE_V2.csv
%   TUNING_FAULT_FEM_C0_EPS.csv
%   AFEM_STOP_PREDICTIVE_CV.csv
%   STRUCT_STOP_data_variability.csv
%   AFEM_STOP_FINAL.csv
%   MAIN_metrics.csv
%   CORE_RESULT_STATE.mat
% =========================================================================
clc;
close all;

if nargin<1
    dataDirOverride='';
end
if nargin<2 || isempty(profile)
    profile='paper';
end

cfg=default_config();
cfg.profile=lower(char(profile));
cfg=apply_profile_parameter_reduced_v2(cfg);

% Fixed interpreted structure for the compact benchmark.
cfg.forcePolygonIndex=10;
cfg.faultIndex=cfg.forcePolygonIndex;

validate_structstop_config_core_v3(cfg);

scriptDir=fileparts(mfilename('fullpath'));
if isempty(scriptDir), scriptDir=pwd; end

if ~isempty(dataDirOverride)
    cfg.dataDir=char(dataDirOverride);
else
    cfg.dataDir=resolve_data_c11_paper_v3_fix1(scriptDir,cfg);
end

fprintf('  C11 data directory: %s\n',cfg.dataDir);
validate_required_files(cfg);

stamp=datestr(now,'yyyymmdd_HHMMSS');
outDir=fullfile(scriptDir,['out_REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2_' stamp]);
if ~exist(outDir,'dir'), mkdir(outDir); end

diary(fullfile(outDir,'RUN_LOG.txt'));
cleanupDiary=onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('\n============================================================\n');
fprintf('REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2\n');
fprintf('sparse controls + interpreted fault -> FEM -> AFEM -> CV stop\n');
fprintf('Output: %s\n',outDir);
fprintf('============================================================\n\n');

% =========================================================================
% 1. READ INTERPRETED C11 + FIXED FAULT GEOMETRY
% =========================================================================
fprintf('[1/8] Reading C11 horizon and interpreted fault ...\n');

Hraw=read_c11_horizon(fullfile(cfg.dataDir,cfg.horizonFile));
Pall=read_fault_polygon(fullfile(cfg.dataDir,cfg.polygonFile));

selectedIndex=cfg.forcePolygonIndex;

if ~any(Pall.index==selectedIndex)
    error('Interpreted fault polygon Index=%d does not exist.',selectedIndex);
end

Psel=Pall.xy(Pall.index==selectedIndex,:);
G=build_fault_geometry(Psel,cfg);
cfg=derive_parameter_reduced_geometry_scales(cfg,G);

UVall=global_to_local(Hraw.xy,G);
phiAll=fault_phi(UVall,G);

uLo=G.uMin-cfg.mainMarginAlong;
uHi=G.uMax+cfg.mainMarginAlong;
vLo=min(G.vc)-cfg.mainMarginCross;
vHi=max(G.vc)+cfg.mainMarginCross;

inside=UVall(:,1)>=uLo & UVall(:,1)<=uHi & ...
       UVall(:,2)>=vLo & UVall(:,2)<=vHi;

UVref=UVall(inside,:);
Zref=Hraw.z(inside);
XYref=Hraw.xy(inside,:);
phiRef=phiAll(inside);
gateRef=fault_gate(UVref(:,1),G,cfg);

if size(UVref,1)<cfg.minLocalReferencePoints
    error('Local interpreted-reference window has only %d points.',size(UVref,1));
end

faultMask=abs(phiRef)<=cfg.evalFaultBand & gateRef>=cfg.evalGateMin;
bgMask=abs(phiRef)>=cfg.evalBackgroundDistance | gateRef<cfg.evalGateMin;
negMask=phiRef<0;
posMask=~negMask;

Rref=build_side_reference_interpolants(UVref,Zref,G,cfg);

fprintf('  polygon Index           : %d\n',selectedIndex);
fprintf('  fault length            : %.2f m\n',G.uMax-G.uMin);
fprintf('  local reference points  : %d\n',size(UVref,1));
fprintf('  fault-band eval points  : %d\n',nnz(faultMask));
fprintf('  local domain u          : %.1f -- %.1f m\n',uLo,uHi);
fprintf('  local domain v          : %.1f -- %.1f m\n',vLo,vHi);

plot_selected_window(outDir,XYref,Zref,Pall,G,selectedIndex,UVref,cfg);

% =========================================================================
% 2. BUILD THE SAME N=80 SPARSE CONTROLS FOR ALL METHODS
% =========================================================================
fprintf('\n[2/8] Building N=%d sparse elevation controls ...\n',cfg.mainN);

obsIdx=spatial_farthest_sample_balanced( ...
    UVref,phiRef,cfg.mainN,cfg.mainSeed,cfg);

obs=make_obs(UVref,Zref,obsIdx,cfg);

% Spatial-CV exclusion distance is derived from available information rather
% than prescribed in metres: use the smaller of the interpreted fault scale
% and the median nearest-neighbour spacing of the sparse controls.
cfg.controlNNScale=median_control_nn_spacing_paramred_v2(obs.uv);
cfg.interpCVBuffer=min(cfg.faultSigmaMin,cfg.controlNNScale);
cfg.interpCVBufferSchedule=[cfg.interpCVBuffer 0];

obsXY=local_to_global(obs.uv,G);
Tobs=table((1:cfg.mainN).',obsXY(:,1),obsXY(:,2), ...
    obs.uv(:,1),obs.uv(:,2),obs.z, ...
    'VariableNames',{'ID','X','Y','u','v','Elevation'});
writetable(Tobs,fullfile(outDir,'SPARSE_CONTROLS.csv'));

fprintf('  side counts (-/+)      : %d / %d\n', ...
    nnz(fault_phi(obs.uv,G)<0),nnz(fault_phi(obs.uv,G)>=0));

plot_interpcv_fold_map(outDir,obs,G,[uLo,uHi],[vLo,vHi],cfg);

% =========================================================================
% 3. SPARSE-DATA CALIBRATION OF REGULARIZATION
% =========================================================================
fprintf('\n[3/8] Calibrating regularization from sparse controls ...\n');

cvTPS=select_tps_lambda_interpcv( ...
    obs,[uLo,uHi],[vLo,vHi],G,cfg, ...
    cfg.mainTuneCVRepeats,cfg.mainTuneCVFolds);
solTPS=fit_tps_solution(obs,cvTPS.value,cfg);
solTPS.name='S-TPS';

meshCV=uniform_mesh_under_budget([uLo,uHi],[vLo,vHi],cfg.cvNodeBudget);
Hcv=build_interp_matrix(meshCV,obs.uv);

KisoCV=assemble_iso_stiffness(meshCV);
cvIso=select_fem_c0_interpcv( ...
    KisoCV,Hcv,obs,[uLo,uHi],[vLo,vHi],G,cfg, ...
    cfg.mainTuneCVRepeats,cfg.mainTuneCVFolds);

% Fault regularization is tuned jointly in (c0, epsilon_min).
% Dense interpreted C11 values are never used by this selection.
cvFault=select_fault_c0_eps_interpcv( ...
    meshCV,Hcv,obs,[uLo,uHi],[vLo,vHi],G,cfg, ...
    cfg.mainTuneCVRepeats,cfg.mainTuneCVFolds);
cfg.faultEpsMin=cvFault.epsValue;

fprintf('  geometry-derived sigma : %.6g m\n',cfg.faultSigmaMin);
fprintf('  TPS lambda             : %.6g\n',cvTPS.value);
fprintf('  ISO-FEM c0             : %.6g\n',cvIso.value);
fprintf('  FAULT-FEM c0           : %.6g\n',cvFault.value);
fprintf('  FAULT-FEM epsilon_min  : %.6g\n',cvFault.epsValue);

write_scalar_cv_table_core(cvTPS,'lambda', ...
    fullfile(outDir,'TUNING_TPS.csv'));
write_scalar_cv_table_core(cvIso,'c0', ...
    fullfile(outDir,'TUNING_ISO_FEM.csv'));
write_joint_fault_cv_table_paramred_v2( ...
    cvFault,fullfile(outDir,'TUNING_FAULT_FEM_C0_EPS.csv'));

write_parameter_provenance_paramred_v2(outDir,cfg,cvTPS,cvIso,cvFault,G);

% =========================================================================
% 4. PREDICTIVE CV + DATA-SCALED STRUCTURAL STOPPING
% =========================================================================
fprintf('\n[4/8] Predictive CV plus data-scaled structural stopping ...\n');
fprintf('  candidate node budgets : %s\n',mat2str(cfg.nodeBudgets));
fprintf('  fault-risk bandwidth   : %.3f m (geometry-derived)\n',cfg.faultSigmaMin);
fprintf('  structural fine ref    : %d nodes\n',max(cfg.nodeBudgets));
fprintf('  probe spacing / band   : %.1f / %.1f m\n', ...
    cfg.structProbeSpacing,cfg.structFaultBand);

% -------------------------------------------------------------------------
% 4A. Nested spatial CV.
% Global and fault-weighted risks are retained as two separate constraints;
% no manually chosen mixing coefficient alpha is used.
% -------------------------------------------------------------------------
stopCV=crossfit_afem_stopping_paramred_v2( ...
    obs,G,[uLo,uHi],[vLo,vHi],cfg);

writetable(stopCV.table,fullfile(outDir,'AFEM_STOP_PREDICTIVE_CV.csv'));
writetable(stopCV.outerTable,fullfile(outDir,'AFEM_STOP_outer_details.csv'));
writetable(stopCV.c0Table,fullfile(outDir,'AFEM_STOP_nested_c0_eps.csv'));

rangeAudit=stopping_range_audit_core_v2(stopCV,cfg);
writetable(rangeAudit,fullfile(outDir,'AFEM_STOP_range_audit.csv'));

fprintf('\n  global one-SE threshold : %.6g\n',stopCV.globalThreshold);
fprintf('  fault  one-SE threshold : %.6g\n',stopCV.faultThreshold);
fprintf('  predictive selected     : %d nodes\n',stopCV.selectedBudget);
fprintf('  predictive certified    : %d\n',stopCV.predictiveCertified);

plot_predictive_dual_guard_paramred_v2(outDir,stopCV,cfg);

% -------------------------------------------------------------------------
% 4B. Full-data nested AFEM sequence and structural stabilization.
% Structural tolerances are estimated from the variability caused by the
% same buffered spatial CV splits on the finest internal mesh.  No tail
% multiplier and no dense C11 truth are used.
% -------------------------------------------------------------------------
structStop=structural_stability_stopping_paramred_v2( ...
    obs,G,[uLo,uHi],[vLo,vHi],cvFault.value,stopCV,cfg);

writetable(structStop.table, ...
    fullfile(outDir,'STRUCT_STOP_self_convergence.csv'));
writetable(structStop.variabilityTable, ...
    fullfile(outDir,'STRUCT_STOP_data_variability.csv'));

stopFinal=apply_structural_selection_to_stopcv_v3(stopCV,structStop);
writetable(stopFinal.table,fullfile(outDir,'AFEM_STOP_FINAL.csv'));

fprintf('\n  structural field tau    : %.6g\n',structStop.fieldThreshold);
fprintf('  structural gradient tau : %.6g\n',structStop.gradThreshold);
fprintf('  joint selected budget   : %d\n',structStop.selectedBudget);
fprintf('  joint stop certified    : %d\n',structStop.certified);
fprintf('  selected field envelope : %.6g\n', ...
    structStop.fieldEnvelope(structStop.selectedIndex));
fprintf('  selected grad envelope  : %.6g\n', ...
    structStop.gradEnvelope(structStop.selectedIndex));

plot_structural_stopping_core_v3(outDir,structStop,cfg);

cfg.mainNodeBudget=structStop.selectedBudget;

% =========================================================================
% 5. REUSE THE SELECTED MODEL FROM THE SELF-CONVERGENCE SEQUENCE
% =========================================================================
fprintf('\n[5/8] Reusing selected full-data AFEM model at budget=%d ...\n', ...
    cfg.mainNodeBudget);

solAF=structStop.solutions{structStop.selectedIndex};
meshAF=structStop.meshes{structStop.selectedIndex};
histAF=structStop.combinedHistories{structStop.selectedIndex};

actualAFNodes=size(meshAF.P,1);

fprintf('  requested stop budget  : %d\n',cfg.mainNodeBudget);
fprintf('  actual AFEM nodes      : %d\n',actualAFNodes);
fprintf('  actual AFEM triangles  : %d\n',size(meshAF.T,1));
fprintf('  structural certified   : %d\n',structStop.certified);

% =========================================================================
% 6. MATCHED-DOF FINAL BASELINES
% =========================================================================
fprintf('\n[6/8] Building matched-DOF uniform baselines ...\n');

meshU=uniform_mesh_under_budget([uLo,uHi],[vLo,vHi],actualAFNodes);
HU=build_interp_matrix(meshU,obs.uv);

Kiso=assemble_iso_stiffness(meshU);
solIso=fit_fem_solution(meshU,Kiso,HU,obs,cvIso.value,'ISO-FEM');

Kfault=assemble_fault_stiffness(meshU,G,cfg);
solFault=fit_fem_solution(meshU,Kfault,HU,obs,cvFault.value,'FAULT-FEM');

sols={solTPS,solIso,solFault,solAF};

% =========================================================================
% 7. RETROSPECTIVE DENSE-REFERENCE EVALUATION
% =========================================================================
fprintf('\n[7/8] Retrospective interpreted-reference evaluation ...\n');
fprintf('  NOTE: these dense values were NOT used for stopping or tuning.\n');

MM=cell(4,1);

for i=1:4
    pred=predict_solution(sols{i},UVref);
    [MM{i},~]=evaluate_dense_v2( ...
        pred,Zref,faultMask,bgMask,negMask,posMask, ...
        obs,sols{i},Rref,G,cfg);
end

mainTable=make_afem_main_table_v4( ...
    sols,MM,meshU,meshAF,cvTPS,cvIso,cvFault,stopFinal,cfg);

writetable(mainTable,fullfile(outDir,'MAIN_metrics.csv'));

disp(' ');
disp('================ CORE MAIN METRICS ================');
disp(mainTable);

plot_afem_main_reconstruction( ...
    outDir,UVref,Zref,sols,G,[uLo,uHi],[vLo,vHi],cfg);

plot_afem_main_errors( ...
    outDir,UVref,Zref,sols,G,[uLo,uHi],[vLo,vHi],cfg);

plot_uniform_vs_adaptive_mesh_v4( ...
    outDir,meshU,meshAF,G,stopFinal,cfg);

plot_afem_fault_profile(outDir,sols,Rref,G,cfg);
plot_afem_history(outDir,histAF,cfg);

% CORE V4 paper-facing audits / LaTeX macros.
write_v4_paper_exports(outDir,mainTable,meshU,meshAF,solAF,obs,G, ...
    cvFault,structStop,histAF,cfg);

% =========================================================================
% 7B. JOURNAL-STYLE PAPER FIGURES
% =========================================================================
fprintf('\n[7B] Rebuilding journal-style paper figures ...\n');
paperfigs_c11_v1(outDir,UVref,Zref,sols,meshU,meshAF,G,obs,mainTable,cfg);

% =========================================================================
% 8. SAVE COMPACT STATE + SUMMARY
% =========================================================================
fprintf('\n[8/8] Saving compact core state ...\n');

write_core_summary( ...
    outDir,selectedIndex,G,obs,cvTPS,cvIso,cvFault,stopCV,stopFinal, ...
    structStop,rangeAudit,meshU,meshAF,mainTable,cfg);

state=struct();
state.cfg=cfg;
state.selectedPolygon=selectedIndex;
state.geometry=G;
state.sparseControls=Tobs;
state.cvTPS=cvTPS;
state.cvIso=cvIso;
state.cvFault=cvFault;
state.predictiveStopCV=stopCV;
state.finalStopCV=stopFinal;
state.structuralStop=strip_structural_runtime_cells_v3(structStop);
state.stoppingRangeAudit=rangeAudit;
state.mainTable=mainTable;
state.uniformMesh=meshU;
state.adaptiveMesh=meshAF;
state.adaptiveHistory=histAF;

save(fullfile(outDir,'CORE_RESULT_STATE.mat'),'state','-v7.3');

fprintf('\n============================================================\n');
fprintf('REAL C11 FAULT-AFEM PARAMETER-REDUCED V2 FINISHED\n');
fprintf('Selected budget = %d | actual AFEM nodes = %d\n', ...
    structStop.selectedBudget,actualAFNodes);
fprintf('Output: %s\n',outDir);
fprintf('============================================================\n\n');

end


% =========================================================================
% SMALL CORE OUTPUT HELPERS
% =========================================================================
function T=stopping_range_audit_core_v2(stopCV,cfg)
% Diagnostic only: verify whether raw-best / one-SE selected complexity is
% still located at an artificial search boundary after the V2 range extension.

b=cfg.nodeBudgets(:);
b=sort(b);

MinBudget=b(1);
MaxBudget=b(end);
RawBestBudget=stopCV.rawBestBudget;
SelectedBudget=stopCV.selectedBudget;

RawBestAtLowerBoundary=RawBestBudget==MinBudget;
RawBestAtUpperBoundary=RawBestBudget==MaxBudget;
RawBestAtBoundary=RawBestAtLowerBoundary || RawBestAtUpperBoundary;

SelectedAtLowerBoundary=SelectedBudget==MinBudget;
SelectedAtUpperBoundary=SelectedBudget==MaxBudget;
SelectedAtBoundary=SelectedAtLowerBoundary || SelectedAtUpperBoundary;

NCandidatesBelow250=nnz(b<250);
NCandidatesAtOrBelow250=nnz(b<=250);
NCandidatesAbove250=nnz(b>250);

% Local shape around 250, when present.
i250=find(b==250,1);
Has250=~isempty(i250);

Risk150=lookup_stop_risk_core_v2(stopCV,150);
Risk175=lookup_stop_risk_core_v2(stopCV,175);
Risk200=lookup_stop_risk_core_v2(stopCV,200);
Risk225=lookup_stop_risk_core_v2(stopCV,225);
Risk250=lookup_stop_risk_core_v2(stopCV,250);
Risk300=lookup_stop_risk_core_v2(stopCV,300);
Risk400=lookup_stop_risk_core_v2(stopCV,400);

if Has250
    q=find(isfinite(stopCV.meanEng));
    [~,j]=min(abs(b(q)-250));
    nearestIdx=q(j);
    RiskAtNearest250=stopCV.meanEng(nearestIdx);
else
    RiskAtNearest250=nan;
end

T=table(MinBudget,MaxBudget,RawBestBudget,SelectedBudget, ...
    RawBestAtLowerBoundary,RawBestAtUpperBoundary,RawBestAtBoundary, ...
    SelectedAtLowerBoundary,SelectedAtUpperBoundary,SelectedAtBoundary, ...
    NCandidatesBelow250,NCandidatesAtOrBelow250,NCandidatesAbove250, ...
    Risk150,Risk175,Risk200,Risk225,Risk250,Risk300,Risk400, ...
    RiskAtNearest250);
end


function r=lookup_stop_risk_core_v2(stopCV,budget)
j=find(stopCV.budgets==budget,1);
if isempty(j)
    r=nan;
else
    r=stopCV.meanEng(j);
end
end



% =========================================================================
% CORE V3: PREDICTIVE--STRUCTURAL STOPPING
% =========================================================================
function S=structural_stability_stopping_paramred_v2( ...
    obs,G,uRange,vRange,c0,stopCV,cfg)

budgets=cfg.nodeBudgets(:);
nb=numel(budgets);

if nb<3
    error('STRUCTSTOP requires at least three nested budgets.');
end

% Fixed structure-only probe set.  No dense C11 values are used.
probeUV=make_fault_probe_grid_core_v3(uRange,vRange,G,cfg);

if size(probeUV,1)<cfg.structMinProbePoints
    error('STRUCTSTOP probe grid has only %d points; need at least %d.', ...
        size(probeUV,1),cfg.structMinProbePoints);
end

fprintf('  Structural self-convergence sequence begins ...\n');
fprintf('    probe points = %d\n',size(probeUV,1));

initBudget=min(cfg.afemInitialNodeBudget,min(budgets)-1);
mesh=uniform_mesh_under_budget(uRange,vRange,initBudget);

solutions=cell(nb,1);
meshes=cell(nb,1);
histories=cell(nb,1);
combinedHistories=cell(nb,1);

actualNodes=zeros(nb,1);
actualTriangles=zeros(nb,1);

Z=nan(size(probeUV,1),nb);
GU=nan(size(probeUV,1),nb);
GV=nan(size(probeUV,1),nb);

histAll=struct('iter',{},'nodes',{},'triangles',{},'etaResidual',{}, ...
    'etaGeoMean',{},'marked',{},'acceptedMarks',{}, ...
    'splitEdges',{},'budgetLimited',{},'areaRelError',{});

for ib=1:nb
    fprintf('    full-data AFEM budget %d/%d = %d\n', ...
        ib,nb,budgets(ib));

    [sol,mesh,hist]=adapt_fault_mesh_to_budget( ...
        mesh,budgets(ib),obs,G,c0,cfg);

    solutions{ib}=sol;
    meshes{ib}=mesh;
    histories{ib}=hist;

    if ~isempty(hist)
        histAll=[histAll,hist]; %#ok<AGROW>
    end
    combinedHistories{ib}=histAll;

    actualNodes(ib)=size(mesh.P,1);
    actualTriangles(ib)=size(mesh.T,1);

    Z(:,ib)=predict_solution(sol,probeUV);

    grad=predict_fem_gradient_core_v3(sol,probeUV);
    GU(:,ib)=grad(:,1);
    GV(:,ib)=grad(:,2);
end

% Use only probe points valid for every nested mesh.
valid=all(isfinite(Z),2) & all(isfinite(GU),2) & all(isfinite(GV),2);

if nnz(valid)<cfg.structMinProbePoints
    error(['Only %d structural probe points are valid on every mesh; ', ...
        'need at least %d.'],nnz(valid),cfg.structMinProbePoints);
end

probeUV=probeUV(valid,:);
Z=Z(valid,:);
GU=GU(valid,:);
GV=GV(valid,:);

iFine=nb;
iTail=nb-1;
iTail2=max(nb-2,1);

zFine=Z(:,iFine);
guFine=GU(:,iFine);
gvFine=GV(:,iFine);

zScale=sqrt(mean((zFine-mean(zFine)).^2));
if ~(zScale>1e-10)
    zScale=max(max(zFine)-min(zFine),1);
end

gScale=sqrt(mean(guFine.^2+gvFine.^2));
if ~(gScale>1e-10)
    gScale=1;
end

fieldRel=zeros(nb,1);
gradRel=zeros(nb,1);
fieldStep=nan(nb,1);
gradStep=nan(nb,1);

for ib=1:nb
    fieldRel(ib)=sqrt(mean((Z(:,ib)-zFine).^2))/zScale;

    dgu=GU(:,ib)-guFine;
    dgv=GV(:,ib)-gvFine;
    gradRel(ib)=sqrt(mean(dgu.^2+dgv.^2))/gScale;

    if ib>1
        fieldStep(ib)=sqrt(mean((Z(:,ib)-Z(:,ib-1)).^2))/zScale;

        dgu=GU(:,ib)-GU(:,ib-1);
        dgv=GV(:,ib)-GV(:,ib-1);
        gradStep(ib)=sqrt(mean(dgu.^2+dgv.^2))/gScale;
    end
end

% Fine-side envelopes: once accepted, all finer models must remain close.
fieldEnvelope=zeros(nb,1);
gradEnvelope=zeros(nb,1);

for ib=1:nb
    fieldEnvelope(ib)=max(fieldRel(ib:end));
    gradEnvelope(ib)=max(gradRel(ib:end));
end

% Data-scaled structural thresholds.
% Fit the same regularized model on the finest full-data mesh after
% withholding each valid buffered spatial-CV fold.  The RMS variation of
% these withheld-data solutions around the full-data fine solution defines
% the structural tolerance; no empirical tail multiplier is introduced.
[fieldThreshold,gradThreshold,VarTable]= ...
    structural_data_variability_thresholds_paramred_v2( ...
    meshes{iFine},obs,probeUV,zFine,guFine,gvFine,zScale,gScale, ...
    G,c0,stopCV,cfg);

tailFieldBase=fieldThreshold;  % compatibility fields only
tailGradBase=gradThreshold;

structuralEligible= ...
    fieldEnvelope<=fieldThreshold & ...
    gradEnvelope<=gradThreshold;

predictiveThreshold=1;
predictiveEligible=stopCV.predictiveEligible(:);

jointEligible=predictiveEligible & structuralEligible;

certified=any(jointEligible);

if certified
    iSel=find(jointEligible,1,'first');
    fallbackReason='NONE';
else
    % Explicit diagnostic fallback: finest model that remains inside the
    % predictive guardrail.  This is marked uncertified in all outputs.
    q=find(predictiveEligible);

    if isempty(q)
        iSel=stopCV.rawBestIndex;
        fallbackReason='NO_PREDICTIVE_ELIGIBLE_LEVEL';
    else
        iSel=q(end);
        fallbackReason='NO_JOINT_LEVEL__USED_FINEST_PREDICTIVE_LEVEL';
    end
end

Selected=false(nb,1);
Selected(iSel)=true;

T=table( ...
    budgets,actualNodes,actualTriangles, ...
    stopCV.meanEng,stopCV.seEng, ...
    predictiveEligible, ...
    fieldRel,gradRel,fieldStep,gradStep, ...
    fieldEnvelope,gradEnvelope, ...
    structuralEligible,jointEligible,Selected, ...
    'VariableNames',{'Budget','ActualNodes','ActualTriangles', ...
    'CV_EngRisk','CV_EngSE','PredictiveEligible', ...
    'FieldRelToFine','GradRelToFine','FieldStepRel','GradStepRel', ...
    'FieldFineEnvelope','GradFineEnvelope', ...
    'StructuralEligible','JointEligible','Selected'});

Sens=VarTable;

S=struct();
S.budgets=budgets;
S.actualNodes=actualNodes;
S.actualTriangles=actualTriangles;

S.probeUV=probeUV;
S.nProbe=size(probeUV,1);

S.fieldRel=fieldRel;
S.gradRel=gradRel;
S.fieldStep=fieldStep;
S.gradStep=gradStep;
S.fieldEnvelope=fieldEnvelope;
S.gradEnvelope=gradEnvelope;

S.fineReferenceIndex=iFine;
S.fineReferenceBudget=budgets(iFine);
S.tailReferenceIndex=iTail;
S.tailReferenceBudget=budgets(iTail);
S.tailPreviousIndex=iTail2;
S.tailPreviousBudget=budgets(iTail2);
S.tailFieldBase=tailFieldBase;
S.tailGradBase=tailGradBase;

S.fieldThreshold=fieldThreshold;
S.gradThreshold=gradThreshold;
S.predictiveThreshold=predictiveThreshold;

S.predictiveEligible=predictiveEligible;
S.structuralEligible=structuralEligible;
S.jointEligible=jointEligible;

S.selectedIndex=iSel;
S.selectedBudget=budgets(iSel);
S.certified=certified;
S.fallbackReason=fallbackReason;

S.table=T;
S.sensitivityTable=Sens;
S.variabilityTable=VarTable;

% Runtime cells are reused by the final solve to avoid repeating AFEM work.
S.solutions=solutions;
S.meshes=meshes;
S.histories=histories;
S.combinedHistories=combinedHistories;
end



function [tauZ,tauG,T]=structural_data_variability_thresholds_paramred_v2( ...
    meshFine,obs,probeUV,zFine,guFine,gvFine,zScale,gScale,G,c0,stopCV,cfg)

R=cfg.interpCVOuterRepeats;
K=cfg.interpCVOuterFolds;
folds=stopCV.foldLabels;

Kf=assemble_fault_stiffness(meshFine,G,cfg);

rows=cell(0,1);
rr=0;
dzAll=[];
dgAll=[];

for r=1:R
    for k=1:K
        [tr,~,usedBuffer,valid]=buffered_checkerboard_split_local( ...
            obs,folds(:,r),k,G,cfg);
        if ~valid, continue; end

        obsTr=subset_obs_local(obs,tr);
        Htr=build_interp_matrix(meshFine,obsTr.uv);
        S=fit_fem_solution(meshFine,Kf,Htr,obsTr,c0,'STRUCT-CV');

        z=predict_solution(S,probeUV);
        g=predict_fem_gradient_core_v3(S,probeUV);

        good=isfinite(z) & isfinite(g(:,1)) & isfinite(g(:,2));
        if nnz(good)<max(20,round(0.5*numel(zFine)))
            continue;
        end

        dz=sqrt(mean((z(good)-zFine(good)).^2))/max(zScale,eps);
        dgu=g(good,1)-guFine(good);
        dgv=g(good,2)-gvFine(good);
        dg=sqrt(mean(dgu.^2+dgv.^2))/max(gScale,eps);

        if ~(isfinite(dz) && isfinite(dg)), continue; end

        dzAll(end+1,1)=dz; %#ok<AGROW>
        dgAll(end+1,1)=dg; %#ok<AGROW>

        rr=rr+1;
        rows{rr,1}=table(r,k,usedBuffer,nnz(tr),dz,dg, ...
            'VariableNames',{'Repeat','Fold','UsedBuffer','NTrain', ...
            'FieldVariation','GradientVariation'}); %#ok<AGROW>
    end
end

if numel(dzAll)<2
    error(['Unable to estimate structural variability from spatial CV: ', ...
        'only %d valid withheld-data fits.'],numel(dzAll));
end

% Root-mean-square variability gives a direct data-derived reference scale.
tauZ=sqrt(mean(dzAll.^2));
tauG=sqrt(mean(dgAll.^2));

T=vertcat(rows{:});
end


function uv=make_fault_probe_grid_core_v3(uRange,vRange,G,cfg)
h=cfg.structProbeSpacing;

u=(uRange(1)+0.5*h):h:(uRange(2)-0.5*h);
v=(vRange(1)+0.5*h):h:(vRange(2)-0.5*h);

[U,V]=meshgrid(u,v);
uv=[U(:),V(:)];

phi=fault_phi(uv,G);
gate=fault_gate(uv(:,1),G,cfg);

m=abs(phi)<=cfg.structFaultBand & gate>=cfg.structGateMin;
uv=uv(m,:);
end


function grad=predict_fem_gradient_core_v3(S,uv)
if ~strcmpi(S.type,'fem')
    error('Structural gradient evaluator requires a FEM solution.');
end

M=S.mesh;
tri=pointLocation(M.TR,uv);

grad=nan(size(uv,1),2);
good=isfinite(tri);

if ~any(good)
    return;
end

tg=tri(good);
ug=find(good);

ut=unique(tg(:));

for k=1:numel(ut)
    e=ut(k);
    q=ug(tg==e);

    nodes=M.T(e,:);
    [B,~]=tri_gradients(M.P(nodes,:));
    ge=(B*S.U(nodes)).';

    grad(q,1)=ge(1);
    grad(q,2)=ge(2);
end
end


function T=structstop_sensitivity_core_v3( ...
    budgets,stopCV,fieldEnv,gradEnv,tailField,tailGrad,cfg)

qSE=cfg.structPredictiveSEAudit(:);
qTail=cfg.structTailFactorAudit(:);

rows=cell(numel(qSE)*numel(qTail),1);
r=0;

for i=1:numel(qSE)
    predThr=stopCV.rawBestRisk+qSE(i)*stopCV.rawBestSE;
    pred=isfinite(stopCV.meanEng) & stopCV.meanEng<=predThr;

    for j=1:numel(qTail)
        r=r+1;

        fThr=qTail(j)*max(tailField,eps);
        gThr=qTail(j)*max(tailGrad,eps);

        st=fieldEnv<=fThr & gradEnv<=gThr;
        joint=pred & st;

        if any(joint)
            k=find(joint,1,'first');
            selBudget=budgets(k);
            certified=1;
        else
            selBudget=nan;
            certified=0;
        end

        PredictiveSEFactor=qSE(i);
        TailFactor=qTail(j);
        PredictiveThreshold=predThr;
        FieldThreshold=fThr;
        GradientThreshold=gThr;
        SelectedBudget=selBudget;
        Certified=certified;

        rows{r}=table(PredictiveSEFactor,TailFactor, ...
            PredictiveThreshold,FieldThreshold,GradientThreshold, ...
            SelectedBudget,Certified);
    end
end

T=vertcat(rows{:});
end


function CV=apply_structural_selection_to_stopcv_v3(CV0,S)
CV=CV0;

i=S.selectedIndex;

CV.predictiveOneSEIndex=CV0.selectedIndex;
CV.predictiveOneSEBudget=CV0.selectedBudget;
CV.predictiveOneSERisk=CV0.selectedRisk;

CV.selectedIndex=i;
CV.selectedBudget=CV.budgets(i);
CV.selectedRisk=CV.meanEng(i);
CV.selectedGlobalMSE=CV.meanGlobal(i);
CV.selectedFaultMSE=CV.meanFault(i);
CV.selectedMeanNodes=CV.meanNodes(i);
CV.selectedMSE=CV.meanEng(i);

CV.selectionMode='predictive-structural';
CV.structuralCertified=S.certified;
CV.structuralFieldThreshold=S.fieldThreshold;
CV.structuralGradThreshold=S.gradThreshold;
CV.predictiveGuardThreshold=S.predictiveThreshold;

T=CV.table;

if ismember('Selected',T.Properties.VariableNames)
    T.Selected(:)=false;
    T.Selected(i)=true;
end

T.PredictiveEligible=S.predictiveEligible;
T.StructuralEligible=S.structuralEligible;
T.JointEligible=S.jointEligible;

CV.table=T;
end


function S0=strip_structural_runtime_cells_v3(S)
% Compact state: keep diagnostics, remove duplicate runtime solution cells.
S0=S;

drop={'solutions','meshes','histories','combinedHistories'};

for k=1:numel(drop)
    if isfield(S0,drop{k})
        S0=rmfield(S0,drop{k});
    end
end
end


function plot_structural_stopping_core_v3(outDir,S,cfg)
f=figure('Color','w','Units','pixels','Position',[90 90 1580 520]);
tl=tiledlayout(f,1,3,'Padding','compact','TileSpacing','compact');

% Predictive guardrail.
ax=nexttile(tl,1);
errorbar(ax,S.budgets,S.table.CV_EngRisk,S.table.CV_EngSE, ...
    '-o','LineWidth',1.4,'MarkerSize',6);
hold(ax,'on');
yline(ax,S.predictiveThreshold,'--','LineWidth',1.3);
plot(ax,S.selectedBudget,S.table.CV_EngRisk(S.selectedIndex), ...
    'p','MarkerSize',12,'LineWidth',1.8);
xlabel(ax,'node budget');
ylabel(ax,'joint predictive score');
title(ax,'Dual-risk predictive guard');
grid(ax,'on');
legend(ax,{'joint score','admissibility threshold','final stop'}, ...
    'Location','best');

% Structural self-convergence.
ax=nexttile(tl,2);
semilogy(ax,S.budgets,max(S.fieldEnvelope,1e-12),'-o', ...
    'LineWidth',1.5,'MarkerSize',6);
hold(ax,'on');
semilogy(ax,S.budgets,max(S.gradEnvelope,1e-12),'-s', ...
    'LineWidth',1.5,'MarkerSize',6);
yline(ax,S.fieldThreshold,'--','LineWidth',1.2);
yline(ax,S.gradThreshold,':','LineWidth',1.2);
xline(ax,S.selectedBudget,'-.','LineWidth',1.2);
xlabel(ax,'node budget');
ylabel(ax,'relative discrepancy to finest internal model');
title(ax,sprintf('Fault-neighborhood self-convergence | fine=%d', ...
    S.fineReferenceBudget));
grid(ax,'on');
legend(ax,{'field envelope','gradient envelope', ...
    'field threshold','gradient threshold','final stop'}, ...
    'Location','best');

% Eligibility.
ax=nexttile(tl,3);
stairs(ax,S.budgets,double(S.predictiveEligible),'-o','LineWidth',1.4);
hold(ax,'on');
stairs(ax,S.budgets,double(S.structuralEligible),'-s','LineWidth',1.4);
stairs(ax,S.budgets,double(S.jointEligible),'-d','LineWidth',1.6);
xline(ax,S.selectedBudget,'-.','LineWidth',1.3);
ylim(ax,[-0.05 1.15]);
yticks(ax,[0 1]);
yticklabels(ax,{'no','yes'});
xlabel(ax,'node budget');
ylabel(ax,'eligible');
title(ax,sprintf('Joint stop | certified=%d',S.certified));
grid(ax,'on');
legend(ax,{'predictive','structural','joint','selected'}, ...
    'Location','best');

title(tl,'Predictive--structural AFEM stopping');

save_figure(f,fullfile(outDir,'FIG_06_STRUCTSTOP_self_convergence.png'),cfg);
end



function write_joint_fault_cv_table_paramred_v2(CV,fileName)
[nc,ne]=size(CV.meanMSE);
rows=cell(nc*ne,1);
r=0;
for ic=1:nc
    for ie=1:ne
        r=r+1;
        C0=CV.c0Grid(ic);
        EpsilonMin=CV.epsGrid(ie);
        CV_MSE=CV.meanMSE(ic,ie);
        CV_SE=CV.seMSE(ic,ie);
        NValid=CV.nValid(ic,ie);
        Selected=(ic==CV.selectedIndexC0 && ie==CV.selectedIndexEps);
        rows{r}=table(C0,EpsilonMin,CV_MSE,CV_SE,NValid,Selected);
    end
end
T=vertcat(rows{:});
writetable(T,fileName);
end


function write_parameter_provenance_paramred_v2(outDir,cfg,cvTPS,cvIso,cvFault,G)
Parameter={ ...
    'sigma_Gamma'; ...
    'epsilon_min'; ...
    'c0_fault'; ...
    'c0_iso'; ...
    'lambda_TPS'; ...
    'cv_buffer'; ...
    'theta_Dorfler'; ...
    'fault_eval_band'; ...
    'fault_structural_band'};
Value=[ ...
    cfg.faultSigmaMin; ...
    cvFault.epsValue; ...
    cvFault.value; ...
    cvIso.value; ...
    cvTPS.value; ...
    cfg.interpCVBuffer; ...
    cfg.afemDoerflerTheta; ...
    cfg.evalFaultBand; ...
    cfg.structFaultBand];
SelectionSource={ ...
    'interpreted fault robust half-width95'; ...
    'joint buffered spatial CV with c0'; ...
    'joint buffered spatial CV with epsilon_min'; ...
    'buffered spatial CV, one-SE scalar rule'; ...
    'buffered spatial CV, one-SE scalar rule'; ...
    'min(sigma_Gamma, median sparse-control NN spacing)'; ...
    'fixed standard AFEM marking parameter'; ...
    '2*sigma_Gamma'; ...
    '2*sigma_Gamma'};
IndependentFreeParameter=[false;false;false;false;false;false;true;false;false];

T=table(Parameter,Value,SelectionSource,IndependentFreeParameter);
writetable(T,fullfile(outDir,'PARAMETER_PROVENANCE_V2.csv'));

fid=fopen(fullfile(outDir,'PARAMETER_PROVENANCE_V2.txt'),'w');
if fid>=0
    c=onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid,'PARAMETER-REDUCED V2 provenance\n');
    fprintf(fid,'================================\n');
    fprintf(fid,'fault half-width95 = %.8g m\n',G.halfWidth95);
    fprintf(fid,'control NN median  = %.8g m\n',cfg.controlNNScale);
    fprintf(fid,'sigma_Gamma        = %.8g m (geometry-derived)\n',cfg.faultSigmaMin);
    fprintf(fid,'CV buffer          = %.8g m (geometry/data-derived)\n',cfg.interpCVBuffer);
    fprintf(fid,'epsilon_min        = %.8g (joint spatial CV)\n',cvFault.epsValue);
    fprintf(fid,'c0_fault           = %.8g (joint spatial CV)\n',cvFault.value);
    fprintf(fid,'c0_iso             = %.8g (one-SE spatial CV)\n',cvIso.value);
    fprintf(fid,'lambda_TPS         = %.8g (one-SE spatial CV)\n',cvTPS.value);
    fprintf(fid,'Dorfler theta       = %.8g (single fixed AFEM algorithm parameter)\n',cfg.afemDoerflerTheta);
    fprintf(fid,'Retired free parameters: sigma_geo, omega_r, omega_g, alpha, ');
    fprintf(fid,'g_force, g_bg, omega_bg, 1%% plateau, q_SE, c_tail.\n');
end
end


function write_scalar_cv_table_core(C,name,fileName)

if isfield(C,'grid')
    x=C.grid(:);
elseif isfield(C,'values')
    x=C.values(:);
else
    % Preserve the selected value even if the underlying helper stores
    % candidate curves under a version-specific field.
    x=C.value;
end

if isfield(C,'meanMSE')
    mse=C.meanMSE(:);
elseif isfield(C,'score')
    mse=C.score(:);
elseif isfield(C,'mse')
    mse=C.mse(:);
else
    mse=nan(size(x));
end

if numel(mse)~=numel(x)
    mse=nan(size(x));
end

Selected=(x==C.value);

T=table(x,mse,Selected, ...
    'VariableNames',{name,'CV_MSE','Selected'});
writetable(T,fileName);
end


function write_core_summary( ...
    outDir,selectedIndex,G,obs,cvTPS,cvIso,cvFault,stopCV,stopFinal, ...
    structStop,rangeAudit,meshU,meshAF,T,cfg)

fid=fopen(fullfile(outDir,'CORE_SUMMARY.txt'),'w');
if fid<0, return; end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2\n');
fprintf(fid,'========================================\n\n');

fprintf(fid,'INPUT\n');
fprintf(fid,'-----\n');
fprintf(fid,'interpreted fault polygon = %d\n',selectedIndex);
fprintf(fid,'fault length              = %.6f m\n',G.uMax-G.uMin);
fprintf(fid,'sparse controls           = %d\n',numel(obs.z));
fprintf(fid,'control side counts       = %d / %d\n\n', ...
    nnz(fault_phi(obs.uv,G)<0),nnz(fault_phi(obs.uv,G)>=0));

fprintf(fid,'PARAMETER PROVENANCE\n');
fprintf(fid,'--------------------\n');
fprintf(fid,'sigma_Gamma               = %.9g m (fault half-width95)\n',cfg.faultSigmaMin);
fprintf(fid,'epsilon_min               = %.9g (joint sparse spatial CV)\n',cvFault.epsValue);
fprintf(fid,'FAULT-FEM c0              = %.9g (joint sparse spatial CV)\n',cvFault.value);
fprintf(fid,'ISO-FEM c0                = %.9g (one-SE sparse spatial CV)\n',cvIso.value);
fprintf(fid,'TPS lambda                = %.9g (one-SE sparse spatial CV)\n',cvTPS.value);
fprintf(fid,'Dorfler theta             = %.9g (single fixed AFEM parameter)\n\n',cfg.afemDoerflerTheta);

fprintf(fid,'PREDICTIVE--STRUCTURAL STOPPING\n');
fprintf(fid,'-------------------------------\n');
fprintf(fid,'candidate budgets         = %s\n',mat2str(cfg.nodeBudgets));
fprintf(fid,'global one-SE threshold   = %.9g\n',stopCV.globalThreshold);
fprintf(fid,'fault one-SE threshold    = %.9g\n',stopCV.faultThreshold);
fprintf(fid,'predictive certified      = %d\n',stopCV.predictiveCertified);
fprintf(fid,'predictive selected       = %d\n',stopCV.selectedBudget);
fprintf(fid,'fine internal reference   = %d nodes\n',structStop.fineReferenceBudget);
fprintf(fid,'field variability tau     = %.9g\n',structStop.fieldThreshold);
fprintf(fid,'gradient variability tau  = %.9g\n',structStop.gradThreshold);
fprintf(fid,'final selected budget     = %d\n',stopFinal.selectedBudget);
fprintf(fid,'joint stop certified      = %d\n',structStop.certified);
fprintf(fid,'raw compatibility best at boundary = %d\n',rangeAudit.RawBestAtBoundary(1));
fprintf(fid,'candidates below 250 nodes          = %d\n\n', ...
    rangeAudit.NCandidatesBelow250(1));

fprintf(fid,'FINAL DISCRETIZATION\n');
fprintf(fid,'--------------------\n');
fprintf(fid,'matched uniform nodes     = %d\n',size(meshU.P,1));
fprintf(fid,'matched uniform triangles = %d\n',size(meshU.T,1));
fprintf(fid,'adaptive nodes            = %d\n',size(meshAF.P,1));
fprintf(fid,'adaptive triangles        = %d\n\n',size(meshAF.T,1));

fprintf(fid,'METHODS\n');
fprintf(fid,'-------\n');
for i=1:height(T)
    fprintf(fid,['%-12s nodes=%g | RMSE all=%.6f | fault=%.6f | ', ...
        'bg=%.6f | Jump0MAE=%.6f | DataRMSE=%.6f\n'], ...
        T.Method{i},T.Nodes(i),T.RMSE_all(i),T.RMSE_fault(i), ...
        T.RMSE_bg(i),T.Jump0MAE(i),T.DataRMSE(i));
end

fprintf(fid,'\nINTERPRETATION\n');
fprintf(fid,'--------------\n');
fprintf(fid,['Dense C11 interpreted-reference values are retrospective evaluation ', ...
    'only.  Regularization calibration, adaptive marking and stopping use ', ...
    'only sparse controls and interpreted fault geometry.\n']);
fprintf(fid,['Adaptive marking is residual Dörfler UNION a geometry-derived ', ...
    'one-sigma fault set; no residual/geology mixing weight is used.\n']);
fprintf(fid,['The residual indicator is used for refinement ranking and is not ', ...
    'claimed as a theorem-level posterior error estimator.\n']);
end


function write_v4_paper_exports(outDir,T,meshU,meshA,solA,obs,G,cvFault,Sstop,histA,cfg)
% Compact parameter-reduced paper-facing exports.

iU=find(strcmp(T.Method,'FAULT-FEM'),1);
iA=find(strcmp(T.Method,'FAULT-AFEM'),1);
if isempty(iU) || isempty(iA), return; end

FaultGainPct=100*(T.RMSE_fault(iU)-T.RMSE_fault(iA))/T.RMSE_fault(iU);
GlobalGainPct=100*(T.RMSE_all(iU)-T.RMSE_all(iA))/T.RMSE_all(iU);
BackgroundGainPct=100*(T.RMSE_bg(iU)-T.RMSE_bg(iA))/T.RMSE_bg(iU);
JumpGainPct=100*(T.Jump0MAE(iU)-T.Jump0MAE(iA))/T.Jump0MAE(iU);

UniformNodes=size(meshU.P,1);
AdaptiveNodes=size(meshA.P,1);
UniformTriangles=size(meshU.T,1);
AdaptiveTriangles=size(meshA.T,1);
SelectedBudget=Sstop.selectedBudget;
StopCertified=Sstop.certified;
SigmaGamma=cfg.faultSigmaMin;
EpsilonMin=cfg.faultEpsMin;
C0Fault=cvFault.value;

Adv=table(FaultGainPct,GlobalGainPct,BackgroundGainPct,JumpGainPct, ...
    UniformNodes,AdaptiveNodes,UniformTriangles,AdaptiveTriangles, ...
    SelectedBudget,StopCertified,SigmaGamma,EpsilonMin,C0Fault);
writetable(Adv,fullfile(outDir,'PARAMRED_V2_ADAPTIVE_ADVANTAGE.csv'));

% Indicator-component audit on the final selected mesh.
H=build_interp_matrix(meshA,obs.uv);
[~,parts]=afem_hybrid_indicator(meshA,solA.U,obs,H,G,cvFault.value,cfg);
SEdge=sum(parts.edge2);
SCell=sum(parts.cell2);
SData=sum(parts.data2);
STotal=max(SEdge+SCell+SData,eps);
Indicator=table(SEdge,SCell,SData,SEdge/STotal,SCell/STotal,SData/STotal, ...
    'VariableNames',{'EdgeEnergy','CellEnergy','DataEnergy', ...
    'EdgeFraction','CellFraction','DataFraction'});
writetable(Indicator,fullfile(outDir,'PARAMRED_V2_INDICATOR_COMPONENTS.csv'));

% Geometry audit retained because geometry itself is an input to the method.
gm=mesh_triangle_geometry(meshA);
GA=fault_geometry_legacy_audit(gm.centroid,G);
Geom=table(GA.n,GA.rms,GA.mae,GA.p95,GA.maxAbs, ...
    'VariableNames',{'N','RMS_DistanceDifference','MAE_DistanceDifference', ...
    'P95AbsDifference','MaxAbsDifference'});
writetable(Geom,fullfile(outDir,'PARAMRED_V2_EXACT_GEOMETRY_AUDIT.csv'));

% C11 surface nodes for downstream paper figures.
XY=local_to_global(meshA.P,G);
triH=mesh_triangle_geometry(meshA);
nodeHSum=accumarray(meshA.T(:),repmat(triH.hT,3,1),[size(meshA.P,1),1],@sum,0);
nodeHCnt=accumarray(meshA.T(:),ones(numel(meshA.T),1),[size(meshA.P,1),1],@sum,0);
nodeH=nodeHSum./max(nodeHCnt,1);
NodeID=(1:size(meshA.P,1)).';
SurfNodes=table(NodeID,XY(:,1),XY(:,2),solA.U,nodeH, ...
    'VariableNames',{'NodeID','X','Y','TVD','LocalMeshScale'});
writetable(SurfNodes,fullfile(outDir,'PARAMRED_V2_C11_SURFACE_NODES.csv'));

% Small parameter-reduced audit figure.
f=figure('Color','w','Units','pixels','Position',[120 120 1280 520]);
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');
ax=nexttile(tl,1);
bar(ax,[FaultGainPct,GlobalGainPct,BackgroundGainPct,JumpGainPct]);
yline(ax,0,'k-');
set(ax,'XTick',1:4,'XTickLabel',{'fault RMSE','global RMSE','background RMSE','jump MAE'});
ylabel(ax,'change vs matched FAULT-FEM (%)');
title(ax,'Adaptive accuracy comparison');
grid(ax,'on');

ax=nexttile(tl,2);
triplot(meshA.T,meshA.P(:,1),meshA.P(:,2),'Parent',ax,'LineWidth',0.35);
hold(ax,'on');
plot(ax,G.uc,G.vc,'r-','LineWidth',1.8);
axis(ax,'equal'); axis(ax,'tight');
xlabel(ax,'u (m)'); ylabel(ax,'v (m)');
title(ax,sprintf('Selected adaptive mesh: %d nodes',AdaptiveNodes));
title(tl,'Parameter-reduced V2 C11 audit');
save_figure(f,fullfile(outDir,'FIG_PARAMRED_V2_ADAPTIVE_AUDIT.png'),cfg);

fid=fopen(fullfile(outDir,'PARAMRED_V2_LATEX_MACROS.tex'),'w');
if fid>=0
    c=onCleanup(@() fclose(fid)); %#ok<NASGU>
    fprintf(fid,'%% Auto-generated by REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2\n');
    fprintf(fid,'\\newcommand{\\PRVTwoFaultGain}{%.2f\\%%}\n',FaultGainPct);
    fprintf(fid,'\\newcommand{\\PRVTwoGlobalGain}{%.2f\\%%}\n',GlobalGainPct);
    fprintf(fid,'\\newcommand{\\PRVTwoBackgroundGain}{%.2f\\%%}\n',BackgroundGainPct);
    fprintf(fid,'\\newcommand{\\PRVTwoJumpGain}{%.2f\\%%}\n',JumpGainPct);
    fprintf(fid,'\\newcommand{\\PRVTwoSelectedBudget}{%d}\n',SelectedBudget);
    fprintf(fid,'\\newcommand{\\PRVTwoAdaptiveNodes}{%d}\n',AdaptiveNodes);
    fprintf(fid,'\\newcommand{\\PRVTwoSigmaGamma}{%.3f}\n',SigmaGamma);
    fprintf(fid,'\\newcommand{\\PRVTwoEpsilonMin}{%.5f}\n',EpsilonMin);
end

if ~isempty(histA)
    writetable(struct2table(histA),fullfile(outDir,'PARAMRED_V2_AFEM_HISTORY.csv'));
end
end


function validate_structstop_config_core_v3(cfg)
b=cfg.nodeBudgets(:);

if isempty(b) || any(~isfinite(b))
    error('cfg.nodeBudgets must be finite and nonempty.');
end

if any(diff(b)<=0)
    error('cfg.nodeBudgets must be strictly increasing because AFEM meshes are nested.');
end

if numel(unique(b))~=numel(b)
    error('cfg.nodeBudgets contains duplicate values.');
end

if min(b)<=cfg.afemInitialNodeBudget
    error(['Smallest stopping budget (%d) must exceed ', ...
        'cfg.afemInitialNodeBudget (%d).'], ...
        min(b),cfg.afemInitialNodeBudget);
end

if numel(b)<3
    error('Predictive--structural stopping requires at least 3 budgets.');
end

if cfg.structProbeSpacing<=0 || cfg.structFaultBand<=0
    error('Structural probe spacing/band must be positive.');
end

if cfg.structMinProbePoints<20
    error('cfg.structMinProbePoints is unrealistically small.');
end
end


function cfg=default_config()

% -------------------------------------------------------------------------
% Files
% -------------------------------------------------------------------------
cfg.horizonFile='TVD_C11.dat';
cfg.polygonFile='Dingji_t11_plg.dat';
cfg.faultStickFile='ExportFaultStick.dat';

% Automatic by default. Set e.g. 44 to reproduce a chosen polygon.
cfg.forcePolygonIndex=10;

% build_fault_geometry requires this field during candidate processing.
cfg.faultIndex=-1;

% -------------------------------------------------------------------------
% Stage A: benchmark-suitability screening
% -------------------------------------------------------------------------
cfg.screenMinPolygonPoints=10;
cfg.screenMinAlongLength=300;       % m
cfg.screenNeighborRadius=250;       % m, layer-specific polygon complexity
cfg.screenTopGeometry=24;           % expensive horizon audit only for these
cfg.screenOutputTop=15;

cfg.screenAlongPad=100;             % m
cfg.screenCrossExtent=320;          % m around centerline
cfg.screenSideMinDistance=45;       % m, exclude immediate interpreted line
cfg.screenSideMaxDistance=260;      % m
cfg.screenMinSidePoints=180;
cfg.screenPolyDegree=2;
cfg.screenMinInteriorFraction=0.10;

% Final screening score weights.
% They sum to one and only rank benchmark suitability.
cfg.wLength=0.10;
cfg.wIsolation=0.19;
cfg.wNeighbor=0.18;
cfg.wLinearity=0.04;
cfg.wSideFit=0.27;
cfg.wJump=0.17;
cfg.wCoverage=0.05;

% -------------------------------------------------------------------------
% Fault centerline extraction
% -------------------------------------------------------------------------
cfg.centerlineBins=28;
cfg.centerlineSmooth=3;

% -------------------------------------------------------------------------
% Main selected local window
% -------------------------------------------------------------------------
cfg.mainMarginAlong=160;
cfg.mainMarginCross=360;
cfg.minLocalReferencePoints=3000;

% -------------------------------------------------------------------------
% Sparse observations
% -------------------------------------------------------------------------
cfg.mainN=80;
cfg.mainSeed=20260815;
cfg.maxSamplingCandidates=18000;
cfg.sampleFaultGuard=30;
cfg.minControlsPerSide=12;
cfg.obsNoiseStd=0;

% -------------------------------------------------------------------------
% FEM
% -------------------------------------------------------------------------
cfg.femSpacing=30;

% Parameter-reduced V2:
% epsilon_min is selected jointly with c0 by spatial CV.
% sigma_Gamma is overwritten after fault geometry is built using the
% interpreted fault's robust half-width (G.halfWidth95).
cfg.faultEpsMin=nan;                  % selected jointly with c0 by spatial CV
cfg.faultEpsGrid=[0.01 0.03 0.06 0.10 0.20];
cfg.faultSigmaMin=nan;                % geometry-derived after G is built
cfg.faultTipTaper=nan;                % tied to sigma_Gamma

% -------------------------------------------------------------------------
% Evaluation zones
% -------------------------------------------------------------------------
cfg.evalFaultBand=nan;                % 2*sigma_Gamma
cfg.evalBackgroundDistance=nan;       % 4*sigma_Gamma
cfg.evalGateMin=exp(-0.5);            % one characteristic tip-decay length

% -------------------------------------------------------------------------
% Spatial CV
% -------------------------------------------------------------------------
cfg.cvRepeats=5;
cfg.cvFolds=5;
cfg.cvPlateau=nan;  % retired: scalar tuning uses one-SE rule

% Global and block TPS.
cfg.tpsLambdaGrid=logspace(-6,2,13);

% Fault-continuous FEM.
cfg.femC0Grid=logspace(-4,3,13);

% OLD GJR.
cfg.gjrBackgroundDegrees=1:4;
cfg.gjrJumpDegrees=0:1;
cfg.gjrCVRepeats=5;
cfg.gjrCVFolds=5;

% Fault-block polynomial.
cfg.fbPolyDegrees=1:4;
cfg.fbPolyCVRepeats=5;
cfg.fbPolyCVFolds=5;

% -------------------------------------------------------------------------
% Corrected interface-jump diagnostic
% -------------------------------------------------------------------------
% For every along-fault sample, evaluate both sides at several normal
% distances, fit a one-sided local linear trend, and extrapolate each side
% to the interface.  The difference of the two intercepts is J0(u).
cfg.jumpNSamples=35;
cfg.jumpTipFraction=0.15;
cfg.jumpFitMinOffset=35;
cfg.jumpFitPolygonClearance=18;
cfg.jumpFitDistanceAdd=[0 35 70 110];
cfg.jumpLocalDegree=1;

% Legacy aliases retained so every helper path is configuration-complete.
% They are consistent with the corrected interface-jump settings above.
cfg.jumpOffsetMin=cfg.jumpFitMinOffset;
cfg.jumpOffsetExtra=cfg.jumpFitPolygonClearance;


% -------------------------------------------------------------------------
% V1 engineering AFEM / matched-budget experiment
% -------------------------------------------------------------------------
cfg.nodeBudgets=[120 135 150 175 200 225 250 300 400 550];

% V2 stopping-range validation:
% the original formal run started at 250 nodes.  We now add four coarser
% candidates while preserving 250/300/400 exactly for direct comparison.
% The adaptive initial mesh is lowered only to ensure that the 150-node
% candidate is reached by actual refinement rather than being the initial
% mesh itself.
% mainNodeBudget is no longer prescribed; it is populated from CV stopping.
cfg.mainNodeBudget=[];
cfg.cvNodeBudget=800;

% Legacy V2 stripe-CV settings are retained for audit only.
cfg.afemStopCVRepeats=3;
cfg.afemStopCVFolds=4;
cfg.afemStopPlateau=0.01;
cfg.afemStopMaxAdaptPerBudget=14;

% -------------------------------------------------------------------------
% V3 interpolation-oriented buffered checkerboard CV
% -------------------------------------------------------------------------
cfg.interpCVGrid=[4 4];

% Requested physical exclusion radius between outer/inner validation points
% and training controls. If too many controls are removed, the code falls
% back through this schedule while recording the actually used buffer.
cfg.interpCVBuffer=nan;                 % derived after sparse controls are built
cfg.interpCVBufferSchedule=[];           % [derived buffer, 0]

cfg.interpCVOuterRepeats=3;
cfg.interpCVOuterFolds=4;

% Nested smoothing-parameter selection inside each outer training split.
cfg.interpCVInnerRepeats=2;
cfg.interpCVInnerFolds=4;

% Full-data tuning of TPS / c0 uses the same interpolation-oriented split.
cfg.mainTuneCVRepeats=3;
cfg.mainTuneCVFolds=4;

% Split viability.
cfg.interpCVMinTrain=30;
cfg.interpCVMinTest=4;
cfg.interpCVMinTrainPerSide=7;

% Formal one-SE stopping; near-minimum plateaus remain sensitivity audits.
cfg.interpCVUseOneSE=true;
cfg.interpCVPlateauAudit=[0.005 0.010 0.020];

% Limit adaptive work inside nested outer CV.
cfg.interpCVMaxAdaptPerBudget=14;

% -------------------------------------------------------------------------
% Parameter-reduced predictive CV.
% -------------------------------------------------------------------------
% Global and fault-weighted prediction risks are treated as two separate
% one-SE constraints.  No alpha mixing coefficient is used.
cfg.engCVAlpha=nan;                   % legacy field, not used by V2
cfg.engCVAlphaAudit=[];

% Fault-risk weighting uses exactly the same geometry-derived sigma_Gamma
% as the reconstruction tensor.  The following legacy fields are populated
% only for compatibility with old output helpers.
cfg.engCVFaultSigmaMin=nan;
cfg.engCVFaultSigmaFactor=1.0;
cfg.engCVFaultSigmaExpand=1;
cfg.engCVFaultGateFloor=0;
cfg.engCVMinFaultEffectiveN=0;
cfg.engCVPlateauAudit=[];


% Initial nested adaptive mesh.
cfg.afemInitialNodeBudget=90;

% ---------------------------------------------------------------------
% Parameter-reduced predictive--structural stopping
% ---------------------------------------------------------------------
% Predictive admissibility is the intersection of independent one-SE sets
% for global and fault-weighted spatial-CV risks.
cfg.structPredictiveSEFactor=nan;     % retired
cfg.structProbeSpacing=12;            % numerical probe sampling only
cfg.structFaultBand=nan;              % 2*sigma_Gamma
cfg.structGateMin=exp(-0.5);
cfg.structMinProbePoints=80;

% Structural tolerances are estimated from spatial-CV withholding
% variability on the finest internal mesh; no tail multiplier is used.
cfg.structTailFactor=nan;             % retired
cfg.structPredictiveSEAudit=[];
cfg.structTailFactorAudit=[];

cfg.afemMaxAdaptPerBudget=18;
cfg.afemHMin=0;                     % node budget, not h_min, controls depth

% Parameter-reduced marking:
%   M = M_res(Dorfler) union M_Gamma(one-sigma fault band).
% No residual/geology mixing weights are used.
cfg.afemResidualWeight=nan;          % retired
cfg.afemGeoWeight=nan;               % retired
cfg.afemGeoSigmaMin=nan;             % tied to sigma_Gamma
cfg.afemGeoSigmaFactor=1.0;
cfg.afemDoerflerTheta=0.50;          % standard algorithmic choice
cfg.afemGeoForceThreshold=exp(-0.5); % one-sigma level; compatibility only
cfg.afemGeoTargetH=inf;              % retired

% Variable-D cell residual is retained.
cfg.afemCellResidualWeight=1.0;

% Background-priority heuristics are retired in parameter-reduced V2.
cfg.afemBackgroundSafeEnable=false;
cfg.afemBackgroundGeoMax=0;
cfg.afemBackgroundMaxH=inf;
cfg.afemBackgroundPriority=0;

cfg.structUseThreeLevelTail=false;    % retired

% Budget comparison plots.
cfg.afemPlotTPSReference=true;

% -------------------------------------------------------------------------
% Figures
% -------------------------------------------------------------------------
cfg.figureDPI=180;
cfg.visNu=300;
cfg.visNv=190;
end



function cfg=apply_profile_parameter_reduced_v2(cfg)
switch lower(cfg.profile)
    case 'quick'
        cfg.mainTuneCVRepeats=1;
        cfg.mainTuneCVFolds=4;
        cfg.interpCVOuterRepeats=1;
        cfg.interpCVOuterFolds=4;
        cfg.interpCVInnerRepeats=1;
        cfg.interpCVInnerFolds=4;
        cfg.femC0Grid=logspace(-4,2,7);
        cfg.faultEpsGrid=[0.01 0.03 0.10 0.20];
        cfg.nodeBudgets=[120 150 200 300 550];
        cfg.afemMaxAdaptPerBudget=12;
    case 'paper'
        % Keep the full paper profile from default_config.
    otherwise
        error('Unknown profile: %s. Use ''quick'' or ''paper''.',cfg.profile);
end
end


function cfg=derive_parameter_reduced_geometry_scales(cfg,G)
sigma=double(G.halfWidth95);
if ~(isfinite(sigma) && sigma>0)
    error('Cannot derive sigma_Gamma from interpreted fault geometry.');
end

cfg.faultSigmaMin=sigma;
cfg.faultTipTaper=sigma;

cfg.evalFaultBand=2*sigma;
cfg.evalBackgroundDistance=4*sigma;
cfg.structFaultBand=2*sigma;

% Legacy compatibility fields; the V2 algorithm does not tune or mix them.
cfg.afemGeoSigmaMin=sigma;
cfg.engCVFaultSigmaMin=sigma;
end


function dmed=median_control_nn_spacing_paramred_v2(XY)
XY=double(XY);
n=size(XY,1);
if n<2, error('At least two sparse controls are required.'); end
dmin=inf(n,1);
for i=1:n
    d=sqrt(sum((XY-XY(i,:)).^2,2));
    d(i)=inf;
    dmin(i)=min(d);
end
q=dmin(isfinite(dmin) & dmin>0);
if isempty(q), error('Unable to derive sparse-control spacing.'); end
dmed=median(q);
end


function validate_required_files(cfg)
req={cfg.horizonFile,cfg.polygonFile};
for i=1:numel(req)
    f=fullfile(cfg.dataDir,req{i});
    if ~exist(f,'file')
        fprintf(2,'\nRequired file is missing:\n  %s\n\n',f);
        fprintf(2,'Required directory layout:\n');
        fprintf(2,'  REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2.m\n');
        fprintf(2,'  data_C11/%s\n',cfg.horizonFile);
        fprintf(2,'  data_C11/%s\n',cfg.polygonFile);
        fprintf(2,'  data_C11/%s   (optional)\n\n',cfg.faultStickFile);
        error('Required data file not found.');
    end
end
end


function D=read_c11_horizon(fileName)
fid=fopen(fileName,'r');
if fid<0, error('Cannot open horizon file: %s',fileName); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

header=fgetl(fid); %#ok<NASGU>
C=textscan(fid,'%f%f%f%f%f', ...
    'MultipleDelimsAsOne',true, ...
    'Delimiter',' \t', ...
    'CollectOutput',true);
A=C{1};
if size(A,2)~=5
    error('Unexpected TVD_C11 format. Expected five numeric columns.');
end

good=all(isfinite(A),2);
A=A(good,:);

D=struct();
D.inline=A(:,1);
D.cdp=A(:,2);
D.xy=A(:,3:4);
D.z=A(:,5);
end


function P=read_fault_polygon(fileName)
fid=fopen(fileName,'r');
if fid<0, error('Cannot open polygon file: %s',fileName); end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

C=textscan(fid,'%f%f%f%f%f', ...
    'CommentStyle','#', ...
    'MultipleDelimsAsOne',true, ...
    'Delimiter',' \t', ...
    'CollectOutput',true);
A=C{1};
if size(A,2)~=5
    error('Unexpected fault polygon format. Expected X Y Z No Index.');
end
good=all(isfinite(A),2);
A=A(good,:);

P=struct();
P.xy=A(:,1:2);
P.z=A(:,3);
P.no=A(:,4);
P.index=round(A(:,5));
end


% =========================================================================
% FAULT GEOMETRY FROM INTERPRETED POLYGON ONLY
% =========================================================================
function G=build_fault_geometry(xy,cfg)
c=mean(xy,1);
X=xy-c;

C=(X.'*X)/max(size(X,1)-1,1);
[V,D]=eig(C);
[~,ord]=sort(diag(D),'descend');
V=V(:,ord);

t=V(:,1).';
n=V(:,2).';

% Deterministic tangent orientation.
if t(1)<0
    t=-t; n=-n;
end

u=X*t.';
v=X*n.';

uMin=min(u);
uMax=max(u);

edges=linspace(uMin,uMax,cfg.centerlineBins+1);
uc=[];
vc=[];
hw=[];

for b=1:cfg.centerlineBins
    if b<cfg.centerlineBins
        m=u>=edges(b) & u<edges(b+1);
    else
        m=u>=edges(b) & u<=edges(b+1);
    end
    if nnz(m)>=2
        ub=median(u(m));
        vb=v(m);
        vlo=percentile_local(vb,10);
        vhi=percentile_local(vb,90);
        uc(end+1,1)=ub; %#ok<AGROW>
        vc(end+1,1)=0.5*(vlo+vhi); %#ok<AGROW>
        hw(end+1,1)=0.5*(vhi-vlo); %#ok<AGROW>
    end
end

if numel(uc)<6
    error('Too few centerline bins from polygon Index=%d.',cfg.faultIndex);
end

[uc,ord]=sort(uc);
vc=vc(ord);
hw=hw(ord);

if cfg.centerlineSmooth>1
    vc=movmean(vc,cfg.centerlineSmooth,'Endpoints','shrink');
    hw=movmean(hw,cfg.centerlineSmooth,'Endpoints','shrink');
end

if uc(1)>uMin
    vc0=interp1(uc,vc,uMin,'linear','extrap');
    hw0=interp1(uc,hw,uMin,'linear','extrap');
    uc=[uMin;uc];
    vc=[vc0;vc];
    hw=[hw0;hw];
end
if uc(end)<uMax
    vc1=interp1(uc,vc,uMax,'linear','extrap');
    hw1=interp1(uc,hw,uMax,'linear','extrap');
    uc=[uc;uMax];
    vc=[vc;vc1];
    hw=[hw;hw1];
end

dvdu=gradient(vc,uc);

% Piecewise-linear centerline segments.  All V4 geometry-dependent paths
% use nearest-segment projection instead of the legacy vertical-distance
% approximation v-v_c(u).
segA=[uc(1:end-1),vc(1:end-1)];
segB=[uc(2:end),vc(2:end)];
segV=segB-segA;
segL=sqrt(sum(segV.^2,2));
segL=max(segL,eps);
segT=segV./segL;
segN=[-segT(:,2),segT(:,1)];

G=struct();
G.c=c;
G.t=t;
G.n=n;
G.uMin=uMin;
G.uMax=uMax;
G.uc=uc;
G.vc=vc;
G.dvdu=dvdu;
G.halfWidth=max(median(hw(isfinite(hw))),1);
G.halfWidth95=percentile_local(abs(v-interp1(uc,vc,u,'linear','extrap')),95);
G.polyUV=[u,v];
G.segA=segA;
G.segB=segB;
G.segV=segV;
G.segL=segL;
G.segT=segT;
G.segN=segN;
end


function uv=global_to_local(xy,G)
X=xy-G.c;
uv=[X*G.t.', X*G.n.'];
end


function xy=local_to_global(uv,G)
xy=G.c + uv(:,1)*G.t + uv(:,2)*G.n;
end


function [phi,dist,tt,nn,proj,segIdx]=fault_project_exact(uv,G)
% Exact nearest-point projection to the piecewise-linear interpreted
% centerline in local (u,v) coordinates.  The signed distance uses the
% consistently oriented segment normal.
uv=double(uv);
nq=size(uv,1);
ns=size(G.segA,1);

bestD2=inf(nq,1);
phi=zeros(nq,1);
proj=zeros(nq,2);
segIdx=ones(nq,1);
tt=zeros(nq,2);
nn=zeros(nq,2);

for j=1:ns
    a=G.segA(j,:);
    v=G.segV(j,:);
    L2=max(sum(v.^2),eps);
    w=uv-a;
    tau=(w*v.')/L2;
    tau=max(0,min(1,tau));
    pj=a+tau.*v;
    d=uv-pj;
    d2=sum(d.^2,2);
    upd=d2<bestD2;
    if any(upd)
        bestD2(upd)=d2(upd);
        proj(upd,:)=pj(upd,:);
        segIdx(upd)=j;
        tt(upd,:)=repmat(G.segT(j,:),nnz(upd),1);
        nn(upd,:)=repmat(G.segN(j,:),nnz(upd),1);
        phi(upd)=d(upd,:)*G.segN(j,:).';
    end
end

dist=sqrt(max(bestD2,0));
end


function phi=fault_phi(uv,G)
[phi,~,~,~,~,~]=fault_project_exact(uv,G);
end


function g=fault_gate(u,G,cfg)
tau=max(cfg.faultTipTaper,eps);
g=0.5*(tanh((u-G.uMin)/tau)-tanh((u-G.uMax)/tau));
g=max(min(g,1),0);
end


function [vc,slope]=fault_center_and_slope(u,G)
% Retained only for plotting/profile parametrization.  Numerical tensor,
% AFEM geometry, CV weighting and structural probes use exact projection.
vc=interp1(G.uc,G.vc,u,'linear','extrap');
slope=interp1(G.uc,G.dvdu,u,'linear','extrap');
end


function A=fault_geometry_legacy_audit(q,G)
% Quantify the difference between V4 exact signed distance and the old
% vertical-distance approximation.  This is retrospective numerical audit,
% not model tuning.
phiExact=fault_phi(q,G);
vc=interp1(G.uc,G.vc,q(:,1),'linear','extrap');
phiLegacy=q(:,2)-vc;
d=phiExact-phiLegacy;
A=struct();
A.n=numel(d);
A.rms=sqrt(mean(d.^2));
A.mae=mean(abs(d));
A.maxAbs=max(abs(d));
A.p95=percentile_local(abs(d),95);
end


% =========================================================================
% OPTIONAL 3-D FAULT-STICK AUDIT
% =========================================================================
function A=audit_fault_sticks_optional(fileName,G,uLo,uHi,vLo,vHi)
A=struct();
A.available=false;
A.nLocal=0;
A.topNames='';
A.hasF151a=false;

if ~exist(fileName,'file')
    fprintf('\n[Fault-stick audit] optional file not supplied; skipping.\n');
    return;
end

fprintf('\n[Fault-stick audit] reading optional 3-D fault sticks ...\n');

fid=fopen(fileName,'r');
if fid<0
    fprintf('  WARNING: failed to open %s\n',fileName);
    return;
end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

C=textscan(fid,'%f%f%f%f%s%f%f', ...
    'CommentStyle','#', ...
    'MultipleDelimsAsOne',true, ...
    'Delimiter',' \t');

if isempty(C{1})
    fprintf('  WARNING: no fault-stick numeric rows were read.\n');
    return;
end

xy=[C{1},C{2}];
names=C{5};
uv=global_to_local(xy,G);

m=uv(:,1)>=uLo & uv(:,1)<=uHi & uv(:,2)>=vLo & uv(:,2)<=vHi;
namesL=names(m);

A.available=true;
A.nLocal=nnz(m);
A.hasF151a=any(strcmp(namesL,'F151a'));

fprintf('  local 3-D fault-stick points = %d\n',A.nLocal);
fprintf('  F151a present in local window = %d\n',A.hasF151a);

if ~isempty(namesL)
    [un,~,ic]=unique(namesL);
    cnt=accumarray(ic,1);
    [cnt,ord]=sort(cnt,'descend');
    un=un(ord);
    nshow=min(6,numel(un));
    txt='';
    fprintf('  dominant local fault names:');
    for i=1:nshow
        fprintf(' %s(%d)',un{i},cnt(i));
        txt=[txt sprintf('%s(%d) ',un{i},cnt(i))]; %#ok<AGROW>
    end
    fprintf('\n');
    A.topNames=strtrim(txt);
end
end


% =========================================================================
% REFERENCE INTERPOLANTS
% =========================================================================
function R=build_side_reference_interpolants(uv,z,G,cfg)
phi=fault_phi(uv,G);
guard=max(10,0.15*G.halfWidth);

neg=phi<=-guard;
pos=phi>= guard;

if nnz(neg)<100 || nnz(pos)<100
    error('Insufficient reference points on one side of fault.');
end

R.neg=scatteredInterpolant(uv(neg,1),uv(neg,2),z(neg), ...
    'natural','nearest');
R.pos=scatteredInterpolant(uv(pos,1),uv(pos,2),z(pos), ...
    'natural','nearest');
R.allNearest=scatteredInterpolant(uv(:,1),uv(:,2),z, ...
    'nearest','nearest');
R.guard=guard;
R.cfg=cfg;
end


function z=reference_predict(R,uv,G)
phi=fault_phi(uv,G);
z=zeros(size(phi));
neg=phi<0;
z(neg)=R.neg(uv(neg,1),uv(neg,2));
z(~neg)=R.pos(uv(~neg,1),uv(~neg,2));
end


% =========================================================================
% SPARSE OBSERVATION SAMPLING
% =========================================================================
function idx=spatial_farthest_sample(uv,phi,N,seed,cfg)
n=size(uv,1);
if N>n, error('Requested N=%d > available reference points=%d.',N,n); end

rng(seed,'twister');

% Candidate reduction for speed while preserving the full region.
if n>cfg.maxSamplingCandidates
    cand=randperm(n,cfg.maxSamplingCandidates).';
else
    cand=(1:n).';
end

Q=uv(cand,:);

% Normalize geometry so u and v have comparable sampling influence.
lo=min(Q,[],1);
hi=max(Q,[],1);
S=max(hi-lo,eps);
Qn=(Q-lo)./S;

selectedLocal=[];

% Force at least one initial control on each side, away from the interface.
neg=find(phi(cand)<-cfg.sampleFaultGuard);
pos=find(phi(cand)> cfg.sampleFaultGuard);

if ~isempty(neg)
    selectedLocal(end+1)=neg(randi(numel(neg))); %#ok<AGROW>
end
if ~isempty(pos)
    jp=pos(randi(numel(pos)));
    if ~ismember(jp,selectedLocal)
        selectedLocal(end+1)=jp; %#ok<AGROW>
    end
end
if isempty(selectedLocal)
    selectedLocal=randi(numel(cand));
end

dmin=inf(numel(cand),1);
for j=selectedLocal
    d=sum((Qn-Qn(j,:)).^2,2);
    dmin=min(dmin,d);
end
dmin(selectedLocal)=-inf;

while numel(selectedLocal)<N
    [~,j]=max(dmin);
    selectedLocal(end+1)=j; %#ok<AGROW>
    d=sum((Qn-Qn(j,:)).^2,2);
    dmin=min(dmin,d);
    dmin(selectedLocal)=-inf;
end

idx=cand(selectedLocal(:));
end


function O=make_obs(uv,z,idx,cfg)
O=struct();
O.uv=uv(idx,:);
O.z=z(idx);
if cfg.obsNoiseStd>0
    O.z=O.z+cfg.obsNoiseStd*randn(size(O.z));
end
O.w=ones(numel(idx),1);
O.idx=idx(:);
end



% =========================================================================
% V2 BALANCED SPARSE SAMPLING
% =========================================================================
function idx=spatial_farthest_sample_balanced(uv,phi,N,seed,cfg)
% Start from the original global farthest-point design.  If either fault
% block receives too few controls for a stable block model, replace it by
% two independent farthest-point designs with a near-balanced allocation.

idx=spatial_farthest_sample(uv,phi,N,seed,cfg);
nNeg=nnz(phi(idx)<-cfg.sampleFaultGuard);
nPos=nnz(phi(idx)> cfg.sampleFaultGuard);

if nNeg>=cfg.minControlsPerSide && nPos>=cfg.minControlsPerSide
    return;
end

negPool=find(phi<-cfg.sampleFaultGuard);
posPool=find(phi> cfg.sampleFaultGuard);

if numel(negPool)<cfg.minControlsPerSide || numel(posPool)<cfg.minControlsPerSide
    error('Not enough reference points on both sides for balanced sparse sampling.');
end

nNegTarget=floor(N/2);
nPosTarget=N-nNegTarget;

a=farthest_from_pool(uv,negPool,nNegTarget,seed+17,cfg);
b=farthest_from_pool(uv,posPool,nPosTarget,seed+31,cfg);
idx=[a(:);b(:)];
end


function idx=farthest_from_pool(uv,pool,N,seed,cfg)
rng(seed,'twister');

if numel(pool)>cfg.maxSamplingCandidates
    q=pool(randperm(numel(pool),cfg.maxSamplingCandidates));
else
    q=pool(:);
end

Q=uv(q,:);
lo=min(Q,[],1);
hi=max(Q,[],1);
sc=max(hi-lo,eps);
Qn=(Q-lo)./sc;

first=randi(numel(q));
sel=first;
dmin=sum((Qn-Qn(first,:)).^2,2);
dmin(first)=-inf;

while numel(sel)<N
    [~,j]=max(dmin);
    sel(end+1)=j; %#ok<AGROW>
    d=sum((Qn-Qn(j,:)).^2,2);
    dmin=min(dmin,d);
    dmin(sel)=-inf;
end

idx=q(sel(:));
end


% =========================================================================
% STRUCTURED P1 FEM MESH / INTERPOLATION
% =========================================================================
function M=make_rect_mesh(uRange,vRange,h)
uAxis=(floor(uRange(1)/h)*h):h:(ceil(uRange(2)/h)*h);
vAxis=(floor(vRange(1)/h)*h):h:(ceil(vRange(2)/h)*h);

[U,V]=meshgrid(uAxis,vAxis);
P=[U(:),V(:)];

nU=numel(uAxis);
nV=numel(vAxis);
T=zeros(2*(nU-1)*(nV-1),3);
r=0;

for iu=1:nU-1
    for iv=1:nV-1
        n00=iv+(iu-1)*nV;
        n01=n00+1;
        n10=iv+iu*nV;
        n11=n10+1;

        r=r+1; T(r,:)=[n00,n10,n11];
        r=r+1; T(r,:)=[n00,n11,n01];
    end
end

M=struct();
M.P=P;
M.T=T;
M.uAxis=uAxis;
M.vAxis=vAxis;
M.nU=nU;
M.nV=nV;
M.TR=triangulation(T,P);
end


function H=build_interp_matrix(M,q)
tri=pointLocation(M.TR,q);
nq=size(q,1);

rows=[];
cols=[];
vals=[];

good=isfinite(tri);
if any(good)
    bc=cartesianToBarycentric(M.TR,tri(good),q(good,:));
    Tg=M.T(tri(good),:);
    rg=find(good);

    rows=[rows;repelem(rg,3,1)]; %#ok<AGROW>
    cols=[cols;reshape(Tg.',[],1)]; %#ok<AGROW>
    vals=[vals;reshape(bc.',[],1)]; %#ok<AGROW>
end

% Boundary fallback. Structured meshes use axis lookup; locally refined
% meshes use the nearest retained vertex. This path should only affect
% numerical boundary cases because triangulation pointLocation handles the
% interior.
bad=find(~good);
if ~isempty(bad)
    for kk=1:numel(bad)
        i=bad(kk);
        if isfield(M,'uAxis') && isfield(M,'vAxis') && ...
                isfield(M,'nV') && ~isempty(M.uAxis) && ~isempty(M.vAxis)
            [~,iu]=min(abs(M.uAxis-q(i,1)));
            [~,iv]=min(abs(M.vAxis-q(i,2)));
            node=iv+(iu-1)*M.nV;
        else
            d2=sum((M.P-q(i,:)).^2,2);
            [~,node]=min(d2);
        end
        rows(end+1,1)=i; %#ok<AGROW>
        cols(end+1,1)=node; %#ok<AGROW>
        vals(end+1,1)=1; %#ok<AGROW>
    end
end

H=sparse(rows,cols,vals,nq,size(M.P,1));
end


function K=assemble_iso_stiffness(M)
n=size(M.P,1);
I=zeros(9*size(M.T,1),1);
J=I; V=I;
q=0;

for e=1:size(M.T,1)
    nodes=M.T(e,:);
    xy=M.P(nodes,:);
    [B,A]=tri_gradients(xy);
    Ke=A*(B.'*B);

    for a=1:3
        for b=1:3
            q=q+1;
            I(q)=nodes(a);
            J(q)=nodes(b);
            V(q)=Ke(a,b);
        end
    end
end

K=sparse(I,J,V,n,n);
K=0.5*(K+K.');
end


function K=assemble_fault_stiffness(M,G,cfg)
n=size(M.P,1);
I=zeros(9*size(M.T,1),1);
J=I; V=I;
q=0;

sigma=cfg.faultSigmaMin;

for e=1:size(M.T,1)
    nodes=M.T(e,:);
    xy=M.P(nodes,:);
    cen=mean(xy,1);

    [B,A]=tri_gradients(xy);

    [phi,~,tt,nn]=fault_project_exact(cen,G);
    gate=fault_gate(cen(1),G,cfg);

    strength=gate*exp(-0.5*(phi/sigma)^2);
    epsn=1-(1-cfg.faultEpsMin)*strength;

    D=tt.'*tt + epsn*(nn.'*nn);
    Ke=A*(B.'*D*B);

    for a=1:3
        for b=1:3
            q=q+1;
            I(q)=nodes(a);
            J(q)=nodes(b);
            V(q)=Ke(a,b);
        end
    end
end

K=sparse(I,J,V,n,n);
K=0.5*(K+K.');
end


function [B,A]=tri_gradients(xy)
x1=xy(1,1); y1=xy(1,2);
x2=xy(2,1); y2=xy(2,2);
x3=xy(3,1); y3=xy(3,2);

detJ=(x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);
A=abs(detJ)/2;
if A<=eps
    error('Degenerate triangle encountered.');
end

b=[y2-y3; y3-y1; y1-y2]/detJ;
c=[x3-x2; x1-x3; x2-x1]/detJ;
B=[b.';c.'];
end


% =========================================================================
% SPATIAL CV
% =========================================================================
function folds=repeated_spatial_folds(uv,R,K)
n=size(uv,1);
folds=zeros(n,R);
X=uv-mean(uv,1);

for r=1:R
    theta=(r-1)*pi/R;
    s=X(:,1)*cos(theta)+X(:,2)*sin(theta);
    [~,ord]=sort(s);
    edges=round(linspace(0,n,K+1));
    f=zeros(n,1);
    for k=1:K
        ii=(edges(k)+1):edges(k+1);
        if ~isempty(ii), f(ord(ii))=k; end
    end
    folds(:,r)=f;
end
end


function CV=select_fem_c0_cv(Ks,H,obs,cfg)
grid=cfg.femC0Grid(:);
R=cfg.cvRepeats;
K=cfg.cvFolds;
folds=repeated_spatial_folds(obs.uv,R,K);
err=nan(numel(grid),R);

for ig=1:numel(grid)
    c0=grid(ig);

    for r=1:R
        sse=0;
        nt=0;

        for k=1:K
            tr=folds(:,r)~=k;
            te=folds(:,r)==k;
            if nnz(te)==0 || nnz(tr)<5, continue; end

            Htr=H(tr,:);
            Hte=H(te,:);
            ztr=obs.z(tr);

            A=c0*Ks + Htr.'*Htr;
            b=Htr.'*ztr;
            A=0.5*(A+A.');
            ridge=1e-12*max(mean(abs(diag(A))),1);
            A=A+ridge*speye(size(A,1));

            U=A\b;
            e=Hte*U-obs.z(te);
            sse=sse+sum(e.^2);
            nt=nt+numel(e);
        end

        if nt>0, err(ig,r)=sse/nt; end
    end
end

CV=select_plateau_scalar(grid,err,cfg.cvPlateau);
end


function CV=select_tps_lambda_cv(obs,cfg)
grid=cfg.tpsLambdaGrid(:);
R=cfg.cvRepeats;
K=cfg.cvFolds;
folds=repeated_spatial_folds(obs.uv,R,K);
err=nan(numel(grid),R);

scale=coordinate_scale(obs.uv);

for ig=1:numel(grid)
    lam=grid(ig);

    for r=1:R
        sse=0;
        nt=0;

        for k=1:K
            tr=folds(:,r)~=k;
            te=folds(:,r)==k;
            if nnz(te)==0 || nnz(tr)<6, continue; end

            mdl=fit_tps(obs.uv(tr,:),obs.z(tr),lam,scale);
            pred=tps_predict(mdl,obs.uv(te,:));
            e=pred-obs.z(te);
            sse=sse+sum(e.^2);
            nt=nt+numel(e);
        end

        if nt>0, err(ig,r)=sse/nt; end
    end
end

CV=select_plateau_scalar(grid,err,cfg.cvPlateau);
end


function CV=select_plateau_scalar(grid,repeatMSE,delta) %#ok<INUSD>
% Parameter-reduced V2 scalar selector: standard one-SE rule.
meanMSE=nan(size(grid));
seMSE=nan(size(grid));

for i=1:numel(grid)
    x=repeatMSE(i,isfinite(repeatMSE(i,:)));
    if isempty(x), continue; end
    meanMSE(i)=mean(x);
    if numel(x)>1
        seMSE(i)=std(x,0,2)/sqrt(numel(x));
    else
        seMSE(i)=0;
    end
end

[best,ib]=min(meanMSE);
if ~isfinite(best), error('CV failed: no finite predictive MSE.'); end

bestSE=seMSE(ib);
if ~isfinite(bestSE), bestSE=0; end
threshold=best+bestSE;

eligible=isfinite(meanMSE) & meanMSE<=threshold;
ii=find(eligible);
if isempty(ii), ii=ib; end

% Grids are ascending in regularization; one-SE chooses the strongest
% regularization whose CV risk is statistically indistinguishable from the
% minimum at the one-standard-error scale.
is=ii(end);

CV=struct();
CV.grid=grid;
CV.repeatMSE=repeatMSE;
CV.meanMSE=meanMSE;
CV.seMSE=seMSE;
CV.rawIndex=ib;
CV.rawValue=grid(ib);
CV.rawMSE=best;
CV.rawSE=bestSE;
CV.oneSEThreshold=threshold;
CV.eligibleOneSE=eligible;
CV.selectedIndex=is;
CV.value=grid(is);
CV.selectedMSE=meanMSE(is);
CV.relativePenalty=(meanMSE(is)-best)/max(best,eps);
end


function print_scalar_cv(name,CV)
fprintf('    raw %s = %.4e | selected = %.4e | CV %.6g -> %.6g | penalty %.3f%%\n', ...
    name,CV.rawValue,CV.value,CV.rawMSE,CV.selectedMSE, ...
    100*CV.relativePenalty);
end


% =========================================================================
% THIN-PLATE SPLINE
% =========================================================================
function S=coordinate_scale(uv)
S.center=mean(uv,1);
span=max(uv,[],1)-min(uv,[],1);
S.scale=max(0.5*span,1);
end


function q=normalize_uv(uv,S)
q=(uv-S.center)./S.scale;
end


function mdl=fit_tps(uv,z,lambda,scale)
q=normalize_uv(uv,scale);
n=size(q,1);

D=pairwise_dist(q,q);
K=tps_kernel(D);
P=[ones(n,1),q];

A=[K+lambda*eye(n), P; P.', zeros(3,3)];
rhs=[z(:);zeros(3,1)];

% Numerical safety.
A(1:n,1:n)=A(1:n,1:n)+1e-12*eye(n);
coef=A\rhs;

mdl=struct();
mdl.uv=uv;
mdl.q=q;
mdl.scale=scale;
mdl.a=coef(1:n);
mdl.b=coef(n+1:end);
mdl.lambda=lambda;
end


function z=tps_predict(mdl,uvq)
q=normalize_uv(uvq,mdl.scale);
D=pairwise_dist(q,mdl.q);
K=tps_kernel(D);
P=[ones(size(q,1),1),q];
z=K*mdl.a+P*mdl.b;
end


function D=pairwise_dist(A,B)
dx=A(:,1)-B(:,1).';
dy=A(:,2)-B(:,2).';
D=sqrt(dx.^2+dy.^2);
end


function K=tps_kernel(r)
K=zeros(size(r));
m=r>0;
rm=r(m);
K(m)=rm.^2.*log(rm);
end


function S=fit_tps_solution(obs,lambda,cfg) %#ok<INUSD>
scale=coordinate_scale(obs.uv);
mdl=fit_tps(obs.uv,obs.z,lambda,scale);
S=struct();
S.type='tps';
S.name='S-TPS';
S.model=mdl;
S.nUnknowns=size(obs.uv,1)+3;
S.dataRMSE=sqrt(mean((tps_predict(mdl,obs.uv)-obs.z).^2));
end


% =========================================================================
% FEM SOLUTION
% =========================================================================
function S=fit_fem_solution(mesh,Ks,H,obs,c0,name)
A=c0*Ks+H.'*H;
b=H.'*obs.z;
A=0.5*(A+A.');
ridge=1e-12*max(mean(abs(diag(A))),1);
A=A+ridge*speye(size(A,1));
U=A\b;

S=struct();
S.type='fem';
S.name=name;
S.mesh=mesh;
S.U=U;
S.c0=c0;
S.nUnknowns=numel(U);
S.dataRMSE=sqrt(mean((H*U-obs.z).^2));
end


% =========================================================================
% GEOLOGICAL JUMP RECONSTRUCTION
% =========================================================================
function CV=select_gjr_model_cv(obs,G,uRange,vRange,cfg)
pList=cfg.gjrBackgroundDegrees(:);
qList=cfg.gjrJumpDegrees(:);

models=[];
for ip=1:numel(pList)
    for iq=1:numel(qList)
        models=[models;pList(ip),qList(iq)]; %#ok<AGROW>
    end
end

R=cfg.gjrCVRepeats;
K=cfg.gjrCVFolds;
folds=repeated_spatial_folds(obs.uv,R,K);
mse=nan(size(models,1),R);

scale=gjr_scale(uRange,vRange,G);

for im=1:size(models,1)
    p=models(im,1);
    q=models(im,2);

    for r=1:R
        sse=0;
        nt=0;

        for k=1:K
            tr=folds(:,r)~=k;
            te=folds(:,r)==k;
            if nnz(te)==0 || nnz(tr)<8, continue; end

            Xtr=gjr_design(obs.uv(tr,:),G,p,q,scale,cfg);
            Xte=gjr_design(obs.uv(te,:),G,p,q,scale,cfg);

            theta=Xtr\obs.z(tr);
            e=Xte*theta-obs.z(te);
            sse=sse+sum(e.^2);
            nt=nt+numel(e);
        end

        if nt>0, mse(im,r)=sse/nt; end
    end
end

meanMSE=nan(size(models,1),1);
seMSE=nan(size(models,1),1);
for i=1:size(models,1)
    x=mse(i,isfinite(mse(i,:)));
    if isempty(x), continue; end
    meanMSE(i)=mean(x);
    if numel(x)>1
        seMSE(i)=std(x,0,2)/sqrt(numel(x));
    else
        seMSE(i)=0;
    end
end

[best,ib]=min(meanMSE);
eligible=meanMSE<=(1+cfg.cvPlateau)*best;

% Among near-minimum models choose minimum number of parameters, then
% smaller polynomial degree.
npar=zeros(size(models,1),1);
for i=1:size(models,1)
    npar(i)=poly_term_count(models(i,1))+(models(i,2)+1);
end

cand=find(eligible & isfinite(meanMSE));
if isempty(cand), cand=ib; end

[~,ord]=sortrows([npar(cand),models(cand,1),models(cand,2)],[1 2 3]);
is=cand(ord(1));

CV=struct();
CV.models=models;
CV.meanMSE=meanMSE;
CV.seMSE=seMSE;
CV.rawIndex=ib;
CV.rawMSE=best;
CV.selectedIndex=is;
CV.selectedMSE=meanMSE(is);
CV.backgroundDegree=models(is,1);
CV.jumpDegree=models(is,2);
CV.nParameters=npar(is);
CV.relativePenalty=(meanMSE(is)-best)/best;
end


function print_gjr_cv(CV)
fprintf('    raw best p/q = %d/%d | selected p/q = %d/%d | npar=%d\n', ...
    CV.models(CV.rawIndex,1),CV.models(CV.rawIndex,2), ...
    CV.backgroundDegree,CV.jumpDegree,CV.nParameters);
fprintf('    CV raw/selected = %.6g / %.6g | penalty %.3f%%\n', ...
    CV.rawMSE,CV.selectedMSE,100*CV.relativePenalty);

for i=1:size(CV.models,1)
    fprintf('      p=%d q=%d : mean=%.6g | SE=%.3g\n', ...
        CV.models(i,1),CV.models(i,2),CV.meanMSE(i),CV.seMSE(i));
end
end


function S=gjr_scale(uRange,vRange,G)
S.uCenter=0.5*sum(uRange);
S.uScale=max(0.5*diff(uRange),1);
S.vCenter=0.5*sum(vRange);
S.vScale=max(0.5*diff(vRange),1);
S.faultUCenter=0.5*(G.uMin+G.uMax);
S.faultUScale=max(0.5*(G.uMax-G.uMin),1);
end


function X=gjr_design(uv,G,p,q,S,cfg)
un=(uv(:,1)-S.uCenter)/S.uScale;
vn=(uv(:,2)-S.vCenter)/S.vScale;

B=poly_total_degree_basis(un,vn,p);

phi=fault_phi(uv,G);
H=double(phi>=0);
gate=fault_gate(uv(:,1),G,cfg);

uf=(uv(:,1)-S.faultUCenter)/S.faultUScale;
J=zeros(size(uv,1),q+1);
for r=0:q
    J(:,r+1)=gate.*H.*(uf.^r);
end

X=[B,J];
end


function B=poly_total_degree_basis(x,y,p)
n=numel(x);
m=poly_term_count(p);
B=zeros(n,m);
c=0;

for d=0:p
    for ix=0:d
        iy=d-ix;
        c=c+1;
        B(:,c)=(x.^ix).*(y.^iy);
    end
end
end


function n=poly_term_count(p)
n=(p+1)*(p+2)/2;
end


function S=fit_gjr_solution(obs,G,uRange,vRange,p,q,cfg)
scale=gjr_scale(uRange,vRange,G);
X=gjr_design(obs.uv,G,p,q,scale,cfg);
theta=X\obs.z;

S=struct();
S.type='gjr';
S.name='IG-GJR';
S.G=G;
S.p=p;
S.q=q;
S.scale=scale;
S.cfg=cfg;
S.theta=theta;
S.nUnknowns=numel(theta);
S.dataRMSE=sqrt(mean((X*theta-obs.z).^2));
end


% =========================================================================
% COMMON PREDICTION
% =========================================================================
function z=predict_solution(S,uv)
switch lower(S.type)
    case 'tps'
        z=tps_predict(S.model,uv);

    case 'fem'
        H=build_interp_matrix(S.mesh,uv);
        z=H*S.U;

    case 'gjr'
        X=gjr_design(uv,S.G,S.p,S.q,S.scale,S.cfg);
        z=X*S.theta;

    case 'fbpoly'
        X=fbpoly_design(uv,S.G,S.degree,S.scale);
        z=X*S.theta;

    case 'fbtps'
        phi=fault_phi(uv,S.G);
        neg=phi<0;
        z=zeros(size(phi));
        if any(neg)
            z(neg)=tps_predict(S.negModel,uv(neg,:));
        end
        if any(~neg)
            z(~neg)=tps_predict(S.posModel,uv(~neg,:));
        end

    otherwise
        error('Unknown solution type: %s',S.type);
end
end



% =========================================================================
% V2 AUTOMATIC C11 POLYGON SCREENING

% =========================================================================
% ENGINEERING FAULT-AFEM
% =========================================================================
function M=uniform_mesh_under_budget(uRange,vRange,nodeBudget)
% Return the densest approximately square structured mesh whose number of
% vertices does not exceed nodeBudget.

if nodeBudget<16
    error('nodeBudget=%d is too small.',nodeBudget);
end

Lu=diff(uRange);
Lv=diff(vRange);
A=max(Lu*Lv,1);
h0=sqrt(A/max(nodeBudget,1));

factors=linspace(0.55,2.8,180);
best=[];
bestN=-inf;

for k=1:numel(factors)
    h=h0*factors(k);
    Mt=make_rect_mesh(uRange,vRange,h);
    n=size(Mt.P,1);
    if n<=nodeBudget && n>bestN
        best=Mt;
        bestN=n;
    end
end

if isempty(best)
    h=h0*3.5;
    best=make_rect_mesh(uRange,vRange,h);
    while size(best.P,1)>nodeBudget
        h=1.12*h;
        best=make_rect_mesh(uRange,vRange,h);
    end
end

M=best;
end


function [S,mesh,history]=adapt_fault_mesh_to_budget(mesh,nodeBudget,obs,G,c0,cfg)
% Nested adaptive refinement under a hard node budget.

history=struct('iter',{},'nodes',{},'triangles',{},'etaResidual',{}, ...
    'etaGeoMean',{},'marked',{},'acceptedMarks',{}, ...
    'splitEdges',{},'budgetLimited',{},'areaRelError',{});

for it=1:cfg.afemMaxAdaptPerBudget
    H=build_interp_matrix(mesh,obs.uv);
    K=assemble_fault_stiffness(mesh,G,cfg);
    S=fit_fem_solution(mesh,K,H,obs,c0,'FAULT-AFEM');
    S.nUnknowns=size(mesh.P,1);

    [eta2,parts]=afem_hybrid_indicator(mesh,S.U,obs,H,G,c0,cfg);

    % Residual-driven Dörfler set.
    markRes=doerfler_mark_local(eta2,cfg.afemDoerflerTheta);

    % Geometry set: all cells whose centroids lie inside one
    % geometry-derived sigma_Gamma band are eligible for refinement.
    % This is a set union, not a weighted sum.
    geom=mesh_triangle_geometry(mesh);
    [phi,~,~,~,~,~]=fault_project_exact(geom.centroid,G);
    gate=fault_gate(geom.centroid(:,1),G,cfg);
    sigma=cfg.faultSigmaMin;
    markGeo=abs(phi)<=sigma & gate>=exp(-0.5);

    mark=markRes | markGeo;

    rec=struct();
    rec.iter=it;
    rec.nodes=size(mesh.P,1);
    rec.triangles=size(mesh.T,1);
    rec.etaResidual=sqrt(sum(parts.residual2));
    rec.etaGeoMean=mean(parts.geo);
    rec.marked=nnz(mark);
    rec.acceptedMarks=0;
    rec.splitEdges=0;
    rec.budgetLimited=false;
    rec.areaRelError=0;

    if size(mesh.P,1)>=nodeBudget || ~any(mark)
        history(end+1)=rec; %#ok<AGROW>
        break;
    end

    priority=parts.priority;
    [meshNew,stat,budgetLimited,nAccepted]= ...
        refine_with_node_budget_local(mesh,mark,priority,nodeBudget,cfg);

    rec.acceptedMarks=nAccepted;
    rec.splitEdges=stat.nSplitEdges;
    rec.budgetLimited=budgetLimited;
    rec.areaRelError=stat.areaRelError;
    history(end+1)=rec; %#ok<AGROW>

    fprintf(['    AFEM it=%2d | nodes=%4d | tri=%4d | etaR=%.3e | ', ...
        'marked=%3d | accepted=%3d | split=%3d'], ...
        it,size(mesh.P,1),size(mesh.T,1),rec.etaResidual, ...
        nnz(mark),nAccepted,stat.nSplitEdges);
    if budgetLimited
        fprintf(' | budget-limited');
    end
    fprintf('\n');

    if size(meshNew.P,1)==size(mesh.P,1)
        break;
    end
    if stat.areaRelError>1e-10
        error('AFEM local refinement area audit failed: %.3e.',stat.areaRelError);
    end

    mesh=meshNew;
end

% Final solve on the returned mesh.
H=build_interp_matrix(mesh,obs.uv);
K=assemble_fault_stiffness(mesh,G,cfg);
S=fit_fem_solution(mesh,K,H,obs,c0,'FAULT-AFEM');
S.nUnknowns=size(mesh.P,1);
S.adaptHistory=history;
end


function [eta2,parts]=afem_hybrid_indicator(mesh,U,obs,H,G,c0,cfg)
geom=mesh_triangle_geometry(mesh);
T=mesh.T;
nt=size(T,1);

Ue=U(T);
gradU=zeros(nt,2);

for e=1:nt
    [B,~]=tri_gradients(mesh.P(T(e,:),:));
    gradU(e,:)=(B*Ue(e,:).').';
end

% Fault-aware tensor and element-centroid flux.
[k11,k12,k22]=fault_tensor_at_points(geom.centroid,G,cfg);
qx=c0*(k11.*gradU(:,1)+k12.*gradU(:,2));
qy=c0*(k12.*gradU(:,1)+k22.*gradU(:,2));

% Interior flux-jump residual.
edge2=zeros(nt,1);
E=[T(:,[1 2]);T(:,[2 3]);T(:,[3 1])];
triId=[(1:nt)';(1:nt)';(1:nt)'];
Es=sort(E,2);
[Eu,~,ic]=unique(Es,'rows');
[ics,ord]=sort(ic);

s0=1;
while s0<=numel(ics)
    t0=s0;
    while t0<numel(ics) && ics(t0+1)==ics(s0)
        t0=t0+1;
    end
    if t0-s0+1==2
        a=ord(s0); b=ord(t0);
        t1=triId(a); t2=triId(b);
        eid=ics(s0);
        v1=Eu(eid,1); v2=Eu(eid,2);
        ev=mesh.P(v2,:)-mesh.P(v1,:);
        he=norm(ev);
        if he>0
            nface=[-ev(2),ev(1)]/he;
            jump=(qx(t1)-qx(t2))*nface(1)+(qy(t1)-qy(t2))*nface(2);
            val=0.5*he^2*jump^2;
            edge2(t1)=edge2(t1)+val;
            edge2(t2)=edge2(t2)+val;
        end
    end
    s0=t0+1;
end

% CORE V4: nonzero cell residual for spatially varying D_Gamma.
% For P1, grad U is constant on a triangle but D_Gamma is not.  Approximate
% div(c0 D grad U) by a midpoint boundary-flux balance (Gauss theorem).
cell2=zeros(nt,1);
for e=1:nt
    nodes=T(e,:);
    xy=mesh.P(nodes,:);
    cen=geom.centroid(e,:);
    fluxInt=0;
    locEdges=[1 2;2 3;3 1];
    for je=1:3
        p1=xy(locEdges(je,1),:);
        p2=xy(locEdges(je,2),:);
        mid=0.5*(p1+p2);
        ev=p2-p1;
        he=norm(ev);
        if he<=eps, continue; end
        nout=[ev(2),-ev(1)]/he;
        if dot(nout,cen-mid)>0
            nout=-nout;
        end
        [a11,a12,a22]=fault_tensor_at_points(mid,G,cfg);
        qmid=c0*[a11*gradU(e,1)+a12*gradU(e,2), ...
                 a12*gradU(e,1)+a22*gradU(e,2)];
        fluxInt=fluxInt+he*dot(qmid,nout);
    end
    rcell=-fluxInt/max(geom.area(e),eps);
    cell2(e)=geom.hT(e)^2*geom.area(e)*rcell^2;
end

% Sparse-data residual assigned to containing element.
r=H*U-obs.z;
triObs=pointLocation(mesh.TR,obs.uv);
bad=~isfinite(triObs);
if any(bad)
    C=geom.centroid;
    ib=find(bad);
    for k=1:numel(ib)
        d2=sum((C-obs.uv(ib(k),:)).^2,2);
        [~,triObs(ib(k))]=min(d2);
    end
end

dataByTri=accumarray(triObs,r.^2,[nt,1],@sum,0);
data2=(geom.hT.^2).*dataByTri;

residual2=edge2 + cfg.afemCellResidualWeight*cell2 + data2;
res=sqrt(max(residual2,0));
if max(res)>0
    resNorm=res/max(res);
else
    resNorm=zeros(size(res));
end

% Geometry proximity is retained only as an independent refinement set and
% as a tie-breaker under a hard node budget.  It is not mixed with the
% residual through an empirical coefficient.
phi=fault_phi(geom.centroid,G);
gate=fault_gate(geom.centroid(:,1),G,cfg);
sigma=cfg.faultSigmaMin;
geo=gate.*exp(-0.5*(phi/sigma).^2);
geo=max(min(geo,1),0);

% Dörfler score uses the residual alone.
eta2=geom.area.*resNorm.^2;

% Parameter-free budget priority: a cell is important if either the
% normalized residual or the geometry proximity is large.
priority=max(resNorm,geo);

parts=struct();
parts.residual2=residual2;
parts.edge2=edge2;
parts.cell2=cell2;
parts.data2=data2;
parts.resNorm=resNorm;
parts.geo=geo;
parts.hybrid=priority;   % compatibility alias
parts.bgPressure=zeros(nt,1);
parts.priority=priority;
end


function [k11,k12,k22]=fault_tensor_at_points(q,G,cfg)
[phi,~,tt,nn]=fault_project_exact(q,G);
gate=fault_gate(q(:,1),G,cfg);

sigma=cfg.faultSigmaMin;
strength=gate.*exp(-0.5*(phi/sigma).^2);
epsn=1-(1-cfg.faultEpsMin).*strength;

k11=tt(:,1).^2 + epsn.*nn(:,1).^2;
k12=tt(:,1).*tt(:,2) + epsn.*nn(:,1).*nn(:,2);
k22=tt(:,2).^2 + epsn.*nn(:,2).^2;
end


function Gm=mesh_triangle_geometry(mesh)
T=mesh.T;
P=mesh.P;
nt=size(T,1);

centroid=(P(T(:,1),:)+P(T(:,2),:)+P(T(:,3),:))/3;
area=zeros(nt,1);
hT=zeros(nt,1);

for e=1:nt
    xy=P(T(e,:),:);
    [~,A]=tri_gradients(xy);
    area(e)=A;
    hT(e)=max([norm(xy(1,:)-xy(2,:)), ...
               norm(xy(2,:)-xy(3,:)), ...
               norm(xy(3,:)-xy(1,:))]);
end

Gm=struct('centroid',centroid,'area',area,'hT',hT);
end


function mark=doerfler_mark_local(eta2,theta)
mark=false(size(eta2));
tot=sum(eta2);
if ~(tot>0), return; end

[es,idx]=sort(eta2,'descend');
cs=cumsum(es);
k=find(cs>=theta*tot,1,'first');
if isempty(k), k=numel(idx); end
mark(idx(1:k))=true;
end


function [meshNew,stat,budgetLimited,nAccepted]= ...
    refine_with_node_budget_local(mesh,mark,priority,nodeBudget,cfg)

[full,statFull]=refine_mesh_conforming_edge_bisection_local(mesh,mark,cfg);

if size(full.P,1)<=nodeBudget
    meshNew=full;
    stat=statFull;
    budgetLimited=false;
    nAccepted=nnz(mark);
    return;
end

budgetLimited=true;
idx=find(mark);

if isempty(idx)
    meshNew=mesh;
    stat=zero_refine_stats_local();
    nAccepted=0;
    return;
end

[~,ord]=sort(priority(idx),'descend');
idx=idx(ord);

lo=1; hi=numel(idx);
bestK=0;
bestMesh=mesh;
bestStat=zero_refine_stats_local();

while lo<=hi
    mid=floor((lo+hi)/2);
    m=false(size(mark));
    m(idx(1:mid))=true;

    [trial,st]=refine_mesh_conforming_edge_bisection_local(mesh,m,cfg);

    if size(trial.P,1)<=nodeBudget
        bestK=mid;
        bestMesh=trial;
        bestStat=st;
        lo=mid+1;
    else
        hi=mid-1;
    end
end

meshNew=bestMesh;
stat=bestStat;
nAccepted=bestK;
end


function s=zero_refine_stats_local()
s=struct('nSplitEdges',0,'nAffectedTriangles',0,'areaRelError',0);
end


function [meshNew,stat]=refine_mesh_conforming_edge_bisection_local(mesh,mark,cfg)
% Nested conforming local edge bisection. One midpoint is created for every
% selected current edge; adjacent triangles are split using 1/2/3-edge
% conformity templates, so no hanging nodes are produced.

P=mesh.P;
T=mesh.T;
nt=size(T,1);

Eall=[T(:,[1 2]);T(:,[2 3]);T(:,[3 1])];
Es=sort(Eall,2);
[Eu,~,ic]=unique(Es,'rows');
edgeId=[ic(1:nt),ic(nt+1:2*nt),ic(2*nt+1:3*nt)];

splitEdge=false(size(Eu,1),1);
ids=find(mark);

for ii=1:numel(ids)
    t=ids(ii);
    v=T(t,:);
    pp=P(v,:);
    len=[norm(pp(1,:)-pp(2,:)), ...
         norm(pp(2,:)-pp(3,:)), ...
         norm(pp(3,:)-pp(1,:))];
    [L,j]=max(len);
    if L>2.01*cfg.afemHMin
        splitEdge(edgeId(t,j))=true;
    end
end

splitIds=find(splitEdge);
stat=struct('nSplitEdges',numel(splitIds), ...
    'nAffectedTriangles',0,'areaRelError',0);

if isempty(splitIds)
    meshNew=mesh;
    return;
end

midIndex=zeros(size(Eu,1),1);
midPts=0.5*(P(Eu(splitIds,1),:)+P(Eu(splitIds,2),:));
midIndex(splitIds)=size(P,1)+(1:numel(splitIds));
Pnew=[P;midPts];

Tnew=zeros(4*nt,3);
nnew=0;
affected=0;

for t=1:nt
    v1=T(t,1); v2=T(t,2); v3=T(t,3);
    f=splitEdge(edgeId(t,:));

    m12=midIndex(edgeId(t,1));
    m23=midIndex(edgeId(t,2));
    m31=midIndex(edgeId(t,3));

    nf=nnz(f);

    if nf==0
        nnew=nnew+1;
        Tnew(nnew,:)=[v1 v2 v3];

    elseif nf==1
        affected=affected+1;
        if f(1)
            ch=[v1 m12 v3; m12 v2 v3];
        elseif f(2)
            ch=[v2 m23 v1; m23 v3 v1];
        else
            ch=[v3 m31 v2; m31 v1 v2];
        end
        Tnew(nnew+(1:2),:)=ch;
        nnew=nnew+2;

    elseif nf==2
        affected=affected+1;
        if f(1) && f(2)
            ch=[m12 v2 m23; v1 m12 v3; m12 m23 v3];
        elseif f(2) && f(3)
            ch=[m23 v3 m31; v2 m23 v1; m23 m31 v1];
        else
            ch=[v1 m12 m31; v2 v3 m12; v3 m31 m12];
        end
        Tnew(nnew+(1:3),:)=ch;
        nnew=nnew+3;

    else
        affected=affected+1;
        ch=[v1 m12 m31; m12 v2 m23; m31 m23 v3; m12 m23 m31];
        Tnew(nnew+(1:4),:)=ch;
        nnew=nnew+4;
    end
end

Tnew=Tnew(1:nnew,:);
meshNew=finalize_unstructured_mesh_local(Pnew,Tnew);

% Strict nesting and domain-area audit.
vertexDiff=abs(meshNew.P(1:size(P,1),:)-P);
if max(vertexDiff(:))>1e-12
    error('AFEM refinement violated nested old vertices.');
end

oldGeom=mesh_triangle_geometry(mesh);
newGeom=mesh_triangle_geometry(meshNew);
stat.nAffectedTriangles=affected;
stat.areaRelError=abs(sum(newGeom.area)-sum(oldGeom.area))/max(sum(oldGeom.area),eps);
end


function M=finalize_unstructured_mesh_local(P,T)
% Orient all triangles counter-clockwise for robust barycentric operations.
for e=1:size(T,1)
    a=P(T(e,1),:);
    b=P(T(e,2),:);
    c=P(T(e,3),:);
    cross2=(b(1)-a(1))*(c(2)-a(2))-(b(2)-a(2))*(c(1)-a(1));
    if cross2<0
        T(e,[2 3])=T(e,[3 2]);
    end
end

M=struct();
M.P=P;
M.T=T;
M.TR=triangulation(T,P);
M.uAxis=[];
M.vAxis=[];
M.nU=[];
M.nV=[];
end


function print_afem_metric(name,M,nNodes)
fprintf(['    %-11s | nodes=%4d | RMSE all/fault/bg = %.4f / %.4f / %.4f ', ...
    '| Jump0MAE=%.4f | data=%.4f\n'], ...
    name,nNodes,M.RMSE_all,M.RMSE_fault,M.RMSE_bg,M.Jump0MAE,M.dataRMSE);
end


function T=afem_budget_row(budget,method,mesh,M)
Budget=budget;
Method={method};
Nodes=size(mesh.P,1);
Triangles=size(mesh.T,1);
RMSE_all=M.RMSE_all;
RMSE_fault=M.RMSE_fault;
RMSE_bg=M.RMSE_bg;
Jump0MAE=M.Jump0MAE;
Jump0RMSE=M.Jump0RMSE;
DataRMSE=M.dataRMSE;

T=table(Budget,Method,Nodes,Triangles,RMSE_all,RMSE_fault,RMSE_bg, ...
    Jump0MAE,Jump0RMSE,DataRMSE);
end


function T=make_afem_main_table(sols,M,meshUniform,meshAF,cvTPS,cvIso,cvFault,cfg)
n=numel(sols);

Method=cell(n,1);
Hyperparameter=cell(n,1);
Nodes=nan(n,1);
Triangles=nan(n,1);
Unknowns=nan(n,1);
RMSE_all=nan(n,1);
RMSE_fault=nan(n,1);
RMSE_bg=nan(n,1);
Jump0MAE=nan(n,1);
Jump0RMSE=nan(n,1);
DataRMSE=nan(n,1);

for i=1:n
    Method{i}=sols{i}.name;
    Unknowns(i)=M{i}.nUnknowns;
    RMSE_all(i)=M{i}.RMSE_all;
    RMSE_fault(i)=M{i}.RMSE_fault;
    RMSE_bg(i)=M{i}.RMSE_bg;
    Jump0MAE(i)=M{i}.Jump0MAE;
    Jump0RMSE(i)=M{i}.Jump0RMSE;
    DataRMSE(i)=M{i}.dataRMSE;
end

Hyperparameter{1}=sprintf('lambda=%.4g',cvTPS.value);
Hyperparameter{2}=sprintf('c0=%.4g',cvIso.value);
Hyperparameter{3}=sprintf('c0=%.4g; eps=%.3g',cvFault.value,cvFault.epsValue);
Hyperparameter{4}=sprintf('c0=%.4g; eps=%.3g; residual+geometry union', ...
    cvFault.value,cvFault.epsValue);

Nodes(1)=size(sols{1}.model.uv,1)+3;
Triangles(1)=nan;
Nodes(2)=size(meshUniform.P,1); Triangles(2)=size(meshUniform.T,1);
Nodes(3)=size(meshUniform.P,1); Triangles(3)=size(meshUniform.T,1);
Nodes(4)=size(meshAF.P,1); Triangles(4)=size(meshAF.T,1);

ref=3;
ImproveAllVsFaultUniformPct=100*(RMSE_all(ref)-RMSE_all)./RMSE_all(ref);
ImproveFaultVsFaultUniformPct=100*(RMSE_fault(ref)-RMSE_fault)./RMSE_fault(ref);
ImproveJumpVsFaultUniformPct=100*(Jump0MAE(ref)-Jump0MAE)./Jump0MAE(ref);

T=table(Method,Hyperparameter,Nodes,Triangles,Unknowns, ...
    RMSE_all,RMSE_fault,RMSE_bg,Jump0MAE,Jump0RMSE,DataRMSE, ...
    ImproveAllVsFaultUniformPct,ImproveFaultVsFaultUniformPct, ...
    ImproveJumpVsFaultUniformPct);
end


function plot_afem_budget_curves(outDir,T,Mtps,cfg)
metrics={'RMSE_all','RMSE_fault'};
files={'FIG_04_RMSE_all_vs_DOF.png','FIG_05_RMSE_fault_vs_DOF.png'};

for imet=1:2
    metric=metrics{imet};

    f=figure('Color','w','Units','pixels','Position',[160 160 980 680]);
    hold on;

    methods={'ISO-FEM','FAULT-FEM','FAULT-AFEM'};
    for j=1:numel(methods)
        m=strcmp(T.Method,methods{j});
        TT=T(m,:);
        [~,ord]=sort(TT.Nodes);
        TT=TT(ord,:);
        plot(TT.Nodes,TT.(metric),'-o','LineWidth',1.6,'MarkerSize',7);
    end

    if cfg.afemPlotTPSReference
        if strcmp(metric,'RMSE_all')
            y=Mtps.RMSE_all;
        else
            y=Mtps.RMSE_fault;
        end
        xlimNow=[min(T.Nodes),max(T.Nodes)];
        plot(xlimNow,[y y],'--','LineWidth',1.2);
        leg={'ISO-FEM','FAULT-FEM','FAULT-AFEM','S-TPS reference'};
    else
        leg=methods;
    end

    grid on;
    xlabel('actual FEM node count');
    ylabel(strrep(metric,'_','\_'));
    title(sprintf('%s under matched node budgets',strrep(metric,'_','\_')));
    legend(leg,'Location','best');

    save_figure(f,fullfile(outDir,files{imet}),cfg);
end
end


function plot_afem_main_reconstruction(outDir,uv,z,sols,G,uRange,vRange,cfg)
[uGrid,vGrid,Q]=visual_grid(uRange,vRange,cfg);

Fref=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
Zref=reshape(Fref(Q(:,1),Q(:,2)),size(uGrid));

Z=cell(numel(sols)+1,1);
Z{1}=Zref;
for i=1:numel(sols)
    Z{i+1}=reshape(predict_solution(sols{i},Q),size(uGrid));
end

allZ=cat(3,Z{:});
clim=[min(allZ(:)),max(allZ(:))];

f=figure('Color','w','Units','pixels','Position',[60 60 1650 900]);
tl=tiledlayout(f,2,3,'Padding','compact','TileSpacing','compact');

titles=[{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)];
lastAx=[];

for i=1:numel(Z)
    ax=nexttile(tl,i);
    imagesc(ax,uGrid(1,:),vGrid(:,1),Z{i});
    set(ax,'YDir','normal');
    axis(ax,'image');
    caxis(ax,clim);
    hold(ax,'on');

    uu=linspace(G.uMin,G.uMax,400);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'k--','LineWidth',1);

    title(ax,titles{i},'FontWeight','bold');
    xlabel(ax,'u (m)');
    ylabel(ax,'v (m)');
    lastAx=ax;
end

cb=colorbar(lastAx);
cb.Layout.Tile='east';
cb.Label.String='TVD (m)';
title(tl,sprintf('C11 reconstruction at node budget %d',cfg.mainNodeBudget));

save_figure(f,fullfile(outDir,'FIG_06_main_reconstruction.png'),cfg);
end


function plot_afem_main_errors(outDir,uv,z,sols,G,uRange,vRange,cfg)
[uGrid,vGrid,Q]=visual_grid(uRange,vRange,cfg);

Fref=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
z0=Fref(Q(:,1),Q(:,2));

E=cell(numel(sols),1);
mx=0;

for i=1:numel(sols)
    e=abs(predict_solution(sols{i},Q)-z0);
    E{i}=reshape(e,size(uGrid));
    mx=max(mx,percentile_local(e,99));
end

f=figure('Color','w','Units','pixels','Position',[80 80 1450 980]);
tl=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');
lastAx=[];

for i=1:numel(sols)
    ax=nexttile(tl,i);
    imagesc(ax,uGrid(1,:),vGrid(:,1),E{i});
    set(ax,'YDir','normal');
    axis(ax,'image');
    caxis(ax,[0,mx]);
    hold(ax,'on');

    uu=linspace(G.uMin,G.uMax,400);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'w--','LineWidth',1);

    title(ax,sols{i}.name,'FontWeight','bold');
    xlabel(ax,'u (m)');
    ylabel(ax,'v (m)');
    lastAx=ax;
end

cb=colorbar(lastAx);
cb.Layout.Tile='east';
cb.Label.String='|TVD error| (m)';
title(tl,'Absolute error relative to interpreted C11 horizon');

save_figure(f,fullfile(outDir,'FIG_07_main_absolute_error.png'),cfg);
end


function plot_uniform_vs_adaptive_mesh(outDir,meshU,meshA,G,cfg)
f=figure('Color','w','Units','pixels','Position',[100 100 1350 640]);
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

meshes={meshU,meshA};
titles={sprintf('Uniform fault FEM: %d nodes',size(meshU.P,1)), ...
        sprintf('Fault AFEM: %d nodes',size(meshA.P,1))};

for i=1:2
    ax=nexttile(tl,i);
    triplot(meshes{i}.T,meshes{i}.P(:,1),meshes{i}.P(:,2), ...
        'Parent',ax,'LineWidth',0.45);
    hold(ax,'on');
    uu=linspace(G.uMin,G.uMax,500);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'r-','LineWidth',2);
    axis(ax,'equal');
    axis(ax,'tight');
    xlabel(ax,'u (m)');
    ylabel(ax,'v (m)');
    title(ax,titles{i});
end

title(tl,sprintf('Matched budget = %d nodes',cfg.mainNodeBudget));
save_figure(f,fullfile(outDir,'FIG_08_uniform_vs_adaptive_mesh.png'),cfg);
end


function plot_afem_fault_profile(outDir,sols,R,G,cfg)
u0=0.5*(G.uMin+G.uMax);
[vc,~]=fault_center_and_slope(u0,G);

vSpan=max(360,3*G.halfWidth95);
v=linspace(vc-vSpan,vc+vSpan,700).';
q=[u0*ones(size(v)),v];

zref=reference_predict(R,q,G);

f=figure('Color','w','Units','pixels','Position',[150 150 1050 680]);
plot(v-vc,zref,'k-','LineWidth',2.3);
hold on;

for i=1:numel(sols)
    plot(v-vc,predict_solution(sols{i},q),'LineWidth',1.4);
end

xline(0,'k--','LineWidth',1);
grid on;
xlabel('cross-fault distance (m)');
ylabel('TVD (m)');
title('Fault-normal profile at selected fault midpoint');
legend([{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)], ...
    'Location','best');

save_figure(f,fullfile(outDir,'FIG_09_fault_normal_profile.png'),cfg);
end


function plot_afem_history(outDir,H,cfg)
if isempty(H), return; end

it=[H.iter].';
nodes=[H.nodes].';
eta=[H.etaResidual].';

f=figure('Color','w','Units','pixels','Position',[180 180 1050 650]);
yyaxis left;
plot(it,nodes,'-o','LineWidth',1.5);
ylabel('node count');

yyaxis right;
semilogy(it,max(eta,eps),'-s','LineWidth',1.5);
ylabel('residual-indicator norm');

grid on;
xlabel('adaptive iteration');
title('FAULT-AFEM nested refinement history');

save_figure(f,fullfile(outDir,'FIG_10_AFEM_history.png'),cfg);
end


function write_afem_diagnostic_summary(outDir,mainTable,budgetTable,cfg)
fid=fopen(fullfile(outDir,'DIAGNOSTIC_summary.txt'),'w');
if fid<0, return; end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'REAL_C11_FAULT_AFEM_V2_CVSTOP diagnostic summary\n');
fprintf(fid,'=========================================\n\n');

mU=strcmp(mainTable.Method,'FAULT-FEM');
mA=strcmp(mainTable.Method,'FAULT-AFEM');

if any(mU) && any(mA)
    u=mainTable(mU,:);
    a=mainTable(mA,:);

    gAll=100*(u.RMSE_all-a.RMSE_all)/u.RMSE_all;
    gFault=100*(u.RMSE_fault-a.RMSE_fault)/u.RMSE_fault;
    gJump=100*(u.Jump0MAE-a.Jump0MAE)/u.Jump0MAE;

    fprintf(fid,'Main matched budget = %d\n',cfg.mainNodeBudget);
    fprintf(fid,'Uniform actual nodes = %d\n',u.Nodes);
    fprintf(fid,'AFEM actual nodes    = %d\n',a.Nodes);
    fprintf(fid,'AFEM improvement vs uniform fault FEM:\n');
    fprintf(fid,'  RMSE_all   : %.3f %%\n',gAll);
    fprintf(fid,'  RMSE_fault : %.3f %%\n',gFault);
    fprintf(fid,'  Jump0MAE   : %.3f %%\n\n',gJump);
end

fprintf(fid,'Interpretation rule:\n');
fprintf(fid,['Positive fault-band gain at comparable node count supports the engineering ', ...
    'value of adaptive mesh concentration near interpreted faults/high-residual regions.\n']);
fprintf(fid,['If gains are small or negative across budgets, the adaptive-grid contribution ', ...
    'should not be claimed as the paper''s main improvement.\n\n']);

fprintf(fid,'Budget table:\n');
for i=1:height(budgetTable)
    fprintf(fid,'%4d | %-11s | nodes=%4d | all=%.4f | fault=%.4f | jump=%.4f\n', ...
        budgetTable.Budget(i),budgetTable.Method{i},budgetTable.Nodes(i), ...
        budgetTable.RMSE_all(i),budgetTable.RMSE_fault(i),budgetTable.Jump0MAE(i));
end
end



% =========================================================================
% V2 CROSS-FITTED SPATIAL-CV STOPPING AND ACCURACY--DOF EFFICIENCY
% =========================================================================

% =========================================================================
% V3 BUFFERED CHECKERBOARD INTERPOLATION CV
% =========================================================================
function folds=checkerboard_spatial_folds_local(uv,R,K,uRange,vRange,cfg)
% Distributed spatial folds. Unlike contiguous stripes, every fold consists
% of multiple separated cells distributed across the reconstruction domain.

if K~=4
    error('V3 checkerboard implementation currently requires K=4.');
end

nu=cfg.interpCVGrid(1);
nv=cfg.interpCVGrid(2);

u0=uRange(1); u1=uRange(2);
v0=vRange(1); v1=vRange(2);

du=max(u1-u0,eps);
dv=max(v1-v0,eps);

iu=floor((uv(:,1)-u0)/du*nu)+1;
iv=floor((uv(:,2)-v0)/dv*nv)+1;

iu=max(1,min(nu,iu));
iv=max(1,min(nv,iv));

patterns=[1 2; 2 1; 1 3; 3 1; 1 1; 3 2];
folds=zeros(size(uv,1),R);

for r=1:R
    ab=patterns(1+mod(r-1,size(patterns,1)),:);
    shift=mod(r-1,K);
    f=mod(ab(1)*(iu-1)+ab(2)*(iv-1)+shift,K)+1;

    % Rare safety fallback: if an uneven sparse sample leaves an empty fold,
    % redistribute the cell labels by a deterministic rank pattern.
    ok=true;
    for k=1:K
        if nnz(f==k)==0
            ok=false;
            break;
        end
    end

    if ~ok
        cellId=(iv-1)*nu+iu;
        [~,ord]=sortrows([cellId,uv(:,1),uv(:,2)],[1 2 3]);
        f=zeros(size(uv,1),1);
        for j=1:numel(ord)
            f(ord(j))=1+mod(j-1+shift,K);
        end
    end

    folds(:,r)=f;
end
end


function [tr,te,usedBuffer,valid]=buffered_checkerboard_split_local( ...
    obs,foldLabels,k,G,cfg)

te=foldLabels==k;
trBase=~te;

valid=false;
usedBuffer=nan;
tr=false(size(te));

if nnz(te)<cfg.interpCVMinTest
    return;
end

schedule=cfg.interpCVBufferSchedule(:).';

for ib=1:numel(schedule)
    dguard=schedule(ib);
    trTry=trBase;

    if dguard>0
        qTr=obs.uv(trBase,:);
        qTe=obs.uv(te,:);

        if ~isempty(qTr) && ~isempty(qTe)
            dmin=inf(size(qTr,1),1);

            % Small N (~80), explicit loop is more portable than pdist2.
            for j=1:size(qTe,1)
                d=sqrt(sum((qTr-qTe(j,:)).^2,2));
                dmin=min(dmin,d);
            end

            keep=dmin>=dguard;
            idx=find(trBase);
            trTry(:)=false;
            trTry(idx(keep))=true;
        end
    end

    if nnz(trTry)<cfg.interpCVMinTrain
        continue;
    end

    phi=fault_phi(obs.uv(trTry,:),G);
    nneg=nnz(phi<0);
    npos=nnz(phi>=0);

    if min(nneg,npos)<cfg.interpCVMinTrainPerSide
        continue;
    end

    tr=trTry;
    usedBuffer=dguard;
    valid=true;
    return;
end
end


function CV=select_fem_c0_interpcv( ...
    Ks,H,obs,uRange,vRange,G,cfg,R,K)

grid=cfg.femC0Grid(:);
folds=checkerboard_spatial_folds_local(obs.uv,R,K,uRange,vRange,cfg);

splitMSE=nan(numel(grid),R,K);
splitBuffer=nan(R,K);

for r=1:R
    for k=1:K
        [tr,te,usedBuffer,valid]=buffered_checkerboard_split_local( ...
            obs,folds(:,r),k,G,cfg);

        splitBuffer(r,k)=usedBuffer;

        if ~valid
            continue;
        end

        Htr=H(tr,:);
        Hte=H(te,:);
        ztr=obs.z(tr);
        zte=obs.z(te);

        for ig=1:numel(grid)
            c0=grid(ig);

            A=c0*Ks+Htr.'*Htr;
            b=Htr.'*ztr;
            A=0.5*(A+A.');
            ridge=1e-12*max(mean(abs(diag(A))),1);
            A=A+ridge*speye(size(A,1));

            U=A\b;
            e=Hte*U-zte;
            splitMSE(ig,r,k)=mean(e.^2);
        end
    end
end

% Aggregate split-level MSE into repeat-level means for the existing robust
% plateau selector. Every repeat pools its valid spatial folds.
repeatMSE=nan(numel(grid),R);

for ig=1:numel(grid)
    for r=1:R
        x=squeeze(splitMSE(ig,r,:));
        x=x(isfinite(x));
        if ~isempty(x)
            repeatMSE(ig,r)=mean(x);
        end
    end
end

CV=select_plateau_scalar(grid,repeatMSE,cfg.cvPlateau);
CV.splitMSE=splitMSE;
CV.splitBuffer=splitBuffer;
CV.foldLabels=folds;
end



function CV=select_fault_c0_eps_interpcv( ...
    mesh,H,obs,uRange,vRange,G,cfg,R,K)
% Joint sparse-data selection of global smoothness c0 and the minimum
% fault-normal regularization ratio epsilon_min.

cGrid=cfg.femC0Grid(:);
eGrid=cfg.faultEpsGrid(:);
folds=checkerboard_spatial_folds_local(obs.uv,R,K,uRange,vRange,cfg);

nc=numel(cGrid);
ne=numel(eGrid);
splitMSE=nan(nc,ne,R,K);
splitBuffer=nan(R,K);

% Assemble one stiffness matrix for each epsilon candidate.
Ks=cell(ne,1);
for ie=1:ne
    cfgE=cfg;
    cfgE.faultEpsMin=eGrid(ie);
    Ks{ie}=assemble_fault_stiffness(mesh,G,cfgE);
end

for r=1:R
    for k=1:K
        [tr,te,usedBuffer,valid]=buffered_checkerboard_split_local( ...
            obs,folds(:,r),k,G,cfg);
        splitBuffer(r,k)=usedBuffer;
        if ~valid, continue; end

        Htr=H(tr,:);
        Hte=H(te,:);
        ztr=obs.z(tr);
        zte=obs.z(te);

        for ie=1:ne
            Kf=Ks{ie};
            for ic=1:nc
                c0=cGrid(ic);
                A=c0*Kf+Htr.'*Htr;
                b=Htr.'*ztr;
                A=0.5*(A+A.');
                ridge=1e-12*max(mean(abs(diag(A))),1);
                A=A+ridge*speye(size(A,1));
                U=A\b;
                e=Hte*U-zte;
                splitMSE(ic,ie,r,k)=mean(e.^2);
            end
        end
    end
end

meanMSE=nan(nc,ne);
seMSE=nan(nc,ne);
nValid=zeros(nc,ne);

for ic=1:nc
    for ie=1:ne
        x=squeeze(splitMSE(ic,ie,:,:));
        x=x(isfinite(x));
        nValid(ic,ie)=numel(x);
        if isempty(x), continue; end
        meanMSE(ic,ie)=mean(x);
        if numel(x)>1
            seMSE(ic,ie)=std(x,0)/sqrt(numel(x));
        else
            seMSE(ic,ie)=0;
        end
    end
end

[best,lin]=min(meanMSE(:));
if ~isfinite(best)
    error('Joint (c0, epsilon_min) CV failed: no finite risk.');
end
[ic,ie]=ind2sub(size(meanMSE),lin);

CV=struct();
CV.c0Grid=cGrid;
CV.epsGrid=eGrid;
CV.meanMSE=meanMSE;
CV.seMSE=seMSE;
CV.nValid=nValid;
CV.splitMSE=splitMSE;
CV.splitBuffer=splitBuffer;
CV.foldLabels=folds;
CV.rawIndexC0=ic;
CV.rawIndexEps=ie;
CV.rawValue=cGrid(ic);
CV.rawEps=eGrid(ie);
CV.rawMSE=best;
CV.selectedIndexC0=ic;
CV.selectedIndexEps=ie;
CV.value=cGrid(ic);
CV.epsValue=eGrid(ie);
CV.selectedMSE=best;
end


function CV=select_tps_lambda_interpcv(obs,uRange,vRange,G,cfg,R,K)
grid=cfg.tpsLambdaGrid(:);
folds=checkerboard_spatial_folds_local(obs.uv,R,K,uRange,vRange,cfg);

splitMSE=nan(numel(grid),R,K);
splitBuffer=nan(R,K);
scale=coordinate_scale(obs.uv);

for r=1:R
    for k=1:K
        [tr,te,usedBuffer,valid]=buffered_checkerboard_split_local( ...
            obs,folds(:,r),k,G,cfg);

        splitBuffer(r,k)=usedBuffer;

        if ~valid || nnz(tr)<6
            continue;
        end

        for ig=1:numel(grid)
            mdl=fit_tps(obs.uv(tr,:),obs.z(tr),grid(ig),scale);
            pred=tps_predict(mdl,obs.uv(te,:));
            e=pred-obs.z(te);
            splitMSE(ig,r,k)=mean(e.^2);
        end
    end
end

repeatMSE=nan(numel(grid),R);
for ig=1:numel(grid)
    for r=1:R
        x=squeeze(splitMSE(ig,r,:));
        x=x(isfinite(x));
        if ~isempty(x)
            repeatMSE(ig,r)=mean(x);
        end
    end
end

CV=select_plateau_scalar(grid,repeatMSE,cfg.cvPlateau);
CV.splitMSE=splitMSE;
CV.splitBuffer=splitBuffer;
CV.foldLabels=folds;
end


function [CV,meshCV]=select_fault_c0_nested_local( ...
    obsTr,G,uRange,vRange,cfg)

meshCV=uniform_mesh_under_budget(uRange,vRange,cfg.cvNodeBudget);
H=build_interp_matrix(meshCV,obsTr.uv);

CV=select_fault_c0_eps_interpcv( ...
    meshCV,H,obsTr,uRange,vRange,G,cfg, ...
    cfg.interpCVInnerRepeats,cfg.interpCVInnerFolds);
end



% =========================================================================
% PARAMETER-REDUCED PREDICTIVE RISKS
% =========================================================================
function [faultMSE,w,sigmaUsed,neff]=fault_weighted_mse_local(e,uv,G,cfg)
% Fault-weighted predictive risk using the same geometry-derived sigma_Gamma
% as the reconstruction tensor. No floor, expansion schedule, or alpha is used.
phi=abs(fault_phi(uv,G));
gate=fault_gate(uv(:,1),G,cfg);
sigmaUsed=cfg.faultSigmaMin;

w=exp(-0.5*(phi/sigmaUsed).^2).*gate;
sw=sum(w);

if ~(isfinite(sw) && sw>eps)
    error('Fault-weighted CV risk is undefined for this split.');
end

neff=(sw^2)/max(sum(w.^2),eps);
faultMSE=sum(w.*(e.^2))/sw;
end


function [globalMSE,faultMSE,diag]=predictive_risks_paramred_v2(e,uv,G,cfg)
globalMSE=mean(e.^2);
[faultMSE,w,sigmaUsed,neff]=fault_weighted_mse_local(e,uv,G,cfg);

diag=struct();
diag.sigmaUsed=sigmaUsed;
diag.faultWeightNeff=neff;
diag.faultWeightSum=sum(w);
diag.maxFaultWeight=max(w);
diag.minFaultWeight=min(w);
end


function [mu,se,n]=aggregate_split_metric_local(X,ib)
x=squeeze(X(ib,:,:));
x=x(isfinite(x));
n=numel(x);

if isempty(x)
    mu=nan;
    se=nan;
elseif numel(x)==1
    mu=x;
    se=0;
else
    mu=mean(x);
    se=std(x,0)/sqrt(numel(x));
end
end


function S=one_se_budget_selection_local(budgets,meanRisk,seRisk)
[best,ib]=min(meanRisk);

if ~isfinite(best)
    error('Engineering-risk selector has no finite CV risk.');
end

bestSE=seRisk(ib);
if ~isfinite(bestSE), bestSE=0; end

threshold=best+bestSE;
eligible=isfinite(meanRisk) & meanRisk<=threshold;

isel=find(eligible,1,'first');
if isempty(isel), isel=ib; end

S=struct();
S.rawBestIndex=ib;
S.rawBestBudget=budgets(ib);
S.rawBestRisk=best;
S.rawBestSE=bestSE;
S.oneSEThreshold=threshold;
S.eligible=eligible;
S.selectedIndex=isel;
S.selectedBudget=budgets(isel);
S.selectedRisk=meanRisk(isel);
end


function [Tcurve,Tsummary]=alpha_sensitivity_from_splits_local( ...
    budgets,globalSplit,faultSplit,meanNodes,alphas)

curveRows=cell(0,1);
summaryRows=cell(0,1);
rc=0;
rs=0;

for ia=1:numel(alphas)
    alpha=alphas(ia);
    riskSplit=(1-alpha)*globalSplit + alpha*faultSplit;

    nb=numel(budgets);
    mu=nan(nb,1);
    se=nan(nb,1);
    nv=nan(nb,1);

    for ib=1:nb
        [mu(ib),se(ib),nv(ib)]=aggregate_split_metric_local(riskSplit,ib);
    end

    Sel=one_se_budget_selection_local(budgets,mu,se);

    for ib=1:nb
        rc=rc+1;
        Alpha=alpha;
        Budget=budgets(ib);
        MeanActualNodes=meanNodes(ib);
        EngRisk=mu(ib);
        EngSE=se(ib);
        NValidSplits=nv(ib);
        EligibleOneSE=Sel.eligible(ib);
        Selected=ib==Sel.selectedIndex;

        curveRows{rc,1}=table(Alpha,Budget,MeanActualNodes, ...
            EngRisk,EngSE,NValidSplits,EligibleOneSE,Selected); %#ok<AGROW>
    end

    rs=rs+1;
    Alpha=alpha;
    RawBestBudget=Sel.rawBestBudget;
    RawBestRisk=Sel.rawBestRisk;
    RawBestSE=Sel.rawBestSE;
    OneSEThreshold=Sel.oneSEThreshold;
    SelectedBudget=Sel.selectedBudget;
    SelectedRisk=Sel.selectedRisk;
    SelectedMeanNodes=meanNodes(Sel.selectedIndex);

    summaryRows{rs,1}=table(Alpha,RawBestBudget,RawBestRisk,RawBestSE, ...
        OneSEThreshold,SelectedBudget,SelectedRisk,SelectedMeanNodes); %#ok<AGROW>
end

Tcurve=vertcat(curveRows{:});
Tsummary=vertcat(summaryRows{:});
end


function CV=crossfit_afem_stopping_paramred_v2(obs,G,uRange,vRange,cfg)
budgets=cfg.nodeBudgets(:);
nb=numel(budgets);
R=cfg.interpCVOuterRepeats;
K=cfg.interpCVOuterFolds;

folds=checkerboard_spatial_folds_local(obs.uv,R,K,uRange,vRange,cfg);

outerGlobal=nan(nb,R,K);
outerFault=nan(nb,R,K);
outerNodes=nan(nb,R,K);

outerBuffer=nan(R,K);
outerC0=nan(R,K);
outerEps=nan(R,K);
outerFaultSigma=nan(R,K);
outerFaultNeff=nan(R,K);

detailRows=cell(0,1);
c0Rows=cell(0,1);
rd=0;
rc=0;

cfgCV=cfg;
cfgCV.afemMaxAdaptPerBudget=cfg.interpCVMaxAdaptPerBudget;

fprintf('  Strict nested dual-risk spatial CV begins ...\n');

for r=1:R
    fprintf('    outer repeat %d/%d\n',r,R);

    for k=1:K
        [tr,te,usedBuffer,valid]=buffered_checkerboard_split_local( ...
            obs,folds(:,r),k,G,cfg);

        outerBuffer(r,k)=usedBuffer;

        if ~valid
            fprintf('      fold %d: skipped (insufficient buffered split)\n',k);
            continue;
        end

        obsTr=subset_obs_local(obs,tr);
        obsTe=subset_obs_local(obs,te);

        % Strict nesting: both c0 and epsilon_min see only outer training data.
        [cvPair,~]=select_fault_c0_nested_local( ...
            obsTr,G,uRange,vRange,cfg);

        c0Fold=cvPair.value;
        epsFold=cvPair.epsValue;
        outerC0(r,k)=c0Fold;
        outerEps(r,k)=epsFold;

        rc=rc+1;
        c0Rows{rc,1}=table( ...
            r,k,usedBuffer,nnz(tr),nnz(te), ...
            c0Fold,epsFold,cvPair.selectedMSE, ...
            'VariableNames',{'Repeat','Fold','UsedBuffer','NTrain','NTest', ...
            'SelectedC0','SelectedEpsilonMin','InnerSelectedMSE'}); %#ok<AGROW>

        initBudget=min(cfg.afemInitialNodeBudget,min(budgets)-1);
        mesh=uniform_mesh_under_budget(uRange,vRange,initBudget);

        cfgFold=cfgCV;
        cfgFold.faultEpsMin=epsFold;

        fprintf(['      fold %d | train/test=%d/%d | buffer=%.1f m | ', ...
            'nested c0=%.4e | eps=%.4f\n'], ...
            k,nnz(tr),nnz(te),usedBuffer,c0Fold,epsFold);

        for ib=1:nb
            [sol,mesh,~]=adapt_fault_mesh_to_budget( ...
                mesh,budgets(ib),obsTr,G,c0Fold,cfgFold);

            pred=predict_solution(sol,obsTe.uv);
            e=pred-obsTe.z;

            [gMSE,fMSE,D]=predictive_risks_paramred_v2( ...
                e,obsTe.uv,G,cfgFold);

            outerGlobal(ib,r,k)=gMSE;
            outerFault(ib,r,k)=fMSE;
            outerNodes(ib,r,k)=size(mesh.P,1);

            if ib==1
                outerFaultSigma(r,k)=D.sigmaUsed;
                outerFaultNeff(r,k)=D.faultWeightNeff;
            end

            rd=rd+1;
            detailRows{rd,1}=table( ...
                r,k,budgets(ib),size(mesh.P,1),usedBuffer,c0Fold,epsFold, ...
                nnz(tr),nnz(te),gMSE,fMSE, ...
                D.sigmaUsed,D.faultWeightNeff,D.faultWeightSum, ...
                'VariableNames',{'Repeat','Fold','Budget','ActualNodes', ...
                'UsedBuffer','NestedC0','NestedEpsilonMin','NTrain','NTest', ...
                'GlobalMSE','FaultWeightedMSE', ...
                'FaultWeightSigma','FaultWeightNeff','FaultWeightSum'}); %#ok<AGROW>
        end
    end
end

meanGlobal=nan(nb,1); seGlobal=nan(nb,1);
meanFault=nan(nb,1);  seFault=nan(nb,1);
meanNodes=nan(nb,1);  stdNodes=nan(nb,1);
nValid=nan(nb,1);

for ib=1:nb
    [meanGlobal(ib),seGlobal(ib),nValid(ib)]=aggregate_split_metric_local(outerGlobal,ib);
    [meanFault(ib),seFault(ib),~]=aggregate_split_metric_local(outerFault,ib);

    n=squeeze(outerNodes(ib,:,:));
    n=n(isfinite(n));
    if ~isempty(n)
        meanNodes(ib)=mean(n);
        if numel(n)>1, stdNodes(ib)=std(n,0); else, stdNodes(ib)=0; end
    end
end

SelG=one_se_budget_selection_local(budgets,meanGlobal,seGlobal);
SelF=one_se_budget_selection_local(budgets,meanFault,seFault);

globalThreshold=SelG.oneSEThreshold;
faultThreshold=SelF.oneSEThreshold;

predictiveEligible=SelG.eligible & SelF.eligible;
predictiveCertified=any(predictiveEligible);

% Dimensionless compatibility score.  JointScore<=1 is exactly equivalent
% to satisfying both independent one-SE predictive constraints.
jointScore=max(meanGlobal/max(globalThreshold,eps), ...
               meanFault/max(faultThreshold,eps));
jointSE=zeros(size(jointScore));

if predictiveCertified
    iSel=find(predictiveEligible,1,'first');
else
    [~,iSel]=min(jointScore);
end

[rawBestRisk,rawBestIndex]=min(jointScore);
Selected=false(nb,1);
Selected(iSel)=true;

T=table(budgets,meanNodes,stdNodes,nValid, ...
    meanGlobal,seGlobal,meanFault,seFault,jointScore,jointSE, ...
    SelG.eligible,SelF.eligible,predictiveEligible,Selected, ...
    'VariableNames',{'Budget','MeanActualNodes','StdActualNodes', ...
    'NValidSplits','CV_GlobalMSE','CV_GlobalSE', ...
    'CV_FaultMSE','CV_FaultSE','CV_EngRisk','CV_EngSE', ...
    'Eligible_GlobalOneSE','Eligible_FaultOneSE', ...
    'Eligible_EngOneSE','Selected'});

if isempty(detailRows), outerTable=table(); else, outerTable=vertcat(detailRows{:}); end
if isempty(c0Rows), c0Table=table(); else, c0Table=vertcat(c0Rows{:}); end

CV=struct();
CV.alpha=nan;
CV.budgets=budgets;
CV.foldLabels=folds;
CV.outerGlobal=outerGlobal;
CV.outerFault=outerFault;
CV.outerEng=nan(size(outerGlobal));
CV.outerNodes=outerNodes;
CV.outerBuffer=outerBuffer;
CV.outerC0=outerC0;
CV.outerEps=outerEps;
CV.outerFaultSigma=outerFaultSigma;
CV.outerFaultNeff=outerFaultNeff;

CV.meanGlobal=meanGlobal;
CV.seGlobal=seGlobal;
CV.meanFault=meanFault;
CV.seFault=seFault;
CV.meanEng=jointScore;
CV.seEng=jointSE;
CV.meanNodes=meanNodes;
CV.stdNodes=stdNodes;
CV.nValid=nValid;

CV.globalThreshold=globalThreshold;
CV.faultThreshold=faultThreshold;
CV.globalRawBestBudget=SelG.rawBestBudget;
CV.faultRawBestBudget=SelF.rawBestBudget;
CV.predictiveEligible=predictiveEligible;
CV.predictiveCertified=predictiveCertified;

CV.table=T;
CV.outerTable=outerTable;
CV.c0Table=c0Table;
CV.alphaCurveTable=table();
CV.alphaTable=table();

CV.rawBestIndex=rawBestIndex;
CV.rawBestBudget=budgets(rawBestIndex);
CV.rawBestRisk=rawBestRisk;
CV.rawBestSE=0;
CV.oneSEThreshold=1;

CV.selectedIndex=iSel;
CV.selectedBudget=budgets(iSel);
CV.selectedRisk=jointScore(iSel);
CV.selectedGlobalMSE=meanGlobal(iSel);
CV.selectedFaultMSE=meanFault(iSel);
CV.selectedMeanNodes=meanNodes(iSel);

CV.rawBestMSE=rawBestRisk;
CV.selectedMSE=jointScore(iSel);
CV.meanMSE=jointScore;
CV.seMSE=jointSE;

% Compatibility fields retained for old range-audit helpers.
CV.selectedBudget005=CV.selectedBudget;
CV.selectedBudget010=CV.selectedBudget;
CV.selectedBudget020=CV.selectedBudget;
end


function plot_predictive_dual_guard_paramred_v2(outDir,CV,cfg)
f=figure('Color','w','Units','pixels','Position',[100 100 1500 520]);
tl=tiledlayout(f,1,3,'Padding','compact','TileSpacing','compact');

ax=nexttile(tl,1);
errorbar(ax,CV.budgets,CV.meanGlobal,CV.seGlobal,'-o','LineWidth',1.4);
hold(ax,'on');
yline(ax,CV.globalThreshold,'--','LineWidth',1.2);
xlabel(ax,'node budget'); ylabel(ax,'global spatial-CV MSE');
title(ax,'Global predictive constraint'); grid(ax,'on');

ax=nexttile(tl,2);
errorbar(ax,CV.budgets,CV.meanFault,CV.seFault,'-s','LineWidth',1.4);
hold(ax,'on');
yline(ax,CV.faultThreshold,'--','LineWidth',1.2);
xlabel(ax,'node budget'); ylabel(ax,'fault-weighted spatial-CV MSE');
title(ax,'Fault predictive constraint'); grid(ax,'on');

ax=nexttile(tl,3);
stairs(ax,CV.budgets,double(CV.predictiveEligible),'-d','LineWidth',1.5);
hold(ax,'on');
xline(ax,CV.selectedBudget,'-.','LineWidth',1.3);
ylim(ax,[-0.05 1.15]); yticks(ax,[0 1]); yticklabels(ax,{'no','yes'});
xlabel(ax,'node budget'); ylabel(ax,'jointly admissible');
title(ax,sprintf('Intersection of one-SE sets | certified=%d',CV.predictiveCertified));
grid(ax,'on');

title(tl,'Parameter-reduced predictive stopping');
save_figure(f,fullfile(outDir,'FIG_05_PREDICTIVE_DUAL_GUARD.png'),cfg);
end


function plot_afem_engcv_stop(outDir,CV,cfg)
f=figure('Color','w','Units','pixels','Position',[100 100 1550 520]);
tl=tiledlayout(f,1,3,'Padding','compact','TileSpacing','compact');

% Global predictive risk.
ax=nexttile(tl,1);
errorbar(ax,CV.meanNodes,CV.meanGlobal,CV.seGlobal,'-o', ...
    'LineWidth',1.4,'MarkerSize',6);
grid(ax,'on');
xlabel(ax,'mean actual AFEM nodes');
ylabel(ax,'CV global MSE');
title(ax,'Global interpolation risk');

% Fault-sensitive predictive risk.
ax=nexttile(tl,2);
errorbar(ax,CV.meanNodes,CV.meanFault,CV.seFault,'-o', ...
    'LineWidth',1.4,'MarkerSize',6);
grid(ax,'on');
xlabel(ax,'mean actual AFEM nodes');
ylabel(ax,'fault-weighted CV MSE');
title(ax,'Fault-sensitive risk');

% Formal engineering risk.
ax=nexttile(tl,3);
errorbar(ax,CV.meanNodes,CV.meanEng,CV.seEng,'-o', ...
    'LineWidth',1.4,'MarkerSize',6);
hold(ax,'on');

i=CV.selectedIndex;
plot(ax,CV.meanNodes(i),CV.meanEng(i),'s', ...
    'MarkerSize',12,'LineWidth',2);

yline(ax,CV.oneSEThreshold,'--', ...
    sprintf('one-SE threshold %.3g',CV.oneSEThreshold), ...
    'LineWidth',1.1);

grid(ax,'on');
xlabel(ax,'mean actual AFEM nodes');
ylabel(ax,'engineering CV risk');
title(ax,sprintf('Formal risk, \\alpha=%.2f | selected %d', ...
    cfg.engCVAlpha,CV.selectedBudget));
legend(ax,{'CV mean \pm SE','selected level','one-SE threshold'}, ...
    'Location','best');

title(tl,'Engineering-risk-aligned AFEM stopping');

save_figure(f,fullfile(outDir,'FIG_04_AFEM_ENGCV_stop.png'),cfg);
end


function plot_engcv_alpha_sensitivity(outDir,CV,cfg)
T=CV.alphaCurveTable;
alphas=unique(T.Alpha,'stable');

f=figure('Color','w','Units','pixels','Position',[150 150 1080 700]);
hold on;

for ia=1:numel(alphas)
    a=alphas(ia);
    m=abs(T.Alpha-a)<1e-12;
    TT=T(m,:);
    [~,ord]=sort(TT.MeanActualNodes);
    TT=TT(ord,:);

    errorbar(TT.MeanActualNodes,TT.EngRisk,TT.EngSE,'-o', ...
        'LineWidth',1.3,'MarkerSize',6);

    isel=find(TT.Selected,1);
    if ~isempty(isel)
        plot(TT.MeanActualNodes(isel),TT.EngRisk(isel),'s', ...
            'MarkerSize',10,'LineWidth',1.8);
    end
end

grid on;
xlabel('mean actual AFEM nodes');
ylabel('engineering CV risk');
title('Engineering-risk sensitivity to fault emphasis \alpha');

leg=cell(1,numel(alphas));
for ia=1:numel(alphas)
    leg{ia}=sprintf('\\alpha=%.2f',alphas(ia));
end
legend(leg,'Location','best');

save_figure(f,fullfile(outDir,'FIG_05_ENGCV_alpha_sensitivity.png'),cfg);
end


function T=make_afem_main_table_v4( ...
    sols,M,meshUniform,meshAF,cvTPS,cvIso,cvFault,stopCV,cfg)

n=numel(sols);

Method=cell(n,1);
Hyperparameter=cell(n,1);
Nodes=nan(n,1);
Triangles=nan(n,1);
Unknowns=nan(n,1);

StopBudget=nan(n,1);
StopAlpha=nan(n,1);
StopGlobalCV=nan(n,1);
StopFaultCV=nan(n,1);
StopEngCV=nan(n,1);
StopEngSE=nan(n,1);

RMSE_all=nan(n,1);
RMSE_fault=nan(n,1);
RMSE_bg=nan(n,1);
Jump0MAE=nan(n,1);
Jump0RMSE=nan(n,1);
DataRMSE=nan(n,1);

for i=1:n
    Method{i}=sols{i}.name;
    Unknowns(i)=M{i}.nUnknowns;
    RMSE_all(i)=M{i}.RMSE_all;
    RMSE_fault(i)=M{i}.RMSE_fault;
    RMSE_bg(i)=M{i}.RMSE_bg;
    Jump0MAE(i)=M{i}.Jump0MAE;
    Jump0RMSE(i)=M{i}.Jump0RMSE;
    DataRMSE(i)=M{i}.dataRMSE;
end

Hyperparameter{1}=sprintf('lambda=%.4g',cvTPS.value);
Hyperparameter{2}=sprintf('c0=%.4g',cvIso.value);
Hyperparameter{3}=sprintf('c0=%.4g; eps=%.3g',cvFault.value,cvFault.epsValue);
Hyperparameter{4}=sprintf(['c0=%.4g; eps=%.3g; ', ...
    'dual-risk CV + data-scaled structural stop'], ...
    cvFault.value,cvFault.epsValue);

Nodes(1)=size(sols{1}.model.uv,1)+3;
Triangles(1)=nan;
Nodes(2)=size(meshUniform.P,1); Triangles(2)=size(meshUniform.T,1);
Nodes(3)=size(meshUniform.P,1); Triangles(3)=size(meshUniform.T,1);
Nodes(4)=size(meshAF.P,1); Triangles(4)=size(meshAF.T,1);

StopBudget(4)=stopCV.selectedBudget;
StopAlpha(4)=stopCV.alpha;
StopGlobalCV(4)=stopCV.selectedGlobalMSE;
StopFaultCV(4)=stopCV.selectedFaultMSE;
StopEngCV(4)=stopCV.selectedRisk;
StopEngSE(4)=stopCV.seEng(stopCV.selectedIndex);

ref=3;
ImproveAllVsFaultUniformPct=100*(RMSE_all(ref)-RMSE_all)./RMSE_all(ref);
ImproveFaultVsFaultUniformPct=100*(RMSE_fault(ref)-RMSE_fault)./RMSE_fault(ref);
ImproveJumpVsFaultUniformPct=100*(Jump0MAE(ref)-Jump0MAE)./Jump0MAE(ref);

T=table(Method,Hyperparameter,Nodes,Triangles,Unknowns, ...
    StopBudget,StopAlpha,StopGlobalCV,StopFaultCV,StopEngCV,StopEngSE, ...
    RMSE_all,RMSE_fault,RMSE_bg,Jump0MAE,Jump0RMSE,DataRMSE, ...
    ImproveAllVsFaultUniformPct,ImproveFaultVsFaultUniformPct, ...
    ImproveJumpVsFaultUniformPct);
end


function plot_uniform_vs_adaptive_mesh_v4(outDir,meshU,meshA,G,stopCV,cfg)
f=figure('Color','w','Units','pixels','Position',[100 100 1350 640]);
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

meshes={meshU,meshA};
titles={sprintf('Uniform fault FEM: %d nodes',size(meshU.P,1)), ...
        sprintf('ENGCV-stopped fault AFEM: %d nodes',size(meshA.P,1))};

for i=1:2
    ax=nexttile(tl,i);

    triplot(meshes{i}.T,meshes{i}.P(:,1),meshes{i}.P(:,2), ...
        'Parent',ax,'LineWidth',0.45);
    hold(ax,'on');

    uu=linspace(G.uMin,G.uMax,500);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'r-','LineWidth',2);

    axis(ax,'equal');
    axis(ax,'tight');
    xlabel(ax,'u (m)');
    ylabel(ax,'v (m)');
    title(ax,titles{i});
end

title(tl,sprintf('Engineering CV \\alpha=%.2f | selected budget=%d', ...
    cfg.engCVAlpha,stopCV.selectedBudget));

save_figure(f,fullfile(outDir,'FIG_10_ENGCV_uniform_vs_adaptive_mesh.png'),cfg);
end


function write_afem_diagnostic_summary_v4( ...
    outDir,mainTable,budgetTable,effTable,stopCV,cvFault,cfg)

fid=fopen(fullfile(outDir,'DIAGNOSTIC_summary_V4.txt'),'w');
if fid<0, return; end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'REAL_C11_FAULT_AFEM_PARAMETER_REDUCED_V2 diagnostic summary\n');
fprintf(fid,'================================================\n\n');

fprintf(fid,'FORMAL TRUTH-FREE ENGINEERING STOPPING\n');
fprintf(fid,'--------------------------------------\n');
fprintf(fid,'outer split         = buffered checkerboard interpolation CV\n');
fprintf(fid,'outer repeats/folds = %d / %d\n', ...
    cfg.interpCVOuterRepeats,cfg.interpCVOuterFolds);
fprintf(fid,'nested c0 repeats/folds = %d / %d\n', ...
    cfg.interpCVInnerRepeats,cfg.interpCVInnerFolds);
fprintf(fid,'requested buffer    = %.1f m\n',cfg.interpCVBuffer);
fprintf(fid,'formal alpha        = %.3f\n',cfg.engCVAlpha);
fprintf(fid,'fault sigma min     = %.3f m\n',cfg.engCVFaultSigmaMin);
fprintf(fid,'fault sigma factor  = %.3f x half-width95\n',cfg.engCVFaultSigmaFactor);
fprintf(fid,'raw best budget     = %d\n',stopCV.rawBestBudget);
fprintf(fid,'raw best EngRisk    = %.8g\n',stopCV.rawBestRisk);
fprintf(fid,'SE at raw best      = %.8g\n',stopCV.rawBestSE);
fprintf(fid,'one-SE threshold    = %.8g\n',stopCV.oneSEThreshold);
fprintf(fid,'selected budget     = %d\n',stopCV.selectedBudget);
fprintf(fid,'selected mean nodes = %.3f\n',stopCV.selectedMeanNodes);
fprintf(fid,'selected global MSE = %.8g\n',stopCV.selectedGlobalMSE);
fprintf(fid,'selected fault MSE  = %.8g\n',stopCV.selectedFaultMSE);
fprintf(fid,'selected EngRisk    = %.8g\n',stopCV.selectedRisk);
fprintf(fid,'0.5/1/2 pct audit   = %d / %d / %d\n\n', ...
    stopCV.selectedBudget005,stopCV.selectedBudget010,stopCV.selectedBudget020);

fprintf(fid,'ALPHA SENSITIVITY\n');
fprintf(fid,'-----------------\n');
for i=1:height(stopCV.alphaTable)
    fprintf(fid,['alpha=%.2f | raw best=%d | one-SE selected=%d | ', ...
        'selected mean nodes=%.2f\n'], ...
        stopCV.alphaTable.Alpha(i), ...
        stopCV.alphaTable.RawBestBudget(i), ...
        stopCV.alphaTable.SelectedBudget(i), ...
        stopCV.alphaTable.SelectedMeanNodes(i));
end

neff=stopCV.outerFaultNeff(isfinite(stopCV.outerFaultNeff));
sig=stopCV.outerFaultSigma(isfinite(stopCV.outerFaultSigma));

if ~isempty(neff)
    fprintf(fid,'\nFAULT-WEIGHT STABILITY\n');
    fprintf(fid,'----------------------\n');
    fprintf(fid,'effective N min/median/max = %.3f / %.3f / %.3f\n', ...
        min(neff),median(neff),max(neff));
    fprintf(fid,'used sigma min/median/max  = %.3f / %.3f / %.3f m\n', ...
        min(sig),median(sig),max(sig));
end

c0v=stopCV.outerC0(isfinite(stopCV.outerC0));
if ~isempty(c0v)
    fprintf(fid,'\nNESTED c0 STABILITY\n');
    fprintf(fid,'-------------------\n');
    fprintf(fid,'outer-fold c0 min/median/max = %.6g / %.6g / %.6g\n', ...
        min(c0v),median(c0v),max(c0v));
    fprintf(fid,'full-data c0               = %.6g\n',cvFault.value);
end

mU=strcmp(mainTable.Method,'FAULT-FEM');
mA=strcmp(mainTable.Method,'FAULT-AFEM');

if any(mU) && any(mA)
    u=mainTable(mU,:);
    a=mainTable(mA,:);

    gAll=100*(u.RMSE_all-a.RMSE_all)/u.RMSE_all;
    gFault=100*(u.RMSE_fault-a.RMSE_fault)/u.RMSE_fault;
    gJump=100*(u.Jump0MAE-a.Jump0MAE)/u.Jump0MAE;

    fprintf(fid,'\nDENSE INTERPRETED-REFERENCE AUDIT AFTER STOPPING\n');
    fprintf(fid,'------------------------------------------------\n');
    fprintf(fid,'uniform actual nodes = %d\n',u.Nodes);
    fprintf(fid,'AFEM actual nodes    = %d\n',a.Nodes);
    fprintf(fid,'AFEM vs matched uniform FAULT-FEM:\n');
    fprintf(fid,'  RMSE_all gain   = %.3f %%\n',gAll);
    fprintf(fid,'  RMSE_fault gain = %.3f %%\n',gFault);
    fprintf(fid,'  Jump0MAE gain   = %.3f %%\n',gJump);
end

fprintf(fid,'\nACCURACY--DOF RETROSPECTIVE EFFICIENCY\n');
fprintf(fid,'--------------------------------------\n');

for i=1:height(effTable)
    if effTable.Matched(i)
        fprintf(fid,['uniform nodes=%d, target fault RMSE=%.4f -> ', ...
            'AFEM nodes=%d, RMSE=%.4f, node saving=%.2f %%\n'], ...
            effTable.UniformNodes(i),effTable.UniformFaultRMSE(i), ...
            effTable.AFEMNodesToMatch(i),effTable.AFEMFaultRMSE(i), ...
            effTable.NodeSavingPct(i));
    else
        fprintf(fid,['uniform nodes=%d, target fault RMSE=%.4f -> ', ...
            'not matched by tested AFEM levels\n'], ...
            effTable.UniformNodes(i),effTable.UniformFaultRMSE(i));
    end
end

fprintf(fid,'\nINTERPRETATION RULE\n');
fprintf(fid,'-------------------\n');
fprintf(fid,['Formal alpha=0.50 is fixed before dense-reference evaluation. ', ...
    'The alpha audit is diagnostic only and must not be cherry-picked.\n']);
fprintf(fid,['Engineering stopping is supported only if the selected level and nearby ', ...
    'alpha audits are reasonably stable and the post-selection fault-band ', ...
    'accuracy remains competitive with matched uniform FAULT-FEM.\n']);
fprintf(fid,['Dense C11 accuracy and DOF-savings tables are retrospective evaluation ', ...
    'only; they are not inputs to alpha or stopping selection.\n']);
end


function CV=crossfit_afem_stopping_interpcv(obs,G,uRange,vRange,cfg)
budgets=cfg.nodeBudgets(:);
nb=numel(budgets);
R=cfg.interpCVOuterRepeats;
K=cfg.interpCVOuterFolds;

folds=checkerboard_spatial_folds_local(obs.uv,R,K,uRange,vRange,cfg);

outerMSE=nan(nb,R,K);
outerNodes=nan(nb,R,K);
outerBuffer=nan(R,K);
outerC0=nan(R,K);

detailRows=cell(0,1);
c0Rows=cell(0,1);
rd=0;
rc=0;

cfgCV=cfg;
cfgCV.afemMaxAdaptPerBudget=cfg.interpCVMaxAdaptPerBudget;

fprintf('  Strict nested interpolation-CV begins ...\n');

for r=1:R
    fprintf('    outer repeat %d/%d\n',r,R);

    for k=1:K
        [tr,te,usedBuffer,valid]=buffered_checkerboard_split_local( ...
            obs,folds(:,r),k,G,cfg);

        outerBuffer(r,k)=usedBuffer;

        if ~valid
            fprintf('      fold %d: skipped (insufficient buffered split)\n',k);
            continue;
        end

        obsTr=subset_obs_local(obs,tr);
        obsTe=subset_obs_local(obs,te);

        % STRICT NESTING: c0 is selected exclusively from outer training data.
        [cvC0,~]=select_fault_c0_nested_local( ...
            obsTr,G,uRange,vRange,cfg);

        c0Fold=cvC0.value;
        outerC0(r,k)=c0Fold;

        rc=rc+1;
        c0Rows{rc,1}=table( ...
            r,k,usedBuffer,nnz(tr),nnz(te), ...
            cvC0.rawValue,cvC0.value,cvC0.rawMSE,cvC0.selectedMSE, ...
            'VariableNames',{'Repeat','Fold','UsedBuffer','NTrain','NTest', ...
            'RawC0','SelectedC0','InnerRawMSE','InnerSelectedMSE'}); %#ok<AGROW>

        initBudget=min(cfg.afemInitialNodeBudget,min(budgets)-1);
        mesh=uniform_mesh_under_budget(uRange,vRange,initBudget);

        fprintf(['      fold %d | train/test=%d/%d | buffer=%.1f m | ', ...
            'nested c0=%.4e\n'], ...
            k,nnz(tr),nnz(te),usedBuffer,c0Fold);

        for ib=1:nb
            [sol,mesh,~]=adapt_fault_mesh_to_budget( ...
                mesh,budgets(ib),obsTr,G,c0Fold,cfgCV);

            pred=predict_solution(sol,obsTe.uv);
            e=pred-obsTe.z;

            mse=mean(e.^2);
            outerMSE(ib,r,k)=mse;
            outerNodes(ib,r,k)=size(mesh.P,1);

            rd=rd+1;
            detailRows{rd,1}=table( ...
                r,k,budgets(ib),size(mesh.P,1), ...
                usedBuffer,c0Fold,nnz(tr),nnz(te),mse, ...
                'VariableNames',{'Repeat','Fold','Budget','ActualNodes', ...
                'UsedBuffer','NestedC0','NTrain','NTest','MSE'}); %#ok<AGROW>
        end
    end
end

% Split-level aggregation is deliberate here: unlike V2, the SE used by the
% one-SE rule reflects the variability across all distributed test blocks.
meanMSE=nan(nb,1);
seMSE=nan(nb,1);
meanNodes=nan(nb,1);
stdNodes=nan(nb,1);
nValid=nan(nb,1);

for ib=1:nb
    x=squeeze(outerMSE(ib,:,:));
    x=x(isfinite(x));

    n=squeeze(outerNodes(ib,:,:));
    n=n(isfinite(n));

    nValid(ib)=numel(x);

    if ~isempty(x)
        meanMSE(ib)=mean(x);
        if numel(x)>1
            seMSE(ib)=std(x,0)/sqrt(numel(x));
        else
            seMSE(ib)=0;
        end
    end

    if ~isempty(n)
        meanNodes(ib)=mean(n);
        if numel(n)>1
            stdNodes(ib)=std(n,0);
        else
            stdNodes(ib)=0;
        end
    end
end

[rawBestMSE,ibest]=min(meanMSE);
if ~isfinite(rawBestMSE)
    error('V3 interpolation-CV stopping failed: no finite MSE.');
end

rawBestSE=seMSE(ibest);
oneSEThreshold=rawBestMSE+rawBestSE;

eligibleOneSE=isfinite(meanMSE) & meanMSE<=oneSEThreshold;
iSel=find(eligibleOneSE,1,'first');
if isempty(iSel), iSel=ibest; end

selectedBudget=budgets(iSel);

% Near-minimum percentage audits only.
sel005=select_coarsest_plateau_budget_local(budgets,meanMSE,0.005);
sel010=select_coarsest_plateau_budget_local(budgets,meanMSE,0.010);
sel020=select_coarsest_plateau_budget_local(budgets,meanMSE,0.020);

Eligible005=isfinite(meanMSE) & meanMSE<=1.005*rawBestMSE;
Eligible010=isfinite(meanMSE) & meanMSE<=1.010*rawBestMSE;
Eligible020=isfinite(meanMSE) & meanMSE<=1.020*rawBestMSE;
Selected=budgets==selectedBudget;

T=table(budgets,meanNodes,stdNodes,nValid,meanMSE,seMSE, ...
    eligibleOneSE,Eligible005,Eligible010,Eligible020,Selected, ...
    'VariableNames',{'Budget','MeanActualNodes','StdActualNodes', ...
    'NValidSplits','CV_MSE','CV_SE','Eligible_OneSE', ...
    'Eligible_0p5pct','Eligible_1pct','Eligible_2pct','Selected'});

if isempty(detailRows)
    outerTable=table();
else
    outerTable=vertcat(detailRows{:});
end

if isempty(c0Rows)
    c0Table=table();
else
    c0Table=vertcat(c0Rows{:});
end

CV=struct();
CV.budgets=budgets;
CV.foldLabels=folds;
CV.outerMSE=outerMSE;
CV.outerNodes=outerNodes;
CV.outerBuffer=outerBuffer;
CV.outerC0=outerC0;
CV.meanMSE=meanMSE;
CV.seMSE=seMSE;
CV.meanNodes=meanNodes;
CV.stdNodes=stdNodes;
CV.nValid=nValid;
CV.table=T;
CV.outerTable=outerTable;
CV.c0Table=c0Table;
CV.rawBestIndex=ibest;
CV.rawBestBudget=budgets(ibest);
CV.rawBestMSE=rawBestMSE;
CV.rawBestSE=rawBestSE;
CV.oneSEThreshold=oneSEThreshold;
CV.selectedIndex=iSel;
CV.selectedBudget=selectedBudget;
CV.selectedMSE=meanMSE(iSel);
CV.selectedMeanNodes=meanNodes(iSel);
CV.selectedBudget005=sel005;
CV.selectedBudget010=sel010;
CV.selectedBudget020=sel020;
end


function plot_interpcv_fold_map(outDir,obs,G,uRange,vRange,cfg)
folds=checkerboard_spatial_folds_local( ...
    obs.uv,1,cfg.interpCVOuterFolds,uRange,vRange,cfg);
fidx=folds(:,1);

f=figure('Color','w','Units','pixels','Position',[160 160 1000 720]);
scatter(obs.uv(:,1),obs.uv(:,2),70,fidx,'filled');
hold on;

uu=linspace(G.uMin,G.uMax,500);
vc=interp1(G.uc,G.vc,uu,'linear','extrap');
plot(uu,vc,'k-','LineWidth',2);

xlim(uRange);
ylim(vRange);
axis equal;
grid on;
xlabel('u (m)');
ylabel('v (m)');
title(sprintf('Distributed checkerboard outer folds (%d x %d cells)', ...
    cfg.interpCVGrid(1),cfg.interpCVGrid(2)));
cb=colorbar;
cb.Label.String='outer fold label';

save_figure(f,fullfile(outDir,'FIG_03_INTERPCV_fold_map.png'),cfg);
end


function plot_afem_interpcv_stop(outDir,CV,cfg)
f=figure('Color','w','Units','pixels','Position',[160 160 1080 700]);

errorbar(CV.meanNodes,CV.meanMSE,CV.seMSE,'-o', ...
    'LineWidth',1.5,'MarkerSize',7);
hold on;

i=CV.selectedIndex;
plot(CV.meanNodes(i),CV.meanMSE(i),'s', ...
    'MarkerSize',12,'LineWidth',2);

yline(CV.oneSEThreshold,'--', ...
    sprintf('one-SE threshold = %.3g',CV.oneSEThreshold), ...
    'LineWidth',1.1);

grid on;
xlabel('mean actual AFEM nodes in outer CV');
ylabel('buffered-checkerboard outer CV MSE');
title(sprintf('Interpolation-oriented AFEM stopping | selected budget=%d', ...
    CV.selectedBudget));
legend({'CV mean \pm SE','selected coarsest one-SE level', ...
    'one-SE threshold'},'Location','best');

save_figure(f,fullfile(outDir,'FIG_04_AFEM_INTERPCV_stop.png'),cfg);
end


function T=make_afem_main_table_v3( ...
    sols,M,meshUniform,meshAF,cvTPS,cvIso,cvFault,stopCV,cfg)

n=numel(sols);

Method=cell(n,1);
Hyperparameter=cell(n,1);
Nodes=nan(n,1);
Triangles=nan(n,1);
Unknowns=nan(n,1);
RMSE_all=nan(n,1);
RMSE_fault=nan(n,1);
RMSE_bg=nan(n,1);
Jump0MAE=nan(n,1);
Jump0RMSE=nan(n,1);
DataRMSE=nan(n,1);
StopBudget=nan(n,1);
StopCV_MSE=nan(n,1);
StopCV_SE=nan(n,1);

for i=1:n
    Method{i}=sols{i}.name;
    Unknowns(i)=M{i}.nUnknowns;
    RMSE_all(i)=M{i}.RMSE_all;
    RMSE_fault(i)=M{i}.RMSE_fault;
    RMSE_bg(i)=M{i}.RMSE_bg;
    Jump0MAE(i)=M{i}.Jump0MAE;
    Jump0RMSE(i)=M{i}.Jump0RMSE;
    DataRMSE(i)=M{i}.dataRMSE;
end

Hyperparameter{1}=sprintf('lambda=%.4g',cvTPS.value);
Hyperparameter{2}=sprintf('c0=%.4g',cvIso.value);
Hyperparameter{3}=sprintf('c0=%.4g; eps=%.3g',cvFault.value,cvFault.epsValue);
Hyperparameter{4}=sprintf(['c0=%.4g; eps=%.3g; ', ...
    'dual one-SE stop'],cvFault.value,cvFault.epsValue);

Nodes(1)=size(sols{1}.model.uv,1)+3;
Triangles(1)=nan;
Nodes(2)=size(meshUniform.P,1); Triangles(2)=size(meshUniform.T,1);
Nodes(3)=size(meshUniform.P,1); Triangles(3)=size(meshUniform.T,1);
Nodes(4)=size(meshAF.P,1); Triangles(4)=size(meshAF.T,1);

StopBudget(4)=stopCV.selectedBudget;
StopCV_MSE(4)=stopCV.selectedMSE;
StopCV_SE(4)=stopCV.seMSE(stopCV.selectedIndex);

ref=3;
ImproveAllVsFaultUniformPct=100*(RMSE_all(ref)-RMSE_all)./RMSE_all(ref);
ImproveFaultVsFaultUniformPct=100*(RMSE_fault(ref)-RMSE_fault)./RMSE_fault(ref);
ImproveJumpVsFaultUniformPct=100*(Jump0MAE(ref)-Jump0MAE)./Jump0MAE(ref);

T=table(Method,Hyperparameter,Nodes,Triangles,Unknowns, ...
    StopBudget,StopCV_MSE,StopCV_SE,RMSE_all,RMSE_fault,RMSE_bg, ...
    Jump0MAE,Jump0RMSE,DataRMSE, ...
    ImproveAllVsFaultUniformPct,ImproveFaultVsFaultUniformPct, ...
    ImproveJumpVsFaultUniformPct);
end


function plot_uniform_vs_adaptive_mesh_v3(outDir,meshU,meshA,G,stopCV,cfg)
f=figure('Color','w','Units','pixels','Position',[100 100 1350 640]);
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

meshes={meshU,meshA};
titles={sprintf('Uniform fault FEM: %d nodes',size(meshU.P,1)), ...
        sprintf('INTERPCV-stopped fault AFEM: %d nodes',size(meshA.P,1))};

for i=1:2
    ax=nexttile(tl,i);
    triplot(meshes{i}.T,meshes{i}.P(:,1),meshes{i}.P(:,2), ...
        'Parent',ax,'LineWidth',0.45);
    hold(ax,'on');

    uu=linspace(G.uMin,G.uMax,500);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'r-','LineWidth',2);

    axis(ax,'equal');
    axis(ax,'tight');
    xlabel(ax,'u (m)');
    ylabel(ax,'v (m)');
    title(ax,titles{i});
end

title(tl,sprintf('Buffered-checkerboard one-SE stopping | budget=%d', ...
    stopCV.selectedBudget));

save_figure(f,fullfile(outDir,'FIG_10_INTERPCV_uniform_vs_adaptive_mesh.png'),cfg);
end


function write_afem_diagnostic_summary_v3( ...
    outDir,mainTable,budgetTable,effTable,stopCV,cvFault,cfg)

fid=fopen(fullfile(outDir,'DIAGNOSTIC_summary_V3.txt'),'w');
if fid<0, return; end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'REAL_C11_FAULT_AFEM_V3_INTERPCV diagnostic summary\n');
fprintf(fid,'===================================================\n\n');

fprintf(fid,'FORMAL TRUTH-FREE STOPPING\n');
fprintf(fid,'--------------------------\n');
fprintf(fid,'CV type               = buffered checkerboard interpolation CV\n');
fprintf(fid,'outer repeats/folds   = %d / %d\n', ...
    cfg.interpCVOuterRepeats,cfg.interpCVOuterFolds);
fprintf(fid,'inner c0 repeats/folds= %d / %d\n', ...
    cfg.interpCVInnerRepeats,cfg.interpCVInnerFolds);
fprintf(fid,'requested buffer      = %.1f m\n',cfg.interpCVBuffer);
fprintf(fid,'raw best budget       = %d\n',stopCV.rawBestBudget);
fprintf(fid,'raw best CV MSE       = %.8g\n',stopCV.rawBestMSE);
fprintf(fid,'SE at raw best        = %.8g\n',stopCV.rawBestSE);
fprintf(fid,'one-SE threshold      = %.8g\n',stopCV.oneSEThreshold);
fprintf(fid,'selected budget       = %d\n',stopCV.selectedBudget);
fprintf(fid,'selected CV MSE       = %.8g\n',stopCV.selectedMSE);
fprintf(fid,'selected mean nodes   = %.3f\n',stopCV.selectedMeanNodes);
fprintf(fid,'0.5/1/2 pct audit     = %d / %d / %d\n\n', ...
    stopCV.selectedBudget005,stopCV.selectedBudget010,stopCV.selectedBudget020);

c0v=stopCV.outerC0(isfinite(stopCV.outerC0));
if ~isempty(c0v)
    fprintf(fid,'NESTED c0 STABILITY\n');
    fprintf(fid,'-------------------\n');
    fprintf(fid,'outer-fold selected c0 min/median/max = %.6g / %.6g / %.6g\n', ...
        min(c0v),median(c0v),max(c0v));
    fprintf(fid,'full-data selected c0                 = %.6g\n\n',cvFault.value);
end

mU=strcmp(mainTable.Method,'FAULT-FEM');
mA=strcmp(mainTable.Method,'FAULT-AFEM');

if any(mU) && any(mA)
    u=mainTable(mU,:);
    a=mainTable(mA,:);

    gAll=100*(u.RMSE_all-a.RMSE_all)/u.RMSE_all;
    gFault=100*(u.RMSE_fault-a.RMSE_fault)/u.RMSE_fault;
    gJump=100*(u.Jump0MAE-a.Jump0MAE)/u.Jump0MAE;

    fprintf(fid,'DENSE INTERPRETED-REFERENCE AUDIT AFTER STOPPING\n');
    fprintf(fid,'------------------------------------------------\n');
    fprintf(fid,'uniform actual nodes = %d\n',u.Nodes);
    fprintf(fid,'AFEM actual nodes    = %d\n',a.Nodes);
    fprintf(fid,'AFEM vs matched uniform FAULT-FEM:\n');
    fprintf(fid,'  RMSE_all gain   = %.3f %%\n',gAll);
    fprintf(fid,'  RMSE_fault gain = %.3f %%\n',gFault);
    fprintf(fid,'  Jump0MAE gain   = %.3f %%\n\n',gJump);
end

fprintf(fid,'ACCURACY--DOF RETROSPECTIVE EFFICIENCY\n');
fprintf(fid,'--------------------------------------\n');

for i=1:height(effTable)
    if effTable.Matched(i)
        fprintf(fid,['uniform nodes=%d, target fault RMSE=%.4f -> ', ...
            'AFEM nodes=%d, RMSE=%.4f, node saving=%.2f %%\n'], ...
            effTable.UniformNodes(i),effTable.UniformFaultRMSE(i), ...
            effTable.AFEMNodesToMatch(i),effTable.AFEMFaultRMSE(i), ...
            effTable.NodeSavingPct(i));
    else
        fprintf(fid,['uniform nodes=%d, target fault RMSE=%.4f -> ', ...
            'not matched by tested AFEM levels\n'], ...
            effTable.UniformNodes(i),effTable.UniformFaultRMSE(i));
    end
end

fprintf(fid,'\nINTERPRETATION\n');
fprintf(fid,'--------------\n');
fprintf(fid,['V3 outer test cells are spatially distributed across the domain rather ', ...
    'than contiguous edge strips, so the stopping audit targets interpolation.\n']);
fprintf(fid,['Every outer split selects c0 from its training controls only; outer test ', ...
    'elevations do not influence smoothing strength or adaptive topology.\n']);
fprintf(fid,['The formal selector is the coarsest one-SE AFEM level. Dense-horizon ', ...
    'accuracy and DOF savings are retrospective evaluation only.\n']);
end


function CV=crossfit_afem_stopping_cv(obs,G,c0,uRange,vRange,cfg)
budgets=cfg.nodeBudgets(:);
nb=numel(budgets);
R=cfg.afemStopCVRepeats;
K=cfg.afemStopCVFolds;

folds=repeated_spatial_folds(obs.uv,R,K);

foldMSE=nan(nb,R,K);
foldNodes=nan(nb,R,K);
repeatMSE=nan(nb,R);
repeatNodes=nan(nb,R);

detailRows=cell(0,1);
rr=0;

cfgCV=cfg;
cfgCV.afemMaxAdaptPerBudget=cfg.afemStopMaxAdaptPerBudget;

fprintf('  Cross-fitted topology audit begins ...\n');

for r=1:R
    fprintf('    repeat %d/%d\n',r,R);

    repeatSSE=zeros(nb,1);
    repeatN=zeros(nb,1);
    repeatNodeSum=zeros(nb,1);
    repeatFoldCount=zeros(nb,1);

    for k=1:K
        tr=folds(:,r)~=k;
        te=folds(:,r)==k;

        if nnz(te)==0 || nnz(tr)<max(12,cfg.minControlsPerSide)
            continue;
        end

        obsTr=subset_obs_local(obs,tr);
        obsTe=subset_obs_local(obs,te);

        % Every fold builds its own hierarchy from TRAINING elevations only.
        initBudget=min(cfg.afemInitialNodeBudget,min(budgets)-1);
        mesh=uniform_mesh_under_budget(uRange,vRange,initBudget);

        for ib=1:nb
            [sol,mesh,~]=adapt_fault_mesh_to_budget( ...
                mesh,budgets(ib),obsTr,G,c0,cfgCV);

            pred=predict_solution(sol,obsTe.uv);
            e=pred-obsTe.z;

            mse=mean(e.^2);
            foldMSE(ib,r,k)=mse;
            foldNodes(ib,r,k)=size(mesh.P,1);

            repeatSSE(ib)=repeatSSE(ib)+sum(e.^2);
            repeatN(ib)=repeatN(ib)+numel(e);
            repeatNodeSum(ib)=repeatNodeSum(ib)+size(mesh.P,1);
            repeatFoldCount(ib)=repeatFoldCount(ib)+1;

            rr=rr+1;
            detailRows{rr,1}=table( ...
                r,k,budgets(ib),size(mesh.P,1),nnz(tr),nnz(te),mse, ...
                'VariableNames',{'Repeat','Fold','Budget','ActualNodes', ...
                'NTrain','NTest','MSE'}); %#ok<AGROW>
        end
    end

    for ib=1:nb
        if repeatN(ib)>0
            repeatMSE(ib,r)=repeatSSE(ib)/repeatN(ib);
        end
        if repeatFoldCount(ib)>0
            repeatNodes(ib,r)=repeatNodeSum(ib)/repeatFoldCount(ib);
        end
    end
end

meanMSE=nan(nb,1);
seMSE=nan(nb,1);
meanNodes=nan(nb,1);
stdNodes=nan(nb,1);

for ib=1:nb
    x=repeatMSE(ib,isfinite(repeatMSE(ib,:)));
    n=repeatNodes(ib,isfinite(repeatNodes(ib,:)));

    if ~isempty(x)
        meanMSE(ib)=mean(x);
        if numel(x)>1
            seMSE(ib)=std(x,0,2)/sqrt(numel(x));
        else
            seMSE(ib)=0;
        end
    end

    if ~isempty(n)
        meanNodes(ib)=mean(n);
        if numel(n)>1
            stdNodes(ib)=std(n,0,2);
        else
            stdNodes(ib)=0;
        end
    end
end

[rawBestMSE,ibest]=min(meanMSE);
if ~isfinite(rawBestMSE)
    error('AFEM stopping CV failed: no finite predictive MSE.');
end

selectedBudget=select_coarsest_plateau_budget_local( ...
    budgets,meanMSE,cfg.afemStopPlateau);
iSel=find(budgets==selectedBudget,1);

sel005=select_coarsest_plateau_budget_local(budgets,meanMSE,0.005);
sel010=select_coarsest_plateau_budget_local(budgets,meanMSE,0.010);
sel020=select_coarsest_plateau_budget_local(budgets,meanMSE,0.020);

Eligible005=meanMSE<=(1.005)*rawBestMSE;
Eligible010=meanMSE<=(1.010)*rawBestMSE;
Eligible020=meanMSE<=(1.020)*rawBestMSE;
Selected=budgets==selectedBudget;

T=table(budgets,meanNodes,stdNodes,meanMSE,seMSE, ...
    Eligible005,Eligible010,Eligible020,Selected, ...
    'VariableNames',{'Budget','MeanActualNodes','StdActualNodes', ...
    'CV_MSE','CV_SE','Eligible_0p5pct','Eligible_1pct', ...
    'Eligible_2pct','Selected'});

if isempty(detailRows)
    foldTable=table();
else
    foldTable=vertcat(detailRows{:});
end

CV=struct();
CV.budgets=budgets;
CV.foldMSE=foldMSE;
CV.foldNodes=foldNodes;
CV.repeatMSE=repeatMSE;
CV.repeatNodes=repeatNodes;
CV.meanMSE=meanMSE;
CV.seMSE=seMSE;
CV.meanNodes=meanNodes;
CV.stdNodes=stdNodes;
CV.table=T;
CV.foldTable=foldTable;
CV.rawBestIndex=ibest;
CV.rawBestBudget=budgets(ibest);
CV.rawBestMSE=rawBestMSE;
CV.selectedBudget=selectedBudget;
CV.selectedIndex=iSel;
CV.selectedMSE=meanMSE(iSel);
CV.relativePenalty=(meanMSE(iSel)-rawBestMSE)/rawBestMSE;
CV.selectedBudget005=sel005;
CV.selectedBudget010=sel010;
CV.selectedBudget020=sel020;
end


function budget=select_coarsest_plateau_budget_local(budgets,meanMSE,delta)
best=min(meanMSE);
eligible=isfinite(meanMSE) & meanMSE<=(1+delta)*best;
ii=find(eligible,1,'first');
if isempty(ii)
    [~,ii]=min(meanMSE);
end
budget=budgets(ii);
end


function O=subset_obs_local(obs,mask)
O=obs;
O.uv=obs.uv(mask,:);
O.z=obs.z(mask,:);
if isfield(obs,'w') && ~isempty(obs.w)
    O.w=obs.w(mask,:);
end
if isfield(obs,'idx') && ~isempty(obs.idx)
    O.idx=obs.idx(mask,:);
end
end


function plot_afem_stop_cv(outDir,CV,cfg)
f=figure('Color','w','Units','pixels','Position',[150 150 1050 680]);

errorbar(CV.meanNodes,CV.meanMSE,CV.seMSE,'-o', ...
    'LineWidth',1.5,'MarkerSize',7);
hold on;

i=CV.selectedIndex;
plot(CV.meanNodes(i),CV.meanMSE(i),'s', ...
    'MarkerSize',12,'LineWidth',2);

ymin=CV.rawBestMSE;
yline((1+cfg.afemStopPlateau)*ymin,'--', ...
    sprintf('%.1f%% plateau',100*cfg.afemStopPlateau), ...
    'LineWidth',1.1);

grid on;
xlabel('mean actual AFEM node count in cross-fitted folds');
ylabel('spatial-CV MSE');
title(sprintf('Cross-fitted AFEM stopping: selected budget %d',CV.selectedBudget));
legend({'CV mean \pm SE','selected coarsest near-minimum level', ...
    'near-minimum threshold'},'Location','best');

save_figure(f,fullfile(outDir,'FIG_03_AFEM_spatial_CV_stop.png'),cfg);
end


function T=make_afem_main_table_v2( ...
    sols,M,meshUniform,meshAF,cvTPS,cvIso,cvFault,stopCV,cfg)

n=numel(sols);

Method=cell(n,1);
Hyperparameter=cell(n,1);
Nodes=nan(n,1);
Triangles=nan(n,1);
Unknowns=nan(n,1);
RMSE_all=nan(n,1);
RMSE_fault=nan(n,1);
RMSE_bg=nan(n,1);
Jump0MAE=nan(n,1);
Jump0RMSE=nan(n,1);
DataRMSE=nan(n,1);
StopBudget=nan(n,1);
StopCV_MSE=nan(n,1);

for i=1:n
    Method{i}=sols{i}.name;
    Unknowns(i)=M{i}.nUnknowns;
    RMSE_all(i)=M{i}.RMSE_all;
    RMSE_fault(i)=M{i}.RMSE_fault;
    RMSE_bg(i)=M{i}.RMSE_bg;
    Jump0MAE(i)=M{i}.Jump0MAE;
    Jump0RMSE(i)=M{i}.Jump0RMSE;
    DataRMSE(i)=M{i}.dataRMSE;
end

Hyperparameter{1}=sprintf('lambda=%.4g',cvTPS.value);
Hyperparameter{2}=sprintf('c0=%.4g',cvIso.value);
Hyperparameter{3}=sprintf('c0=%.4g; eps=%.3g',cvFault.value,cvFault.epsValue);
Hyperparameter{4}=sprintf('c0=%.4g; eps=%.3g; parameter-reduced stop', ...
    cvFault.value,cvFault.epsValue);

Nodes(1)=size(sols{1}.model.uv,1)+3;
Triangles(1)=nan;
Nodes(2)=size(meshUniform.P,1); Triangles(2)=size(meshUniform.T,1);
Nodes(3)=size(meshUniform.P,1); Triangles(3)=size(meshUniform.T,1);
Nodes(4)=size(meshAF.P,1); Triangles(4)=size(meshAF.T,1);

StopBudget(4)=stopCV.selectedBudget;
StopCV_MSE(4)=stopCV.selectedMSE;

ref=3;
ImproveAllVsFaultUniformPct=100*(RMSE_all(ref)-RMSE_all)./RMSE_all(ref);
ImproveFaultVsFaultUniformPct=100*(RMSE_fault(ref)-RMSE_fault)./RMSE_fault(ref);
ImproveJumpVsFaultUniformPct=100*(Jump0MAE(ref)-Jump0MAE)./Jump0MAE(ref);

T=table(Method,Hyperparameter,Nodes,Triangles,Unknowns, ...
    StopBudget,StopCV_MSE,RMSE_all,RMSE_fault,RMSE_bg, ...
    Jump0MAE,Jump0RMSE,DataRMSE, ...
    ImproveAllVsFaultUniformPct,ImproveFaultVsFaultUniformPct, ...
    ImproveJumpVsFaultUniformPct);
end


function T=make_fault_accuracy_efficiency_table(B)
% Retrospective evaluation only.
% For each uniform FAULT-FEM accuracy target, find the minimum actual AFEM
% node count among tested levels that reaches or beats the target.

U=B(strcmp(B.Method,'FAULT-FEM'),:);
A=B(strcmp(B.Method,'FAULT-AFEM'),:);

[~,ou]=sort(U.Nodes);
U=U(ou,:);
[~,oa]=sort(A.Nodes);
A=A(oa,:);

n=height(U);

UniformBudget=U.Budget;
UniformNodes=U.Nodes;
UniformFaultRMSE=U.RMSE_fault;

AFEMNodesToMatch=nan(n,1);
AFEMBudgetToMatch=nan(n,1);
AFEMFaultRMSE=nan(n,1);
NodeSavingPct=nan(n,1);
Matched=false(n,1);

for i=1:n
    target=U.RMSE_fault(i);

    j=find(A.RMSE_fault<=target,1,'first');
    if ~isempty(j)
        AFEMNodesToMatch(i)=A.Nodes(j);
        AFEMBudgetToMatch(i)=A.Budget(j);
        AFEMFaultRMSE(i)=A.RMSE_fault(j);
        NodeSavingPct(i)=100*(U.Nodes(i)-A.Nodes(j))/U.Nodes(i);
        Matched(i)=true;
    end
end

T=table(UniformBudget,UniformNodes,UniformFaultRMSE, ...
    AFEMBudgetToMatch,AFEMNodesToMatch,AFEMFaultRMSE, ...
    NodeSavingPct,Matched);
end


function plot_fault_efficiency(outDir,B,E,cfg)
U=B(strcmp(B.Method,'FAULT-FEM'),:);
A=B(strcmp(B.Method,'FAULT-AFEM'),:);

[~,ou]=sort(U.Nodes); U=U(ou,:);
[~,oa]=sort(A.Nodes); A=A(oa,:);

f=figure('Color','w','Units','pixels','Position',[180 180 1050 700]);
plot(U.Nodes,U.RMSE_fault,'-o','LineWidth',1.6,'MarkerSize',7);
hold on;
plot(A.Nodes,A.RMSE_fault,'-s','LineWidth',1.6,'MarkerSize',7);

% Draw only successful discrete efficiency matches.
for i=1:height(E)
    if E.Matched(i) && E.NodeSavingPct(i)>0
        y=E.UniformFaultRMSE(i);
        x1=E.AFEMNodesToMatch(i);
        x2=E.UniformNodes(i);
        plot([x1 x2],[y y],'k:','LineWidth',0.8);
    end
end

grid on;
xlabel('actual node count');
ylabel('fault-band RMSE (m)');
title('Fault-band accuracy--DOF efficiency');
legend({'uniform FAULT-FEM','FAULT-AFEM'},'Location','best');

save_figure(f,fullfile(outDir,'FIG_06_fault_accuracy_DOF_efficiency.png'),cfg);
end


function plot_uniform_vs_adaptive_mesh_v2(outDir,meshU,meshA,G,stopCV,cfg)
f=figure('Color','w','Units','pixels','Position',[100 100 1350 640]);
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

meshes={meshU,meshA};
titles={sprintf('Uniform fault FEM: %d nodes',size(meshU.P,1)), ...
        sprintf('CV-stopped fault AFEM: %d nodes',size(meshA.P,1))};

for i=1:2
    ax=nexttile(tl,i);
    triplot(meshes{i}.T,meshes{i}.P(:,1),meshes{i}.P(:,2), ...
        'Parent',ax,'LineWidth',0.45);
    hold(ax,'on');

    uu=linspace(G.uMin,G.uMax,500);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'r-','LineWidth',2);

    axis(ax,'equal');
    axis(ax,'tight');
    xlabel(ax,'u (m)');
    ylabel(ax,'v (m)');
    title(ax,titles{i});
end

title(tl,sprintf('Automatic spatial-CV stopping | selected budget=%d', ...
    stopCV.selectedBudget));

save_figure(f,fullfile(outDir,'FIG_09_CVSTOP_uniform_vs_adaptive_mesh.png'),cfg);
end


function write_afem_diagnostic_summary_v2( ...
    outDir,mainTable,budgetTable,effTable,stopCV,cfg)

fid=fopen(fullfile(outDir,'DIAGNOSTIC_summary_V2.txt'),'w');
if fid<0, return; end
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'REAL_C11_FAULT_AFEM_V2_CVSTOP diagnostic summary\n');
fprintf(fid,'=================================================\n\n');

fprintf(fid,'TRUTH-FREE STOPPING DECISION\n');
fprintf(fid,'----------------------------\n');
fprintf(fid,'raw best budget       = %d\n',stopCV.rawBestBudget);
fprintf(fid,'raw best CV MSE       = %.8g\n',stopCV.rawBestMSE);
fprintf(fid,'selected budget       = %d\n',stopCV.selectedBudget);
fprintf(fid,'selected CV MSE       = %.8g\n',stopCV.selectedMSE);
fprintf(fid,'predictive penalty    = %.4f %%\n',100*stopCV.relativePenalty);
fprintf(fid,'plateau 0.5/1/2 pct   = %d / %d / %d\n\n', ...
    stopCV.selectedBudget005,stopCV.selectedBudget010,stopCV.selectedBudget020);

mU=strcmp(mainTable.Method,'FAULT-FEM');
mA=strcmp(mainTable.Method,'FAULT-AFEM');

if any(mU) && any(mA)
    u=mainTable(mU,:);
    a=mainTable(mA,:);

    gAll=100*(u.RMSE_all-a.RMSE_all)/u.RMSE_all;
    gFault=100*(u.RMSE_fault-a.RMSE_fault)/u.RMSE_fault;
    gJump=100*(u.Jump0MAE-a.Jump0MAE)/u.Jump0MAE;

    fprintf(fid,'DENSE INTERPRETED-REFERENCE AUDIT AFTER STOPPING\n');
    fprintf(fid,'------------------------------------------------\n');
    fprintf(fid,'uniform actual nodes = %d\n',u.Nodes);
    fprintf(fid,'AFEM actual nodes    = %d\n',a.Nodes);
    fprintf(fid,'AFEM vs matched uniform FAULT-FEM:\n');
    fprintf(fid,'  RMSE_all gain   = %.3f %%\n',gAll);
    fprintf(fid,'  RMSE_fault gain = %.3f %%\n',gFault);
    fprintf(fid,'  Jump0MAE gain   = %.3f %%\n\n',gJump);
end

fprintf(fid,'ACCURACY--DOF EFFICIENCY\n');
fprintf(fid,'------------------------\n');

for i=1:height(effTable)
    if effTable.Matched(i)
        fprintf(fid,['uniform nodes=%d, target fault RMSE=%.4f -> ', ...
            'AFEM nodes=%d, RMSE=%.4f, node saving=%.2f %%\n'], ...
            effTable.UniformNodes(i),effTable.UniformFaultRMSE(i), ...
            effTable.AFEMNodesToMatch(i),effTable.AFEMFaultRMSE(i), ...
            effTable.NodeSavingPct(i));
    else
        fprintf(fid,['uniform nodes=%d, target fault RMSE=%.4f -> ', ...
            'not matched by tested AFEM levels\n'], ...
            effTable.UniformNodes(i),effTable.UniformFaultRMSE(i));
    end
end

fprintf(fid,'\nINTERPRETATION\n');
fprintf(fid,'--------------\n');
fprintf(fid,['The stopping decision is based on cross-fitted spatial prediction only; ', ...
    'dense interpreted-horizon errors are not used to select the AFEM level.\n']);
fprintf(fid,['The efficiency table is retrospective and should be reported as an ', ...
    'evaluation result, not as information available during deployment.\n']);
fprintf(fid,['A coarse near-minimum CV level with competitive fault-band RMSE supports ', ...
    'the engineering claim of accuracy--cost adaptive stopping.\n']);
end


% =========================================================================
function S=screen_c11_polygons(Hraw,Pall,cfg)

ids=unique(Pall.index(:));
n=numel(ids);

NPoints=zeros(n,1);
AlongLength=nan(n,1);
Linearity=nan(n,1);
IsolationDistance=nan(n,1);
NeighborCount=nan(n,1);
GeometryEligible=false(n,1);

xyCell=cell(n,1);

% Basic geometry.
for i=1:n
    xy=Pall.xy(Pall.index==ids(i),:);
    xyCell{i}=xy;
    NPoints(i)=size(xy,1);

    if size(xy,1)>=3
        [L,lin]=simple_polygon_geometry(xy);
        AlongLength(i)=L;
        Linearity(i)=lin;
    end

    GeometryEligible(i)=NPoints(i)>=cfg.screenMinPolygonPoints && ...
        AlongLength(i)>=cfg.screenMinAlongLength;
end

% Pairwise layer-specific isolation and neighboring polygon count.
IsolationDistance(:)=inf;
NeighborCount(:)=0;

for i=1:n-1
    A=xyCell{i};
    if isempty(A), continue; end

    for j=i+1:n
        B=xyCell{j};
        if isempty(B), continue; end

        d=min_pairwise_distance(A,B);

        IsolationDistance(i)=min(IsolationDistance(i),d);
        IsolationDistance(j)=min(IsolationDistance(j),d);

        if d<=cfg.screenNeighborRadius
            NeighborCount(i)=NeighborCount(i)+1;
            NeighborCount(j)=NeighborCount(j)+1;
        end
    end
end

IsolationDistance(~isfinite(IsolationDistance))=nan;

% Geometry pre-ranking only determines which candidates receive the more
% expensive dense-horizon side-fit audit.
eligible=find(GeometryEligible);
preScore=nan(n,1);

if ~isempty(eligible)
    a=rank_score(AlongLength(eligible),true);
    b=rank_score(IsolationDistance(eligible),true);
    c=rank_score(NeighborCount(eligible),false);
    d=rank_score(Linearity(eligible),true);
    preScore(eligible)=0.28*a+0.34*b+0.28*c+0.10*d;
end

finitePre=find(isfinite(preScore));
[~,oo]=sort(preScore(finitePre),'descend');
ordPre=finitePre(oo);
ordPre=ordPre(1:min(cfg.screenTopGeometry,numel(ordPre)));

% Dense-horizon suitability metrics.
SideFitRMSE=nan(n,1);
SideFitRMSErel=nan(n,1);
JumpProxyMedianAbs=nan(n,1);
JumpProxySignedMedian=nan(n,1);
LocalRelief=nan(n,1);
LocalReferencePoints=zeros(n,1);
SidePointsNeg=zeros(n,1);
SidePointsPos=zeros(n,1);
HorizonDiagnosticValid=false(n,1);

fprintf('  Geometry-eligible polygons : %d / %d\n',numel(eligible),n);
fprintf('  Dense-horizon audit        : top %d geometry candidates\n',numel(ordPre));

for kk=1:numel(ordPre)
    i=ordPre(kk);
    idx=ids(i);

    cfgK=cfg;
    cfgK.faultIndex=idx;

    try
        G=build_fault_geometry(xyCell{i},cfgK);
        D=screen_horizon_candidate(Hraw,G,cfgK);

        SideFitRMSE(i)=D.sideFitRMSE;
        SideFitRMSErel(i)=D.sideFitRMSErel;
        JumpProxyMedianAbs(i)=D.jumpMedianAbs;
        JumpProxySignedMedian(i)=D.jumpSignedMedian;
        LocalRelief(i)=D.localRelief;
        LocalReferencePoints(i)=D.nLocal;
        SidePointsNeg(i)=D.nNeg;
        SidePointsPos(i)=D.nPos;
        HorizonDiagnosticValid(i)=D.valid;

        fprintf('    %2d/%2d | Index=%3d | L=%6.1f | iso=%6.1f | neigh=%2d | ', ...
            kk,numel(ordPre),idx,AlongLength(i),IsolationDistance(i),NeighborCount(i));
        if D.valid
            fprintf('sideRel=%.4f | J0~=%.2f m\n',D.sideFitRMSErel,D.jumpMedianAbs);
        else
            fprintf('INVALID horizon side audit\n');
        end
    catch ME
        fprintf('    %2d/%2d | Index=%3d | screening failed: %s\n', ...
            kk,numel(ordPre),idx,ME.message);
    end
end

% Final rank is only among candidates with a valid dense-horizon audit.
valid=GeometryEligible & HorizonDiagnosticValid;
FinalScore=nan(n,1);

if any(valid)
    ii=find(valid);

    sLength=rank_score(AlongLength(ii),true);
    sIso=rank_score(IsolationDistance(ii),true);
    sNeigh=rank_score(NeighborCount(ii),false);
    sLin=rank_score(Linearity(ii),true);
    sFit=rank_score(SideFitRMSErel(ii),false);
    sJump=rank_score(JumpProxyMedianAbs(ii),true);
    cov=min(SidePointsNeg(ii),SidePointsPos(ii));
    sCov=rank_score(cov,true);

    FinalScore(ii)= ...
        cfg.wLength*sLength + ...
        cfg.wIsolation*sIso + ...
        cfg.wNeighbor*sNeigh + ...
        cfg.wLinearity*sLin + ...
        cfg.wSideFit*sFit + ...
        cfg.wJump*sJump + ...
        cfg.wCoverage*sCov;
end

T=table(ids,NPoints,AlongLength,Linearity,IsolationDistance,NeighborCount, ...
    GeometryEligible,preScore,SideFitRMSE,SideFitRMSErel, ...
    JumpProxyMedianAbs,JumpProxySignedMedian,LocalRelief, ...
    LocalReferencePoints,SidePointsNeg,SidePointsPos, ...
    HorizonDiagnosticValid,FinalScore, ...
    'VariableNames',{'FaultIndex','NPoints','AlongLength','Linearity', ...
    'IsolationDistance','NeighborCount','GeometryEligible','GeometryPreScore', ...
    'SideFitRMSE','SideFitRMSErel','JumpProxyMedianAbs', ...
    'JumpProxySignedMedian','LocalRelief','LocalReferencePoints', ...
    'SidePointsNeg','SidePointsPos','HorizonDiagnosticValid','FinalScore'});

finiteFinal=find(isfinite(T.FinalScore));
[~,oo]=sort(T.FinalScore(finiteFinal),'descend');
ord=finiteFinal(oo);
ranked=T(ord,:);

if isempty(ranked)
    error('Automatic screening produced no valid C11 candidate.');
end

S=struct();
S.all=T;
S.ranked=ranked;
S.selectedIndex=ranked.FaultIndex(1);
end


function [L,linearity]=simple_polygon_geometry(xy)
c=mean(xy,1);
X=xy-c;

C=(X.'*X)/max(size(X,1)-1,1);
[V,D]=eig(C); %#ok<ASGLU>
lam=sort(diag(D),'descend');

[~,imax]=max(diag(D));
t=V(:,imax);
u=X*t;

L=max(u)-min(u);
if lam(1)<=eps
    linearity=0;
else
    linearity=max(0,min(1,1-lam(2)/lam(1)));
end
end


function d=min_pairwise_distance(A,B)
% Shift the very large mine coordinates before the dot-product distance
% formula to avoid catastrophic cancellation at metre-scale separations.
o=A(1,:);
Ac=A-o;
Bc=B-o;

aa=sum(Ac.^2,2);
bb=sum(Bc.^2,2).';
D2=max(aa+bb-2*(Ac*Bc.'),0);
d=sqrt(min(D2(:)));
end


function s=rank_score(x,highGood)
x=x(:);
n=numel(x);
s=nan(n,1);

good=isfinite(x);
if nnz(good)==0, return; end
if nnz(good)==1
    s(good)=1;
    return;
end

xg=x(good);
[~,ord]=sort(xg,'ascend');
r=zeros(numel(xg),1);
r(ord)=linspace(0,1,numel(xg));

if highGood
    sg=r;
else
    sg=1-r;
end

s(good)=sg;
end


function D=screen_horizon_candidate(Hraw,G,cfg)

UV=global_to_local(Hraw.xy,G);

% Cheap coarse window first.
v0=0.5*(min(G.vc)+max(G.vc));
m=UV(:,1)>=G.uMin-cfg.screenAlongPad & ...
  UV(:,1)<=G.uMax+cfg.screenAlongPad & ...
  UV(:,2)>=v0-cfg.screenCrossExtent & ...
  UV(:,2)<=v0+cfg.screenCrossExtent;

uv=UV(m,:);
z=Hraw.z(m);

if numel(z)<2*cfg.screenMinSidePoints
    D=invalid_screen_diag(numel(z));
    return;
end

phi=fault_phi(uv,G);
span=G.uMax-G.uMin;
uA=G.uMin+cfg.screenMinInteriorFraction*span;
uB=G.uMax-cfg.screenMinInteriorFraction*span;

use=uv(:,1)>=uA & uv(:,1)<=uB & ...
    abs(phi)>=cfg.screenSideMinDistance & ...
    abs(phi)<=cfg.screenSideMaxDistance;

neg=use & phi<0;
pos=use & phi>0;

if nnz(neg)<cfg.screenMinSidePoints || nnz(pos)<cfg.screenMinSidePoints
    D=invalid_screen_diag(numel(z));
    D.nNeg=nnz(neg);
    D.nPos=nnz(pos);
    return;
end

S=screen_poly_scale(uv(use,:),G);
Bneg=screen_poly_basis(uv(neg,:),S,cfg.screenPolyDegree);
Bpos=screen_poly_basis(uv(pos,:),S,cfg.screenPolyDegree);

cneg=Bneg\z(neg);
cpos=Bpos\z(pos);

eneg=Bneg*cneg-z(neg);
epos=Bpos*cpos-z(pos);

rneg=sqrt(mean(eneg.^2));
rpos=sqrt(mean(epos.^2));
rms=0.5*(rneg+rpos);

relief=percentile_local(z,95)-percentile_local(z,5);
rmsRel=rms/max(relief,1);

uJ=linspace(uA,uB,17).';
vc=interp1(G.uc,G.vc,uJ,'linear','extrap');
q=[uJ,vc];

BJ=screen_poly_basis(q,S,cfg.screenPolyDegree);
jump=BJ*cpos-BJ*cneg;

D=struct();
D.valid=true;
D.sideFitRMSE=rms;
D.sideFitRMSErel=rmsRel;
D.jumpMedianAbs=median(abs(jump));
D.jumpSignedMedian=median(jump);
D.localRelief=relief;
D.nLocal=numel(z);
D.nNeg=nnz(neg);
D.nPos=nnz(pos);
end


function D=invalid_screen_diag(nLocal)
D=struct();
D.valid=false;
D.sideFitRMSE=nan;
D.sideFitRMSErel=nan;
D.jumpMedianAbs=nan;
D.jumpSignedMedian=nan;
D.localRelief=nan;
D.nLocal=nLocal;
D.nNeg=0;
D.nPos=0;
end


function S=screen_poly_scale(uv,G)
S.uCenter=0.5*(G.uMin+G.uMax);
S.uScale=max(0.5*(G.uMax-G.uMin),1);
S.vCenter=median(G.vc);
S.vScale=max(250,4*G.halfWidth95);
end


function B=screen_poly_basis(uv,S,p)
u=(uv(:,1)-S.uCenter)/S.uScale;
v=(uv(:,2)-S.vCenter)/S.vScale;
B=poly_total_degree_basis(u,v,p);
end


% =========================================================================
% V2 FAULT-BLOCK POLYNOMIAL
% =========================================================================
function CV=select_fbpoly_model_cv(obs,G,uRange,vRange,cfg)
degrees=cfg.fbPolyDegrees(:);
R=cfg.fbPolyCVRepeats;
K=cfg.fbPolyCVFolds;
folds=repeated_spatial_folds(obs.uv,R,K);
mse=nan(numel(degrees),R);

scale=fbpoly_scale(uRange,vRange);

for ip=1:numel(degrees)
    p=degrees(ip);

    for r=1:R
        sse=0;
        nt=0;

        for k=1:K
            tr=folds(:,r)~=k;
            te=folds(:,r)==k;
            if nnz(te)==0, continue; end

            Xtr=fbpoly_design(obs.uv(tr,:),G,p,scale);
            Xte=fbpoly_design(obs.uv(te,:),G,p,scale);

            npar=size(Xtr,2);
            if nnz(tr)<=npar+2 || rank(full(Xtr))<npar
                continue;
            end

            theta=Xtr\obs.z(tr);
            e=Xte*theta-obs.z(te);
            sse=sse+sum(e.^2);
            nt=nt+numel(e);
        end

        if nt>0, mse(ip,r)=sse/nt; end
    end
end

meanMSE=nan(numel(degrees),1);
seMSE=nan(numel(degrees),1);

for i=1:numel(degrees)
    x=mse(i,isfinite(mse(i,:)));
    if isempty(x), continue; end
    meanMSE(i)=mean(x);
    if numel(x)>1
        seMSE(i)=std(x,0,2)/sqrt(numel(x));
    else
        seMSE(i)=0;
    end
end

[best,ib]=min(meanMSE);
if ~isfinite(best), error('FAULT-BLOCK-POLY CV failed.'); end

eligible=meanMSE<=(1+cfg.cvPlateau)*best;
cand=find(eligible & isfinite(meanMSE));
if isempty(cand), cand=ib; end

% Simpler polynomial among near-minimum predictive models.
is=cand(1);

CV=struct();
CV.degrees=degrees;
CV.meanMSE=meanMSE;
CV.seMSE=seMSE;
CV.rawIndex=ib;
CV.rawDegree=degrees(ib);
CV.rawMSE=best;
CV.selectedIndex=is;
CV.degree=degrees(is);
CV.selectedMSE=meanMSE(is);
CV.nParameters=2*poly_term_count(CV.degree);
CV.relativePenalty=(CV.selectedMSE-best)/best;
end


function print_fbpoly_cv(CV)
fprintf('    raw degree=%d | selected degree=%d | npar=%d\n', ...
    CV.rawDegree,CV.degree,CV.nParameters);
fprintf('    CV raw/selected %.6g / %.6g | penalty %.3f%%\n', ...
    CV.rawMSE,CV.selectedMSE,100*CV.relativePenalty);

for i=1:numel(CV.degrees)
    fprintf('      p=%d : mean %.6g | SE %.3g\n', ...
        CV.degrees(i),CV.meanMSE(i),CV.seMSE(i));
end
end


function S=fbpoly_scale(uRange,vRange)
S.uCenter=0.5*sum(uRange);
S.uScale=max(0.5*diff(uRange),1);
S.vCenter=0.5*sum(vRange);
S.vScale=max(0.5*diff(vRange),1);
end


function X=fbpoly_design(uv,G,p,S)
u=(uv(:,1)-S.uCenter)/S.uScale;
v=(uv(:,2)-S.vCenter)/S.vScale;

B=poly_total_degree_basis(u,v,p);
phi=fault_phi(uv,G);
neg=phi<0;
pos=~neg;

X=[B.*neg,B.*pos];
end


function S=fit_fbpoly_solution(obs,G,uRange,vRange,p,cfg) %#ok<INUSD>
scale=fbpoly_scale(uRange,vRange);
X=fbpoly_design(obs.uv,G,p,scale);

theta=X\obs.z;

S=struct();
S.type='fbpoly';
S.name='FAULT-BLOCK-POLY';
S.G=G;
S.degree=p;
S.scale=scale;
S.theta=theta;
S.nUnknowns=numel(theta);
S.dataRMSE=sqrt(mean((X*theta-obs.z).^2));
end


% =========================================================================
% V2 FAULT-BLOCK TPS
% =========================================================================
function CV=select_fbtps_lambda_cv(obs,G,cfg)
grid=cfg.tpsLambdaGrid(:);
R=cfg.cvRepeats;
K=cfg.cvFolds;
folds=repeated_spatial_folds(obs.uv,R,K);
mse=nan(numel(grid),R);

phiAll=fault_phi(obs.uv,G);

for ig=1:numel(grid)
    lambda=grid(ig);

    for r=1:R
        sse=0;
        nt=0;

        for k=1:K
            tr=folds(:,r)~=k;
            te=folds(:,r)==k;
            if nnz(te)==0, continue; end

            negTr=tr & phiAll<0;
            posTr=tr & phiAll>=0;

            if nnz(negTr)<6 || nnz(posTr)<6
                continue;
            end

            scNeg=coordinate_scale(obs.uv(negTr,:));
            scPos=coordinate_scale(obs.uv(posTr,:));

            mNeg=fit_tps(obs.uv(negTr,:),obs.z(negTr),lambda,scNeg);
            mPos=fit_tps(obs.uv(posTr,:),obs.z(posTr),lambda,scPos);

            phiTe=phiAll(te);
            q=obs.uv(te,:);
            pred=zeros(nnz(te),1);

            negTe=phiTe<0;
            if any(negTe), pred(negTe)=tps_predict(mNeg,q(negTe,:)); end
            if any(~negTe), pred(~negTe)=tps_predict(mPos,q(~negTe,:)); end

            e=pred-obs.z(te);
            sse=sse+sum(e.^2);
            nt=nt+numel(e);
        end

        if nt>0, mse(ig,r)=sse/nt; end
    end
end

CV=select_plateau_scalar(grid,mse,cfg.cvPlateau);
end


function S=fit_fbtps_solution(obs,G,lambda,cfg) %#ok<INUSD>
phi=fault_phi(obs.uv,G);
neg=phi<0;
pos=~neg;

if nnz(neg)<6 || nnz(pos)<6
    error('FAULT-BLOCK-TPS requires >=6 sparse controls on each side.');
end

scNeg=coordinate_scale(obs.uv(neg,:));
scPos=coordinate_scale(obs.uv(pos,:));

mNeg=fit_tps(obs.uv(neg,:),obs.z(neg),lambda,scNeg);
mPos=fit_tps(obs.uv(pos,:),obs.z(pos),lambda,scPos);

pred=zeros(size(obs.z));
pred(neg)=tps_predict(mNeg,obs.uv(neg,:));
pred(pos)=tps_predict(mPos,obs.uv(pos,:));

S=struct();
S.type='fbtps';
S.name='FAULT-BLOCK-TPS';
S.G=G;
S.negModel=mNeg;
S.posModel=mPos;
S.lambda=lambda;
S.nUnknowns=nnz(neg)+3+nnz(pos)+3;
S.dataRMSE=sqrt(mean((pred-obs.z).^2));
end


% =========================================================================
% V2 CORRECTED DENSE METRICS / INTERFACE JUMP
% =========================================================================
function [M,J]=evaluate_dense_v2( ...
    pred,zref,faultMask,bgMask,negMask,posMask,obs,S,R,G,cfg)

e=pred-zref;

M=struct();
M.RMSE_all=sqrt(mean(e.^2));
M.MAE_all=mean(abs(e));
M.RMSE_fault=sqrt(mean(e(faultMask).^2));
M.MAE_fault=mean(abs(e(faultMask)));
M.RMSE_bg=sqrt(mean(e(bgMask).^2));
M.RMSE_neg=sqrt(mean(e(negMask).^2));
M.RMSE_pos=sqrt(mean(e(posMask).^2));
M.dataRMSE=S.dataRMSE;
M.nUnknowns=S.nUnknowns;

J=interface_jump_extrapolation(S,R,G,cfg);

good=isfinite(J.ref) & isfinite(J.pred);
if any(good)
    de=J.pred(good)-J.ref(good);
    M.Jump0MAE=mean(abs(de));
    M.Jump0RMSE=sqrt(mean(de.^2));
    M.RefJumpMedianAbs=median(abs(J.ref(good)));
    M.PredJumpMedianAbs=median(abs(J.pred(good)));
    M.Jump0Correlation=corr_local(J.ref(good),J.pred(good));
else
    M.Jump0MAE=nan;
    M.Jump0RMSE=nan;
    M.RefJumpMedianAbs=nan;
    M.PredJumpMedianAbs=nan;
    M.Jump0Correlation=nan;
end

pobs=predict_solution(S,obs.uv);
M.trainRMSE=sqrt(mean((pobs-obs.z).^2));
end


function J=interface_jump_extrapolation(S,R,G,cfg)
span=G.uMax-G.uMin;
u1=G.uMin+cfg.jumpTipFraction*span;
u2=G.uMax-cfg.jumpTipFraction*span;
uList=linspace(u1,u2,cfg.jumpNSamples).';

d0=max(cfg.jumpFitMinOffset,G.halfWidth95+cfg.jumpFitPolygonClearance);
d=d0+cfg.jumpFitDistanceAdd(:).';

Jref=nan(numel(uList),1);
Jpred=nan(numel(uList),1);

for i=1:numel(uList)
    [vc,slope]=fault_center_and_slope(uList(i),G);
    c=[uList(i),vc];

    nn=[-slope,1];
    nn=nn/max(norm(nn),eps);

    qPlus=c+d(:)*nn;
    qMinus=c-d(:)*nn;

    zrP=reference_predict(R,qPlus,G);
    zrM=reference_predict(R,qMinus,G);

    zpP=predict_solution(S,qPlus);
    zpM=predict_solution(S,qMinus);

    Jref(i)=two_side_intercept_jump(d,zrP,zrM,cfg.jumpLocalDegree);
    Jpred(i)=two_side_intercept_jump(d,zpP,zpM,cfg.jumpLocalDegree);
end

J=struct();
J.u=uList;
J.ref=Jref;
J.pred=Jpred;
J.distances=d;
end


function J=two_side_intercept_jump(d,zPlus,zMinus,degree)
d=d(:);
zPlus=zPlus(:);
zMinus=zMinus(:);

goodP=isfinite(d)&isfinite(zPlus);
goodM=isfinite(d)&isfinite(zMinus);

if nnz(goodP)<degree+2 || nnz(goodM)<degree+2
    J=nan;
    return;
end

pP=polyfit(d(goodP),zPlus(goodP),degree);
pM=polyfit(d(goodM),zMinus(goodM),degree);

bP=polyval(pP,0);
bM=polyval(pM,0);
J=bP-bM;
end


function r=corr_local(a,b)
a=a(:); b=b(:);
g=isfinite(a)&isfinite(b);
a=a(g); b=b(g);

if numel(a)<3 || std(a)<=eps || std(b)<=eps
    r=nan;
    return;
end

C=corrcoef(a,b);
r=C(1,2);
end


function print_metric_v2(name,M)
fprintf(['  %-18s | all %.4f | fault %.4f | bg %.4f | ', ...
    'side(-/+) %.4f/%.4f | Jump0MAE %.4f | corr %.3f | data %.4f | unk %d\n'], ...
    name,M.RMSE_all,M.RMSE_fault,M.RMSE_bg,M.RMSE_neg,M.RMSE_pos, ...
    M.Jump0MAE,M.Jump0Correlation,M.dataRMSE,M.nUnknowns);
end


% =========================================================================
% V2 TABLES / DIAGNOSTIC SUMMARY
% =========================================================================
function T=make_model_cv_table(cvSTPS,cvFC,cvOld,cvFBP,cvFBT)
Method={'S-TPS';'FAULT-CONT-FEM';'OLD-IG-GJR';'FAULT-BLOCK-POLY';'FAULT-BLOCK-TPS'};
SelectedModel=cell(5,1);
CV_MSE=nan(5,1);
RawBestCV_MSE=nan(5,1);

SelectedModel{1}=sprintf('lambda=%.4g',cvSTPS.value);
CV_MSE(1)=cvSTPS.selectedMSE; RawBestCV_MSE(1)=cvSTPS.rawMSE;

SelectedModel{2}=sprintf('c0=%.4g',cvFC.value);
CV_MSE(2)=cvFC.selectedMSE; RawBestCV_MSE(2)=cvFC.rawMSE;

SelectedModel{3}=sprintf('p=%d,q=%d',cvOld.backgroundDegree,cvOld.jumpDegree);
CV_MSE(3)=cvOld.selectedMSE; RawBestCV_MSE(3)=cvOld.rawMSE;

SelectedModel{4}=sprintf('p=%d',cvFBP.degree);
CV_MSE(4)=cvFBP.selectedMSE; RawBestCV_MSE(4)=cvFBP.rawMSE;

SelectedModel{5}=sprintf('lambda=%.4g',cvFBT.value);
CV_MSE(5)=cvFBT.selectedMSE; RawBestCV_MSE(5)=cvFBT.rawMSE;

T=table(Method,SelectedModel,CV_MSE,RawBestCV_MSE);
end


function T=make_main_table_v2(sols,M,cvSTPS,cvFC,cvOld,cvFBP,cvFBT)
n=numel(sols);
Method=cell(n,1);
Model=cell(n,1);
Unknowns=zeros(n,1);
RMSE_all=zeros(n,1);
MAE_all=zeros(n,1);
RMSE_fault=zeros(n,1);
MAE_fault=zeros(n,1);
RMSE_bg=zeros(n,1);
RMSE_neg=zeros(n,1);
RMSE_pos=zeros(n,1);
Jump0MAE=zeros(n,1);
Jump0RMSE=zeros(n,1);
Jump0Correlation=zeros(n,1);
RefJumpMedianAbs=zeros(n,1);
PredJumpMedianAbs=zeros(n,1);
DataRMSE=zeros(n,1);

for i=1:n
    Method{i}=sols{i}.name;
    Unknowns(i)=M{i}.nUnknowns;
    RMSE_all(i)=M{i}.RMSE_all;
    MAE_all(i)=M{i}.MAE_all;
    RMSE_fault(i)=M{i}.RMSE_fault;
    MAE_fault(i)=M{i}.MAE_fault;
    RMSE_bg(i)=M{i}.RMSE_bg;
    RMSE_neg(i)=M{i}.RMSE_neg;
    RMSE_pos(i)=M{i}.RMSE_pos;
    Jump0MAE(i)=M{i}.Jump0MAE;
    Jump0RMSE(i)=M{i}.Jump0RMSE;
    Jump0Correlation(i)=M{i}.Jump0Correlation;
    RefJumpMedianAbs(i)=M{i}.RefJumpMedianAbs;
    PredJumpMedianAbs(i)=M{i}.PredJumpMedianAbs;
    DataRMSE(i)=M{i}.dataRMSE;
end

Model{1}=sprintf('lambda=%.4g',cvSTPS.value);
Model{2}=sprintf('c0=%.4g',cvFC.value);
Model{3}=sprintf('p=%d,q=%d',cvOld.backgroundDegree,cvOld.jumpDegree);
Model{4}=sprintf('piecewise p=%d',cvFBP.degree);
Model{5}=sprintf('lambda=%.4g per block',cvFBT.value);

% Positive means the row is better than global S-TPS.
ref=1;
ImproveAllVsSTPSPct=100*(RMSE_all(ref)-RMSE_all)./RMSE_all(ref);
ImproveFaultVsSTPSPct=100*(RMSE_fault(ref)-RMSE_fault)./RMSE_fault(ref);
ImproveJumpVsSTPSPct=100*(Jump0MAE(ref)-Jump0MAE)./Jump0MAE(ref);

T=table(Method,Model,Unknowns,RMSE_all,MAE_all,RMSE_fault,MAE_fault, ...
    RMSE_bg,RMSE_neg,RMSE_pos,Jump0MAE,Jump0RMSE,Jump0Correlation, ...
    RefJumpMedianAbs,PredJumpMedianAbs,DataRMSE, ...
    ImproveAllVsSTPSPct,ImproveFaultVsSTPSPct,ImproveJumpVsSTPSPct);
end


function T=make_geometry_audit_table_v2(G,A,selectedIndex,screen,cfg)
row=screen.all(screen.all.FaultIndex==selectedIndex,:);

FaultIndex=selectedIndex;
AlongLength=G.uMax-G.uMin;
PolygonHalfWidthMedian=G.halfWidth;
PolygonHalfWidth95=G.halfWidth95;
ScreenFinalScore=row.FinalScore;
IsolationDistance=row.IsolationDistance;
NeighborCount=row.NeighborCount;
ScreenSideFitRMSErel=row.SideFitRMSErel;
ScreenJumpProxyMedianAbs=row.JumpProxyMedianAbs;
FaultStickAvailable=A.available;
FaultStickLocalPoints=A.nLocal;
F151aPresent=A.hasF151a;
DominantFaultStickNames={A.topNames};
ScreenNeighborRadius=cfg.screenNeighborRadius;

T=table(FaultIndex,AlongLength,PolygonHalfWidthMedian,PolygonHalfWidth95, ...
    ScreenFinalScore,IsolationDistance,NeighborCount,ScreenSideFitRMSErel, ...
    ScreenJumpProxyMedianAbs,ScreenNeighborRadius,FaultStickAvailable, ...
    FaultStickLocalPoints,F151aPresent,DominantFaultStickNames);
end


function write_diagnostic_summary(outDir,sols,M)
name=cellfun(@(s)s.name,sols,'UniformOutput',false);

iST=find(strcmp(name,'S-TPS'),1);
iOld=find(strcmp(name,'OLD-IG-GJR'),1);
iPoly=find(strcmp(name,'FAULT-BLOCK-POLY'),1);
iBT=find(strcmp(name,'FAULT-BLOCK-TPS'),1);

fid=fopen(fullfile(outDir,'DIAGNOSTIC_summary.txt'),'w');
cleanup=onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'REAL_C11_FAULT_AFEM_V2_CVSTOP\n\n');

g1=100*(M{iST}.RMSE_fault-M{iBT}.RMSE_fault)/M{iST}.RMSE_fault;
g2=100*(M{iBT}.RMSE_fault-M{iPoly}.RMSE_fault)/M{iBT}.RMSE_fault;
g3=100*(M{iOld}.RMSE_fault-M{iPoly}.RMSE_fault)/M{iOld}.RMSE_fault;

fprintf(fid,'Q1 Fault-block partition value:\n');
fprintf(fid,'  S-TPS fault RMSE          = %.6f\n',M{iST}.RMSE_fault);
fprintf(fid,'  FAULT-BLOCK-TPS fault RMSE= %.6f\n',M{iBT}.RMSE_fault);
fprintf(fid,'  FB-TPS improvement vs S-TPS = %.3f %%\n\n',g1);

fprintf(fid,'Q2 Low-dimensional piecewise approximation:\n');
fprintf(fid,'  FB-POLY fault RMSE = %.6f\n',M{iPoly}.RMSE_fault);
fprintf(fid,'  FB-TPS  fault RMSE = %.6f\n',M{iBT}.RMSE_fault);
fprintf(fid,'  FB-POLY improvement vs FB-TPS = %.3f %% (positive means POLY better)\n\n',g2);

fprintf(fid,'Q3 Shared-background old GJR diagnosis:\n');
fprintf(fid,'  OLD-GJR fault RMSE = %.6f\n',M{iOld}.RMSE_fault);
fprintf(fid,'  FB-POLY fault RMSE = %.6f\n',M{iPoly}.RMSE_fault);
fprintf(fid,'  FB-POLY improvement vs OLD-GJR = %.3f %%\n',g3);
end


% =========================================================================
% V2 FIGURES
% =========================================================================
function plot_screening_map(outDir,Pall,screen,selectedIndex,cfg)
f=figure('Color','w','Units','pixels','Position',[80 80 1400 900]);
hold on;

ids=unique(Pall.index);
for i=1:numel(ids)
    xy=Pall.xy(Pall.index==ids(i),:);
    plot(xy(:,1),xy(:,2),'-','LineWidth',0.6);
end

xySel=Pall.xy(Pall.index==selectedIndex,:);
plot(xySel(:,1),xySel(:,2),'k-','LineWidth',3);

nLab=min(10,height(screen.ranked));
for i=1:nLab
    idx=screen.ranked.FaultIndex(i);
    xy=Pall.xy(Pall.index==idx,:);
    c=mean(xy,1);
    text(c(1),c(2),sprintf('%d',idx),'FontWeight','bold','FontSize',10);
end

axis equal tight;
grid on;
xlabel('X (m)');
ylabel('Y (m)');
title(sprintf('C11 fault-polygon benchmark screening | selected Index=%d',selectedIndex));

save_figure(f,fullfile(outDir,'FIG_01_screening_map.png'),cfg);
end


function plot_screening_scores(outDir,screen,cfg)
n=min(12,height(screen.ranked));
T=screen.ranked(1:n,:);

f=figure('Color','w','Units','pixels','Position',[120 120 1200 720]);
bar(T.FinalScore);
grid on;
set(gca,'XTick',1:n,'XTickLabel',cellstr(num2str(T.FaultIndex)));
xlabel('fault polygon Index');
ylabel('benchmark suitability score');
title('Top automatic C11 benchmark-suitability scores');

save_figure(f,fullfile(outDir,'FIG_02_screening_top_scores.png'),cfg);
end


function plot_selected_window(outDir,XYref,Zref,Pall,G,selectedIndex,UVref,cfg) %#ok<INUSD>
f=figure('Color','w','Units','pixels','Position',[100 100 1250 850]);

scatter(XYref(:,1),XYref(:,2),8,Zref,'filled');
hold on;

% Overlay every interpreted C11 polygon that intersects the local XY bbox.
xlim0=[min(XYref(:,1)),max(XYref(:,1))];
ylim0=[min(XYref(:,2)),max(XYref(:,2))];

ids=unique(Pall.index);
for i=1:numel(ids)
    xy=Pall.xy(Pall.index==ids(i),:);
    if max(xy(:,1))>=xlim0(1) && min(xy(:,1))<=xlim0(2) && ...
       max(xy(:,2))>=ylim0(1) && min(xy(:,2))<=ylim0(2)
        plot(xy(:,1),xy(:,2),'-','LineWidth',0.8);
    end
end

xySel=Pall.xy(Pall.index==selectedIndex,:);
plot(xySel(:,1),xySel(:,2),'k-','LineWidth',3);

uu=linspace(G.uMin,G.uMax,400).';
vc=interp1(G.uc,G.vc,uu,'linear','extrap');
xyC=local_to_global([uu,vc],G);
plot(xyC(:,1),xyC(:,2),'w--','LineWidth',1.8);

axis equal tight;
grid on;
xlabel('X (m)'); ylabel('Y (m)');
title(sprintf('Selected C11 local benchmark | polygon Index=%d',selectedIndex));
cb=colorbar; cb.Label.String='TVD (m)';

save_figure(f,fullfile(outDir,'FIG_03_selected_window.png'),cfg);
end


function plot_reconstruction_v2(outDir,uv,z,sols,G,uRange,vRange,cfg)
[U,V,Q]=visual_grid(uRange,vRange,cfg);
Fref=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
Z0=reshape(Fref(Q(:,1),Q(:,2)),size(U));

Z=cell(numel(sols)+1,1);
Z{1}=Z0;
for i=1:numel(sols)
    Z{i+1}=reshape(predict_solution(sols{i},Q),size(U));
end

allZ=cat(3,Z{:});
clim=[min(allZ(:)),max(allZ(:))];

f=figure('Color','w','Units','pixels','Position',[50 50 1700 1050]);
tl=tiledlayout(f,2,3,'Padding','compact','TileSpacing','compact');
titles=[{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)];

lastAx=[];
for i=1:numel(Z)
    ax=nexttile(tl,i);
    imagesc(ax,U(1,:),V(:,1),Z{i});
    set(ax,'YDir','normal');
    axis(ax,'image');
    caxis(ax,clim);
    hold(ax,'on');
    uu=linspace(G.uMin,G.uMax,400);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'k--','LineWidth',1);
    title(ax,titles{i},'FontWeight','bold');
    xlabel(ax,'u (m)'); ylabel(ax,'v (m)');
    lastAx=ax;
end

cb=colorbar(lastAx);
cb.Layout.Tile='east';
cb.Label.String='TVD (m)';
title(tl,'C11 fault-block diagnostic reconstruction');

save_figure(f,fullfile(outDir,'FIG_04_reconstruction.png'),cfg);
end


function plot_absolute_error_v2(outDir,uv,z,sols,G,uRange,vRange,cfg)
[U,V,Q]=visual_grid(uRange,vRange,cfg);
Fref=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
z0=Fref(Q(:,1),Q(:,2));

E=cell(numel(sols),1);
mx=0;

for i=1:numel(sols)
    e=abs(predict_solution(sols{i},Q)-z0);
    E{i}=reshape(e,size(U));
    mx=max(mx,percentile_local(e,99));
end

f=figure('Color','w','Units','pixels','Position',[60 60 1700 1050]);
tl=tiledlayout(f,2,3,'Padding','compact','TileSpacing','compact');

lastAx=[];
for i=1:numel(sols)
    ax=nexttile(tl,i);
    imagesc(ax,U(1,:),V(:,1),E{i});
    set(ax,'YDir','normal');
    axis(ax,'image');
    caxis(ax,[0,mx]);
    hold(ax,'on');
    uu=linspace(G.uMin,G.uMax,400);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'w--','LineWidth',1);
    title(ax,sols{i}.name,'FontWeight','bold');
    xlabel(ax,'u (m)'); ylabel(ax,'v (m)');
    lastAx=ax;
end

ax=nexttile(tl,6); axis(ax,'off');

cb=colorbar(lastAx);
cb.Layout.Tile='east';
cb.Label.String='|TVD error| (m)';
title(tl,'Absolute error relative to interpreted C11 horizon');

save_figure(f,fullfile(outDir,'FIG_05_absolute_error.png'),cfg);
end


function plot_fault_normal_profile_v2(outDir,sols,R,G,cfg)
u0=0.5*(G.uMin+G.uMax);
[vc,~]=fault_center_and_slope(u0,G);

vSpan=max(300,2.5*cfg.evalBackgroundDistance);
v=linspace(vc-vSpan,vc+vSpan,700).';
q=[u0*ones(size(v)),v];

zref=reference_predict(R,q,G);

f=figure('Color','w','Units','pixels','Position',[160 160 1100 700]);
plot(v-vc,zref,'k-','LineWidth',2.4);
hold on;

for i=1:numel(sols)
    plot(v-vc,predict_solution(sols{i},q),'LineWidth',1.35);
end

xline(0,'k--','LineWidth',1);
grid on;
xlabel('cross-fault coordinate relative to centerline (m)');
ylabel('TVD (m)');
title('Fault-normal profile: continuous vs block-separated models');
legend([{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)], ...
    'Location','best');

save_figure(f,fullfile(outDir,'FIG_06_fault_normal_profile.png'),cfg);
end


function plot_interface_jump_v2(outDir,sols,R,G,cfg)
f=figure('Color','w','Units','pixels','Position',[160 160 1200 720]);
hold on;

J0=interface_jump_extrapolation(sols{1},R,G,cfg);
plot(J0.u,J0.ref,'k-','LineWidth',2.4);

for i=1:numel(sols)
    J=interface_jump_extrapolation(sols{i},R,G,cfg);
    plot(J.u,J.pred,'LineWidth',1.35);
end

yline(0,'k:');
grid on;
xlabel('along-fault coordinate u (m)');
ylabel('two-sided interface-extrapolated contrast J_0(u) (m)');
title('Corrected local interface-jump diagnostic');
legend([{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)], ...
    'Location','best');

save_figure(f,fullfile(outDir,'FIG_07_interface_jump.png'),cfg);
end



% =========================================================================
% DENSE METRICS + CROSS-FAULT CONTRAST
% =========================================================================
function M=evaluate_dense(pred,zref,faultMask,bgMask,obs,S,R,G,cfg)
e=pred-zref;

M=struct();
M.RMSE_all=sqrt(mean(e.^2));
M.MAE_all=mean(abs(e));
M.RMSE_fault=sqrt(mean(e(faultMask).^2));
M.MAE_fault=mean(abs(e(faultMask)));
M.RMSE_bg=sqrt(mean(e(bgMask).^2));
M.dataRMSE=S.dataRMSE;
M.nUnknowns=S.nUnknowns;

[Jref,Jpred,uJ]=cross_fault_contrast(S,R,G,cfg); %#ok<ASGLU>
good=isfinite(Jref) & isfinite(Jpred);
if any(good)
    dj=Jpred(good)-Jref(good);
    M.JumpMAE=mean(abs(dj));
    M.JumpRMSE=sqrt(mean(dj.^2));
    M.RefContrastMean=mean(abs(Jref(good)));
    M.PredContrastMean=mean(abs(Jpred(good)));
else
    M.JumpMAE=nan;
    M.JumpRMSE=nan;
    M.RefContrastMean=nan;
    M.PredContrastMean=nan;
end

% Training residual against the same sparse observations, duplicated here
% for table convenience.
pobs=predict_solution(S,obs.uv);
M.trainRMSE=sqrt(mean((pobs-obs.z).^2));
end


function [Jref,Jpred,uList]=cross_fault_contrast(S,R,G,cfg)
span=G.uMax-G.uMin;
u1=G.uMin+cfg.jumpTipFraction*span;
u2=G.uMax-cfg.jumpTipFraction*span;
uList=linspace(u1,u2,cfg.jumpNSamples).';

offset=max(cfg.jumpOffsetMin,G.halfWidth95+cfg.jumpOffsetExtra);

[vc,slope]=fault_center_and_slope(uList,G);

qp=zeros(numel(uList),2);
qm=qp;

for i=1:numel(uList)
    nn=[-slope(i),1];
    nn=nn/max(norm(nn),eps);
    c=[uList(i),vc(i)];
    qp(i,:)=c+offset*nn;
    qm(i,:)=c-offset*nn;
end

zp=reference_predict(R,qp,G);
zm=reference_predict(R,qm,G);
Jref=zp-zm;

pp=predict_solution(S,qp);
pm=predict_solution(S,qm);
Jpred=pp-pm;
end


function print_metric(name,M)
fprintf('  %-15s | all %.4f | fault %.4f | bg %.4f | JumpMAE %.4f | data %.4f | unk %d\n', ...
    name,M.RMSE_all,M.RMSE_fault,M.RMSE_bg,M.JumpMAE,M.dataRMSE,M.nUnknowns);
end


function T=make_main_table(sols,M,cvTPS,cvIso,cvFault,cvGJR)
n=numel(sols);
Method=cell(n,1);
Unknowns=zeros(n,1);
RMSE_all=zeros(n,1);
MAE_all=zeros(n,1);
RMSE_fault=zeros(n,1);
MAE_fault=zeros(n,1);
RMSE_bg=zeros(n,1);
JumpMAE=zeros(n,1);
JumpRMSE=zeros(n,1);
DataRMSE=zeros(n,1);
Hyperparameter=cell(n,1);

for i=1:n
    Method{i}=sols{i}.name;
    Unknowns(i)=M{i}.nUnknowns;
    RMSE_all(i)=M{i}.RMSE_all;
    MAE_all(i)=M{i}.MAE_all;
    RMSE_fault(i)=M{i}.RMSE_fault;
    MAE_fault(i)=M{i}.MAE_fault;
    RMSE_bg(i)=M{i}.RMSE_bg;
    JumpMAE(i)=M{i}.JumpMAE;
    JumpRMSE(i)=M{i}.JumpRMSE;
    DataRMSE(i)=M{i}.dataRMSE;
end

Hyperparameter{1}=sprintf('lambda=%.4g',cvTPS.value);
Hyperparameter{2}=sprintf('c0=%.4g',cvIso.value);
Hyperparameter{3}=sprintf('c0=%.4g; eps=%.3g',cvFault.value,cvFault.epsValue);
Hyperparameter{4}=sprintf('p=%d,q=%d',cvGJR.backgroundDegree,cvGJR.jumpDegree);

ref=3; % strongest continuous fault-aware baseline
ImproveAllVsFaultContPct=100*(RMSE_all(ref)-RMSE_all)./RMSE_all(ref);
ImproveFaultVsFaultContPct=100*(RMSE_fault(ref)-RMSE_fault)./RMSE_fault(ref);
ImproveJumpVsFaultContPct=100*(JumpMAE(ref)-JumpMAE)./JumpMAE(ref);

T=table(Method,Hyperparameter,Unknowns,RMSE_all,MAE_all,RMSE_fault, ...
    MAE_fault,RMSE_bg,JumpMAE,JumpRMSE,DataRMSE, ...
    ImproveAllVsFaultContPct,ImproveFaultVsFaultContPct, ...
    ImproveJumpVsFaultContPct);
end


function T=make_geometry_audit_table(G,A,cfg)
FaultIndex=cfg.faultIndex;
AlongLength=G.uMax-G.uMin;
PolygonHalfWidthMedian=G.halfWidth;
PolygonHalfWidth95=G.halfWidth95;
FaultStickAvailable=A.available;
FaultStickLocalPoints=A.nLocal;
F151aPresent=A.hasF151a;
DominantFaultStickNames={A.topNames};

T=table(FaultIndex,AlongLength,PolygonHalfWidthMedian,PolygonHalfWidth95, ...
    FaultStickAvailable,FaultStickLocalPoints,F151aPresent, ...
    DominantFaultStickNames);
end


% =========================================================================
% SPARSE TABLES
% =========================================================================
function T=make_sparse_row(N,r,S,M)
Nobs=N;
Repeat=r;
Method={S.name};
Unknowns=M.nUnknowns;
RMSE_all=M.RMSE_all;
RMSE_fault=M.RMSE_fault;
RMSE_bg=M.RMSE_bg;
JumpMAE=M.JumpMAE;
JumpRMSE=M.JumpRMSE;
DataRMSE=M.dataRMSE;

T=table(Nobs,Repeat,Method,Unknowns,RMSE_all,RMSE_fault,RMSE_bg, ...
    JumpMAE,JumpRMSE,DataRMSE);
end


function S=summarize_sparse(T)
Ns=unique(T.Nobs);
methods=unique(T.Method,'stable');
rows=cell(0,1);
r=0;

for iN=1:numel(Ns)
    for im=1:numel(methods)
        m=T.Nobs==Ns(iN) & strcmp(T.Method,methods{im});
        if ~any(m), continue; end

        [a1,a2]=mean_std(T.RMSE_all(m));
        [f1,f2]=mean_std(T.RMSE_fault(m));
        [b1,b2]=mean_std(T.RMSE_bg(m));
        [j1,j2]=mean_std(T.JumpMAE(m));
        [d1,d2]=mean_std(T.DataRMSE(m));

        r=r+1;
        Nobs=Ns(iN);
        Method=methods(im);
        rows{r,1}=table(Nobs,Method,a1,a2,f1,f2,b1,b2,j1,j2,d1,d2, ...
            'VariableNames',{'Nobs','Method', ...
            'RMSE_all_mean','RMSE_all_std', ...
            'RMSE_fault_mean','RMSE_fault_std', ...
            'RMSE_bg_mean','RMSE_bg_std', ...
            'JumpMAE_mean','JumpMAE_std', ...
            'DataRMSE_mean','DataRMSE_std'}); %#ok<AGROW>
    end
end

S=vertcat(rows{:});
end


function [m,s]=mean_std(x)
x=x(isfinite(x));
if isempty(x)
    m=nan; s=nan;
elseif numel(x)==1
    m=x; s=0;
else
    m=mean(x); s=std(x,0);
end
end


% =========================================================================
% FIGURES
% =========================================================================
function plot_data_overview(outDir,uv,z,obs,G,cfg)
f=figure('Color','w','Units','pixels','Position',[100 100 1250 720]);

scatter(uv(:,1),uv(:,2),8,z,'filled');
hold on;

uu=linspace(G.uMin,G.uMax,500).';
vc=interp1(G.uc,G.vc,uu,'linear','extrap');
plot(uu,vc,'k-','LineWidth',2.0);
plot(obs.uv(:,1),obs.uv(:,2),'wo','MarkerFaceColor','k','MarkerSize',5);

axis equal tight;
grid on;
xlabel('along-fault coordinate u (m)');
ylabel('cross-fault coordinate v (m)');
title(sprintf('C11 interpreted horizon and fault polygon %d centerline',cfg.faultIndex));
cb=colorbar;
cb.Label.String='TVD (m)';
legend({'Dense interpreted horizon','interpreted fault centerline','sparse controls'}, ...
    'Location','best');

save_figure(f,fullfile(outDir,'FIG_01_data_overview.png'),cfg);
end


function plot_reconstruction(outDir,uv,z,sols,G,uRange,vRange,cfg)
[uGrid,vGrid,Q]=visual_grid(uRange,vRange,cfg);
Fref=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
Z0=reshape(Fref(Q(:,1),Q(:,2)),size(uGrid));

Z=cell(numel(sols)+1,1);
Z{1}=Z0;
for i=1:numel(sols)
    Z{i+1}=reshape(predict_solution(sols{i},Q),size(uGrid));
end

allZ=cat(3,Z{:});
clim=[min(allZ(:)),max(allZ(:))];

f=figure('Color','w','Units','pixels','Position',[60 60 1650 900]);
tl=tiledlayout(f,2,3,'Padding','compact','TileSpacing','compact');
titles=[{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)];

lastAx=[];
for i=1:numel(Z)
    ax=nexttile(tl,i);
    imagesc(ax,uGrid(1,:),vGrid(:,1),Z{i});
    set(ax,'YDir','normal');
    axis(ax,'image');
    caxis(ax,clim);
    hold(ax,'on');
    uu=linspace(G.uMin,G.uMax,400);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'k--','LineWidth',1);
    title(ax,titles{i},'FontWeight','bold');
    xlabel(ax,'u (m)'); ylabel(ax,'v (m)');
    lastAx=ax;
end
cb=colorbar(lastAx);
cb.Layout.Tile='east';
cb.Label.String='TVD (m)';
title(tl,'C11 sparse reconstruction with interpreted fault geometry');

save_figure(f,fullfile(outDir,'FIG_02_reconstruction.png'),cfg);
end


function plot_absolute_error(outDir,uv,z,sols,G,uRange,vRange,cfg)
[uGrid,vGrid,Q]=visual_grid(uRange,vRange,cfg);
Fref=scatteredInterpolant(uv(:,1),uv(:,2),z,'nearest','nearest');
z0=Fref(Q(:,1),Q(:,2));

E=cell(numel(sols),1);
mx=0;
for i=1:numel(sols)
    e=abs(predict_solution(sols{i},Q)-z0);
    E{i}=reshape(e,size(uGrid));
    mx=max(mx,percentile_local(e,99));
end

f=figure('Color','w','Units','pixels','Position',[80 80 1400 980]);
tl=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');

lastAx=[];
for i=1:numel(sols)
    ax=nexttile(tl,i);
    imagesc(ax,uGrid(1,:),vGrid(:,1),E{i});
    set(ax,'YDir','normal');
    axis(ax,'image');
    caxis(ax,[0,mx]);
    hold(ax,'on');
    uu=linspace(G.uMin,G.uMax,400);
    vc=interp1(G.uc,G.vc,uu,'linear','extrap');
    plot(ax,uu,vc,'w--','LineWidth',1);
    title(ax,sols{i}.name,'FontWeight','bold');
    xlabel(ax,'u (m)'); ylabel(ax,'v (m)');
    lastAx=ax;
end
cb=colorbar(lastAx);
cb.Layout.Tile='east';
cb.Label.String='|TVD error| (m)';
title(tl,'Absolute error relative to interpreted C11 horizon');

save_figure(f,fullfile(outDir,'FIG_03_absolute_error.png'),cfg);
end


function plot_fault_normal_profile(outDir,sols,R,G,cfg)
u0=0.5*(G.uMin+G.uMax);
[vc,~]=fault_center_and_slope(u0,G);

vSpan=max(420,3*G.halfWidth95);
v=linspace(vc-vSpan,vc+vSpan,600).';
q=[u0*ones(size(v)),v];

zref=reference_predict(R,q,G);

f=figure('Color','w','Units','pixels','Position',[160 160 1050 680]);
plot(v-vc,zref,'k-','LineWidth',2.3);
hold on;
for i=1:numel(sols)
    plot(v-vc,predict_solution(sols{i},q),'LineWidth',1.4);
end
xline(0,'k--','LineWidth',1);
grid on;
xlabel('cross-fault distance (m)');
ylabel('TVD (m)');
title('Fault-normal reconstruction profile at middle of polygon 44');
legend([{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)], ...
    'Location','best');

save_figure(f,fullfile(outDir,'FIG_04_fault_normal_profile.png'),cfg);
end


function plot_cross_fault_contrast(outDir,sols,R,G,cfg)
f=figure('Color','w','Units','pixels','Position',[180 180 1100 680]);
hold on;

[Jref,~,u]=cross_fault_contrast(sols{1},R,G,cfg);
plot(u,Jref,'k-','LineWidth',2.3);

for i=1:numel(sols)
    [~,J,~]=cross_fault_contrast(sols{i},R,G,cfg);
    plot(u,J,'LineWidth',1.4);
end

grid on;
xlabel('along-fault coordinate u (m)');
ylabel('cross-fault TVD contrast (m)');
title('Cross-fault contrast along interpreted fault');
legend([{'Interpreted reference'},cellfun(@(s)s.name,sols,'UniformOutput',false)], ...
    'Location','best');

save_figure(f,fullfile(outDir,'FIG_05_cross_fault_contrast.png'),cfg);
end


function plot_sparse_metric(outDir,S,metric,fileName)
meanName=[metric '_mean'];
stdName=[metric '_std'];
methods=unique(S.Method,'stable');

f=figure('Color','w','Units','pixels','Position',[200 200 950 650]);
hold on;

for i=1:numel(methods)
    m=strcmp(S.Method,methods{i});
    T=S(m,:);
    [~,ord]=sort(T.Nobs);
    T=T(ord,:);
    errorbar(T.Nobs,T.(meanName),T.(stdName),'-o','LineWidth',1.4, ...
        'MarkerSize',6);
end

grid on;
xlabel('number of sparse elevation controls N');
ylabel(strrep(metric,'_','\_'));
title(sprintf('Sparse-observation robustness: %s',metric));
legend(methods,'Location','best');

save_figure(f,fullfile(outDir,fileName),default_config());
end


function [U,V,Q]=visual_grid(uRange,vRange,cfg)
u=linspace(uRange(1),uRange(2),cfg.visNu);
v=linspace(vRange(1),vRange(2),cfg.visNv);
[U,V]=meshgrid(u,v);
Q=[U(:),V(:)];
end


function save_figure(f,fileName,cfg)
drawnow;
try
    exportgraphics(f,fileName,'Resolution',cfg.figureDPI, ...
        'BackgroundColor','white');
catch
    saveas(f,fileName);
end
end


% =========================================================================
% SMALL UTILITIES
% =========================================================================
function q=percentile_local(x,p)
x=x(isfinite(x));
if isempty(x)
    q=nan;
    return;
end
x=sort(x(:));
if numel(x)==1
    q=x;
    return;
end
r=1+(numel(x)-1)*(p/100);
i=floor(r);
j=ceil(r);
if i==j
    q=x(i);
else
    q=x(i)+(r-i)*(x(j)-x(i));
end
end


% =========================================================================
% JOURNAL-STYLE PAPER FIGURES V1
% =========================================================================
function paperfigs_c11_v1(outDir,UVref,Zref,sols,meshU,meshAF,G,obs,mainTable,cfg)

pdir=fullfile(outDir,'PAPER_FIGURES_REBUILT');
if ~exist(pdir,'dir'), mkdir(pdir); end

fontName=paper_font_c11_v1();
cmap=paper_cmap_c11_v1(256);

paper_c11_method_compare_v1(pdir,UVref,Zref,sols,G,obs,cfg,fontName,cmap);
paper_c11_mesh_zoom_v1(pdir,meshU,meshAF,G,obs,fontName);
paper_c11_mesh_local_only_v2(pdir,meshU,meshAF,G,obs,fontName);
paper_c11_geology3d_v1(pdir,UVref,Zref,sols{4},meshAF,G,obs,cfg,fontName,cmap);
paper_c11_fault_local_maps_v2(pdir,UVref,Zref,sols{4},G,obs,cfg,fontName,cmap);
paper_c11_advantage_v1(pdir,mainTable,fontName);

fprintf('  paper figures -> %s\n',pdir);

end


function paper_c11_method_compare_v1(pdir,UVref,Zref,sols,G,obs,cfg,fontName,cmap)

[uGrid,vGrid,Q]=visual_grid([min(UVref(:,1)),max(UVref(:,1))], ...
                           [min(UVref(:,2)),max(UVref(:,2))],cfg);

Fref=scatteredInterpolant(UVref(:,1),UVref(:,2),Zref,'natural','nearest');
Z0=reshape(Fref(Q(:,1),Q(:,2)),size(uGrid));

% Keep the four most informative panels for the paper:
% reference / S-TPS / FAULT-FEM / FAULT-AFEM.
sel=[0 1 3 4];
ZZ=cell(4,1);
ZZ{1}=Z0;
for k=2:4
    ZZ{k}=reshape(predict_solution(sols{sel(k)},Q),size(uGrid));
end

allZ=cat(3,ZZ{:});
clim=[min(allZ(:)),max(allZ(:))];

titles={'解释参考面','S-TPS','断层约束均匀有限元','断层约束自适应有限元'};

f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 14.0], ...
    'Renderer','painters');
tl=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');

for i=1:4
    ax=nexttile(tl,i);
    imagesc(ax,uGrid(1,:),vGrid(:,1),ZZ{i});
    set(ax,'YDir','normal','FontName',fontName,'FontSize',8.5,'LineWidth',0.7, ...
        'TickDir','out','Box','on','Layer','top');
    axis(ax,'image');
    caxis(ax,clim);
    colormap(ax,cmap);
    hold(ax,'on');

    plot(ax,G.uc,G.vc,'-','LineWidth',1.7,'Color',[0.82 0.13 0.10]);
    if i==1 || i==4
        scatter(ax,obs.uv(:,1),obs.uv(:,2),11,'k','filled', ...
            'MarkerEdgeColor','w','LineWidth',0.25);
    end

    title(ax,sprintf('(%c) %s','a'+i-1,titles{i}), ...
        'FontName',fontName,'FontSize',9,'FontWeight','bold');
    xlabel(ax,'u / m','FontName',fontName);
    ylabel(ax,'v / m','FontName',fontName);
end

cb=colorbar;
cb.Layout.Tile='east';
cb.Label.String='煤层面标高 / m';
cb.Label.FontName=fontName;
cb.FontName=fontName;
cb.FontSize=8.5;

exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_01_METHOD_COMPARE.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_01_METHOD_COMPARE.pdf'),'ContentType','vector');
close(f);

end


function paper_c11_mesh_zoom_v1(pdir,meshU,meshA,G,obs,fontName)

f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 13.0], ...
    'Renderer','painters');
tl=tiledlayout(f,2,2,'Padding','compact','TileSpacing','compact');

meshes={meshU,meshA};
names={'均匀网格','自适应网格'};

vC=median(G.vc);
uSpan=G.uMax-G.uMin;
uZoom=[G.uMin+0.15*uSpan, G.uMax-0.15*uSpan];
vHalf=max(110,1.8*G.halfWidth95);
vZoom=[vC-vHalf,vC+vHalf];

for i=1:2
    ax=nexttile(tl,i);
    triplot(meshes{i}.T,meshes{i}.P(:,1),meshes{i}.P(:,2), ...
        'Parent',ax,'Color',[0.35 0.38 0.42],'LineWidth',0.42);
    hold(ax,'on');
    plot(ax,G.uc,G.vc,'-','LineWidth',1.9,'Color',[0.82 0.13 0.10]);
    scatter(ax,obs.uv(:,1),obs.uv(:,2),9,'k','filled');
    axis(ax,'equal'); axis(ax,'tight');
    set(ax,'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
    xlabel(ax,'u / m'); ylabel(ax,'v / m');
    title(ax,sprintf('(%c) %s：全区','a'+i-1,names{i}), ...
        'FontName',fontName,'FontSize',9,'FontWeight','bold');
end

for i=1:2
    ax=nexttile(tl,i+2);
    triplot(meshes{i}.T,meshes{i}.P(:,1),meshes{i}.P(:,2), ...
        'Parent',ax,'Color',[0.30 0.33 0.37],'LineWidth',0.52);
    hold(ax,'on');
    plot(ax,G.uc,G.vc,'-','LineWidth',2.0,'Color',[0.82 0.13 0.10]);
    scatter(ax,obs.uv(:,1),obs.uv(:,2),10,'k','filled');
    xlim(ax,uZoom); ylim(ax,vZoom);
    axis(ax,'equal');
    set(ax,'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
    xlabel(ax,'u / m'); ylabel(ax,'v / m');
    title(ax,sprintf('(%c) %s：断层邻域放大','c'+i-1,names{i}), ...
        'FontName',fontName,'FontSize',9,'FontWeight','bold');
end

exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_02_MESH_LOCAL_ZOOM.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_02_MESH_LOCAL_ZOOM.pdf'),'ContentType','vector');
close(f);

end


function paper_c11_geology3d_v1(pdir,UVref,Zref,solAF,meshAF,G,obs,cfg,fontName,cmap)

f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 8.8], ...
    'Renderer','opengl');
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

% Reference surface.
ax=nexttile(tl,1);
nU=90; nV=70;
u=linspace(min(UVref(:,1)),max(UVref(:,1)),nU);
v=linspace(min(UVref(:,2)),max(UVref(:,2)),nV);
[UU,VV]=meshgrid(u,v);
Fref=scatteredInterpolant(UVref(:,1),UVref(:,2),Zref,'natural','nearest');
ZR=Fref(UU,VV);

surf(ax,UU,VV,-ZR,ZR,'EdgeColor','none','FaceAlpha',1);
hold(ax,'on');
plot3(ax,G.uc,G.vc,-Fref(G.uc,G.vc),'-','LineWidth',2.3,'Color',[0.82 0.13 0.10]);
scatter3(ax,obs.uv(:,1),obs.uv(:,2),-obs.z,14,'k','filled','MarkerEdgeColor','w');
paper_geology_axes_c11_v1(ax,fontName);
title(ax,'(a) 解释参考煤层面','FontName',fontName,'FontSize',9,'FontWeight','bold');
colormap(ax,cmap);

% Adaptive FEM surface.
ax=nexttile(tl,2);
trisurf(meshAF.T,meshAF.P(:,1),meshAF.P(:,2),-solAF.U,solAF.U, ...
    'Parent',ax,'EdgeColor',[0.25 0.28 0.32],'LineWidth',0.28, ...
    'FaceColor','interp','FaceAlpha',1);
hold(ax,'on');

zf=predict_solution(solAF,[G.uc,G.vc]);
plot3(ax,G.uc,G.vc,-zf,'-','LineWidth',2.4,'Color',[0.82 0.13 0.10]);
scatter3(ax,obs.uv(:,1),obs.uv(:,2),-obs.z,14,'k','filled','MarkerEdgeColor','w');
paper_geology_axes_c11_v1(ax,fontName);
title(ax,'(b) 自适应有限元重建煤层面','FontName',fontName,'FontSize',9,'FontWeight','bold');
colormap(ax,cmap);

clim=[min(Zref),max(Zref)];
for k=1:2
    ax=nexttile(tl,k);
    caxis(ax,clim);
end

cb=colorbar;
cb.Layout.Tile='east';
cb.Label.String='煤层面标高 / m';
cb.Label.FontName=fontName;
cb.FontName=fontName;
cb.FontSize=8.5;

exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_03_GEOLOGY_3D.png'),'Resolution',600);
close(f);

end


function paper_geology_axes_c11_v1(ax,fontName)
view(ax,[-38 26]);
axis(ax,'tight');
daspect(ax,[1 1 0.45]);
grid(ax,'on');
box(ax,'on');
set(ax,'FontName',fontName,'FontSize',8.2,'LineWidth',0.65,'TickDir','out', ...
    'GridAlpha',0.16,'MinorGridAlpha',0.08);
xlabel(ax,'u / m','FontName',fontName);
ylabel(ax,'v / m','FontName',fontName);
zlabel(ax,'标高 / m','FontName',fontName);
camlight(ax,'headlight');
lighting(ax,'gouraud');
end


function paper_c11_advantage_v1(pdir,T,fontName)

iF=find(strcmp(T.Method,'FAULT-FEM'),1);
iA=find(strcmp(T.Method,'FAULT-AFEM'),1);

if isempty(iF) || isempty(iA), return; end

base=[T.RMSE_fault(iF),T.RMSE_all(iF),T.RMSE_bg(iF),T.Jump0MAE(iF)];
adap=[T.RMSE_fault(iA),T.RMSE_all(iA),T.RMSE_bg(iA),T.Jump0MAE(iA)];
gain=100*(base-adap)./base;

labels={'断层邻域RMSE','全区RMSE','背景RMSE','断层标高差MAE'};

f=figure('Color','w','Units','centimeters','Position',[2 2 12.0 7.6], ...
    'Renderer','painters');
b=barh(gain,0.58,'FaceColor',[0.17 0.47 0.70],'EdgeColor','none');
ax=gca;
set(ax,'YTick',1:4,'YTickLabel',labels,'YDir','reverse', ...
    'FontName',fontName,'FontSize',8.5,'LineWidth',0.7,'TickDir','out');
xlabel('相对断层约束均匀有限元的改善率 / %','FontName',fontName);
grid(ax,'on'); ax.XGrid='on'; ax.YGrid='off';
xlim([0,max(gain)*1.23]);

for i=1:4
    text(gain(i)+0.35,i,sprintf('%.1f%%',gain(i)), ...
        'FontName',fontName,'FontSize',8.5,'VerticalAlignment','middle');
end

exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_04_ADVANTAGE.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_04_ADVANTAGE.pdf'),'ContentType','vector');
close(f);

end




function paper_c11_mesh_local_only_v2(pdir,meshU,meshA,G,obs,fontName)

f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 7.8], ...
    'Renderer','painters');
tl=tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

meshes={meshU,meshA};
names={'均匀网格','自适应网格'};

vC=median(G.vc);
uSpan=G.uMax-G.uMin;
uZoom=[G.uMin+0.08*uSpan, G.uMax-0.08*uSpan];
vHalf=max(115,1.9*G.halfWidth95);
vZoom=[vC-vHalf,vC+vHalf];

for i=1:2
    ax=nexttile(tl,i);
    triplot(meshes{i}.T,meshes{i}.P(:,1),meshes{i}.P(:,2), ...
        'Parent',ax,'Color',[0.25 0.28 0.31],'LineWidth',0.48);
    hold(ax,'on');
    plot(ax,G.uc,G.vc,'-','LineWidth',2.1,'Color',[0.82 0.13 0.10]);
    inObs=obs.uv(:,1)>=uZoom(1) & obs.uv(:,1)<=uZoom(2) & ...
          obs.uv(:,2)>=vZoom(1) & obs.uv(:,2)<=vZoom(2);
    scatter(ax,obs.uv(inObs,1),obs.uv(inObs,2),12,'k','filled', ...
        'MarkerEdgeColor','w','LineWidth',0.25);
    xlim(ax,uZoom); ylim(ax,vZoom); axis(ax,'equal');
    set(ax,'FontName',fontName,'FontSize',8.5,'LineWidth',0.7, ...
        'TickDir','out','Box','on','Layer','top');
    xlabel(ax,'u / m'); ylabel(ax,'v / m');
    title(ax,sprintf('(%c) %s','a'+i-1,names{i}), ...
        'FontName',fontName,'FontSize',9,'FontWeight','bold');
end

exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_02B_MESH_LOCAL_COMPARE.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_02B_MESH_LOCAL_COMPARE.pdf'),'ContentType','vector');
close(f);
end


function paper_c11_fault_local_maps_v2(pdir,UVref,Zref,solAF,G,obs,cfg,fontName,cmap)

uMin=max(min(UVref(:,1)),G.uMin-40);
uMax=min(max(UVref(:,1)),G.uMax+40);
vMin=max(min(UVref(:,2)),min(G.vc)-145);
vMax=min(max(UVref(:,2)),max(G.vc)+145);

nU=110; nV=70;
u=linspace(uMin,uMax,nU); v=linspace(vMin,vMax,nV);
[UU,VV]=meshgrid(u,v);
Q=[UU(:),VV(:)];

Fref=scatteredInterpolant(UVref(:,1),UVref(:,2),Zref,'natural','nearest');
ZR=reshape(Fref(Q(:,1),Q(:,2)),size(UU));
ZA=reshape(predict_solution(solAF,Q),size(UU));
EA=abs(ZA-ZR);

clim=[min([ZR(:);ZA(:)]),max([ZR(:);ZA(:)])];
eMax=percentile_local(EA(:),97.5);
if ~isfinite(eMax) || eMax<=0, eMax=max(EA(:)); end

f=figure('Color','w','Units','centimeters','Position',[2 2 18.2 6.9], ...
    'Renderer','painters');
tl=tiledlayout(f,1,3,'Padding','compact','TileSpacing','compact');

A={ZR,ZA,EA};
titles={'解释参考面','自适应有限元重建','绝对误差'};
for i=1:3
    ax=nexttile(tl,i);
    imagesc(ax,u,v,A{i}); set(ax,'YDir','normal');
    axis(ax,'image'); hold(ax,'on');
    plot(ax,G.uc,G.vc,'-','LineWidth',1.9,'Color',[0.82 0.13 0.10]);
    inObs=obs.uv(:,1)>=uMin & obs.uv(:,1)<=uMax & obs.uv(:,2)>=vMin & obs.uv(:,2)<=vMax;
    scatter(ax,obs.uv(inObs,1),obs.uv(inObs,2),9,'k','filled', ...
        'MarkerEdgeColor','w','LineWidth',0.2);
    set(ax,'FontName',fontName,'FontSize',8.2,'LineWidth',0.65, ...
        'TickDir','out','Box','on','Layer','top');
    xlabel(ax,'u / m'); ylabel(ax,'v / m');
    title(ax,sprintf('(%c) %s','a'+i-1,titles{i}), ...
        'FontName',fontName,'FontSize',8.8,'FontWeight','bold');
    if i<3
        colormap(ax,cmap); caxis(ax,clim);
    else
        colormap(ax,parula(256)); caxis(ax,[0 eMax]);
    end
end

% Independent compact colorbars so the third panel can use an error scale.
ax1=nexttile(tl,1); cb1=colorbar(ax1,'southoutside');
cb1.Label.String='煤层面标高 / m'; cb1.FontName=fontName; cb1.FontSize=7.8;
ax3=nexttile(tl,3); cb3=colorbar(ax3,'southoutside');
cb3.Label.String='绝对误差 / m'; cb3.FontName=fontName; cb3.FontSize=7.8;

exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_05_FAULT_LOCAL_ZOOM.png'),'Resolution',600);
exportgraphics(f,fullfile(pdir,'PAPER_FIG_C11_05_FAULT_LOCAL_ZOOM.pdf'),'ContentType','vector');
close(f);
end



function dataDir=resolve_data_c11_paper_v3_fix1(scriptDir,cfg)
% Robust deterministic C11 data search. No GUI is opened.
%
% Search order:
%   1) environment variable C11_DATA_DIR
%   2) script/current/parent/grandparent/great-grandparent:
%        <root>/data_C11
%        <root> itself
%   3) recursive search below the project root (grandparent of scriptDir)

required={cfg.horizonFile,cfg.polygonFile};

envDir=getenv('C11_DATA_DIR');
roots={scriptDir,pwd};

p1=fileparts(scriptDir);
p2=fileparts(p1);
p3=fileparts(p2);
roots=[roots,{p1,p2,p3}];

cands={};
if ~isempty(envDir)
    cands{end+1}=envDir; %#ok<AGROW>
end

for i=1:numel(roots)
    if isempty(roots{i}), continue; end
    cands{end+1}=fullfile(roots{i},'data_C11'); %#ok<AGROW>
    cands{end+1}=roots{i}; %#ok<AGROW>
end

% Stable unique.
keep=true(size(cands));
for i=2:numel(cands)
    keep(i)=~any(strcmpi(cands{i},cands(1:i-1)));
end
cands=cands(keep);

for i=1:numel(cands)
    if has_required_c11_v3_fix1(cands{i},required)
        dataDir=cands{i};
        return;
    end
end

% Recursive project search, limited to the project root rather than the
% whole drive. For E:\...\代码\绘图 this normally searches E:\...\ .
projectRoot=p2;
if isempty(projectRoot) || ~isfolder(projectRoot)
    projectRoot=p1;
end

try
    hit=dir(fullfile(projectRoot,'**',cfg.horizonFile));
    for i=1:numel(hit)
        d=hit(i).folder;
        if has_required_c11_v3_fix1(d,required)
            dataDir=d;
            return;
        end
    end
catch
    % Older MATLAB releases may not support ** recursion. Direct candidate
    % search above remains valid.
end

error(['Cannot find C11 source data. Required files are %s and %s.\n' ...
       'Recommended folder: <project root>\data_C11\n' ...
       'Alternatively set environment variable C11_DATA_DIR or pass the ' ...
       'data directory into this function.'],cfg.horizonFile,cfg.polygonFile);
end


function tf=has_required_c11_v3_fix1(d,required)
tf=isfolder(d);
if ~tf, return; end
for j=1:numel(required)
    if ~isfile(fullfile(d,required{j}))
        tf=false;
        return;
    end
end
end


function name=paper_font_c11_v1()
cands={'Microsoft YaHei','SimHei','SimSun','Arial Unicode MS','Arial'};
avail=listfonts;
name='Arial';
for i=1:numel(cands)
    if any(strcmpi(avail,cands{i}))
        name=cands{i}; return;
    end
end
end


function C=paper_cmap_c11_v1(n)
if nargin<1, n=256; end
anchor=[ ...
    0.12 0.30 0.60; ...
    0.10 0.55 0.72; ...
    0.28 0.72 0.65; ...
    0.70 0.82 0.48; ...
    0.96 0.79 0.28; ...
    0.88 0.38 0.16];
x=linspace(0,1,size(anchor,1));
xi=linspace(0,1,n);
C=[interp1(x,anchor(:,1),xi,'pchip')', ...
   interp1(x,anchor(:,2),xi,'pchip')', ...
   interp1(x,anchor(:,3),xi,'pchip')'];
C=max(0,min(1,C));
end
