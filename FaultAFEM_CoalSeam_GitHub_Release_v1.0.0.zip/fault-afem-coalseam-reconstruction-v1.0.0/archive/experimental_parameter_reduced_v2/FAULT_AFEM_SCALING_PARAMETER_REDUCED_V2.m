function outDir = FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2(profile)
% FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2
% =========================================================================
% 2-D scale-expansion validation using the same reduced-parameter logic:
%   - sigma_Gamma is derived once from the base-scale sparse-control spacing;
%   - (lambda_dimless, epsilon_min) are selected by base-scale spatial CV;
%   - these calibrated values are frozen for every larger scale and seed;
%   - adaptive marking is residual-Dorfler UNION one-sigma fault geometry;
%   - no 0.65/0.35 mixing or geometry-priority coefficient is used.
%
% Dense synthetic truth is used only for retrospective matched-accuracy
% evaluation, never for parameter calibration or adaptive marking.
%
% Usage:
%   outDir = FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2('quick');
%   outDir = FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2('paper');
% =========================================================================
clc;
close all;

if nargin<1 || isempty(profile)
    profile='paper';
end
cfg = scaling_cfg(profile);

scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir)
    scriptDir = pwd;
end

stamp = datestr(now,'yyyymmdd_HHMMSS');
outDir = fullfile(scriptDir,['out_FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2_' stamp]);

if ~exist(outDir,'dir')
    mkdir(outDir);
end

diary(fullfile(outDir,'SCALING_LOG.txt'));
cleanupDiary = onCleanup(@() diary('off')); %#ok<NASGU>

fprintf('\n============================================================\n');
fprintf('FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2\n');
fprintf('Profile : %s\n',upper(cfg.profile));
fprintf('Scales  : %s\n',mat2str(cfg.scales));
fprintf('Seeds   : %s\n',mat2str(cfg.seeds));
fprintf('Output  : %s\n',outDir);
fprintf('============================================================\n\n');

fprintf('[Theory] Two-level idealized node-ratio model\n');
fprintf('  N_loc/N_uni ~= rho + (1-rho)/chi^2, chi=h_coarse/h_fine\n\n');

% =========================================================================
% Base-scale sparse-data calibration.  Parameters are frozen afterwards.
% =========================================================================
calSeed=cfg.seeds(1);
rng(calSeed + 1000,'twister');
calProblem=build_scaling_problem(cfg.baseLx,cfg.baseLy,1,cfg);

cfg.faultTensorSigma=median_nearest_neighbor_distance_paramred_v2(calProblem.obsXY);
Cal=calibrate_scaling_regularization_paramred_v2(calProblem,cfg);
cfg.lambdaDimless=Cal.lambdaValue;
cfg.epsMin=Cal.epsValue;

fprintf('[Calibration] sparse-data only\n');
fprintf('  sigma_Gamma        : %.6f m (median control NN spacing)\n',cfg.faultTensorSigma);
fprintf('  lambda_dimless     : %.6g\n',cfg.lambdaDimless);
fprintf('  epsilon_min        : %.6g\n\n',cfg.epsMin);

writetable(Cal.table,fullfile(outDir,'SCALING_PARAMETER_CALIBRATION.csv'));

allCurveRows = table();
matchedRows = table();
theoryRows = table();

runCounter = 0;
totalRuns = numel(cfg.scales)*numel(cfg.seeds);

for is = 1:numel(cfg.scales)

    scale = cfg.scales(is);

    Lx = cfg.baseLx*scale;
    Ly = cfg.baseLy*scale;

    fprintf('\n============================================================\n');
    fprintf('DOMAIN SCALE %g | %.1f km x %.1f km\n', ...
        scale,Lx/1000,Ly/1000);
    fprintf('============================================================\n');

    theoryRow = make_theory_row(scale,Lx,Ly,cfg);
    theoryRows = [theoryRows; theoryRow]; %#ok<AGROW>

    for ir = 1:numel(cfg.seeds)

        runCounter = runCounter + 1;
        seed = cfg.seeds(ir);

        fprintf('\n------------------------------------------------------------\n');
        fprintf('[Run %d/%d] scale=%g | seed=%d\n', ...
            runCounter,totalRuns,scale,seed);
        fprintf('------------------------------------------------------------\n');

        rng(seed + round(1000*scale),'twister');

        problem = build_scaling_problem(Lx,Ly,scale,cfg);

        fprintf('  observations          : %d\n',size(problem.obsXY,1));
        fprintf('  fault eval points     : %d\n',size(problem.evalFaultXY,1));
        fprintf('  global eval points    : %d\n',size(problem.evalGlobalXY,1));

        % -------------------------------------------------------------
        % Stage A: dense uniform fault-aware FEM curve.
        % -------------------------------------------------------------
        fprintf('\n  [A] Dense uniform fault-aware FEM curve\n');

        uniformCurve = run_uniform_curve(problem,cfg,scale,seed);

        bestUniform = min(uniformCurve.RMSEFault);

        % -------------------------------------------------------------
        % Stage B: broad AFEM curve.  It may stop early once it has
        % already crossed the provisional uniform-based target.
        % -------------------------------------------------------------
        fprintf('\n  [B] Broad Fault-AFEM curve\n');

        adaptiveCurve = run_adaptive_curve_v2( ...
            problem,cfg,scale,seed,bestUniform);

        % -------------------------------------------------------------
        % Stage C: strict common-target bracketing.
        % -------------------------------------------------------------
        fprintf('\n  [C] Strict common-target matching\n');

        bestU0 = min(uniformCurve.RMSEFault);
        bestA0 = min(adaptiveCurve.RMSEFault);

        % PAPER rule: target is anchored ONLY to the uniform reference.
        % AFEM is not allowed to relax the target.
        target = cfg.accuracySlack*bestU0;

        fprintf('    initial best uniform : %.6f m\n',bestU0);
        fprintf('    initial best AFEM    : %.6f m\n',bestA0);
        fprintf('    PAPER common target  : %.6f m = %.3f * bestUniform\n', ...
            target,cfg.accuracySlack);

        uniformCurve = strict_refine_uniform_threshold( ...
            uniformCurve,problem,target,cfg,scale,seed);

        adaptiveCurve = strict_refine_afem_threshold( ...
            adaptiveCurve,problem,target,cfg,scale,seed);

        theorySaving = theoryRow.IdealizedNodeSavingPct2D(1);

        matched = make_strict_match_row( ...
            uniformCurve,adaptiveCurve,target, ...
            theorySaving,scale,seed,problem,cfg);

        matchedRows = [matchedRows; matched]; %#ok<AGROW>

        curve = [uniformCurve; adaptiveCurve];
        allCurveRows = [allCurveRows; curve]; %#ok<AGROW>

        fprintf('\n  [Strict matched accuracy]\n');
        fprintf('    status                    : %s\n',matched.MatchStatus{1});
        fprintf('    target fault RMSE         : %.6f m\n',matched.TargetFaultRMSE);

        fprintf('    uniform fail/pass nodes   : %g / %g\n', ...
            matched.UniformFailNodes,matched.UniformPassNodes);
        fprintf('    AFEM fail/pass nodes      : %g / %g\n', ...
            matched.AFEMFailNodes,matched.AFEMPassNodes);

        fprintf('    uniform bracket width     : %.3f %%\n', ...
            matched.UniformBracketWidthPct);
        fprintf('    AFEM bracket width        : %.3f %%\n', ...
            matched.AFEMBracketWidthPct);

        fprintf('    uniform interpolated N*   : %.2f\n', ...
            matched.UniformInterpolatedNodes);
        fprintf('    AFEM interpolated N*      : %.2f\n', ...
            matched.AFEMInterpolatedNodes);

        fprintf('    conservative node saving  : %+7.2f %%\n', ...
            matched.NodeSavingPct);
        fprintf('    interpolated node saving  : %+7.2f %%\n', ...
            matched.InterpolatedNodeSavingPct);

        fprintf('    theory node saving        : %+7.2f %%\n', ...
            matched.TheoryNodeSavingPct);
        fprintf('    interp - theory           : %+7.2f percentage points\n', ...
            matched.InterpolatedMinusTheoryPctPoints);

        fprintf('    nnz saving                : %+7.2f %%\n', ...
            matched.NNZSavingPct);
        fprintf('    matrix storage saving     : %+7.2f %%\n', ...
            matched.MatrixSavingPct);
        fprintf('    final-solve time saving   : %+7.2f %%\n', ...
            matched.SolveTimeSavingPct);
        fprintf('    global RMSE penalty       : %+7.2f %%\n', ...
            matched.GlobalPenaltyPct);
    end
end

% =========================================================================
% Aggregate by scale.
% =========================================================================
fprintf('\n============================================================\n');
fprintf('[Aggregate] Matched-accuracy scaling summary\n');
fprintf('============================================================\n');

agg = aggregate_matched_rows(matchedRows,cfg);

disp(agg);

writetable(allCurveRows,fullfile(outDir,'SCALING_ALL_CURVES.csv'));
writetable(matchedRows,fullfile(outDir,'SCALING_PAPER_MATCHED_ACCURACY.csv'));
writetable(agg,fullfile(outDir,'SCALING_AGGREGATE.csv'));
writetable(theoryRows,fullfile(outDir,'SCALING_THEORY.csv'));
paperSummary = build_paper_summary_table(matchedRows,agg);
writetable(paperSummary,fullfile(outDir,'SCALING_PAPER_SUMMARY.csv'));

% =========================================================================
% Figures.
% =========================================================================
fprintf('\n[Figures] Creating scaling plots ...\n');

plot_nodes_vs_scale(agg,theoryRows,outDir,cfg);
plot_node_saving_vs_scale(agg,theoryRows,outDir,cfg);
plot_accuracy_dof_curves(allCurveRows,outDir,cfg);
plot_cost_ratios(agg,outDir,cfg);
plot_bracket_resolution(agg,outDir,cfg);

% =========================================================================
% Save state.
% =========================================================================
S = struct();
S.cfg = cfg;
S.calibration = Cal;
S.allCurves = allCurveRows;
S.matched = matchedRows;
S.aggregate = agg;
S.theory = theoryRows;

save(fullfile(outDir,'SCALING_STATE.mat'),'S','-v7.3');

write_scaling_readme(fullfile(outDir,'SCALING_README.txt'),cfg,agg);

fprintf('\n============================================================\n');
fprintf('SCALING VALIDATION FINISHED\n');
fprintf('Output: %s\n',outDir);
fprintf('============================================================\n');

end


% =========================================================================
% CONFIGURATION
% =========================================================================
function cfg = scaling_cfg(profile)

% -------------------------------------------------------------------------
% Run profile.
%
% QUICK first:
%   scale = [1 2 4], one seed.
%
% PAPER after QUICK is verified:
%   scale = [1 2 4 8], three independent observation/noise seeds.
% -------------------------------------------------------------------------
cfg.profile = lower(char(profile));

switch lower(cfg.profile)

    case 'quick'

        cfg.scales = [1 2 4];
        cfg.seeds = 20260816;

    case 'paper'

        cfg.scales = [1 2 4 8];
        cfg.seeds = [20260816 20260917 20261027];

    otherwise
        error('Unknown cfg.profile = %s',cfg.profile);
end

% -------------------------------------------------------------------------
% Physical domain.
% -------------------------------------------------------------------------
cfg.baseLx = 1000;                 % m
cfg.baseLy = 1000;                 % m

% -------------------------------------------------------------------------
% DENSE uniform resolution ladder.
%
% This is deliberately much denser than V1.  The strict bracket refinement
% below adds additional h values only around the target crossing.
% -------------------------------------------------------------------------
cfg.uniformH = [ ...
    160 140 120 105 90 80 70 62.5 57.5 52.5 ...
    47.5 43 39 35];

cfg.hFine = min(cfg.uniformH);
cfg.hCoarse = 160;

% If the coarsest tested mesh already passes, V2 may expand to a still
% coarser uniform mesh to create a genuine FAIL/PASS bracket.
cfg.uniformHMaxStrict = 260;

% -------------------------------------------------------------------------
% Broad AFEM budget fractions relative to the finest uniform node count.
%
% V2 stops the broad AFEM scan as soon as it crosses the provisional
% uniform-based common target.  Fine threshold localization is then handled
% by strict_refine_afem_threshold().
% -------------------------------------------------------------------------
cfg.adaptiveBudgetFractions = ...
    [0.06 0.10 0.16 0.24 0.34 0.46 0.60 0.76 0.90];

% -------------------------------------------------------------------------
% STRICT threshold matching.
% -------------------------------------------------------------------------
cfg.accuracySlack = 1.05;

% Target bracket is considered resolved when
%
%     (N_pass - N_fail)/N_pass <= bracketRelTol
%
cfg.bracketRelTol = 0.03;          % 3 %
cfg.uniformBracketMaxRounds = 4;
cfg.afemBracketMaxRounds = 4;

% Number of new interior samples per local bracket round.
cfg.uniformBracketInterior = 4;
cfg.afemBracketInterior = 3;

% AFEM also uses an absolute stop because very small problems can have a
% 3 % width of only a few nodes.
cfg.afemBracketAbsNodes = 12;

% -------------------------------------------------------------------------
% FIXED-PHYSICAL-SCALE synthetic geology.
%
% Unlike V1, wavelengths and fault waviness are specified in METERS and do
% not scale with Lx/Ly.  Expanding the domain therefore adds more geological
% structure rather than making the model physically smoother.
% -------------------------------------------------------------------------
cfg.backgroundLevel = -520;

cfg.backgroundSlopeXPerKm = 3.0;   % m per km
cfg.backgroundSlopeYPerKm = -2.0;

cfg.bgAmp1 = 4.5;
cfg.bgLambdaX1 = 700;
cfg.bgLambdaY1 = 900;
cfg.bgPhase1 = 0.20;

cfg.bgAmp2 = 3.2;
cfg.bgLambdaX2 = 420;
cfg.bgLambdaY2 = 650;
cfg.bgPhase2 = -0.45;

cfg.bgAmp3 = 1.8;
cfg.bgLambdaX3 = 1100;
cfg.bgLambdaY3 = 360;
cfg.bgPhase3 = 0.75;

% Fault geometry: physical amplitudes/wavelengths are also fixed.
cfg.faultAmp1 = 85;                % m
cfg.faultLambda1 = 1200;           % m
cfg.faultPhase1 = 0.35;

cfg.faultAmp2 = 28;                % m
cfg.faultLambda2 = 560;            % m
cfg.faultPhase2 = -0.55;

cfg.jumpAmp = 14.0;                % m
cfg.jumpTransitionWidth = 8.0;     % m

% -------------------------------------------------------------------------
% Fault-aware tensor.
% -------------------------------------------------------------------------
cfg.epsMin = nan;               % selected by sparse-data CV
cfg.epsGrid = [0.01 0.03 0.06 0.10 0.20];
cfg.faultTensorSigma = nan;        % derived from base-scale controls

% -------------------------------------------------------------------------
% Sparse observations.
%
% Observation density is kept approximately constant:
%
%      Nobs(scale) ~= baseNObs * scale^2.
% -------------------------------------------------------------------------
cfg.baseNObs = 80;
cfg.obsNoiseStd = 0.20;
cfg.obsBoundaryMarginFrac = 0.02;

% -------------------------------------------------------------------------
% Evaluation resolution remains fixed in physical units.
% -------------------------------------------------------------------------
cfg.faultBandWidth = 100;
cfg.faultEvalAlongSpacing = 20;
cfg.faultEvalOffsets = -100:25:100;

cfg.globalEvalSpacing = 80;

% -------------------------------------------------------------------------
% Dimensionless regularization normalization.
% -------------------------------------------------------------------------
cfg.lambdaDimless = nan;        % selected by sparse-data CV
cfg.lambdaGrid = [0.03 0.06 0.10 0.20 0.40 0.80];
cfg.ridgeRelative = 1e-10;

% -------------------------------------------------------------------------
% Adaptive indicator.
% -------------------------------------------------------------------------
cfg.dorflerTheta = 0.50;

cfg.geoForceThreshold = exp(-0.5); % one-sigma geometry set

cfg.minInsertDistance = 0.20*cfg.hFine;
cfg.maxAdaptiveIterationsPerBudget = 30;

% -------------------------------------------------------------------------
% Solver.
% -------------------------------------------------------------------------
cfg.pcgTol = 1e-8;
cfg.pcgMaxIt = 700;
cfg.icholDiagComp = 0.01;

% -------------------------------------------------------------------------
% Figures.
% -------------------------------------------------------------------------
cfg.figureDPI = 300;
end



% =========================================================================
% PARAMETER-REDUCED SPARSE-DATA CALIBRATION
% =========================================================================
function dmed = median_nearest_neighbor_distance_paramred_v2(XY)
% Robust data-support scale from the sparse controls.  No dense truth enters.
XY=double(XY);
n=size(XY,1);
if n<2
    error('At least two controls are required to derive sigma_Gamma.');
end
dmin=inf(n,1);
for i=1:n
    dx=XY(:,1)-XY(i,1);
    dy=XY(:,2)-XY(i,2);
    d=sqrt(dx.^2+dy.^2);
    d(i)=inf;
    dmin(i)=min(d);
end
dmed=median(dmin(isfinite(dmin) & dmin>0));
if ~(isfinite(dmed) && dmed>0)
    error('Unable to derive a positive median nearest-neighbour spacing.');
end
end


function Cal = calibrate_scaling_regularization_paramred_v2(problem,cfg)
% Joint sparse-data CV for (lambda_dimless, epsilon_min) on the base scale.
%
% The dense synthetic truth is deliberately NOT used here.  A fixed
% checkerboard spatial split is constructed from the sparse controls.
% lambda_dimless is converted to the dimensional coefficient on every
% training fold by trace normalization of H''H and K.

hCal=median(cfg.uniformH);
[P,T]=structured_tri_mesh(problem.Lx,problem.Ly,hCal);
[H,tid]=interpolation_matrix(P,T,problem.obsXY);
valid=isfinite(tid);
if nnz(valid)<max(12,round(0.8*numel(valid)))
    error('Calibration mesh does not contain enough sparse controls.');
end

XY=problem.obsXY(valid,:);
z=problem.obsZ(valid);
H=H(valid,:);

% Four spatial checkerboard folds.  The count is fixed algorithmically and
% does not change across scales or seeds.
Kfold=4;
xu=min(max(XY(:,1)/max(problem.Lx,eps),0),1-eps);
yu=min(max(XY(:,2)/max(problem.Ly,eps),0),1-eps);
ix=floor(4*xu);
iy=floor(4*yu);
fold=mod(ix+2*iy,Kfold)+1;

rows=table();
bestMean=inf;
bestLambda=nan;
bestEps=nan;

for ie=1:numel(cfg.epsGrid)
    cfgE=cfg;
    cfgE.epsMin=cfg.epsGrid(ie);
    K=assemble_fault_stiffness(P,T,problem.Lx,problem.Ly,cfgE);
    scaleK=full(trace(K))/max(size(P,1),1);
    if ~(isfinite(scaleK) && scaleK>0), scaleK=1; end

    for il=1:numel(cfg.lambdaGrid)
        vals=nan(Kfold,1);

        for f=1:Kfold
            te=(fold==f);
            tr=~te;
            if nnz(te)<2 || nnz(tr)<4
                continue;
            end

            Htr=H(tr,:);
            Hte=H(te,:);
            ztr=z(tr);
            zte=z(te);

            HtH=Htr'*Htr;
            scaleH=full(trace(HtH))/max(size(P,1),1);
            if ~(isfinite(scaleH) && scaleH>0), scaleH=1; end

            cEff=cfg.lambdaGrid(il)*(scaleH/scaleK);
            A=HtH+cEff*K;
            ds=mean(full(diag(A)));
            if ~(isfinite(ds) && ds>0), ds=1; end
            A=A+cfg.ridgeRelative*ds*speye(size(A,1));
            b=Htr'*ztr;

            [U,~,~,~,~]=robust_pcg(A,b,cfg);
            e=Hte*U-zte;
            vals(f)=mean(e.^2);
        end

        ok=isfinite(vals);
        if nnz(ok)<2
            mu=inf; se=inf;
        else
            mu=mean(vals(ok));
            se=std(vals(ok),0)/sqrt(nnz(ok));
        end

        row=table(cfg.lambdaGrid(il),cfg.epsGrid(ie),mu,se,nnz(ok), ...
            'VariableNames',{'LambdaDimless','EpsilonMin','MeanCVMSE','SECVMSE','ValidFolds'});
        rows=[rows;row]; %#ok<AGROW>

        if mu<bestMean
            bestMean=mu;
            bestLambda=cfg.lambdaGrid(il);
            bestEps=cfg.epsGrid(ie);
        end
    end
end

if ~(isfinite(bestMean) && isfinite(bestLambda) && isfinite(bestEps))
    error('Sparse-data joint calibration of lambda and epsilon_min failed.');
end

Cal=struct();
Cal.lambdaValue=bestLambda;
Cal.epsValue=bestEps;
Cal.bestMeanCVMSE=bestMean;
Cal.table=rows;
Cal.meshH=hCal;
Cal.sigmaGamma=cfg.faultTensorSigma;
end


% =========================================================================
% PROBLEM GENERATION
% =========================================================================
function problem = build_scaling_problem(Lx,Ly,scale,cfg)

nObs = max(40,round(cfg.baseNObs*scale^2));

marginX = cfg.obsBoundaryMarginFrac*Lx;
marginY = cfg.obsBoundaryMarginFrac*Ly;

obsX = marginX + (Lx-2*marginX)*rand(nObs,1);
obsY = marginY + (Ly-2*marginY)*rand(nObs,1);

obsXY = [obsX obsY];

zTrue = synthetic_truth(obsXY,Lx,Ly,cfg);
obsZ = zTrue + cfg.obsNoiseStd*randn(nObs,1);

% Fault-band evaluation points.
xAlong = (0:cfg.faultEvalAlongSpacing:Lx).';
if xAlong(end)<Lx
    xAlong = [xAlong; Lx]; %#ok<AGROW>
end

yf = fault_y(xAlong,Lx,Ly,cfg);
slope = fault_slope(xAlong,Lx,Ly,cfg);

nvec = [-slope,ones(size(slope))];
nrm = sqrt(sum(nvec.^2,2));
nvec = nvec./nrm;

evalFaultXY = zeros(0,2);

for j = 1:numel(cfg.faultEvalOffsets)

    q = [xAlong yf] + cfg.faultEvalOffsets(j)*nvec;

    inside = q(:,1)>=0 & q(:,1)<=Lx & q(:,2)>=0 & q(:,2)<=Ly;

    evalFaultXY = [evalFaultXY; q(inside,:)]; %#ok<AGROW>
end

evalFaultZ = synthetic_truth(evalFaultXY,Lx,Ly,cfg);

% Global evaluation lattice.
xg = 0:cfg.globalEvalSpacing:Lx;
yg = 0:cfg.globalEvalSpacing:Ly;

if xg(end)<Lx, xg=[xg Lx]; end %#ok<AGROW>
if yg(end)<Ly, yg=[yg Ly]; end %#ok<AGROW>

[XG,YG] = meshgrid(xg,yg);

evalGlobalXY = [XG(:) YG(:)];
evalGlobalZ = synthetic_truth(evalGlobalXY,Lx,Ly,cfg);

problem = struct();
problem.Lx = Lx;
problem.Ly = Ly;

problem.obsXY = obsXY;
problem.obsZ = obsZ;

problem.evalFaultXY = evalFaultXY;
problem.evalFaultZ = evalFaultZ;

problem.evalGlobalXY = evalGlobalXY;
problem.evalGlobalZ = evalGlobalZ;
end


function z = synthetic_truth(XY,Lx,Ly,cfg)

x = XY(:,1);
y = XY(:,2);

% Fixed physical dip/trend.
trend = cfg.backgroundLevel ...
    + cfg.backgroundSlopeXPerKm*((x-0.5*Lx)/1000) ...
    + cfg.backgroundSlopeYPerKm*((y-0.5*Ly)/1000);

% Fixed physical wavelengths: expanding Lx/Ly creates more cycles rather
% than stretching the same one-cycle model over a larger region.
u1 = cfg.bgAmp1 ...
    .* sin(2*pi*x/cfg.bgLambdaX1 + cfg.bgPhase1) ...
    .* cos(2*pi*y/cfg.bgLambdaY1 - 0.15);

u2 = cfg.bgAmp2 ...
    .* cos(2*pi*x/cfg.bgLambdaX2 + cfg.bgPhase2) ...
    .* sin(2*pi*y/cfg.bgLambdaY2 + 0.30);

u3 = cfg.bgAmp3 ...
    .* sin(2*pi*x/cfg.bgLambdaX3 + cfg.bgPhase3) ...
    .* sin(2*pi*y/cfg.bgLambdaY3 - 0.20);

bg = trend + u1 + u2 + u3;

phi = fault_signed_distance_approx(XY,Lx,Ly,cfg);

jump = 0.5*cfg.jumpAmp*tanh(phi/cfg.jumpTransitionWidth);

z = bg + jump;
end


function y = fault_y(x,Lx,Ly,cfg) %#ok<INUSD>

y = 0.5*Ly ...
    + cfg.faultAmp1 ...
    .* sin(2*pi*x/cfg.faultLambda1 + cfg.faultPhase1) ...
    + cfg.faultAmp2 ...
    .* sin(2*pi*x/cfg.faultLambda2 + cfg.faultPhase2);
end


function s = fault_slope(x,Lx,Ly,cfg) %#ok<INUSD>

s = cfg.faultAmp1*(2*pi/cfg.faultLambda1) ...
    .* cos(2*pi*x/cfg.faultLambda1 + cfg.faultPhase1) ...
    + cfg.faultAmp2*(2*pi/cfg.faultLambda2) ...
    .* cos(2*pi*x/cfg.faultLambda2 + cfg.faultPhase2);
end


function phi = fault_signed_distance_approx(XY,Lx,Ly,cfg)

x = XY(:,1);
y = XY(:,2);

yf = fault_y(x,Lx,Ly,cfg);
s = fault_slope(x,Lx,Ly,cfg);

phi = (y-yf)./sqrt(1+s.^2);
end


function g = fault_gate(XY,Lx,Ly,cfg)

phi = fault_signed_distance_approx(XY,Lx,Ly,cfg);

g = exp(-0.5*(abs(phi)/cfg.faultTensorSigma).^2);
end


% =========================================================================
% UNIFORM CURVE
% =========================================================================
function curve = run_uniform_curve(problem,cfg,scale,seed)

curve = table();

for ih = 1:numel(cfg.uniformH)

    h = cfg.uniformH(ih);

    [P,T] = structured_tri_mesh(problem.Lx,problem.Ly,h);

    fprintf('    h=%6.1f m | nodes=%7d | tri=%7d ... ', ...
        h,size(P,1),size(T,1));

    result = solve_and_evaluate(P,T,problem,cfg);

    fprintf('fault=%.4f | global=%.4f | solve=%.3fs\n', ...
        result.RMSEFault,result.RMSEGlobal,result.SolveTime);

    row = make_curve_row( ...
        scale,seed,'UNIFORM-FAULT-FEM',ih,h,nan,P,T,result);

    curve = [curve; row]; %#ok<AGROW>
end
end


% =========================================================================
% ADAPTIVE CURVE
% =========================================================================
function curve = run_adaptive_curve_v2( ...
    problem,cfg,scale,seed,bestUniform)

[Pfine,~] = structured_tri_mesh(problem.Lx,problem.Ly,cfg.hFine);
nFine = size(Pfine,1);

[P,T] = structured_tri_mesh(problem.Lx,problem.Ly,cfg.hCoarse);

minBudget = size(P,1);

budgets = round(cfg.adaptiveBudgetFractions*nFine);
budgets = max(budgets,minBudget);
budgets = unique(budgets,'stable');

if budgets(1)>minBudget
    budgets = [minBudget budgets];
end

curve = table();

current = solve_and_evaluate(P,T,problem,cfg);

provisionalTarget = cfg.accuracySlack*bestUniform;

for ib = 1:numel(budgets)

    targetBudget = budgets(ib);

    if size(P,1)<targetBudget

        [P,T,current] = refine_to_budget( ...
            P,T,current,problem,targetBudget,cfg);
    end

    current = solve_and_evaluate(P,T,problem,cfg);

    fprintf('    budget=%7d | actual=%7d | tri=%7d | fault=%.4f | global=%.4f | solve=%.3fs\n', ...
        targetBudget,size(P,1),size(T,1), ...
        current.RMSEFault,current.RMSEGlobal,current.SolveTime);

    row = make_curve_row( ...
        scale,seed,'FAULT-AFEM',ib,nan,targetBudget,P,T,current);

    curve = [curve; row]; %#ok<AGROW>

    % If AFEM is already at least as accurate as the provisional target
    % based on the best uniform curve, no larger broad budgets are needed.
    % Strict local bracketing follows immediately afterwards.
    if ib>=2 && current.RMSEFault<=provisionalTarget

        fprintf('      broad AFEM early stop: crossed provisional target %.6f m\n', ...
            provisionalTarget);
        break;
    end
end
end


function [P,T,current] = refine_to_budget( ...
    P,T,current,problem,targetBudget,cfg)

iter = 0;

while size(P,1)<targetBudget

    iter = iter+1;

    if iter>cfg.maxAdaptiveIterationsPerBudget
        warning('Adaptive refinement hit iteration cap before budget.');
        break;
    end

    [indicator,hT,centroid] = adaptive_indicator( ...
        P,T,current.U,current.obsResidual,problem,cfg);

    canRefine = hT > 0.90*cfg.hFine;

    if ~any(canRefine)
        break;
    end

    score = current.triArea .* indicator.^2;
    score(~canRefine) = 0;

    % Residual-based Dörfler set.
    markRes = dorfler_mark(score,cfg.dorflerTheta);

    % Geometry set: all refinable elements whose centroids lie inside the
    % one-sigma fault band.  This is a set-union rule, not a weighted sum.
    geo = fault_gate(centroid,problem.Lx,problem.Ly,cfg);
    markGeo = find(geo>=cfg.geoForceThreshold & canRefine);

    mark = unique([markRes(:); markGeo(:)]);
    mark = mark(canRefine(mark));

    if isempty(mark)
        break;
    end

    gap = targetBudget-size(P,1);

    if numel(mark)>gap
        % Under a hard node budget, retain candidates with the strongest
        % residual OR geometry evidence.  No additional empirical weight is
        % introduced.
        priority = max(indicator(mark),geo(mark));
        [~,ord] = sort(priority,'descend');
        mark = mark(ord(1:gap));
    end

    newPts = centroid(mark,:);

    newPts = filter_new_points(newPts,P,cfg.minInsertDistance);

    if isempty(newPts)
        break;
    end

    if size(newPts,1)>gap
        newPts = newPts(1:gap,:);
    end

    P = [P; newPts]; %#ok<AGROW>

    % Node-nested, connectivity-retriangulated adaptive sequence.
    DT = delaunayTriangulation(P);
    T = DT.ConnectivityList;

    current = solve_and_evaluate(P,T,problem,cfg);
end
end


% =========================================================================
% FEM SOLVE
% =========================================================================
function result = solve_and_evaluate(P,T,problem,cfg)

tTotal = tic;

[H,obsTri] = interpolation_matrix(P,T,problem.obsXY);

[K,triArea,gradPhi,Dcomp] = assemble_fault_stiffness( ...
    P,T,problem.Lx,problem.Ly,cfg); %#ok<ASGLU>

HtH = H'*H;

scaleH = full(trace(HtH))/max(size(P,1),1);
scaleK = full(trace(K))/max(size(P,1),1);

if ~(isfinite(scaleH) && scaleH>0)
    scaleH = 1;
end
if ~(isfinite(scaleK) && scaleK>0)
    scaleK = 1;
end

cEff = cfg.lambdaDimless*(scaleH/scaleK);

tAssembly = toc(tTotal);

A = HtH + cEff*K;
b = H'*problem.obsZ;

diagScale = mean(full(diag(A)));

if ~(isfinite(diagScale) && diagScale>0)
    diagScale = 1;
end

A = A + cfg.ridgeRelative*diagScale*speye(size(A,1));

wA = whos('A');

tSolve = tic;

[U,flag,relres,iters,precondName] = robust_pcg(A,b,cfg);

solveTime = toc(tSolve);

predObs = H*U;
obsResidual = predObs-problem.obsZ;

predFault = evaluate_fem(P,T,U,problem.evalFaultXY);
predGlobal = evaluate_fem(P,T,U,problem.evalGlobalXY);

faultMask = isfinite(predFault);
globalMask = isfinite(predGlobal);

rmseFault = sqrt(mean( ...
    (predFault(faultMask)-problem.evalFaultZ(faultMask)).^2));

rmseGlobal = sqrt(mean( ...
    (predGlobal(globalMask)-problem.evalGlobalZ(globalMask)).^2));

result = struct();

result.U = U;
result.obsTri = obsTri;
result.obsResidual = obsResidual;

result.RMSEFault = rmseFault;
result.RMSEGlobal = rmseGlobal;
result.DataRMSE = sqrt(mean(obsResidual.^2));

result.AssemblyTime = tAssembly;
result.SolveTime = solveTime;
result.TotalSingleSolveTime = toc(tTotal);

result.NNZ = nnz(A);
result.MatrixMB = wA.bytes/1024^2;

result.PCGFlag = flag;
result.PCGRelRes = relres;
result.PCGIters = iters;
result.Preconditioner = precondName;

result.cEff = cEff;
result.triArea = triArea;
result.gradPhi = gradPhi;
result.Dcomp = Dcomp;
end


function [U,flag,relres,iters,precondName] = robust_pcg(A,b,cfg)

n = size(A,1);

try
    opts.type = 'nofill';
    opts.diagcomp = cfg.icholDiagComp;

    L = ichol(A,opts);

    [U,flag,relres,iters] = pcg( ...
        A,b,cfg.pcgTol,cfg.pcgMaxIt,L,L');

    precondName = 'ICHOL-NOFILL';

catch

    d = full(diag(A));
    d(~isfinite(d) | d<=0) = 1;

    M = spdiags(d,0,n,n);

    [U,flag,relres,iters] = pcg( ...
        A,b,cfg.pcgTol,cfg.pcgMaxIt,M);

    precondName = 'JACOBI';
end

if flag~=0

    % Last-resort sparse direct solve for robustness.
    U = A\b;

    r = A*U-b;

    relres = norm(r)/max(norm(b),eps);
    iters = nan;
    flag = -1;
    precondName = 'BACKSLASH-FALLBACK';
end
end


% =========================================================================
% FEM ASSEMBLY
% =========================================================================
function [K,area,G,Dcomp] = assemble_fault_stiffness(P,T,Lx,Ly,cfg)

nNode = size(P,1);
nTri = size(T,1);

p1 = P(T(:,1),:);
p2 = P(T(:,2),:);
p3 = P(T(:,3),:);

area2 = ...
    (p2(:,1)-p1(:,1)).*(p3(:,2)-p1(:,2)) ...
    - (p3(:,1)-p1(:,1)).*(p2(:,2)-p1(:,2));

if any(abs(area2)<1e-14)
    error('Degenerate triangles detected.');
end

area = abs(area2)/2;

% P1 basis gradients.
g1x = (p2(:,2)-p3(:,2))./area2;
g1y = (p3(:,1)-p2(:,1))./area2;

g2x = (p3(:,2)-p1(:,2))./area2;
g2y = (p1(:,1)-p3(:,1))./area2;

g3x = (p1(:,2)-p2(:,2))./area2;
g3y = (p2(:,1)-p1(:,1))./area2;

G = struct();
G.gx = [g1x g2x g3x];
G.gy = [g1y g2y g3y];

cent = (p1+p2+p3)/3;

slope = fault_slope(cent(:,1),Lx,Ly,cfg);

tnorm = sqrt(1+slope.^2);

tx = 1./tnorm;
ty = slope./tnorm;

nx = -slope./tnorm;
ny = 1./tnorm;

gate = fault_gate(cent,Lx,Ly,cfg);

epsn = 1-(1-cfg.epsMin).*gate;

d11 = tx.^2 + epsn.*nx.^2;
d12 = tx.*ty + epsn.*nx.*ny;
d22 = ty.^2 + epsn.*ny.^2;

Dcomp = [d11 d12 d22];

I = zeros(9*nTri,1);
J = zeros(9*nTri,1);
V = zeros(9*nTri,1);

cursor = 0;

for a = 1:3
    for b = 1:3

        idx = cursor + (1:nTri).';

        I(idx) = T(:,a);
        J(idx) = T(:,b);

        gax = G.gx(:,a);
        gay = G.gy(:,a);

        gbx = G.gx(:,b);
        gby = G.gy(:,b);

        V(idx) = area .* ( ...
            d11.*gax.*gbx ...
            + d12.*(gax.*gby + gay.*gbx) ...
            + d22.*gay.*gby);

        cursor = cursor+nTri;
    end
end

K = sparse(I,J,V,nNode,nNode);
K = 0.5*(K+K');
end


function [H,tid] = interpolation_matrix(P,T,Q)

TR = triangulation(T,P);

tid = pointLocation(TR,Q);

if any(~isfinite(tid))
    bad = sum(~isfinite(tid));
    error('%d interpolation points lie outside the mesh.',bad);
end

bc = cartesianToBarycentric(TR,tid,Q);

triNodes = T(tid,:);

nQ = size(Q,1);

rows = repmat((1:nQ).',1,3);

H = sparse( ...
    rows(:), ...
    triNodes(:), ...
    bc(:), ...
    nQ,size(P,1));
end


function v = evaluate_fem(P,T,U,Q)

TR = triangulation(T,P);

tid = pointLocation(TR,Q);

v = nan(size(Q,1),1);

inside = isfinite(tid);

if ~any(inside)
    return;
end

bc = cartesianToBarycentric(TR,tid(inside),Q(inside,:));

nodes = T(tid(inside),:);

vals = U(nodes);

v(inside) = sum(vals.*bc,2);
end


% =========================================================================
% ADAPTIVE INDICATOR
% =========================================================================
function [eta,hT,centroid] = adaptive_indicator( ...
    P,T,U,obsResidual,problem,cfg)

nTri = size(T,1);

p1 = P(T(:,1),:);
p2 = P(T(:,2),:);
p3 = P(T(:,3),:);

centroid = (p1+p2+p3)/3;

area2 = ...
    (p2(:,1)-p1(:,1)).*(p3(:,2)-p1(:,2)) ...
    - (p3(:,1)-p1(:,1)).*(p2(:,2)-p1(:,2));

area = abs(area2)/2;

e12 = sqrt(sum((p1-p2).^2,2));
e23 = sqrt(sum((p2-p3).^2,2));
e31 = sqrt(sum((p3-p1).^2,2));

hT = max([e12 e23 e31],[],2);

% -------------------------------------------------------------------------
% Triangle gradients.
% -------------------------------------------------------------------------
g1x = (p2(:,2)-p3(:,2))./area2;
g1y = (p3(:,1)-p2(:,1))./area2;

g2x = (p3(:,2)-p1(:,2))./area2;
g2y = (p1(:,1)-p3(:,1))./area2;

g3x = (p1(:,2)-p2(:,2))./area2;
g3y = (p2(:,1)-p1(:,1))./area2;

u1 = U(T(:,1));
u2 = U(T(:,2));
u3 = U(T(:,3));

gradx = u1.*g1x + u2.*g2x + u3.*g3x;
grady = u1.*g1y + u2.*g2y + u3.*g3y;

% -------------------------------------------------------------------------
% Fault tensor and flux q = D grad u.
% -------------------------------------------------------------------------
slope = fault_slope(centroid(:,1),problem.Lx,problem.Ly,cfg);

tnorm = sqrt(1+slope.^2);

tx = 1./tnorm;
ty = slope./tnorm;

nx = -slope./tnorm;
ny = 1./tnorm;

geo = fault_gate(centroid,problem.Lx,problem.Ly,cfg);

epsn = 1-(1-cfg.epsMin).*geo;

d11 = tx.^2 + epsn.*nx.^2;
d12 = tx.*ty + epsn.*nx.*ny;
d22 = ty.^2 + epsn.*ny.^2;

qx = d11.*gradx + d12.*grady;
qy = d12.*gradx + d22.*grady;

% -------------------------------------------------------------------------
% Flux-jump contribution.
% -------------------------------------------------------------------------
allE = sort([ ...
    T(:,[1 2]); ...
    T(:,[2 3]); ...
    T(:,[3 1])],2);

owner = [ ...
    (1:nTri).'; ...
    (1:nTri).'; ...
    (1:nTri).'];

[E,~,ic] = unique(allE,'rows');

count = accumarray(ic,1);
sumOwner = accumarray(ic,owner);
firstOwner = accumarray(ic,owner,[],@min);

secondOwner = sumOwner-firstOwner;

etaFlux2 = zeros(nTri,1);

interior = find(count==2);

for k = 1:numel(interior)

    ie = interior(k);

    t1 = firstOwner(ie);
    t2 = secondOwner(ie);

    a = P(E(ie,1),:);
    b = P(E(ie,2),:);

    edge = b-a;
    he = norm(edge);

    if he<=0
        continue;
    end

    n = [edge(2) -edge(1)]/he;

    jump = (qx(t1)-qx(t2))*n(1) ...
        + (qy(t1)-qy(t2))*n(2);

    val = 0.5*he^2*jump^2;

    etaFlux2(t1) = etaFlux2(t1)+val;
    etaFlux2(t2) = etaFlux2(t2)+val;
end

% -------------------------------------------------------------------------
% Sparse-data residual contribution.
% -------------------------------------------------------------------------
TR = triangulation(T,P);
obsTri = pointLocation(TR,problem.obsXY);

etaData2 = zeros(nTri,1);

valid = isfinite(obsTri);

tmp = accumarray( ...
    obsTri(valid), ...
    obsResidual(valid).^2, ...
    [nTri 1],@sum,0);

etaData2 = hT.^2 .* tmp;

etaRes = sqrt(max(etaFlux2 + etaData2,0));

m = max(etaRes);

if ~(isfinite(m) && m>0)
    resNorm = zeros(size(etaRes));
else
    resNorm = etaRes/(m+eps);
end

% The residual indicator is used only for the Dörfler set.  Fault geometry
% enters independently through the geometry-set union in refine_to_budget().
eta = resNorm;

% Suppress meaningless refinement on extremely tiny triangles.
eta(hT<0.90*cfg.hFine) = 0;

% Keep finite.
eta(~isfinite(eta)) = 0;

% area is intentionally not folded into eta here; Dörfler score uses area.
end


function mark = dorfler_mark(score,theta)

score = score(:);
score(~isfinite(score) | score<0) = 0;

total = sum(score);

if total<=0
    mark = [];
    return;
end

[sv,ord] = sort(score,'descend');

cs = cumsum(sv);

k = find(cs>=theta*total,1,'first');

if isempty(k)
    k = numel(ord);
end

mark = ord(1:k);
end


function Q = filter_new_points(Q,P,minDist)

if isempty(Q)
    return;
end

% Remove exact/near duplicates among proposed points.
Q = unique(round(Q,10),'rows','stable');

keep = true(size(Q,1),1);

for i = 1:size(Q,1)

    d2 = (P(:,1)-Q(i,1)).^2 + (P(:,2)-Q(i,2)).^2;

    if min(d2)<minDist^2
        keep(i) = false;
    end
end

Q = Q(keep,:);
end


% =========================================================================
% MESH
% =========================================================================
function [P,T] = structured_tri_mesh(Lx,Ly,h)

nx = max(2,ceil(Lx/h)+1);
ny = max(2,ceil(Ly/h)+1);

x = linspace(0,Lx,nx);
y = linspace(0,Ly,ny);

[X,Y] = meshgrid(x,y);

P = [X(:) Y(:)];

T = zeros(2*(nx-1)*(ny-1),3);

c = 0;

for j = 1:(ny-1)
    for i = 1:(nx-1)

        n1 = sub2ind([ny nx],j,i);
        n2 = sub2ind([ny nx],j,i+1);
        n3 = sub2ind([ny nx],j+1,i);
        n4 = sub2ind([ny nx],j+1,i+1);

        c = c+1;
        T(c,:) = [n1 n2 n4];

        c = c+1;
        T(c,:) = [n1 n4 n3];
    end
end
end


% =========================================================================
% CURVE / MATCHED ACCURACY TABLES
% =========================================================================
function row = make_curve_row( ...
    scale,seed,method,level,h,budget,P,T,result)

Scale = scale;
Seed = seed;
Method = {method};
Level = level;

RequestedH = h;
RequestedBudget = budget;

Nodes = size(P,1);
Elements = size(T,1);

RMSEFault = result.RMSEFault;
RMSEGlobal = result.RMSEGlobal;
DataRMSE = result.DataRMSE;

AssemblyTime = result.AssemblyTime;
SolveTime = result.SolveTime;
TotalSingleSolveTime = result.TotalSingleSolveTime;

NNZ = result.NNZ;
MatrixMB = result.MatrixMB;

PCGFlag = result.PCGFlag;
PCGRelRes = result.PCGRelRes;
PCGIters = result.PCGIters;

EffectiveC0 = result.cEff;

row = table( ...
    Scale,Seed,Method,Level,RequestedH,RequestedBudget, ...
    Nodes,Elements,RMSEFault,RMSEGlobal,DataRMSE, ...
    AssemblyTime,SolveTime,TotalSingleSolveTime, ...
    NNZ,MatrixMB,PCGFlag,PCGRelRes,PCGIters,EffectiveC0);
end


function C = strict_refine_uniform_threshold( ...
    C,problem,target,cfg,scale,seed)

C = sort_curve_by_nodes_conservative(C);

% If even the coarsest mesh passes, expand to coarser h until a FAIL is
% observed or the configured maximum h is reached.
roundID = 0;

while true

    [failRow,passRow,hasBracket] = threshold_bracket(C,target);

    if hasBracket
        break;
    end

    if isempty(passRow)
        % This should not occur because target is defined from the best
        % initial uniform RMSE, but keep an explicit failure path.
        warning('Uniform curve has no PASS row at the common target.');
        return;
    end

    maxH = max(C.RequestedH(isfinite(C.RequestedH)));

    if maxH>=cfg.uniformHMaxStrict
        return;
    end

    hNew = min(cfg.uniformHMaxStrict,1.25*maxH);

    roundID = roundID+1;

    row = evaluate_uniform_candidate( ...
        problem,cfg,scale,seed,hNew,9000+roundID);

    C = append_candidate_row(C,row,'uniform');
    C = sort_curve_by_nodes_conservative(C);
end

for ir = 1:cfg.uniformBracketMaxRounds

    [failRow,passRow,hasBracket] = threshold_bracket(C,target);

    if ~hasBracket
        break;
    end

    relWidth = ...
        (passRow.Nodes-failRow.Nodes)/max(passRow.Nodes,1);

    fprintf('      uniform strict round %d | fail/pass=%d/%d | width=%.3f %%\n', ...
        ir,failRow.Nodes,passRow.Nodes,100*relWidth);

    if relWidth<=cfg.bracketRelTol
        break;
    end

    hFail = failRow.RequestedH;
    hPass = passRow.RequestedH;

    if ~(isfinite(hFail) && isfinite(hPass) && hFail>hPass)
        fprintf('      uniform local h bracket is not monotone; stop local refinement.\n');
        break;
    end

    hTry = linspace(hPass,hFail,cfg.uniformBracketInterior+2);
    hTry = hTry(2:end-1);

    nAdded = 0;

    for j = 1:numel(hTry)

        if any(abs(C.RequestedH-hTry(j))<1e-10)
            continue;
        end

        row = evaluate_uniform_candidate( ...
            problem,cfg,scale,seed,hTry(j), ...
            10000+100*ir+j);

        oldN = height(C);

        C = append_candidate_row(C,row,'uniform');

        if height(C)>oldN
            nAdded = nAdded+1;
        end
    end

    C = sort_curve_by_nodes_conservative(C);

    if nAdded==0
        break;
    end
end
end


function C = strict_refine_afem_threshold( ...
    C,problem,target,cfg,scale,seed)

C = sort_curve_by_nodes_conservative(C);

[Pfine,~] = structured_tri_mesh(problem.Lx,problem.Ly,cfg.hFine);
nFine = size(Pfine,1);

% If the broad AFEM curve has not reached the strict uniform-anchored
% target, extend to the finest allowed budget.
[~,passRow,~] = threshold_bracket(C,target);

if isempty(passRow)

    maxBudget = max(C.RequestedBudget(isfinite(C.RequestedBudget)));

    if maxBudget<nFine

        row = evaluate_afem_budget_from_scratch( ...
            problem,cfg,scale,seed,nFine,19001);

        C = append_candidate_row(C,row,'afem');
        C = sort_curve_by_nodes_conservative(C);
    end
end

for ir = 1:cfg.afemBracketMaxRounds

    [failRow,passRow,hasBracket] = threshold_bracket(C,target);

    if ~hasBracket

        if isempty(passRow)
            fprintf('      AFEM strict bracket unavailable: no PASS row.\n');
        else
            fprintf('      AFEM strict bracket unavailable: coarsest tested mesh already passes.\n');
        end
        break;
    end

    nodeGap = passRow.Nodes-failRow.Nodes;
    relWidth = nodeGap/max(passRow.Nodes,1);

    fprintf('      AFEM strict round %d | fail/pass=%d/%d | width=%.3f %%\n', ...
        ir,failRow.Nodes,passRow.Nodes,100*relWidth);

    % FINAL PAPER RULE:
    % once the bracket is <= 12 nodes, exhaustively test every integer
    % budget in the open interval and locate the first observed PASS.
    if nodeGap<=cfg.afemBracketAbsNodes

        fprintf('      AFEM integer sweep in [%d,%d] ...\n', ...
            failRow.Nodes,passRow.Nodes);

        for budget = (failRow.Nodes+1):(passRow.Nodes-1)

            existingBudgets = C.RequestedBudget(isfinite(C.RequestedBudget));

            if any(abs(existingBudgets-budget)<0.5)
                continue;
            end

            row = evaluate_afem_budget_from_scratch( ...
                problem,cfg,scale,seed,budget, ...
                30000+budget);

            C = append_candidate_row(C,row,'afem');
        end

        C = sort_curve_by_nodes_conservative(C);

        % The integer sweep is the strongest discrete localization possible.
        break;
    end

    if relWidth<=cfg.bracketRelTol
        break;
    end

    bFail = failRow.Nodes;
    bPass = passRow.Nodes;

    bTry = linspace(bFail,bPass,cfg.afemBracketInterior+2);
    bTry = unique(round(bTry(2:end-1)));

    nAdded = 0;

    for j = 1:numel(bTry)

        budget = bTry(j);

        if budget<=bFail || budget>=bPass
            continue;
        end

        existingBudgets = C.RequestedBudget(isfinite(C.RequestedBudget));

        if any(abs(existingBudgets-budget)<0.5)
            continue;
        end

        row = evaluate_afem_budget_from_scratch( ...
            problem,cfg,scale,seed,budget, ...
            20000+100*ir+j);

        oldN = height(C);
        C = append_candidate_row(C,row,'afem');

        if height(C)>oldN
            nAdded = nAdded+1;
        end
    end

    C = sort_curve_by_nodes_conservative(C);

    if nAdded==0
        break;
    end
end
end


function row = evaluate_uniform_candidate( ...
    problem,cfg,scale,seed,h,level)

[P,T] = structured_tri_mesh(problem.Lx,problem.Ly,h);

fprintf('        strict uniform h=%8.3f | nodes=%7d ... ', ...
    h,size(P,1));

result = solve_and_evaluate(P,T,problem,cfg);

fprintf('fault=%.5f\n',result.RMSEFault);

row = make_curve_row( ...
    scale,seed,'UNIFORM-FAULT-FEM',level,h,nan,P,T,result);
end


function row = evaluate_afem_budget_from_scratch( ...
    problem,cfg,scale,seed,budget,level)

[P,T] = structured_tri_mesh(problem.Lx,problem.Ly,cfg.hCoarse);

current = solve_and_evaluate(P,T,problem,cfg);

if size(P,1)<budget

    [P,T,current] = refine_to_budget( ...
        P,T,current,problem,budget,cfg);
end

current = solve_and_evaluate(P,T,problem,cfg);

fprintf('        strict AFEM budget=%7d | actual=%7d ... fault=%.5f\n', ...
    budget,size(P,1),current.RMSEFault);

row = make_curve_row( ...
    scale,seed,'FAULT-AFEM',level,nan,budget,P,T,current);
end


function C = append_candidate_row(C,row,kind)

if isempty(C)
    C = row;
    return;
end

switch lower(kind)

    case 'uniform'

        % Requested h values that produce the same structured node count
        % correspond to the same nx-by-ny mesh.  Avoid duplicate solves in
        % the final threshold table.
        duplicate = any(C.Nodes==row.Nodes);

    case 'afem'

        % Different requested budgets can occasionally terminate at the
        % same actual node count.  Keep both during raw evaluation, then
        % collapse conservatively in sort_curve_by_nodes_conservative().
        duplicate = any( ...
            isfinite(C.RequestedBudget) ...
            & isfinite(row.RequestedBudget) ...
            & abs(C.RequestedBudget-row.RequestedBudget)<0.5);

    otherwise
        duplicate = false;
end

if ~duplicate
    C = [C; row];
end
end


function C = sort_curve_by_nodes_conservative(C)

if isempty(C)
    return;
end

[~,ord] = sort(C.Nodes,'ascend');
C = C(ord,:);

u = unique(C.Nodes,'stable');

keep = false(height(C),1);

for i = 1:numel(u)

    idx = find(C.Nodes==u(i));

    if numel(idx)==1
        keep(idx) = true;
    else
        % Conservative duplicate handling:
        % at equal actual DOF retain the largest fault RMSE.
        [~,j] = max(C.RMSEFault(idx));
        keep(idx(j)) = true;
    end
end

C = C(keep,:);

[~,ord] = sort(C.Nodes,'ascend');
C = C(ord,:);
end


function [failRow,passRow,hasBracket] = threshold_bracket(C,target)

failRow = table();
passRow = table();
hasBracket = false;

if isempty(C)
    return;
end

C = sort_curve_by_nodes_conservative(C);

ip = find(C.RMSEFault<=target,1,'first');

if isempty(ip)
    return;
end

passRow = C(ip,:);

if ip==1
    return;
end

lower = 1:(ip-1);

jf = find(C.RMSEFault(lower)>target,1,'last');

if isempty(jf)
    return;
end

failRow = C(lower(jf),:);

hasBracket = true;
end


function nStar = interpolated_crossing_nodes(failRow,passRow,target)

nStar = nan;

if isempty(failRow) || isempty(passRow)
    return;
end

n0 = failRow.Nodes;
n1 = passRow.Nodes;

e0 = failRow.RMSEFault;
e1 = passRow.RMSEFault;

if ~(e0>target && e1<=target && n1>n0)
    return;
end

den = e0-e1;

if abs(den)<eps
    nStar = n1;
    return;
end

a = (e0-target)/den;
a = min(max(a,0),1);

nStar = n0 + a*(n1-n0);
end


function tf = uniform_discrete_grid_resolved(failRow,passRow,problem)

tf = false;

if isempty(failRow) || isempty(passRow)
    return;
end

% For square domains with the structured mesh generator used here,
% node counts are n_x*n_y.  When Lx=Ly and h is common in both directions,
% adjacent attainable grids near the crossing are typically n^2 and (n+1)^2.
%
% We verify this using integer square roots rather than assuming it.
if abs(problem.Lx-problem.Ly) > 1e-9*max(problem.Lx,problem.Ly)
    return;
end

nf = round(sqrt(failRow.Nodes));
np = round(sqrt(passRow.Nodes));

isSquareFail = (nf^2 == failRow.Nodes);
isSquarePass = (np^2 == passRow.Nodes);

tf = isSquareFail && isSquarePass && (np==nf+1);
end


function M = make_strict_match_row( ...
    U,A,target,theorySaving,scale,seed,problem,cfg)

U = sort_curve_by_nodes_conservative(U);
A = sort_curve_by_nodes_conservative(A);

[uFail,uPass,uBracket] = threshold_bracket(U,target);
[aFail,aPass,aBracket] = threshold_bracket(A,target);

Scale = scale;
Seed = seed;
TargetFaultRMSE = target;

TheoryNodeSavingPct = theorySaving;

if isempty(uPass) || isempty(aPass)

    MatchStatus = {'UNAVAILABLE'};

    UniformFailNodes = nan;
    UniformPassNodes = nan;
    AFEMFailNodes = nan;
    AFEMPassNodes = nan;

    UniformBracketWidthPct = nan;
    AFEMBracketWidthPct = nan;

    UniformInterpolatedNodes = nan;
    AFEMInterpolatedNodes = nan;

    UniformNodes = nan;
    AFEMNodes = nan;

    UniformFaultRMSE = nan;
    AFEMFaultRMSE = nan;

    UniformGlobalRMSE = nan;
    AFEMGlobalRMSE = nan;

    AccuracyMismatchPct = nan;
    GlobalPenaltyPct = nan;

    NodeSavingPct = nan;
    InterpolatedNodeSavingPct = nan;

    UniformNNZ = nan;
    AFEMNNZ = nan;
    NNZSavingPct = nan;

    UniformMatrixMB = nan;
    AFEMMatrixMB = nan;
    MatrixSavingPct = nan;

    UniformSolveTime = nan;
    AFEMSolveTime = nan;
    SolveTimeSavingPct = nan;

    ConservativeMinusTheoryPctPoints = nan;
    InterpolatedMinusTheoryPctPoints = nan;

else

    UniformNodes = uPass.Nodes;
    AFEMNodes = aPass.Nodes;

    UniformFaultRMSE = uPass.RMSEFault;
    AFEMFaultRMSE = aPass.RMSEFault;

    UniformGlobalRMSE = uPass.RMSEGlobal;
    AFEMGlobalRMSE = aPass.RMSEGlobal;

    UniformNNZ = uPass.NNZ;
    AFEMNNZ = aPass.NNZ;

    UniformMatrixMB = uPass.MatrixMB;
    AFEMMatrixMB = aPass.MatrixMB;

    UniformSolveTime = uPass.SolveTime;
    AFEMSolveTime = aPass.SolveTime;

    NodeSavingPct = 100*(1-AFEMNodes/UniformNodes);
    NNZSavingPct = 100*(1-AFEMNNZ/UniformNNZ);
    MatrixSavingPct = 100*(1-AFEMMatrixMB/UniformMatrixMB);
    SolveTimeSavingPct = 100*(1-AFEMSolveTime/UniformSolveTime);

    AccuracyMismatchPct = ...
        100*abs(UniformFaultRMSE-AFEMFaultRMSE)/target;

    GlobalPenaltyPct = ...
        100*(AFEMGlobalRMSE/UniformGlobalRMSE - 1);

    if uBracket

        UniformFailNodes = uFail.Nodes;
        UniformPassNodes = uPass.Nodes;

        UniformBracketWidthPct = ...
            100*(uPass.Nodes-uFail.Nodes)/uPass.Nodes;

        UniformInterpolatedNodes = ...
            interpolated_crossing_nodes(uFail,uPass,target);

    else

        UniformFailNodes = nan;
        UniformPassNodes = uPass.Nodes;

        UniformBracketWidthPct = nan;
        UniformInterpolatedNodes = uPass.Nodes;
    end

    if aBracket

        AFEMFailNodes = aFail.Nodes;
        AFEMPassNodes = aPass.Nodes;

        AFEMBracketWidthPct = ...
            100*(aPass.Nodes-aFail.Nodes)/aPass.Nodes;

        AFEMInterpolatedNodes = ...
            interpolated_crossing_nodes(aFail,aPass,target);

    else

        AFEMFailNodes = nan;
        AFEMPassNodes = aPass.Nodes;

        AFEMBracketWidthPct = nan;
        AFEMInterpolatedNodes = aPass.Nodes;
    end

    if isfinite(UniformInterpolatedNodes) ...
            && isfinite(AFEMInterpolatedNodes)

        InterpolatedNodeSavingPct = ...
            100*(1-AFEMInterpolatedNodes/UniformInterpolatedNodes);

    else
        InterpolatedNodeSavingPct = nan;
    end

    ConservativeMinusTheoryPctPoints = ...
        NodeSavingPct-TheoryNodeSavingPct;

    InterpolatedMinusTheoryPctPoints = ...
        InterpolatedNodeSavingPct-TheoryNodeSavingPct;

    % -------------------------------------------------------------
    % Resolution status.
    % -------------------------------------------------------------
    uniformDiscreteResolved = ...
        uBracket && uniform_discrete_grid_resolved(uFail,uPass,problem);

    adaptiveIntegerResolved = ...
        aBracket && (aPass.Nodes-aFail.Nodes)<=1;

    adaptiveTightResolved = ...
        aBracket && ( ...
        AFEMBracketWidthPct<=100*cfg.bracketRelTol + 1e-12 ...
        || (aPass.Nodes-aFail.Nodes)<=cfg.afemBracketAbsNodes);

    if uniformDiscreteResolved && adaptiveIntegerResolved
        MatchStatus = {'PAPER-RESOLVED'};
    elseif uniformDiscreteResolved && adaptiveTightResolved
        MatchStatus = {'DISCRETE-GRID-RESOLVED'};
    elseif uBracket && aBracket
        MatchStatus = {'LOOSE-BRACKET'};
    else
        MatchStatus = {'ONE-SIDED'};
    end
end

M = table( ...
    Scale,Seed,MatchStatus,TargetFaultRMSE, ...
    UniformFailNodes,UniformPassNodes,UniformBracketWidthPct, ...
    AFEMFailNodes,AFEMPassNodes,AFEMBracketWidthPct, ...
    UniformInterpolatedNodes,AFEMInterpolatedNodes, ...
    UniformNodes,AFEMNodes, ...
    UniformFaultRMSE,AFEMFaultRMSE,AccuracyMismatchPct, ...
    UniformGlobalRMSE,AFEMGlobalRMSE,GlobalPenaltyPct, ...
    NodeSavingPct,InterpolatedNodeSavingPct, ...
    UniformNNZ,AFEMNNZ,NNZSavingPct, ...
    UniformMatrixMB,AFEMMatrixMB,MatrixSavingPct, ...
    UniformSolveTime,AFEMSolveTime,SolveTimeSavingPct, ...
    TheoryNodeSavingPct, ...
    ConservativeMinusTheoryPctPoints, ...
    InterpolatedMinusTheoryPctPoints);
end


function A = aggregate_matched_rows(M,cfg) %#ok<INUSD>

scales = unique(M.Scale);

A = table();

for i = 1:numel(scales)

    s = scales(i);

    X = M(M.Scale==s,:);

    valid = isfinite(X.NodeSavingPct);

    Scale = s;
    NValid = sum(valid);

    if any(valid)
        PaperResolvedRate = mean( ...
            strcmp(X.MatchStatus(valid),'PAPER-RESOLVED') ...
            | strcmp(X.MatchStatus(valid),'DISCRETE-GRID-RESOLVED'));
    else
        PaperResolvedRate = nan;
    end

    UniformNodesMedian = median_finite(X.UniformNodes(valid));
    AFEMNodesMedian = median_finite(X.AFEMNodes(valid));

    UniformInterpolatedNodesMedian = ...
        median_finite(X.UniformInterpolatedNodes(valid));

    AFEMInterpolatedNodesMedian = ...
        median_finite(X.AFEMInterpolatedNodes(valid));

    NodeSavingMeanPct = mean_finite(X.NodeSavingPct(valid));
    NodeSavingMedianPct = median_finite(X.NodeSavingPct(valid));
    NodeSavingStdPct = std_finite(X.NodeSavingPct(valid));

    InterpolatedNodeSavingMeanPct = ...
        mean_finite(X.InterpolatedNodeSavingPct(valid));

    InterpolatedNodeSavingMedianPct = ...
        median_finite(X.InterpolatedNodeSavingPct(valid));

    UniformBracketWidthMeanPct = ...
        mean_finite(X.UniformBracketWidthPct(valid));

    AFEMBracketWidthMeanPct = ...
        mean_finite(X.AFEMBracketWidthPct(valid));

    AccuracyMismatchMeanPct = ...
        mean_finite(X.AccuracyMismatchPct(valid));

    GlobalPenaltyMeanPct = ...
        mean_finite(X.GlobalPenaltyPct(valid));

    GlobalPenaltyMedianPct = ...
        median_finite(X.GlobalPenaltyPct(valid));

    NNZSavingMeanPct = mean_finite(X.NNZSavingPct(valid));
    MatrixSavingMeanPct = mean_finite(X.MatrixSavingPct(valid));
    SolveTimeSavingMeanPct = mean_finite(X.SolveTimeSavingPct(valid));

    UniformFaultRMSEMean = mean_finite(X.UniformFaultRMSE(valid));
    AFEMFaultRMSEMean = mean_finite(X.AFEMFaultRMSE(valid));

    TheoryNodeSavingMeanPct = ...
        mean_finite(X.TheoryNodeSavingPct(valid));

    ConservativeTheoryGapMeanPctPoints = ...
        mean_finite(X.ConservativeMinusTheoryPctPoints(valid));

    InterpolatedTheoryGapMeanPctPoints = ...
        mean_finite(X.InterpolatedMinusTheoryPctPoints(valid));

    row = table( ...
        Scale,NValid,PaperResolvedRate, ...
        UniformNodesMedian,AFEMNodesMedian, ...
        UniformInterpolatedNodesMedian,AFEMInterpolatedNodesMedian, ...
        NodeSavingMeanPct,NodeSavingMedianPct,NodeSavingStdPct, ...
        InterpolatedNodeSavingMeanPct,InterpolatedNodeSavingMedianPct, ...
        UniformBracketWidthMeanPct,AFEMBracketWidthMeanPct, ...
        AccuracyMismatchMeanPct, ...
        GlobalPenaltyMeanPct,GlobalPenaltyMedianPct, ...
        NNZSavingMeanPct,MatrixSavingMeanPct,SolveTimeSavingMeanPct, ...
        UniformFaultRMSEMean,AFEMFaultRMSEMean, ...
        TheoryNodeSavingMeanPct, ...
        ConservativeTheoryGapMeanPctPoints, ...
        InterpolatedTheoryGapMeanPctPoints);

    A = [A; row]; %#ok<AGROW>
end
end


function T = build_paper_summary_table(M,A)

% One concise table for manuscript drafting.
Scale = A.Scale;
NValid = A.NValid;
PaperResolvedRate = A.PaperResolvedRate;

UniformNodesMedian = A.UniformNodesMedian;
AFEMNodesMedian = A.AFEMNodesMedian;

NodeSavingMeanPct = A.NodeSavingMeanPct;
NodeSavingStdPct = A.NodeSavingStdPct;

NNZSavingMeanPct = A.NNZSavingMeanPct;
MatrixSavingMeanPct = A.MatrixSavingMeanPct;

GlobalPenaltyMeanPct = A.GlobalPenaltyMeanPct;
GlobalPenaltyMedianPct = A.GlobalPenaltyMedianPct;

TheoryNodeSavingMeanPct = A.TheoryNodeSavingMeanPct;

T = table( ...
    Scale,NValid,PaperResolvedRate, ...
    UniformNodesMedian,AFEMNodesMedian, ...
    NodeSavingMeanPct,NodeSavingStdPct, ...
    NNZSavingMeanPct,MatrixSavingMeanPct, ...
    GlobalPenaltyMeanPct,GlobalPenaltyMedianPct, ...
    TheoryNodeSavingMeanPct);
end


% =========================================================================
% THEORY
% =========================================================================
function T = make_theory_row(scale,Lx,Ly,cfg)

x = linspace(0,Lx,5000).';

s = fault_slope(x,Lx,Ly,cfg);

dx = x(2)-x(1);

faultLength = sum(sqrt(1+s.^2))*dx;

area = Lx*Ly;

bandAreaApprox = min(area,2*cfg.faultBandWidth*faultLength);

rho = bandAreaApprox/area;

r = cfg.hCoarse/cfg.hFine;

ratio2D = rho + (1-rho)/r^2;
saving2D = 100*(1-ratio2D);

Scale = scale;
LxM = Lx;
LyM = Ly;
FaultLengthM = faultLength;
FaultBandAreaFraction = rho;
CoarseFineRatio = r;
IdealizedNodeRatio2D = ratio2D;
IdealizedNodeSavingPct2D = saving2D;

T = table( ...
    Scale,LxM,LyM,FaultLengthM,FaultBandAreaFraction, ...
    CoarseFineRatio,IdealizedNodeRatio2D,IdealizedNodeSavingPct2D);
end


% =========================================================================
% FIGURES
% =========================================================================
function plot_nodes_vs_scale(A,T,outDir,cfg)

valid = isfinite(A.UniformNodesMedian) & isfinite(A.AFEMNodesMedian);

f = figure('Color','w','Units','pixels','Position',[100 100 920 620]);
ax = axes(f); hold(ax,'on');

loglog(ax,A.Scale(valid),A.UniformNodesMedian(valid),'-o', ...
    'LineWidth',1.8,'MarkerSize',7);

loglog(ax,A.Scale(valid),A.AFEMNodesMedian(valid),'-s', ...
    'LineWidth',1.8,'MarkerSize',7);

xlabel(ax,'Domain linear scale');
ylabel(ax,'Nodes required at matched fault accuracy');
title(ax,'Matched-accuracy DOF scaling');
legend(ax,{'Uniform fault-aware FEM','Fault-AFEM'}, ...
    'Location','northwest');
grid(ax,'on');
box(ax,'on');

save_scaling_figure(f,fullfile(outDir,'FIG_S01_nodes_vs_scale'),cfg);
end


function plot_node_saving_vs_scale(A,T,outDir,cfg)

f = figure('Color','w','Units','pixels','Position',[100 100 960 620]);
ax = axes(f); hold(ax,'on');

h1 = errorbar(ax,A.Scale,A.NodeSavingMeanPct,A.NodeSavingStdPct, ...
    '-o','LineWidth',1.8,'MarkerSize',7);

h2 = plot(ax,A.Scale,A.InterpolatedNodeSavingMeanPct, ...
    '--s','LineWidth',1.6,'MarkerSize',7);

[~,ord] = sort(T.Scale);

h3 = plot(ax,T.Scale(ord),T.IdealizedNodeSavingPct2D(ord), ...
    ':^','LineWidth',1.7,'MarkerSize',7);

xlabel(ax,'Domain linear scale');
ylabel(ax,'Node saving at matched fault accuracy (%)');
title(ax,'Strict matched-accuracy node saving versus problem scale');

legend(ax,[h1 h2 h3], ...
    {'Discrete PASS-node saving', ...
     'Interpolated threshold-crossing saving', ...
     'Idealized two-scale prediction'}, ...
     'Location','southeast');

grid(ax,'on');
box(ax,'on');

save_scaling_figure(f,fullfile(outDir,'FIG_S02_node_saving_vs_scale'),cfg);
end


function plot_accuracy_dof_curves(C,outDir,cfg)

scales = unique(C.Scale);

f = figure('Color','w','Units','pixels','Position',[50 50 1100 760]);

tl = tiledlayout(f,ceil(numel(scales)/2),2, ...
    'Padding','compact','TileSpacing','compact');

for i = 1:numel(scales)

    s = scales(i);

    X = C(C.Scale==s,:);

    % Aggregate seeds at each actual node count is not straightforward.
    % For quick interpretability, plot every run with thin lines.
    nexttile(tl); hold on;

    seeds = unique(X.Seed);

    h1 = [];
    h2 = [];

    for j = 1:numel(seeds)

        Y = X(X.Seed==seeds(j),:);

        U = Y(strcmp(Y.Method,'UNIFORM-FAULT-FEM'),:);
        A = Y(strcmp(Y.Method,'FAULT-AFEM'),:);

        [~,ou] = sort(U.Nodes);
        [~,oa] = sort(A.Nodes);

        hu = semilogx(U.Nodes(ou),U.RMSEFault(ou),'-o', ...
            'LineWidth',1.0,'MarkerSize',4);

        ha = semilogx(A.Nodes(oa),A.RMSEFault(oa),'-s', ...
            'LineWidth',1.0,'MarkerSize',4);

        if isempty(h1), h1=hu; end
        if isempty(h2), h2=ha; end
    end

    xlabel('Nodes');
    ylabel('Fault RMSE (m)');
    title(sprintf('Scale %g',s));
    grid on;
    box on;

    if i==1 && ~isempty(h1) && ~isempty(h2)
        legend([h1 h2], ...
            {'Uniform fault-aware FEM','Fault-AFEM'}, ...
            'Location','best');
    end
end

save_scaling_figure(f,fullfile(outDir,'FIG_S03_accuracy_dof_curves'),cfg);
end


function plot_cost_ratios(A,outDir,cfg)

f = figure('Color','w','Units','pixels','Position',[100 100 980 620]);

tl = tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');

nexttile(tl,1);

plot(A.Scale,100-A.NNZSavingMeanPct,'-o','LineWidth',1.8,'MarkerSize',7);
hold on;
plot(A.Scale,100-A.MatrixSavingMeanPct,'-s','LineWidth',1.8,'MarkerSize',7);

xlabel('Domain linear scale');
ylabel('AFEM / uniform cost proxy (%)');
title('Sparse-system storage proxies');
legend({'nnz ratio','matrix storage ratio'},'Location','best');
grid on; box on;

nexttile(tl,2);

plot(A.Scale,100-A.SolveTimeSavingMeanPct,'-o', ...
    'LineWidth',1.8,'MarkerSize',7);

xlabel('Domain linear scale');
ylabel('AFEM / uniform single-solve time (%)');
title('Single-solve timing ratio');
grid on; box on;

save_scaling_figure(f,fullfile(outDir,'FIG_S04_cost_ratios'),cfg);
end


function plot_bracket_resolution(A,outDir,cfg)

f = figure('Color','w','Units','pixels','Position',[100 100 940 600]);
ax = axes(f); hold(ax,'on');

plot(ax,A.Scale,A.UniformBracketWidthMeanPct,'-o', ...
    'LineWidth',1.7,'MarkerSize',7);

plot(ax,A.Scale,A.AFEMBracketWidthMeanPct,'-s', ...
    'LineWidth',1.7,'MarkerSize',7);

yline(ax,100*cfg.bracketRelTol,'--','LineWidth',1.2);

xlabel(ax,'Domain linear scale');
ylabel(ax,'Mean FAIL/PASS bracket width (%)');
title(ax,'Strict threshold-bracket resolution');

legend(ax, ...
    {'Uniform bracket','AFEM bracket','Relative-width target'}, ...
    'Location','northeast');

grid(ax,'on');
box(ax,'on');

save_scaling_figure(f,fullfile(outDir,'FIG_S05_bracket_resolution'),cfg);
end


function save_scaling_figure(f,base,cfg)

pngFile = [base '.png'];
pdfFile = [base '.pdf'];

if exist('exportgraphics','file')==2

    exportgraphics(f,pngFile,'Resolution',cfg.figureDPI);

    try
        exportgraphics(f,pdfFile,'ContentType','vector');
    catch
        print(f,pdfFile,'-dpdf','-painters','-bestfit');
    end

else

    print(f,pngFile,'-dpng',sprintf('-r%d',cfg.figureDPI));
    print(f,pdfFile,'-dpdf','-painters','-bestfit');
end

close(f);
end


% =========================================================================
% README
% =========================================================================
function write_scaling_readme(fileName,cfg,A)

fid = fopen(fileName,'w');
assert(fid>=0);
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>

fprintf(fid,'FAULT_AFEM_SCALING_PARAMETER_REDUCED_V2\n');
fprintf(fid,'=======================================\n\n');

fprintf(fid,'Profile: %s\n',cfg.profile);
fprintf(fid,'Scales : %s\n',mat2str(cfg.scales));
fprintf(fid,'Seeds  : %s\n\n',mat2str(cfg.seeds));

fprintf(fid,'Parameter-reduced V2 design:\n');
fprintf(fid,'  1. sigma_Gamma is derived from base-scale sparse-control spacing;\n');
fprintf(fid,'  2. lambda_dimless and epsilon_min are jointly selected by sparse spatial CV;\n');
fprintf(fid,'  3. AFEM uses residual Dörfler marking UNION a one-sigma fault-geometry set;\n');
fprintf(fid,'  4. no residual/geology mixing weights are used;\n');
fprintf(fid,'  5. calibrated parameters are frozen across all scale/seed runs;\n');
fprintf(fid,'  6. matched-accuracy comparison and two-scale theory are unchanged.\n\n');
fprintf(fid,'Selected calibration:\n');
fprintf(fid,'  sigma_Gamma    = %.8g m\n',cfg.faultTensorSigma);
fprintf(fid,'  lambda_dimless = %.8g\n',cfg.lambdaDimless);
fprintf(fid,'  epsilon_min    = %.8g\n\n',cfg.epsMin);

fprintf(fid,'Common target rule:\n');
fprintf(fid,'  target = %.3f * best uniform fault RMSE.\n\n', ...
    cfg.accuracySlack);

fprintf(fid,'Bracket resolution target:\n');
fprintf(fid,'  relative width <= %.2f%%.\n\n',100*cfg.bracketRelTol);

fprintf(fid,'Primary paper evidence should prioritize:\n');
fprintf(fid,'  discrete PASS nodes, nnz, matrix storage, and GlobalPenaltyPct.\n');
fprintf(fid,'  Runtime is secondary because MATLAB/JIT/cache effects can be substantial.\n');
fprintf(fid,'  GlobalPenaltyPct = 100*(AFEM global RMSE / uniform global RMSE - 1).\n\n');

fprintf(fid,'Important interpretation:\n');
fprintf(fid,'  MatrixMB is assembled sparse-matrix storage, not process peak RAM.\n');
fprintf(fid,'  The AFEM indicator is an engineering heuristic, not a theorem-level estimator.\n');
fprintf(fid,'  Adaptive node sets are nested, while Delaunay connectivity is retriangulated.\n\n');

fprintf(fid,'Aggregate summary:\n');
fprintf(fid,'%s\n',evalc('disp(A)'));
end


% =========================================================================
% SMALL UTILITIES
% =========================================================================
function m = mean_finite(x)

x = x(isfinite(x));

if isempty(x)
    m = nan;
else
    m = mean(x);
end
end


function m = median_finite(x)

x = x(isfinite(x));

if isempty(x)
    m = nan;
else
    m = median(x);
end
end


function s = std_finite(x)

x = x(isfinite(x));

if numel(x)<=1
    s = 0;
else
    s = std(x);
end
end
