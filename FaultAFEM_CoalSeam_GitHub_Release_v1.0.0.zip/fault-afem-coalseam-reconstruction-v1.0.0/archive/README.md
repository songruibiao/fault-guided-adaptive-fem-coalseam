# Experimental / non-paper branch

`experimental_parameter_reduced_v2/` is retained for provenance because it appeared in the supplied archive and represents a meaningful later experiment. It changes the parameter-selection/refinement design relative to the current manuscript (including set-union marking rather than the manuscript's 0.65/0.35 hybrid indicator). It must therefore **not** be mixed with the paper-equivalent results in `results/`.
