function out = RUN_ALL_AVAILABLE(dataDir)
% RUN_ALL_AVAILABLE  Run all computations that can be run from this release.
% 1) Environment/data check
% 2) Redraw reported 2-D scaling summary (frozen numbers; not recomputation)
% 3) Run self-contained 3-D synthetic benchmark
% 4) Run C11 only if the required raw data files are present
root = fileparts(mfilename('fullpath'));
if nargin < 1 || isempty(dataDir), dataDir=fullfile(root,'data','C11'); end
out = struct;
out.check = RUN_CHECK(dataDir);
out.scalingFigureDir = RUN_REPORTED_SCALING_FIGURE();
out.synthetic3DDir = RUN_3D_SYNTHETIC();
if out.check.dataOK
    out.c11 = RUN_C11_REALDATA(dataDir);
else
    out.c11 = [];
    warning('Skipping C11 real-data computation because required raw .dat files are absent.');
end
end
